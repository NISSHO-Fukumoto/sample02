import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';

const db = drizzle(process.env.DATABASE_URL);

const result = await db.execute(`
  SELECT 
    MAX(target_production_count) AS today_max_target
  FROM machine_logs
  WHERE 
    DATE(CONVERT_TZ(created_at, '+00:00', '+09:00')) = CURDATE()
`);

console.log('Result:', JSON.stringify(result, null, 2));
