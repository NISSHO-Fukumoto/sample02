import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { type DashboardLayout, type Machine } from "@/lib/types";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { GripVertical, Check } from "lucide-react";

interface DashboardSettingsModalProps {
  open: boolean;
  onClose: () => void;
  layout: DashboardLayout;
  machines: Machine[];
  terminalId: string;
  onSave: (layout: DashboardLayout) => void;
}

export default function DashboardSettingsModal({
  open,
  onClose,
  layout,
  machines,
  terminalId,
  onSave,
}: DashboardSettingsModalProps) {
  const [localLayout, setLocalLayout] = useState<DashboardLayout>(layout);
  const [machineOrder, setMachineOrder] = useState<string[]>(
    layout.cardOrder && layout.cardOrder.length > 0
      ? layout.cardOrder
      : machines.map((m) => m.machineId)
  );
  const [visibleMachines, setVisibleMachines] = useState<string[]>(
    layout.visibleMachines && layout.visibleMachines.length > 0
      ? layout.visibleMachines
      : machines.map((m) => m.machineId)
  );

  const saveLayout = trpc.layout.save.useMutation();

  const handleSave = async () => {
    const newLayout: DashboardLayout = {
      ...localLayout,
      cardOrder: machineOrder,
      visibleMachines,
      terminalId,
    };
    await saveLayout.mutateAsync({
      terminalId,
      layoutName: newLayout.layoutName ?? "デフォルト",
      cardOrder: machineOrder,
      visibleMachines,
      showTargetProduction: newLayout.showTargetProduction,
      showActualProductionTime: newLayout.showActualProductionTime,
      showEnergyPlaceholder: newLayout.showEnergyPlaceholder,
      showCostPlaceholder: newLayout.showCostPlaceholder,
      refreshInterval: newLayout.refreshInterval,
      gridColumns: newLayout.gridColumns,
    });
    onSave(newLayout);
  };

  const toggleMachineVisibility = (machineId: string) => {
    setVisibleMachines((prev) =>
      prev.includes(machineId)
        ? prev.filter((id) => id !== machineId)
        : [...prev, machineId]
    );
  };

  const moveMachine = (index: number, direction: "up" | "down") => {
    const newOrder = [...machineOrder];
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newOrder.length) return;
    [newOrder[index], newOrder[targetIndex]] = [newOrder[targetIndex], newOrder[index]];
    setMachineOrder(newOrder);
  };

  const allMachinesInOrder = [
    ...machineOrder.map((id) => machines.find((m) => m.machineId === id)).filter(Boolean),
    ...machines.filter((m) => !machineOrder.includes(m.machineId)),
  ] as Machine[];

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg w-full bg-card border-border">
        <DialogHeader>
          <DialogTitle>ダッシュボード表示設定</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 max-h-[70vh] overflow-y-auto pr-1">
          {/* 更新間隔 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">自動更新間隔</Label>
            <Select
              value={String(localLayout.refreshInterval)}
              onValueChange={(v) =>
                setLocalLayout((prev) => ({ ...prev, refreshInterval: parseInt(v) }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0">手動のみ</SelectItem>
                <SelectItem value="60000">1分</SelectItem>
                <SelectItem value="300000">5分</SelectItem>
                <SelectItem value="1800000">30分</SelectItem>
                <SelectItem value="3600000">1時間</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* グリッド列数 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">カード列数</Label>
            <Select
              value={String(localLayout.gridColumns)}
              onValueChange={(v) =>
                setLocalLayout((prev) => ({ ...prev, gridColumns: parseInt(v) }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2">2列</SelectItem>
                <SelectItem value="3">3列</SelectItem>
                <SelectItem value="4">4列</SelectItem>
                <SelectItem value="5">5列</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* 表示項目の切り替え */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">追加表示項目</Label>
            {[
              { key: "showTargetProduction" as const, label: "目標生産数・達成率" },
              { key: "showActualProductionTime" as const, label: "実生産時間" },
              { key: "showEnergyPlaceholder" as const, label: "エネルギー消費量 (準備中)" },
              { key: "showCostPlaceholder" as const, label: "コスト・売上 (準備中)" },
            ].map(({ key, label }) => (
              <div key={key} className="flex items-center justify-between">
                <Label className="text-sm text-muted-foreground cursor-pointer">{label}</Label>
                <Switch
                  checked={localLayout[key]}
                  onCheckedChange={(v) =>
                    setLocalLayout((prev) => ({ ...prev, [key]: v }))
                  }
                />
              </div>
            ))}
          </div>

          <Separator />

          {/* 機械の表示・順序設定 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">機械の表示・順序</Label>
            <p className="text-xs text-muted-foreground">
              チェックで表示/非表示、矢印で並び替え
            </p>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {allMachinesInOrder.map((machine, index) => (
                <div
                  key={machine.machineId}
                  className="flex items-center gap-2 bg-secondary/30 rounded-lg px-3 py-2"
                >
                  <GripVertical className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                  <button
                    onClick={() => toggleMachineVisibility(machine.machineId)}
                    className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                      visibleMachines.includes(machine.machineId)
                        ? "bg-primary border-primary"
                        : "border-border"
                    }`}
                  >
                    {visibleMachines.includes(machine.machineId) && (
                      <Check className="h-3 w-3 text-primary-foreground" />
                    )}
                  </button>
                  <span className="text-sm flex-1 truncate">{machine.machineName}</span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => moveMachine(index, "up")}
                      disabled={index === 0}
                      className="text-muted-foreground hover:text-foreground disabled:opacity-20 text-xs px-1"
                    >
                      ↑
                    </button>
                    <button
                      onClick={() => moveMachine(index, "down")}
                      disabled={index === allMachinesInOrder.length - 1}
                      className="text-muted-foreground hover:text-foreground disabled:opacity-20 text-xs px-1"
                    >
                      ↓
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            キャンセル
          </Button>
          <Button
            onClick={handleSave}
            disabled={saveLayout.isPending}
            className="flex-1"
          >
            {saveLayout.isPending ? "保存中..." : "保存"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
