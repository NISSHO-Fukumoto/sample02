import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  calcMachineStatus,
  formatSeconds,
  getMachineStatusColor,
  getMachineStatusLabel,
  getStateColor,
  getStateLabel,
  type DailyRecord,
  type Machine,
  type MachineLog,
  type StopEvent,
} from "@/lib/types";
import { trpc } from "@/lib/trpc";
import { useMemo, useEffect, useRef, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import { Printer, Tag, X } from "lucide-react";
import { toast } from "sonner";

// ===== 停止理由プリセット =====
const STOP_REASON_PRESETS = [
  "段取り替え",
  "材料切れ",
  "機械故障",
  "品質確認",
  "清掃・点検",
  "休憩",
  "調整",
  "金型交換",
  "電気系統不良",
  "その他",
];

// ===== ガントチャート風タイムライン =====
function MachineTimeline({
  logs,
  timeStart = "08:00",
  timeEnd = "18:00",
}: {
  logs: MachineLog[];
  timeStart?: string;
  timeEnd?: string;
}) {
  const today = new Date();
  const [startH, startM] = timeStart.split(":").map(Number);
  const [endH, endM] = timeEnd.split(":").map(Number);
  const dayStart = new Date(today);
  dayStart.setHours(startH, startM, 0, 0);
  const dayEnd = new Date(today);
  dayEnd.setHours(endH, endM, 0, 0);
  const totalMs = dayEnd.getTime() - dayStart.getTime();

  // 今日のログのみ抽出
  const todayLogs = logs.filter((log) => {
    const d = new Date(log.periodStart);
    return (
      d.getFullYear() === today.getFullYear() &&
      d.getMonth() === today.getMonth() &&
      d.getDate() === today.getDate()
    );
  });

  // 時間軸ラベル（2時間ごと）
  const hourLabels: { label: string; pct: number }[] = [];
  for (let h = startH; h <= endH; h += 2) {
    const ms = (h * 60 - (startH * 60 + startM)) * 60 * 1000;
    const pct = Math.min(100, Math.max(0, (ms / totalMs) * 100));
    hourLabels.push({ label: `${h}:00`, pct });
  }

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground font-medium">
        本日の稼働タイムライン（{timeStart} 〜 {timeEnd}）
      </p>
      {/* 時間軸 */}
      <div className="relative h-4">
        {hourLabels.map(({ label, pct }) => (
          <span
            key={label}
            className="absolute text-[10px] text-muted-foreground/70 -translate-x-1/2"
            style={{ left: `${pct}%` }}
          >
            {label}
          </span>
        ))}
      </div>
      {/* タイムラインバー */}
      <div className="relative h-8 bg-secondary/40 rounded-md overflow-hidden border border-border/30">
        {todayLogs.map((log) => {
          const start = Math.max(0, new Date(log.periodStart).getTime() - dayStart.getTime());
          const end = Math.min(totalMs, new Date(log.periodEnd).getTime() - dayStart.getTime());
          if (end <= 0 || start >= totalMs) return null;
          const left = (start / totalMs) * 100;
          const width = ((end - start) / totalMs) * 100;
          const colorMap: Record<string, string> = {
            running: "bg-emerald-500/80",
            idle: "bg-yellow-400/80",
            stopped: "bg-red-500/80",
            maintenance: "bg-purple-500/80",
          };
          const color = colorMap[log.state] ?? "bg-gray-400/80";
          return (
            <div
              key={log.id}
              className={`absolute h-full ${color} transition-all`}
              style={{ left: `${left}%`, width: `${Math.max(0.3, width)}%` }}
              title={`${log.state} ${new Date(log.periodStart).toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}〜${new Date(log.periodEnd).toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}`}
            />
          );
        })}
        {/* 現在時刻マーカー */}
        {(() => {
          const nowMs = Date.now() - dayStart.getTime();
          if (nowMs < 0 || nowMs > totalMs) return null;
          const pct = (nowMs / totalMs) * 100;
          return (
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white/80 z-10"
              style={{ left: `${pct}%` }}
            />
          );
        })()}
      </div>
      {/* 凡例 */}
      <div className="flex gap-4 text-[10px] text-muted-foreground flex-wrap">
        <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-emerald-500/80 inline-block" />稼働中</span>
        <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-yellow-400/80 inline-block" />チョコ停</span>
        <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-red-500/80 inline-block" />ドカ停</span>
        <span className="flex items-center gap-1"><span className="w-3 h-2 rounded-sm bg-purple-500/80 inline-block" />メンテナンス</span>
        <span className="flex items-center gap-1"><span className="w-0.5 h-3 bg-white/80 inline-block" />現在時刻</span>
      </div>
    </div>
  );
}

// ===== 停止イベントリスト（タグ付け機能付き） =====
function StopEventList({
  events,
  onUpdate,
}: {
  events: StopEvent[];
  onUpdate: () => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editValue, setEditValue] = useState("");

  const updateReason = trpc.stopEvents.updateReason.useMutation({
    onSuccess: () => {
      toast.success("停止理由を更新しました");
      setEditingId(null);
      onUpdate();
    },
    onError: () => toast.error("更新に失敗しました"),
  });

  const handleEdit = (event: StopEvent) => {
    setEditingId(event.id);
    setEditValue(event.manualReason ?? "");
  };

  const handleSave = (id: number) => {
    updateReason.mutate({ id, manualReason: editValue || null });
  };

  if (events.length === 0) {
    return (
      <p className="text-sm text-muted-foreground text-center py-8">
        本日の停止イベントはありません
      </p>
    );
  }

  return (
    <div className="space-y-2">
      {events.map((event) => (
        <div
          key={event.id}
          className={`flex items-start gap-3 p-3 rounded-lg border ${
            event.stopType === "DOKA"
              ? "border-red-500/30 bg-red-500/5"
              : "border-yellow-500/30 bg-yellow-500/5"
          }`}
        >
          {/* 停止種別バッジ */}
          <Badge
            variant="outline"
            className={`shrink-0 text-xs font-bold ${
              event.stopType === "DOKA"
                ? "text-red-400 border-red-500/50"
                : "text-yellow-400 border-yellow-500/50"
            }`}
          >
            {event.stopType === "DOKA" ? "ドカ停" : "チョコ停"}
          </Badge>

          {/* 時刻・時間 */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
              <span>
                {new Date(event.startTime).toLocaleTimeString("ja-JP", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
                {event.endTime && (
                  <>
                    {" 〜 "}
                    {new Date(event.endTime).toLocaleTimeString("ja-JP", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </>
                )}
              </span>
              {event.duration && (
                <span className="font-medium text-foreground">
                  ({formatSeconds(event.duration)})
                </span>
              )}
            </div>

            {/* 停止理由タグ付け */}
            {editingId === event.id ? (
              <div className="flex gap-2 mt-1">
                <div className="flex-1 space-y-1">
                  <Select
                    value={editValue}
                    onValueChange={(v) => setEditValue(v)}
                  >
                    <SelectTrigger className="h-7 text-xs">
                      <SelectValue placeholder="理由を選択..." />
                    </SelectTrigger>
                    <SelectContent>
                      {STOP_REASON_PRESETS.map((r) => (
                        <SelectItem key={r} value={r} className="text-xs">
                          {r}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    placeholder="または直接入力..."
                    className="h-7 text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <Button
                    size="sm"
                    className="h-7 text-xs px-2"
                    onClick={() => handleSave(event.id)}
                    disabled={updateReason.isPending}
                  >
                    保存
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs px-2"
                    onClick={() => setEditingId(null)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {event.manualReason ? (
                  <Badge variant="secondary" className="text-xs">
                    <Tag className="h-2.5 w-2.5 mr-1" />
                    {event.manualReason}
                  </Badge>
                ) : (
                  <span className="text-xs text-muted-foreground/60 italic">
                    理由未設定
                  </span>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 text-xs px-2 ml-auto"
                  onClick={() => handleEdit(event)}
                >
                  <Tag className="h-3 w-3 mr-1" />
                  タグ付け
                </Button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// ===== メインモーダル =====
interface MachineDetailModalProps {
  machine: Machine;
  logs: MachineLog[];
  dailyRecord?: DailyRecord | null;
  latestLog?: MachineLog | null;
  todayMaxTarget?: number | null;
  open: boolean;
  onClose: () => void;
}

export default function MachineDetailModal({
  machine,
  logs,
  dailyRecord,
  latestLog,
  todayMaxTarget,
  open,
  onClose,
}: MachineDetailModalProps) {
  // ログはlogsを優先、なければlatestLogをフォールバック
  const allLogs = logs.length > 0 ? logs : (latestLog ? [latestLog] : []);
  const currentLog = allLogs[0] ?? null;

  const status = calcMachineStatus(
    currentLog?.periodEnd ?? null,
    machine.durChoco ?? 60,
    machine.durDoka ?? 600,
    machine.durEnd ?? 3600
  );
  const statusColors = getMachineStatusColor(status);
  const statusLabel = getMachineStatusLabel(status);

  // 今日の停止イベントを取得
  const [todayStart] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const { data: stopEventsData, refetch: refetchStopEvents } = trpc.stopEvents.list.useQuery(
    { machineId: machine.machineId, from: todayStart, limit: 200 },
    { enabled: open }
  );

  // チャートデータ
  const chartData = useMemo(() => {
    return allLogs
      .slice()
      .reverse()
      .map((log) => {
        // 稼働率を計算: 運転時間 / (運転時間 + アイドル時間 + 停止時間) × 100
        const totalSeconds = log.runningSeconds + log.idleSeconds + log.stoppedSeconds;
        const calculatedRate = totalSeconds > 0 ? (log.runningSeconds / totalSeconds) * 100 : 0;
        
        return {
          time: new Date(log.periodEnd).toLocaleString("ja-JP", {
            month: "numeric",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          }),
          稼働率: calculatedRate,
          運転: Math.round(log.runningSeconds / 60),
          チョコ停: Math.round(log.idleSeconds / 60),
          ドカ停: Math.round(log.stoppedSeconds / 60),
          生産数: log.productionCount,
        };
      })
      .filter((data) => {
        // 数値がすべて0の場合は除外
        const hasNonZero =
          data.稼働率 !== 0 ||
          data.運転 !== 0 ||
          data.チョコ停 !== 0 ||
          data.ドカ停 !== 0 ||
          data.生産数 !== 0;
        return hasNonZero;
      });
  }, [allLogs]);

  // ログ履歴の表示データから集計値を計算
  const displayLogs = allLogs
    .filter((log) => {
      const hasNonZero =
        parseFloat(log.operationRate ?? "0") !== 0 ||
        log.runningSeconds !== 0 ||
        log.idleSeconds !== 0 ||
        log.stoppedSeconds !== 0 ||
        log.productionCount !== 0;
      return hasNonZero;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .filter((log, index, arr) => {
      const hour = new Date(log.createdAt).getHours();
      return arr.findIndex((item) => new Date(item.createdAt).getHours() === hour) === index;
    });

  // 表示データから集計値を計算
  const totalRunningSeconds = displayLogs.reduce((sum, log) => sum + log.runningSeconds, 0);
  const totalIdleSeconds = displayLogs.reduce((sum, log) => sum + log.idleSeconds, 0);
  const totalStoppedSeconds = displayLogs.reduce((sum, log) => sum + log.stoppedSeconds, 0);
  const totalProductionCount = displayLogs.reduce((sum, log) => sum + log.productionCount, 0);
  const totalSeconds = totalRunningSeconds + totalIdleSeconds + totalStoppedSeconds;
  const utilizationRate = totalSeconds > 0 ? (totalRunningSeconds / totalSeconds) * 100 : 0;

  const productionCount = totalProductionCount;
  const targetCount = todayMaxTarget ?? machine.targetProductionCount ?? null;
  const runTime = totalRunningSeconds;
  const chocoTime = totalIdleSeconds;
  const dokaTime = totalStoppedSeconds;

  const handlePrint = () => window.print();

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-5xl w-[90vw] max-h-[90vh] p-0 gap-0 bg-card border-border flex flex-col overflow-hidden">
        <DialogHeader className="px-6 pt-5 pb-4 border-b border-border shrink-0">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Badge
                  variant="outline"
                  className={`text-xs ${statusColors.badge}`}
                >
                  <span
                    className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 ${statusColors.dot} ${
                      status === "running" ? "animate-pulse" :
                      status === "doka" ? "animate-ping" : ""
                    }`}
                  />
                  {statusLabel}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {machine.machineType}
                  {machine.lineName && ` · ${machine.lineName}`}
                  {machine.location && ` · ${machine.location}`}
                </span>
              </div>
              <DialogTitle className="text-xl font-bold">
                {machine.machineName}
              </DialogTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                機械ID: {machine.machineId}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrint}
                className="no-print gap-2"
              >
                <Printer className="h-3.5 w-3.5" />
                印刷
              </Button>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 min-h-0 h-full max-h-[calc(90vh-120px)]">
          <div className="p-6 space-y-6">
            {/* KPIサマリー */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-secondary/40 rounded-xl p-3 text-center">
                <div className={`text-3xl font-bold tabular-nums ${
                  utilizationRate >= 85 ? "text-emerald-400" :
                  utilizationRate >= 70 ? "text-yellow-400" :
                  utilizationRate >= 50 ? "text-orange-400" : "text-red-400"
                }`}>
                  {utilizationRate.toFixed(1)}<span className="text-sm font-normal text-muted-foreground">%</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">稼働率</p>
              </div>
              <div className="bg-secondary/40 rounded-xl p-3 text-center">
                <div className="text-2xl font-bold text-foreground tabular-nums">
                  {productionCount.toLocaleString()}
                  {targetCount && (
                    <>
                      <br />
                      <span className="text-sm font-normal text-muted-foreground">
                        /{targetCount.toLocaleString()}
                      </span>
                    </>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">生産数</p>
              </div>
              <div className="bg-secondary/40 rounded-xl p-3 text-center">
                <div className="text-xl font-bold text-emerald-400 tabular-nums">
                  {formatSeconds(runTime)}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">運転時間</p>
              </div>
              <div className="bg-secondary/40 rounded-xl p-3 text-center">
                <div className="text-xl font-bold text-red-400 tabular-nums">
                  {formatSeconds(chocoTime + dokaTime)}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">停止合計</p>
              </div>
            </div>

            {/* タイムライン */}
            <div className="bg-secondary/20 rounded-xl p-4">
              <MachineTimeline
                logs={allLogs}
                timeStart={machine.timeStart ?? "08:00"}
                timeEnd={machine.timeEnd ?? "18:00"}
              />
            </div>

            {/* 将来拡張: エネルギー・コスト */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[
                { label: "蒸気消費量", unit: "kg", value: currentLog?.steamConsumption },
                { label: "電力消費量", unit: "kWh", value: currentLog?.electricityConsumption },
                { label: "エアー消費量", unit: "m³", value: currentLog?.airConsumption },
                { label: "ガス消費量", unit: "m³", value: currentLog?.gasConsumption },
                { label: "水消費量", unit: "L", value: currentLog?.waterConsumption },
                { label: "湯消費量", unit: "L", value: currentLog?.hotWaterConsumption },
              ].map((item) => (
                <div
                  key={item.label}
                  className="border border-dashed border-border/40 rounded-lg p-2 text-center"
                >
                  <div className="text-sm font-medium text-muted-foreground/60">
                    {item.value ? `${item.value} ${item.unit}` : "—"}
                  </div>
                  <div className="text-[10px] text-muted-foreground/40 mt-0.5">{item.label}</div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "人件費", value: currentLog?.laborCost, prefix: "¥" },
                { label: "生産コスト", value: currentLog?.productionCost, prefix: "¥" },
                { label: "生産売上", value: currentLog?.productionRevenue, prefix: "¥" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="border border-dashed border-border/40 rounded-lg p-2 text-center"
                >
                  <div className="text-sm font-medium text-muted-foreground/60">
                    {item.value ? `${item.prefix}${parseFloat(item.value).toLocaleString()}` : "—"}
                  </div>
                  <div className="text-[10px] text-muted-foreground/40 mt-0.5">{item.label}</div>
                </div>
              ))}
            </div>

            <Separator />

            {/* タブ: グラフ / 停止イベント / ログ履歴 */}
            <Tabs defaultValue="chart">
              <TabsList className="bg-secondary/50 w-full grid grid-cols-3">
                <TabsTrigger value="chart">グラフ分析</TabsTrigger>
                <TabsTrigger value="stopevents">
                  停止イベント
                  {stopEventsData && stopEventsData.length > 0 && (
                    <Badge variant="destructive" className="ml-1.5 text-[10px] h-4 px-1">
                      {stopEventsData.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="table">ログ履歴</TabsTrigger>
              </TabsList>

              {/* グラフタブ */}
              <TabsContent value="chart" className="space-y-4 mt-4">
                {chartData.length > 0 ? (
                  <>
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">稼働率推移</h4>
                      <ResponsiveContainer width="100%" height={180}>
                        <AreaChart data={chartData}>
                          <defs>
                            <linearGradient id="rateGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 240)" />
                          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} />
                          <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} unit="%" />
                          <Tooltip
                            contentStyle={{ backgroundColor: "oklch(0.16 0.012 240)", border: "1px solid oklch(0.25 0.015 240)", borderRadius: "8px", fontSize: "12px" }}
                          />
                          <Area type="monotone" dataKey="稼働率" stroke="oklch(0.72 0.18 200)" fill="url(#rateGrad)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">時間内訳（分）</h4>
                      <ResponsiveContainer width="100%" height={180}>
                        <BarChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 240)" />
                          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} />
                          <YAxis tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} unit="分" />
                          <Tooltip
                            contentStyle={{ backgroundColor: "oklch(0.16 0.012 240)", border: "1px solid oklch(0.25 0.015 240)", borderRadius: "8px", fontSize: "12px" }}
                          />
                          <Legend wrapperStyle={{ fontSize: "11px" }} />
                          <Bar dataKey="運転" fill="oklch(0.72 0.20 145)" radius={[2, 2, 0, 0]} />
                          <Bar dataKey="チョコ停" fill="oklch(0.75 0.18 75)" radius={[2, 2, 0, 0]} />
                          <Bar dataKey="ドカ停" fill="oklch(0.60 0.22 25)" radius={[2, 2, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">生産数推移</h4>
                      <ResponsiveContainer width="100%" height={140}>
                        <AreaChart data={chartData}>
                          <defs>
                            <linearGradient id="prodGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="oklch(0.72 0.20 145)" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="oklch(0.72 0.20 145)" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 240)" />
                          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} />
                          <YAxis tick={{ fontSize: 10, fill: "oklch(0.60 0.01 240)" }} />
                          <Tooltip
                            contentStyle={{ backgroundColor: "oklch(0.16 0.012 240)", border: "1px solid oklch(0.25 0.015 240)", borderRadius: "8px", fontSize: "12px" }}
                          />
                          <Area type="monotone" dataKey="生産数" stroke="oklch(0.72 0.20 145)" fill="url(#prodGrad)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    データがありません
                  </div>
                )}
              </TabsContent>

              {/* 停止イベントタブ */}
              <TabsContent value="stopevents" className="mt-4 max-h-[70vh] overflow-y-auto pr-4">
                <StopEventList
                  events={(stopEventsData ?? []) as StopEvent[]}
                  onUpdate={refetchStopEvents}
                />
              </TabsContent>

              {/* ログ履歴タブ */}
              <TabsContent value="table" className="mt-4">
                <div className="rounded-lg border border-border">
                    <table className="w-full text-xs">
                      <thead className="bg-secondary/50">
                      <tr>
                        <th className="text-left px-3 py-2.5 font-medium text-muted-foreground">期間</th>
                        <th className="text-right px-3 py-2.5 font-medium text-muted-foreground">稼働率</th>
                        <th className="text-right px-3 py-2.5 font-medium text-muted-foreground">運転</th>
                        <th className="text-right px-3 py-2.5 font-medium text-muted-foreground">チョコ停</th>
                        <th className="text-right px-3 py-2.5 font-medium text-muted-foreground">ドカ停</th>
                        <th className="text-right px-3 py-2.5 font-medium text-muted-foreground">生産数</th>
                        <th className="text-center px-3 py-2.5 font-medium text-muted-foreground">状態</th>
                      </tr>
                      </thead>
                      <tbody>
                        {allLogs
                          .filter((log) => {
                          // 数値がすべて0の場合は除外
                          const totalSeconds = log.runningSeconds + log.idleSeconds + log.stoppedSeconds;
                          const calculatedRate = totalSeconds > 0 ? (log.runningSeconds / totalSeconds) * 100 : 0;
                          const hasNonZero =
                            calculatedRate !== 0 ||
                            log.runningSeconds !== 0 ||
                            log.idleSeconds !== 0 ||
                            log.stoppedSeconds !== 0 ||
                            log.productionCount !== 0;
                          return hasNonZero;
                        })
                        .sort((a, b) => new Date(b.periodEnd).getTime() - new Date(a.periodEnd).getTime())
                        .filter((log, index, arr) => {
                          // 時間毎に最新レコードのみを保持
                          const hour = new Date(log.createdAt).getHours();
                          return arr.findIndex((item) => new Date(item.createdAt).getHours() === hour) === index;
                        })
                        .map((log, i) => (
                        <tr
                          key={log.id}
                          className={`border-t border-border/50 ${i % 2 === 0 ? "" : "bg-secondary/20"}`}
                        >
                          <td className="px-3 py-2 text-muted-foreground">
                            {new Date(log.createdAt).toLocaleString("ja-JP", {
                              month: "numeric",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </td>
                          <td className={`px-3 py-2 text-right font-medium ${
                            (() => {
                              const totalSeconds = log.runningSeconds + log.idleSeconds + log.stoppedSeconds;
                              const rate = totalSeconds > 0 ? (log.runningSeconds / totalSeconds) * 100 : 0;
                              return rate >= 85 ? "text-emerald-400" :
                                     rate >= 70 ? "text-yellow-400" : "text-red-400";
                            })()
                          }`}>
                            {(() => {
                              const totalSeconds = log.runningSeconds + log.idleSeconds + log.stoppedSeconds;
                              const rate = totalSeconds > 0 ? (log.runningSeconds / totalSeconds) * 100 : 0;
                              return rate.toFixed(1);
                            })()}%
                          </td>
                          <td className="px-3 py-2 text-right text-emerald-400">
                            {formatSeconds(log.runningSeconds)}
                          </td>
                          <td className="px-3 py-2 text-right text-yellow-400">
                            {formatSeconds(log.idleSeconds)}
                          </td>
                          <td className="px-3 py-2 text-right text-red-400">
                            {formatSeconds(log.stoppedSeconds)}
                          </td>
                          <td className="px-3 py-2 text-right font-medium">
                            {log.productionCount.toLocaleString()}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <Badge
                              variant="outline"
                              className={`text-[10px] ${getStateColor(log.state)}`}
                            >
                              {getStateLabel(log.state)}
                            </Badge>
                          </td>
                        </tr>
                        ))
                        }
                        {allLogs.length === 0 && (
                          <tr>
                            <td colSpan={7} className="px-3 py-8 text-center text-muted-foreground">
                              データがありません
                            </td>
                          </tr>
                        )}
                    </tbody>
                  </table>
                  </div>
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
