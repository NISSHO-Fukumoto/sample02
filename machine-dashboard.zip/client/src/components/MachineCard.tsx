import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  calcMachineStatus,
  formatSeconds,
  getMachineStatusColor,
  getMachineStatusLabel,
  getOperationRateColor,
  type DailyRecord,
  type DashboardLayout,
  type Machine,
  type MachineLog,
} from "@/lib/types";
import { Activity, Package, Timer, TrendingUp, Zap } from "lucide-react";
import { useEffect, useRef } from "react";

// 機械名称の文字数に応じてフォントサイズを自動調整するコンポーネント
function MachineName({ name }: { name: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLSpanElement>(null);
  const charWidth = Array.from(name).reduce((acc, ch) => {
    return acc + (ch.charCodeAt(0) > 0x7f ? 1 : 0.5);
  }, 0);
  const isLong = charWidth > 12;

  useEffect(() => {
    if (!isLong) return;
    const container = containerRef.current;
    const text = textRef.current;
    if (!container || !text) return;

    const resize = () => {
      text.style.fontSize = "";
      const baseFontSize = 20;
      const containerWidth = container.clientWidth;
      const naturalWidth = text.scrollWidth;
      if (naturalWidth > containerWidth) {
        const ratio = containerWidth / naturalWidth;
        const newSize = Math.max(11, Math.floor(baseFontSize * ratio));
        text.style.fontSize = `${newSize}px`;
      }
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    return () => ro.disconnect();
  }, [name, isLong]);

  return (
    <div ref={containerRef} className="w-full overflow-hidden">
      <span
        ref={textRef}
        className="font-bold leading-tight whitespace-nowrap block"
        style={{ fontSize: "20px", lineHeight: 1.25 }}
      >
        {name}
      </span>
    </div>
  );
}

interface MachineCardProps {
  machine: Machine;
  log?: MachineLog | null;
  dailyRecord?: DailyRecord | null;
  layout: DashboardLayout;
  todayMaxTarget?: number | null;
  onClick: () => void;
  isDragging?: boolean;
}

export default function MachineCard({
  machine,
  log,
  dailyRecord,
  layout,
  todayMaxTarget,
  onClick,
  isDragging,
}: MachineCardProps) {
  // リアルタイムステータスを閾値ベースで計算
  const status = calcMachineStatus(
    log?.periodEnd ?? null,
    machine.durChoco ?? 60,
    machine.durDoka ?? 600,
    machine.durEnd ?? 3600
  );
  const statusColors = getMachineStatusColor(status);
  const statusLabel = getMachineStatusLabel(status);

  // 稼働率（daily_recordsがあればそちらを優先、なければlogから計算）
  const utilizationRate = dailyRecord
    ? parseFloat(dailyRecord.utilizationRate ?? "0")
    : log
    ? (() => {
        const totalSeconds = log.runningSeconds + log.idleSeconds + log.stoppedSeconds;
        return totalSeconds > 0 ? (log.runningSeconds / totalSeconds) * 100 : 0;
      })()
    : 0;

  const rateColorClass = getOperationRateColor(utilizationRate);

  // 生産数（daily_recordsがあればそちらを優先）
  const productionCount = dailyRecord?.totalCount ?? log?.productionCount ?? 0;
  // 目標値: 当日の最大目標 > 最新ログ > 機械マスター
  const targetCount = todayMaxTarget ?? log?.targetProductionCount ?? machine.targetProductionCount ?? null;

  // 生産進捗率
  const productionProgress =
    layout.showTargetProduction && targetCount && targetCount > 0
      ? Math.min(100, (productionCount / targetCount) * 100)
      : null;

  // 時間データ（daily_recordsがあればそちらを優先）
  const runTime = dailyRecord?.totalRunTime ?? log?.runningSeconds ?? 0;
  const chocoTime = dailyRecord?.totalChocoTime ?? log?.idleSeconds ?? 0;
  const dokaTime = dailyRecord?.totalDokaTime ?? log?.stoppedSeconds ?? 0;

  // ドカ停中は赤枠点滅強調
  const isDoka = status === "doka";

  return (
    <Card
      className={`machine-card card-hover cursor-pointer border transition-all duration-200 ${statusColors.border} ${statusColors.glow} ${statusColors.ring} bg-card/80 backdrop-blur-sm ${isDragging ? "opacity-50 scale-95" : ""} ${isDoka ? "doka-alert" : ""}`}
      onClick={onClick}
    >
      <CardHeader className="pb-2 pt-4 px-4">
        {/* 種別・ライン名 + ステータスバッジ */}
        <div className="flex items-start justify-between gap-2 mb-1">
          <p className="text-xs text-muted-foreground truncate">
            {machine.machineType}
            {machine.lineName && ` · ${machine.lineName}`}
          </p>
          <Badge
            variant="outline"
            className={`text-xs shrink-0 ${statusColors.badge}`}
          >
            <span
              className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 ${statusColors.dot} ${
                status === "running" ? "animate-pulse" :
                status === "doka" ? "animate-ping" : ""
              }`}
            />
            {statusLabel}
          </Badge>
        </div>
        {/* 機械名称：大きく表示、長い場合は自動縮小 */}
        <MachineName name={machine.machineName} />
      </CardHeader>

      <CardContent className="px-4 pb-4 space-y-3">
        {/* 稼働率 - 大きく中央表示 */}
        <div className="text-center py-2">
          <div className={`text-4xl font-bold tabular-nums ${rateColorClass}`}>
            {utilizationRate.toFixed(1)}
            <span className="text-lg font-normal text-muted-foreground ml-0.5">%</span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">稼働率</p>
          <Progress value={utilizationRate} className="mt-2 h-1.5" />
        </div>

        {/* 時間データ（運転・チョコ停・ドカ停） */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-secondary/50 rounded-lg p-2">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Activity className="h-3 w-3 text-emerald-400" />
            </div>
            <div className="text-xs font-semibold text-emerald-400 tabular-nums">
              {formatSeconds(runTime)}
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">運転時間</div>
          </div>
          <div className="bg-secondary/50 rounded-lg p-2">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Timer className="h-3 w-3 text-yellow-400" />
            </div>
            <div className="text-xs font-semibold text-yellow-400 tabular-nums">
              {formatSeconds(chocoTime)}
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">チョコ停</div>
          </div>
          <div className="bg-secondary/50 rounded-lg p-2">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Zap className="h-3 w-3 text-red-400" />
            </div>
            <div className="text-xs font-semibold text-red-400 tabular-nums">
              {formatSeconds(dokaTime)}
            </div>
            <div className="text-[10px] text-muted-foreground mt-0.5">ドカ停</div>
          </div>
        </div>

        {/* 生産数（現在数 / 目標数） */}
        <div className="flex items-center justify-between bg-secondary/30 rounded-lg px-3 py-2">
          <div className="flex items-center gap-2">
            <Package className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs text-muted-foreground">生産数</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-bold text-foreground tabular-nums">
              {productionCount.toLocaleString()}
            </span>
            {layout.showTargetProduction && targetCount ? (
              <span className="text-xs text-muted-foreground">
                / {targetCount.toLocaleString()}
              </span>
            ) : null}
          </div>
        </div>

        {/* 生産進捗バー（目標数表示が有効な場合） */}
        {productionProgress !== null && (
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">目標達成率</span>
              <span className={productionProgress >= 100 ? "text-emerald-400" : "text-yellow-400"}>
                {productionProgress.toFixed(1)}%
              </span>
            </div>
            <Progress value={productionProgress} className="h-1" />
          </div>
        )}

        {/* 実生産時間（設定で有効時） */}
        {layout.showActualProductionTime && (
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <TrendingUp className="h-3 w-3" />
              <span>実生産時間</span>
            </div>
            <span className="font-medium text-foreground">
              {formatSeconds(runTime)}
            </span>
          </div>
        )}

        {/* 将来拡張: エネルギー消費プレースホルダー */}
        {layout.showEnergyPlaceholder && (
          <div className="border border-dashed border-border/50 rounded-lg p-2">
            <p className="text-[10px] text-muted-foreground/50 text-center">
              エネルギー消費量 (準備中)
            </p>
          </div>
        )}

        {/* 将来拡張: コストプレースホルダー */}
        {layout.showCostPlaceholder && (
          <div className="border border-dashed border-border/50 rounded-lg p-2">
            <p className="text-[10px] text-muted-foreground/50 text-center">
              コスト・売上 (準備中)
            </p>
          </div>
        )}

        {/* 最終更新時刻 */}
        {log && (
          <p className="text-[10px] text-muted-foreground/60 text-right">
            最終: {new Date(log.periodEnd).toLocaleString("ja-JP", {
              month: "numeric",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
