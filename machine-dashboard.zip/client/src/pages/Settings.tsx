import { Settings as SettingsIcon, Info, Server, Database, Terminal, Tag, Plus, Pencil, Trash2, Check, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

// ===== 機械種別マスター管理コンポーネント =====
function MachineTypeManager() {
  const utils = trpc.useUtils();
  const { data: types, isLoading } = trpc.machineTypes.list.useQuery();

  const [newTypeName, setNewTypeName] = useState("");
  const [newSortOrder, setNewSortOrder] = useState(0);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editName, setEditName] = useState("");
  const [editSortOrder, setEditSortOrder] = useState(0);
  const [deleteTarget, setDeleteTarget] = useState<{ id: number; typeName: string } | null>(null);

  const createType = trpc.machineTypes.create.useMutation({
    onSuccess: () => {
      utils.machineTypes.list.invalidate();
      setNewTypeName("");
      setNewSortOrder(0);
      toast.success("機械種別を追加しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const updateType = trpc.machineTypes.update.useMutation({
    onSuccess: () => {
      utils.machineTypes.list.invalidate();
      setEditingId(null);
      toast.success("機械種別を更新しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const deleteType = trpc.machineTypes.delete.useMutation({
    onSuccess: () => {
      utils.machineTypes.list.invalidate();
      setDeleteTarget(null);
      toast.success("機械種別を削除しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const startEdit = (type: { id: number; typeName: string; sortOrder: number | null }) => {
    setEditingId(type.id);
    setEditName(type.typeName);
    setEditSortOrder(type.sortOrder ?? 0);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditName("");
    setEditSortOrder(0);
  };

  const handleCreate = () => {
    if (!newTypeName.trim()) {
      toast.error("種別名を入力してください");
      return;
    }
    createType.mutate({ typeName: newTypeName.trim(), sortOrder: newSortOrder });
  };

  const handleUpdate = () => {
    if (!editName.trim() || editingId === null) return;
    updateType.mutate({ id: editingId, typeName: editName.trim(), sortOrder: editSortOrder });
  };

  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">
        機械マスター登録時に選択できる種別の一覧です。追加・名称変更・削除が可能です。
      </p>

      {/* 新規追加フォーム */}
      <Card className="bg-secondary/20 border-border/60">
        <CardContent className="pt-4 pb-4">
          <p className="text-xs font-medium text-muted-foreground mb-3">新しい種別を追加</p>
          <div className="flex gap-2">
            <Input
              value={newTypeName}
              onChange={(e) => setNewTypeName(e.target.value)}
              placeholder="種別名（例: CNC加工機）"
              className="flex-1 h-8 text-sm"
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            />
            <Input
              type="number"
              value={newSortOrder}
              onChange={(e) => setNewSortOrder(parseInt(e.target.value) || 0)}
              placeholder="順序"
              className="w-20 h-8 text-sm"
              title="表示順（小さい数字が先に表示）"
            />
            <Button
              size="sm"
              className="h-8 gap-1.5 shrink-0"
              onClick={handleCreate}
              disabled={createType.isPending}
            >
              <Plus className="h-3.5 w-3.5" />
              追加
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 種別一覧 */}
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/50 border-b border-border">
            <tr>
              <th className="text-left px-4 py-2.5 font-medium text-muted-foreground text-xs">種別名</th>
              <th className="text-center px-4 py-2.5 font-medium text-muted-foreground text-xs w-20">表示順</th>
              <th className="text-right px-4 py-2.5 font-medium text-muted-foreground text-xs w-24">操作</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center text-muted-foreground text-sm">
                  読み込み中...
                </td>
              </tr>
            ) : !types?.length ? (
              <tr>
                <td colSpan={3} className="px-4 py-8 text-center text-muted-foreground text-sm">
                  種別が登録されていません
                </td>
              </tr>
            ) : (
              types.map((type, i) => (
                <tr
                  key={type.id}
                  className={`border-t border-border/50 ${i % 2 === 0 ? "" : "bg-secondary/10"}`}
                >
                  <td className="px-4 py-2.5">
                    {editingId === type.id ? (
                      <Input
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="h-7 text-sm"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleUpdate();
                          if (e.key === "Escape") cancelEdit();
                        }}
                      />
                    ) : (
                      <div className="flex items-center gap-2">
                        <Tag className="h-3.5 w-3.5 text-muted-foreground/60 shrink-0" />
                        <span className="font-medium">{type.type_name}</span>
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-center">
                    {editingId === type.id ? (
                      <Input
                        type="number"
                        value={editSortOrder}
                        onChange={(e) => setEditSortOrder(parseInt(e.target.value) || 0)}
                        className="h-7 text-sm text-center"
                      />
                    ) : (
                      <Badge variant="outline" className="text-xs font-mono">
                        {type.sort_order ?? 0}
                      </Badge>
                    )}
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-1">
                      {editingId === type.id ? (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-emerald-400 hover:text-emerald-300"
                            onClick={handleUpdate}
                            disabled={updateType.isPending}
                            title="保存"
                          >
                            <Check className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={cancelEdit}
                            title="キャンセル"
                          >
                            <X className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => startEdit({ id: type.id, typeName: type.type_name, sortOrder: type.sort_order })}
                            title="編集"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            onClick={() => setDeleteTarget({ id: type.id, typeName: type.type_name })}
                            title="削除"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 削除確認ダイアログ */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>種別を削除しますか？</AlertDialogTitle>
            <AlertDialogDescription>
              「{deleteTarget?.typeName}」を削除します。この種別を使用している機械の種別フィールドには影響しません。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteType.mutate({ id: deleteTarget.id })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              削除する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===== メイン設定ページ =====
export default function Settings() {
  const terminalId = localStorage.getItem("machine-dashboard-terminal-id") ?? "未設定";

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <SettingsIcon className="h-5 w-5 text-primary" />
          システム設定
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          マスターデータ管理・システム情報・接続設定
        </p>
      </div>

      <Tabs defaultValue="machine-types">
        <TabsList className="bg-secondary/50 mb-4">
          <TabsTrigger value="machine-types" className="gap-1.5 text-xs">
            <Tag className="h-3.5 w-3.5" />
            機械種別マスター
          </TabsTrigger>
          <TabsTrigger value="terminal" className="gap-1.5 text-xs">
            <Terminal className="h-3.5 w-3.5" />
            端末情報
          </TabsTrigger>
          <TabsTrigger value="api" className="gap-1.5 text-xs">
            <Server className="h-3.5 w-3.5" />
            データ収集API
          </TabsTrigger>
          <TabsTrigger value="system" className="gap-1.5 text-xs">
            <Info className="h-3.5 w-3.5" />
            システム情報
          </TabsTrigger>
        </TabsList>

        {/* 機械種別マスター */}
        <TabsContent value="machine-types">
          <Card className="bg-card/80 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Tag className="h-4 w-4 text-primary" />
                機械種別マスター
              </CardTitle>
            </CardHeader>
            <CardContent>
              <MachineTypeManager />
            </CardContent>
          </Card>
        </TabsContent>

        {/* 端末情報 */}
        <TabsContent value="terminal">
          <Card className="bg-card/80 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Terminal className="h-4 w-4 text-primary" />
                この端末の情報
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">端末ID</span>
                <code className="bg-secondary/50 px-2 py-0.5 rounded text-xs font-mono text-primary">
                  {terminalId}
                </code>
              </div>
              <p className="text-xs text-muted-foreground bg-secondary/30 rounded-lg p-3">
                この端末IDはダッシュボードのレイアウト設定を保存するために使用されます。
                ブラウザのローカルストレージに保存されており、同じ端末・ブラウザからアクセスすると同じ設定が読み込まれます。
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* データ収集API */}
        <TabsContent value="api">
          <Card className="bg-card/80 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Server className="h-4 w-4 text-primary" />
                データ収集API
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">エンドポイント</p>
                <code className="block text-xs bg-secondary/50 px-3 py-2 rounded-lg font-mono text-primary">
                  POST {window.location.origin}/api/ingest
                </code>
              </div>

              <Separator />

              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">リクエストヘッダー</p>
                <code className="block text-xs bg-secondary/50 px-3 py-2 rounded-lg font-mono text-muted-foreground whitespace-pre">
{`Content-Type: application/json
Authorization: Bearer <APIキー>
  または
X-Api-Key: <APIキー>`}
                </code>
              </div>

              <Separator />

              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">リクエストボディ (JSON)</p>
                <code className="block text-xs bg-secondary/50 px-3 py-2 rounded-lg font-mono text-muted-foreground whitespace-pre">
{`{
  "machineId": "MC-001",        // 必須 (またはデバイスに紐付け)
  "periodStart": "2024-01-01T08:00:00Z",  // 必須
  "periodEnd": "2024-01-01T09:00:00Z",    // 必須
  "state": "running",           // running/stopped/idle/maintenance
  "runningSeconds": 3200,       // 運転時間(秒)
  "stoppedSeconds": 400,        // 停止時間(秒)
  "idleSeconds": 0,             // チョコ停時間(秒)
  "maintenanceSeconds": 0,      // メンテナンス時間(秒)
  "productionCount": 450,       // 生産数
  "targetProductionCount": 500  // 目標生産数 (任意)
}`}
                </code>
              </div>

              <Separator />

              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">Raspberry Pi サンプルコード (Python)</p>
                <code className="block text-xs bg-secondary/50 px-3 py-2 rounded-lg font-mono text-muted-foreground whitespace-pre overflow-x-auto">
{`import requests
from datetime import datetime, timezone

SERVER_URL = "${window.location.origin}/api/ingest"
API_KEY = "your-api-key-here"

def send_data(machine_id, period_start, period_end,
              state, running_sec, stopped_sec,
              idle_sec, production_count):
    payload = {
        "machineId": machine_id,
        "periodStart": period_start.isoformat(),
        "periodEnd": period_end.isoformat(),
        "state": state,
        "runningSeconds": running_sec,
        "stoppedSeconds": stopped_sec,
        "idleSeconds": idle_sec,
        "maintenanceSeconds": 0,
        "productionCount": production_count
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }
    response = requests.post(SERVER_URL, json=payload,
                             headers=headers, timeout=10)
    return response.json()`}
                </code>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* システム情報 */}
        <TabsContent value="system">
          <Card className="bg-card/80 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Info className="h-4 w-4 text-primary" />
                システム情報
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">システム名</span>
                <span>製造現場 機械稼働状況ダッシュボード</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">バージョン</span>
                <span>1.1.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">データベース</span>
                <span>MySQL (Manus Platform)</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
