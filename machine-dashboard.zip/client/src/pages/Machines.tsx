import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { type Machine } from "@/lib/types";
import { useState } from "react";
import { toast } from "sonner";
import { Factory, Plus, Pencil, Trash2, AlertCircle, PenLine } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface MachineFormData {
  machineId: string;
  machineName: string;
  machineType: string;
  location: string;
  lineName: string;
  description: string;
  isActive: boolean;
  targetProductionCount: number;
  sortOrder: number;
}

const EMPTY_FORM: MachineFormData = {
  machineId: "",
  machineName: "",
  machineType: "",
  location: "",
  lineName: "",
  description: "",
  isActive: true,
  targetProductionCount: 0,
  sortOrder: 0,
};

// 機械種別フィールド: ドロップダウン選択 + 自由入力切り替え
function MachineTypeField({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const { data: types } = trpc.machineTypes.list.useQuery();
  const [freeInput, setFreeInput] = useState(false);

  // 初回表示時: 既存値がリストにない場合は自由入力モードに切り替え
  const isInList = types?.some((t) => t.typeName === value);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label>
          機械種別 <span className="text-destructive">*</span>
        </Label>
        <button
          type="button"
          className="text-[11px] text-primary hover:underline flex items-center gap-1"
          onClick={() => {
            setFreeInput((v) => !v);
            if (freeInput) onChange(""); // 自由入力→ドロップダウンに戻す時はリセット
          }}
        >
          <PenLine className="h-3 w-3" />
          {freeInput ? "リストから選択" : "直接入力する"}
        </button>
      </div>

      {freeInput || (!isInList && value) ? (
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="種別名を直接入力（例: CNC加工機）"
          className="h-9"
        />
      ) : (
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger className="h-9">
            <SelectValue placeholder="種別を選択" />
          </SelectTrigger>
          <SelectContent>
            {types?.map((t) => (
              <SelectItem key={t.id} value={t.type_name}>
                {t.type_name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}

export default function Machines() {
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Machine | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Machine | null>(null);
  const [form, setForm] = useState<MachineFormData>(EMPTY_FORM);

  const utils = trpc.useUtils();
  const { data: machines, isLoading } = trpc.machines.list.useQuery({});

  const createMachine = trpc.machines.create.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      setFormOpen(false);
      toast.success("機械を追加しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const updateMachine = trpc.machines.update.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      setFormOpen(false);
      setEditTarget(null);
      toast.success("機械情報を更新しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const deleteMachine = trpc.machines.delete.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      setDeleteTarget(null);
      toast.success("機械を削除しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const openCreate = () => {
    setEditTarget(null);
    setForm(EMPTY_FORM);
    setFormOpen(true);
  };

  const openEdit = (machine: Machine) => {
    setEditTarget(machine);
    setForm({
      machineId: machine.machineId,
      machineName: machine.machineName,
      machineType: machine.machineType,
      location: machine.location ?? "",
      lineName: machine.lineName ?? "",
      description: machine.description ?? "",
      isActive: machine.isActive,
      targetProductionCount: machine.targetProductionCount ?? 0,
      sortOrder: machine.sortOrder ?? 0,
    });
    setFormOpen(true);
  };

  const handleSubmit = () => {
    if (!form.machineId || !form.machineName || !form.machineType) {
      toast.error("機械ID、機械名、機械種別は必須です");
      return;
    }
    if (editTarget) {
      updateMachine.mutate({
        machineId: form.machineId,
        machineName: form.machineName,
        machineType: form.machineType,
        location: form.location || null,
        lineName: form.lineName || null,
        description: form.description || null,
        isActive: form.isActive,
        targetProductionCount: form.targetProductionCount,
        sortOrder: form.sortOrder,
      });
    } else {
      createMachine.mutate({
        machineId: form.machineId,
        machineName: form.machineName,
        machineType: form.machineType,
        location: form.location || undefined,
        lineName: form.lineName || undefined,
        description: form.description || undefined,
        isActive: form.isActive,
        targetProductionCount: form.targetProductionCount,
        sortOrder: form.sortOrder,
      });
    }
  };

  return (
    <div className="space-y-5">
      {/* ヘッダー */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Factory className="h-5 w-5 text-primary" />
            機械マスター管理
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {machines?.length ?? 0}台登録済み
          </p>
        </div>
        <Button onClick={openCreate} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          機械を追加
        </Button>
      </div>

      {/* テーブル */}
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/50 border-b border-border">
            <tr>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">機械ID</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">機械名</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">種別</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden sm:table-cell">ライン</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">場所</th>
              <th className="text-right px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">目標生産数</th>
              <th className="text-center px-4 py-3 font-medium text-muted-foreground">状態</th>
              <th className="text-right px-4 py-3 font-medium text-muted-foreground">操作</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                  読み込み中...
                </td>
              </tr>
            ) : machines?.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Factory className="h-8 w-8 opacity-30" />
                    <p>機械が登録されていません</p>
                  </div>
                </td>
              </tr>
            ) : (
              machines?.map((machine, i) => (
                <tr
                  key={machine.machineId}
                  className={`border-t border-border/50 hover:bg-secondary/20 transition-colors ${i % 2 === 0 ? "" : "bg-secondary/10"}`}
                >
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                    {machine.machineId}
                  </td>
                  <td className="px-4 py-3 font-medium">{machine.machineName}</td>
                  <td className="px-4 py-3 text-muted-foreground">{machine.machineType}</td>
                  <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">
                    {machine.lineName ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">
                    {machine.location ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-right hidden lg:table-cell">
                    {machine.targetProductionCount?.toLocaleString() ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <Badge
                      variant="outline"
                      className={machine.isActive ? "text-emerald-400 border-emerald-400/30" : "text-muted-foreground"}
                    >
                      {machine.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => openEdit(machine as Machine)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => setDeleteTarget(machine as Machine)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 追加・編集フォーム */}
      <Dialog open={formOpen} onOpenChange={(v) => { if (!v) { setFormOpen(false); setEditTarget(null); } }}>
        <DialogContent className="max-w-lg bg-card border-border">
          <DialogHeader>
            <DialogTitle>{editTarget ? "機械情報を編集" : "機械を追加"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>機械ID <span className="text-destructive">*</span></Label>
                <Input
                  value={form.machineId}
                  onChange={(e) => setForm((p) => ({ ...p, machineId: e.target.value }))}
                  placeholder="例: MC-001"
                  disabled={!!editTarget}
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label>機械名 <span className="text-destructive">*</span></Label>
                <Input
                  value={form.machineName}
                  onChange={(e) => setForm((p) => ({ ...p, machineName: e.target.value }))}
                  placeholder="例: 第1プレス機"
                />
              </div>
            </div>

            {/* 機械種別: ドロップダウン + 自由入力切り替え */}
            <MachineTypeField
              value={form.machineType}
              onChange={(v) => setForm((p) => ({ ...p, machineType: v }))}
            />

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>ライン名</Label>
                <Input
                  value={form.lineName}
                  onChange={(e) => setForm((p) => ({ ...p, lineName: e.target.value }))}
                  placeholder="例: Aライン"
                />
              </div>
              <div className="space-y-1.5">
                <Label>設置場所</Label>
                <Input
                  value={form.location}
                  onChange={(e) => setForm((p) => ({ ...p, location: e.target.value }))}
                  placeholder="例: 第1工場"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>目標生産数 (日)</Label>
                <Input
                  type="number"
                  value={form.targetProductionCount}
                  onChange={(e) => setForm((p) => ({ ...p, targetProductionCount: parseInt(e.target.value) || 0 }))}
                  min={0}
                />
              </div>
              <div className="space-y-1.5">
                <Label>表示順</Label>
                <Input
                  type="number"
                  value={form.sortOrder}
                  onChange={(e) => setForm((p) => ({ ...p, sortOrder: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>備考</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                rows={2}
                placeholder="機械の説明や注意事項"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label>有効</Label>
              <Switch
                checked={form.isActive}
                onCheckedChange={(v) => setForm((p) => ({ ...p, isActive: v }))}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={() => { setFormOpen(false); setEditTarget(null); }} className="flex-1">
              キャンセル
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={createMachine.isPending || updateMachine.isPending}
              className="flex-1"
            >
              {editTarget ? "更新" : "追加"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 削除確認 */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              機械を削除しますか？
            </AlertDialogTitle>
            <AlertDialogDescription>
              「{deleteTarget?.machineName}」を削除します。この操作は元に戻せません。
              関連する稼働ログも削除される場合があります。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteMachine.mutate({ machineId: deleteTarget.machineId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              削除する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
