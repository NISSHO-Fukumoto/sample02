import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import MachineCard from "@/components/MachineCard";
import MachineDetailModal from "@/components/MachineDetailModal";
import DashboardSettingsModal from "@/components/DashboardSettingsModal";
import { trpc } from "@/lib/trpc";
import { calcMachineStatus, type Machine, type MachineLog, type DailyRecord, type DashboardLayout } from "@/lib/types";
import { useEffect, useRef, useState, useCallback } from "react";
import { toast } from "sonner";
import {
  Activity,
  LayoutGrid,
  Printer,
  RefreshCw,
  Settings2,
} from "lucide-react";

// 端末IDをlocalStorageで永続化
function getTerminalId(): string {
  const key = "machine-dashboard-terminal-id";
  let id = localStorage.getItem(key);
  if (!id) {
    id = `term_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem(key, id);
  }
  return id;
}

const DEFAULT_LAYOUT: DashboardLayout = {
  id: 0,
  terminalId: null,
  userId: null,
  layoutName: "デフォルト",
  cardOrder: [],
  visibleMachines: [],
  showTargetProduction: false,
  showActualProductionTime: false,
  showEnergyPlaceholder: false,
  showCostPlaceholder: false,
  refreshInterval: 300000,
  gridColumns: 3,
  createdAt: new Date(),
  updatedAt: new Date(),
};

export default function Dashboard() {
  const terminalId = useRef(getTerminalId());
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [layout, setLayout] = useState<DashboardLayout>(DEFAULT_LAYOUT);
  const [lastRefreshed, setLastRefreshed] = useState(new Date());

  // データ取得
  const { data: machines, isLoading: machinesLoading } = trpc.machines.list.useQuery({ activeOnly: true });
  const { data: latestLogs, isLoading: logsLoading, refetch: refetchLogs } = trpc.logs.latestPerMachine.useQuery();
  const { data: savedLayout } = trpc.layout.get.useQuery({ terminalId: terminalId.current });
  const { data: todayMaxTarget } = trpc.logs.todayMaxTarget.useQuery();

  // レイアウト保存
  useEffect(() => {
    if (savedLayout) {
      setLayout({
        ...DEFAULT_LAYOUT,
        ...savedLayout,
        cardOrder: (savedLayout.cardOrder as string[]) ?? [],
        visibleMachines: (savedLayout.visibleMachines as string[]) ?? [],
      });
    }
  }, [savedLayout]);

  // 自動更新
  useEffect(() => {
    if (layout.refreshInterval <= 0) return;
    const timer = setInterval(() => {
      refetchLogs();
      setLastRefreshed(new Date());
    }, layout.refreshInterval);
    return () => clearInterval(timer);
  }, [layout.refreshInterval, refetchLogs]);

  // ログをmachineIdでマップ化
  const logMap = new Map<string, MachineLog>();
  (latestLogs ?? []).forEach((log) => {
    logMap.set(log.machineId, log as MachineLog);
  });

  // 今日の日報データを取得
  const { data: dailyRecords } = trpc.dailyRecords.todayAll.useQuery();
  const dailyRecordMap = new Map<string, DailyRecord>();
  (dailyRecords ?? []).forEach((dr: any) => {
    dailyRecordMap.set(dr.machineId, dr as DailyRecord);
  });

  // 選択機械の詳細ログを取得
  const [detailDateRange] = useState(() => {
    const to = new Date();
    const from = new Date(to.getTime() - 7 * 24 * 60 * 60 * 1000);
    return { from, to };
  });
  const { data: selectedMachineLogs } = trpc.logs.history.useQuery(
    { machineId: selectedMachine?.machineId ?? "", from: detailDateRange.from, to: detailDateRange.to },
    { enabled: !!selectedMachine }
  );

  // 表示する機械の順序を決定
  const visibleMachines = (machines ?? []).filter((m) => {
    if (layout.visibleMachines && layout.visibleMachines.length > 0) {
      return layout.visibleMachines.includes(m.machineId);
    }
    return true;
  });

  const orderedMachines = [...visibleMachines].sort((a, b) => {
    const order = layout.cardOrder ?? [];
    const ai = order.indexOf(a.machineId);
    const bi = order.indexOf(b.machineId);
    if (ai === -1 && bi === -1) return (a.sortOrder ?? 0) - (b.sortOrder ?? 0);
    if (ai === -1) return 1;
    if (bi === -1) return -1;
    return ai - bi;
  });

  // 集計サマリー: 日毎データから合計値を計算
  const totalMachines = orderedMachines.length;
  const runningMachines = orderedMachines.filter((m) => {
    const log = logMap.get(m.machineId);
    const status = calcMachineStatus(
      log?.periodEnd ?? null,
      (m as Machine).durChoco ?? 60,
      (m as Machine).durDoka ?? 600,
      (m as Machine).durEnd ?? 3600
    );
    return status === "running";
  }).length;
  
  // 日毎データから集計を計算
  const totalRunTime = orderedMachines.reduce((sum, m) => {
    const dr = dailyRecordMap.get(m.machineId);
    return sum + (dr?.totalRunTime ?? 0);
  }, 0);
  
  const totalChocoTime = orderedMachines.reduce((sum, m) => {
    const dr = dailyRecordMap.get(m.machineId);
    return sum + (dr?.totalChocoTime ?? 0);
  }, 0);
  
  const totalDokaTime = orderedMachines.reduce((sum, m) => {
    const dr = dailyRecordMap.get(m.machineId);
    return sum + (dr?.totalDokaTime ?? 0);
  }, 0);
  
  const totalProductionFromDaily = orderedMachines.reduce((sum, m) => {
    const dr = dailyRecordMap.get(m.machineId);
    return sum + (dr?.totalCount ?? 0);
  }, 0);
  
  // 稼働率: 運転時間 / (運転時間 + 停止時間) * 100
  const totalStopTime = totalChocoTime + totalDokaTime;
  const avgRate = totalRunTime + totalStopTime > 0 
    ? (totalRunTime / (totalRunTime + totalStopTime)) * 100 
    : 0;
  
  const totalProduction = totalProductionFromDaily > 0 ? totalProductionFromDaily : orderedMachines.reduce((sum, m) => {
    const log = logMap.get(m.machineId);
    return sum + (log?.productionCount ?? 0);
  }, 0);

  const handleManualRefresh = useCallback(() => {
    refetchLogs();
    setLastRefreshed(new Date());
    toast.success("データを更新しました");
  }, [refetchLogs]);

  const handlePrint = () => {
    window.print();
  };

  const gridColsClass =
    layout.gridColumns === 1 ? "grid-cols-1" :
    layout.gridColumns === 2 ? "grid-cols-1 sm:grid-cols-2" :
    layout.gridColumns === 3 ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" :
    layout.gridColumns === 4 ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" :
    "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5";

  const isLoading = machinesLoading || logsLoading;

  return (
    <div className="space-y-5">
      {/* ヘッダー */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 print-hidden">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            稼働状況ダッシュボード
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            最終更新: {lastRefreshed.toLocaleTimeString("ja-JP")}
            {layout.refreshInterval > 0 && (
              <span className="ml-2 opacity-60">
                ({layout.refreshInterval / 60000}分毎に自動更新)
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2 no-print">
          <Select
            value={String(layout.gridColumns)}
            onValueChange={(v) => setLayout((prev) => ({ ...prev, gridColumns: parseInt(v) }))}
          >
            <SelectTrigger className="w-28 h-8 text-xs">
              <LayoutGrid className="h-3.5 w-3.5 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2">2列</SelectItem>
              <SelectItem value="3">3列</SelectItem>
              <SelectItem value="4">4列</SelectItem>
              <SelectItem value="5">5列</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={handleManualRefresh} className="h-8 gap-1.5">
            <RefreshCw className="h-3.5 w-3.5" />
            更新
          </Button>
          <Button variant="outline" size="sm" onClick={handlePrint} className="h-8 gap-1.5">
            <Printer className="h-3.5 w-3.5" />
            印刷
          </Button>
          <Button variant="outline" size="sm" onClick={() => setSettingsOpen(true)} className="h-8 gap-1.5">
            <Settings2 className="h-3.5 w-3.5" />
            表示設定
          </Button>
        </div>
      </div>

      {/* 印刷用ヘッダー */}
      <div className="print-header hidden">
        製造現場 機械稼働状況ダッシュボード
        <br />
        <span style={{ fontSize: "10pt", fontWeight: "normal" }}>
          {new Date().toLocaleString("ja-JP")}
        </span>
      </div>

      {/* サマリーカード: 日毎データから集計 */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <SummaryCard label="稼働率" value={`${avgRate.toFixed(1)}%`} colorClass={avgRate >= 85 ? "text-emerald-400" : avgRate >= 70 ? "text-yellow-400" : "text-red-400"} />
        <SummaryCard label="生産数" value={totalProduction.toLocaleString()} colorClass="text-primary" allowLineBreak={true} />
        <SummaryCard label="運転時間" value={`${Math.floor(totalRunTime / 60)}分`} colorClass="text-blue-400" />
        <SummaryCard label="停止時間" value={`${Math.floor((totalChocoTime + totalDokaTime) / 60)}分`} colorClass="text-red-400" />
      </div>

      {/* 機械カードグリッド */}
      {isLoading ? (
        <div className={`grid ${gridColsClass} gap-4`}>
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      ) : orderedMachines.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Activity className="h-12 w-12 text-muted-foreground/30 mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground">機械が登録されていません</h3>
          <p className="text-sm text-muted-foreground/60 mt-1">
            「機械マスター」から機械を追加してください
          </p>
        </div>
      ) : (
        <div className={`grid ${gridColsClass} gap-4 machine-card-grid`}>
          {orderedMachines.map((machine) => (
            <MachineCard
              key={machine.machineId}
              machine={machine as Machine}
              log={logMap.get(machine.machineId)}
              dailyRecord={dailyRecordMap.get(machine.machineId)}
              layout={layout}
              todayMaxTarget={todayMaxTarget}
              onClick={() => setSelectedMachine(machine as Machine)}
            />
          ))}
        </div>
      )}

      {/* 機械詳細モーダル */}
      {selectedMachine && (
        <MachineDetailModal
          machine={selectedMachine}
          logs={(selectedMachineLogs ?? []) as MachineLog[]}
          dailyRecord={dailyRecordMap.get(selectedMachine.machineId)}
          latestLog={logMap.get(selectedMachine.machineId)}
          todayMaxTarget={todayMaxTarget}
          open={!!selectedMachine}
          onClose={() => setSelectedMachine(null)}
        />
      )}

      {/* ダッシュボード設定モーダル */}
      <DashboardSettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        layout={layout}
        machines={(machines ?? []) as Machine[]}
        terminalId={terminalId.current}
        onSave={(newLayout) => {
          setLayout(newLayout);
          setSettingsOpen(false);
          toast.success("ダッシュボード設定を保存しました");
        }}
      />
    </div>
  );
}

function SummaryCard({ label, value, colorClass, allowLineBreak }: { label: string; value: string; colorClass: string; allowLineBreak?: boolean }) {
  return (
    <div className="bg-card/60 border border-border/50 rounded-xl p-4">
      <div className={`text-2xl font-bold tabular-nums ${colorClass} ${allowLineBreak ? 'break-words' : 'whitespace-nowrap'}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}
