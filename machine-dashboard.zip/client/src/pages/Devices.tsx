import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { type Device } from "@/lib/types";
import { useState } from "react";
import { toast } from "sonner";
import { Wifi, Plus, Pencil, Trash2, Copy, RefreshCw, AlertCircle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface DeviceFormData {
  deviceId: string;
  deviceName: string;
  machineId: string;
  ipAddress: string;
  location: string;
  isActive: boolean;
}

const EMPTY_FORM: DeviceFormData = {
  deviceId: "",
  deviceName: "",
  machineId: "",
  ipAddress: "",
  location: "",
  isActive: true,
};

export default function Devices() {
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Device | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Device | null>(null);
  const [form, setForm] = useState<DeviceFormData>(EMPTY_FORM);

  const utils = trpc.useUtils();
  const { data: devices, isLoading } = trpc.devices.list.useQuery();
  const { data: machines } = trpc.machines.list.useQuery({});

  const createDevice = trpc.devices.create.useMutation({
    onSuccess: () => {
      utils.devices.list.invalidate();
      setFormOpen(false);
      toast.success("デバイスを追加しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const updateDevice = trpc.devices.update.useMutation({
    onSuccess: () => {
      utils.devices.list.invalidate();
      setFormOpen(false);
      setEditTarget(null);
      toast.success("デバイス情報を更新しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const deleteDevice = trpc.devices.delete.useMutation({
    onSuccess: () => {
      utils.devices.list.invalidate();
      setDeleteTarget(null);
      toast.success("デバイスを削除しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const regenerateKey = trpc.devices.regenerateApiKey.useMutation({
    onSuccess: () => {
      utils.devices.list.invalidate();
      toast.success("APIキーを再生成しました");
    },
    onError: (e) => toast.error(`エラー: ${e.message}`),
  });

  const openCreate = () => {
    setEditTarget(null);
    setForm(EMPTY_FORM);
    setFormOpen(true);
  };

  const openEdit = (device: Device) => {
    setEditTarget(device);
    setForm({
      deviceId: device.deviceId,
      deviceName: device.deviceName ?? "",
      machineId: device.machineId ?? "",
      ipAddress: device.ipAddress ?? "",
      location: device.location ?? "",
      isActive: device.isActive,
    });
    setFormOpen(true);
  };

  const handleSubmit = () => {
    if (!form.deviceId) {
      toast.error("デバイスIDは必須です");
      return;
    }
    if (editTarget) {
      updateDevice.mutate({
        deviceId: form.deviceId,
        deviceName: form.deviceName || null,
        machineId: form.machineId || null,
        ipAddress: form.ipAddress || null,
        location: form.location || null,
        isActive: form.isActive,
      });
    } else {
      createDevice.mutate({
        deviceId: form.deviceId,
        deviceName: form.deviceName || undefined,
        machineId: form.machineId || undefined,
        ipAddress: form.ipAddress || undefined,
        location: form.location || undefined,
        isActive: form.isActive,
      });
    }
  };

  const copyApiKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast.success("APIキーをコピーしました");
  };

  const machineMap = new Map((machines ?? []).map((m) => [m.machineId, m.machineName]));

  return (
    <div className="space-y-5">
      {/* ヘッダー */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Wifi className="h-5 w-5 text-primary" />
            デバイス管理
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Raspberry Pi ノード端末の管理
          </p>
        </div>
        <Button onClick={openCreate} size="sm" className="gap-2">
          <Plus className="h-4 w-4" />
          デバイスを追加
        </Button>
      </div>

      {/* APIエンドポイント情報 */}
      <div className="bg-secondary/30 border border-border/50 rounded-xl p-4 space-y-2">
        <h3 className="text-sm font-medium">データ送信エンドポイント</h3>
        <div className="flex items-center gap-2">
          <code className="text-xs bg-secondary/50 px-3 py-1.5 rounded-lg text-primary font-mono flex-1">
            POST {window.location.origin}/api/ingest
          </code>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => {
              navigator.clipboard.writeText(`${window.location.origin}/api/ingest`);
              toast.success("URLをコピーしました");
            }}
          >
            <Copy className="h-3.5 w-3.5" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          認証: <code className="bg-secondary/50 px-1 rounded">Authorization: Bearer &lt;APIキー&gt;</code> または <code className="bg-secondary/50 px-1 rounded">X-Api-Key: &lt;APIキー&gt;</code>
        </p>
      </div>

      {/* テーブル */}
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/50 border-b border-border">
            <tr>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">デバイスID</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">名称</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">紐付け機械</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden md:table-cell">IPアドレス</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground hidden lg:table-cell">最終接続</th>
              <th className="text-left px-4 py-3 font-medium text-muted-foreground">APIキー</th>
              <th className="text-center px-4 py-3 font-medium text-muted-foreground">状態</th>
              <th className="text-right px-4 py-3 font-medium text-muted-foreground">操作</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">読み込み中...</td></tr>
            ) : devices?.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center">
                  <div className="flex flex-col items-center gap-2 text-muted-foreground">
                    <Wifi className="h-8 w-8 opacity-30" />
                    <p>デバイスが登録されていません</p>
                  </div>
                </td>
              </tr>
            ) : (
              devices?.map((device, i) => (
                <tr
                  key={device.deviceId}
                  className={`border-t border-border/50 hover:bg-secondary/20 transition-colors ${i % 2 === 0 ? "" : "bg-secondary/10"}`}
                >
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                    {device.deviceId}
                  </td>
                  <td className="px-4 py-3 font-medium">{device.deviceName ?? "—"}</td>
                  <td className="px-4 py-3">
                    {device.machineId ? (
                      <Badge variant="outline" className="text-xs text-primary border-primary/30">
                        {machineMap.get(device.machineId) ?? device.machineId}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-xs">未割り付け</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground font-mono text-xs hidden md:table-cell">
                    {device.ipAddress ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs hidden lg:table-cell">
                    {device.lastSeenAt
                      ? new Date(device.lastSeenAt).toLocaleString("ja-JP", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })
                      : "未接続"}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <code className="text-xs bg-secondary/50 px-2 py-0.5 rounded font-mono text-muted-foreground max-w-[120px] truncate">
                        {device.apiKey.slice(0, 12)}...
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => copyApiKey(device.apiKey)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        title="APIキーを再生成"
                        onClick={() => regenerateKey.mutate({ deviceId: device.deviceId })}
                      >
                        <RefreshCw className="h-3 w-3" />
                      </Button>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <Badge
                      variant="outline"
                      className={device.isActive ? "text-emerald-400 border-emerald-400/30" : "text-muted-foreground"}
                    >
                      {device.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(device as Device)}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => setDeleteTarget(device as Device)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* フォーム */}
      <Dialog open={formOpen} onOpenChange={(v) => { if (!v) { setFormOpen(false); setEditTarget(null); } }}>
        <DialogContent className="max-w-lg bg-card border-border">
          <DialogHeader>
            <DialogTitle>{editTarget ? "デバイスを編集" : "デバイスを追加"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>デバイスID <span className="text-destructive">*</span></Label>
                <Input
                  value={form.deviceId}
                  onChange={(e) => setForm((p) => ({ ...p, deviceId: e.target.value }))}
                  placeholder="例: rpi-001"
                  disabled={!!editTarget}
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label>デバイス名</Label>
                <Input
                  value={form.deviceName}
                  onChange={(e) => setForm((p) => ({ ...p, deviceName: e.target.value }))}
                  placeholder="例: 第1工場ノード"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>紐付け機械</Label>
              <Select
                value={form.machineId || "none"}
                onValueChange={(v) => setForm((p) => ({ ...p, machineId: v === "none" ? "" : v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="機械を選択 (任意)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">未割り付け</SelectItem>
                  {(machines ?? []).map((m) => (
                    <SelectItem key={m.machineId} value={m.machineId}>
                      {m.machineName} ({m.machineId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                デバイスに機械を紐付けると、APIリクエスト時にmachineIdを省略できます
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>IPアドレス</Label>
                <Input
                  value={form.ipAddress}
                  onChange={(e) => setForm((p) => ({ ...p, ipAddress: e.target.value }))}
                  placeholder="例: 192.168.1.100"
                  className="font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label>設置場所</Label>
                <Input
                  value={form.location}
                  onChange={(e) => setForm((p) => ({ ...p, location: e.target.value }))}
                  placeholder="例: 第1工場"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Label>有効</Label>
              <Switch
                checked={form.isActive}
                onCheckedChange={(v) => setForm((p) => ({ ...p, isActive: v }))}
              />
            </div>

            {!editTarget && (
              <p className="text-xs text-muted-foreground bg-secondary/30 rounded-lg p-3">
                APIキーは自動生成されます。デバイス追加後に確認・コピーしてください。
              </p>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={() => { setFormOpen(false); setEditTarget(null); }} className="flex-1">
              キャンセル
            </Button>
            <Button onClick={handleSubmit} disabled={createDevice.isPending || updateDevice.isPending} className="flex-1">
              {editTarget ? "更新" : "追加"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* 削除確認 */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              デバイスを削除しますか？
            </AlertDialogTitle>
            <AlertDialogDescription>
              「{deleteTarget?.deviceName ?? deleteTarget?.deviceId}」を削除します。この操作は元に戻せません。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTarget && deleteDevice.mutate({ deviceId: deleteTarget.deviceId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              削除する
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
