// ===== Machine Types =====
export type MachineState = "running" | "stopped" | "idle" | "maintenance";

// ===== リアルタイムステータス（閾値ベース） =====
export type MachineStatus = "running" | "choco" | "doka" | "off";

export interface DailyRecord {
  id: number;
  recordDate: string | Date;
  machineId: string;
  totalCount: number;
  totalRunTime: number;
  totalChocoTime: number;
  totalDokaTime: number;
  totalStopTime: number;
  utilizationRate?: string | null;
  updatedAt: Date;
}

export interface StopEvent {
  id: number;
  machineId: string;
  stopType: "CHOCO" | "DOKA";
  startTime: Date;
  endTime?: Date | null;
  duration?: number | null;
  manualReason?: string | null;
  createdAt: Date;
}

export interface Machine {
  id: number;
  machineId: string;
  machineName: string;
  machineType: string;
  location?: string | null;
  lineName?: string | null;
  description?: string | null;
  isActive: boolean;
  targetProductionCount?: number | null;
  sortOrder?: number | null;
  // 閾値・稼働設定
  timeStart?: string | null;
  timeEnd?: string | null;
  durChoco?: number | null;   // チョコ停判定秒数（デフォルト60秒）
  durDoka?: number | null;    // ドカ停判定秒数（デフォルト600秒）
  durEnd?: number | null;     // 電源OFF判定秒数（デフォルト3600秒）
  breakTimes?: unknown;
  createdAt: Date;
  updatedAt: Date;
}

export interface Device {
  id: number;
  deviceId: string;
  deviceName?: string | null;
  apiKey: string;
  machineId?: string | null;
  ipAddress?: string | null;
  location?: string | null;
  isActive: boolean;
  lastSeenAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface MachineLog {
  id: number;
  machineId: string;
  deviceId?: string | null;
  periodStart: Date;
  periodEnd: Date;
  state: MachineState;
  runningSeconds: number;
  stoppedSeconds: number;
  idleSeconds: number;
  maintenanceSeconds: number;
  totalSeconds: number;
  operationRate?: string | null;
  productionCount: number;
  targetProductionCount?: number | null;
  // 将来拡張項目
  steamConsumption?: string | null;
  electricityConsumption?: string | null;
  airConsumption?: string | null;
  gasConsumption?: string | null;
  waterConsumption?: string | null;
  hotWaterConsumption?: string | null;
  laborCost?: string | null;
  productionCost?: string | null;
  productionRevenue?: string | null;
  rawData?: unknown;
  createdAt: Date;
}

export interface DashboardLayout {
  id: number;
  userId?: number | null;
  terminalId?: string | null;
  layoutName?: string | null;
  cardOrder?: string[] | null;
  visibleMachines?: string[] | null;
  showTargetProduction: boolean;
  showActualProductionTime: boolean;
  showEnergyPlaceholder: boolean;
  showCostPlaceholder: boolean;
  refreshInterval: number;
  gridColumns: number;
  createdAt: Date;
  updatedAt: Date;
}

// ===== Dashboard Card Data =====
export interface MachineCardData {
  machine: Machine;
  latestLog?: MachineLog | null;
}

// ===== Utility =====
export function formatSeconds(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}時間${m}分`;
  if (m > 0) return `${m}分${s}秒`;
  return `${s}秒`;
}

export function getStateLabel(state: MachineState): string {
  const labels: Record<MachineState, string> = {
    running: "稼働中",
    stopped: "停止",
    idle: "チョコ停",
    maintenance: "メンテナンス",
  };
  return labels[state] ?? state;
}

export function getStateColor(state: MachineState): string {
  const colors: Record<MachineState, string> = {
    running: "text-emerald-400",
    stopped: "text-red-400",
    idle: "text-yellow-400",
    maintenance: "text-purple-400",
  };
  return colors[state] ?? "text-gray-400";
}

export function getOperationRateColor(rate: number): string {
  if (rate >= 85) return "text-emerald-400";
  if (rate >= 70) return "text-yellow-400";
  if (rate >= 50) return "text-orange-400";
  return "text-red-400";
}

export function getOperationRateGlow(rate: number): string {
  if (rate >= 85) return "shadow-emerald-500/20";
  if (rate >= 70) return "shadow-yellow-500/20";
  return "shadow-red-500/20";
}

/**
 * 最終カウント時刻から経過秒数を計算し、機械のリアルタイムステータスを返す
 * @param lastCountAt 最終カウント時刻（最新ログのperiodEnd）
 * @param durChoco チョコ停判定秒数（デフォルト60）
 * @param durDoka ドカ停判定秒数（デフォルト600）
 * @param durEnd 電源OFF判定秒数（デフォルト3600）
 */
export function calcMachineStatus(
  lastCountAt: Date | null | undefined,
  durChoco = 60,
  durDoka = 600,
  durEnd = 3600
): MachineStatus {
  if (!lastCountAt) return "off";
  const elapsed = Math.floor((Date.now() - new Date(lastCountAt).getTime()) / 1000);
  if (elapsed < durChoco) return "running";
  if (elapsed < durDoka) return "choco";
  if (elapsed < durEnd) return "doka";
  return "off";
}

export function getMachineStatusLabel(status: MachineStatus): string {
  const labels: Record<MachineStatus, string> = {
    running: "稼働中",
    choco: "チョコ停疑い",
    doka: "ドカ停中",
    off: "電源OFF",
  };
  return labels[status];
}

export function getMachineStatusColor(status: MachineStatus): {
  badge: string;
  dot: string;
  border: string;
  glow: string;
  ring: string;
} {
  switch (status) {
    case "running":
      return {
        badge: "text-emerald-400 border-emerald-500/40",
        dot: "bg-emerald-400",
        border: "border-emerald-500/50 hover:border-emerald-400/70",
        glow: "shadow-lg shadow-emerald-500/15",
        ring: "",
      };
    case "choco":
      return {
        badge: "text-yellow-400 border-yellow-500/40",
        dot: "bg-yellow-400",
        border: "border-yellow-500/50 hover:border-yellow-400/70",
        glow: "shadow-lg shadow-yellow-500/15",
        ring: "",
      };
    case "doka":
      return {
        badge: "text-red-400 border-red-500/60",
        dot: "bg-red-400",
        border: "border-red-500/70 hover:border-red-400/90",
        glow: "shadow-xl shadow-red-500/30",
        ring: "ring-2 ring-red-500/50 animate-pulse-border",
      };
    case "off":
      return {
        badge: "text-gray-400 border-gray-500/40",
        dot: "bg-gray-400",
        border: "border-gray-500/30 hover:border-gray-400/50",
        glow: "shadow-md shadow-gray-500/10",
        ring: "",
      };
  }
}
