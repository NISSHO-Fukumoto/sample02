/**
 * PostgreSQL テーブル初期化スクリプト
 * 使用方法: node scripts/setup-db.mjs
 */
import pg from "pg";

const { Client } = pg;

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

// Try without SSL first, then with SSL
const client = new Client({
  connectionString,
  ssl: process.env.DATABASE_URL?.includes('sslmode=require') 
    ? { rejectUnauthorized: false } 
    : false,
});

await client.connect();
console.log("Connected to PostgreSQL");

const sql = `
-- Enums
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('user', 'admin');
EXCEPTION WHEN duplicate_object THEN null; END $$;

DO $$ BEGIN
  CREATE TYPE machine_state AS ENUM ('running', 'stopped', 'idle', 'maintenance');
EXCEPTION WHEN duplicate_object THEN null; END $$;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  open_id VARCHAR(64) NOT NULL UNIQUE,
  name TEXT,
  email VARCHAR(320),
  login_method VARCHAR(64),
  role user_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL,
  last_signed_in TIMESTAMP DEFAULT NOW() NOT NULL
);

-- Machines
CREATE TABLE IF NOT EXISTS machines (
  id SERIAL PRIMARY KEY,
  machine_id VARCHAR(50) NOT NULL UNIQUE,
  machine_name VARCHAR(100) NOT NULL,
  machine_type VARCHAR(50) NOT NULL,
  location VARCHAR(100),
  line_name VARCHAR(50),
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  target_production_count INTEGER DEFAULT 0,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL
);

-- Devices
CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  device_id VARCHAR(64) NOT NULL UNIQUE,
  device_name VARCHAR(100),
  api_key VARCHAR(128) NOT NULL UNIQUE,
  machine_id VARCHAR(50) REFERENCES machines(machine_id),
  ip_address VARCHAR(45),
  location VARCHAR(100),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  last_seen_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL
);

-- Machine Logs
CREATE TABLE IF NOT EXISTS machine_logs (
  id BIGSERIAL PRIMARY KEY,
  machine_id VARCHAR(50) NOT NULL REFERENCES machines(machine_id),
  device_id VARCHAR(64) REFERENCES devices(device_id),
  period_start TIMESTAMP NOT NULL,
  period_end TIMESTAMP NOT NULL,
  state machine_state NOT NULL DEFAULT 'stopped',
  running_seconds INTEGER NOT NULL DEFAULT 0,
  stopped_seconds INTEGER NOT NULL DEFAULT 0,
  idle_seconds INTEGER NOT NULL DEFAULT 0,
  maintenance_seconds INTEGER NOT NULL DEFAULT 0,
  total_seconds INTEGER NOT NULL DEFAULT 0,
  operation_rate DECIMAL(5,2) DEFAULT 0,
  production_count INTEGER NOT NULL DEFAULT 0,
  target_production_count INTEGER DEFAULT 0,
  steam_consumption DECIMAL(10,3),
  electricity_consumption DECIMAL(10,3),
  air_consumption DECIMAL(10,3),
  gas_consumption DECIMAL(10,3),
  water_consumption DECIMAL(10,3),
  hot_water_consumption DECIMAL(10,3),
  labor_cost DECIMAL(12,2),
  production_cost DECIMAL(12,2),
  production_revenue DECIMAL(12,2),
  raw_data JSONB,
  created_at TIMESTAMP DEFAULT NOW() NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_machine_logs_machine_period ON machine_logs (machine_id, period_start DESC);
CREATE INDEX IF NOT EXISTS idx_machine_logs_device ON machine_logs (device_id);

-- Dashboard Layouts
CREATE TABLE IF NOT EXISTS dashboard_layouts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  terminal_id VARCHAR(128),
  layout_name VARCHAR(100) DEFAULT 'デフォルト',
  card_order JSONB DEFAULT '[]',
  visible_machines JSONB DEFAULT '[]',
  show_target_production BOOLEAN NOT NULL DEFAULT FALSE,
  show_actual_production_time BOOLEAN NOT NULL DEFAULT FALSE,
  show_energy_placeholder BOOLEAN NOT NULL DEFAULT FALSE,
  show_cost_placeholder BOOLEAN NOT NULL DEFAULT FALSE,
  refresh_interval INTEGER NOT NULL DEFAULT 300000,
  grid_columns INTEGER NOT NULL DEFAULT 3,
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL
);

-- System Settings
CREATE TABLE IF NOT EXISTS system_settings (
  id SERIAL PRIMARY KEY,
  ingest_api_key VARCHAR(256) DEFAULT '',
  default_refresh_interval INTEGER NOT NULL DEFAULT 300000,
  created_at TIMESTAMP DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW() NOT NULL
);

INSERT INTO system_settings (ingest_api_key, default_refresh_interval)
SELECT 'default-ingest-key-change-me', 300000
WHERE NOT EXISTS (SELECT 1 FROM system_settings);
`;

try {
  await client.query(sql);
  console.log("Database tables created successfully!");
} catch (err) {
  console.error("Error creating tables:", err.message);
  process.exit(1);
} finally {
  await client.end();
}
