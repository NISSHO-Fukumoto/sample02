import { describe, expect, it } from "vitest";
import { generateReportHtml } from "./reportTemplate";
import type { ReportData } from "./db";

function makeReportData(overrides: Partial<ReportData> = {}): ReportData {
  const now = new Date("2026-02-22T09:00:00Z");
  const from = new Date("2026-02-15T00:00:00Z");
  const to = new Date("2026-02-21T23:59:59Z");

  return {
    period: {
      from,
      to,
    },
    generatedAt: now,
    overallSummary: {
      totalMachines: 6,
      activeMachines: 4,
      avgOperationRate: 78.5,
      totalProductionCount: 12500,
      totalRunningSeconds: 172800,
      totalStoppedSeconds: 28800,
      totalIdleSeconds: 14400,
    },
    machineSummaries: [
      {
        machineId: "MC-001",
        machineName: "プレス機 A",
        machineType: "プレス機",
        lineName: "ライン1",
        location: "第1工場",
        totalRunningSeconds: 43200,
        totalStoppedSeconds: 7200,
        totalIdleSeconds: 3600,
        totalMaintenanceSeconds: 0,
        totalSeconds: 54000,
        avgOperationRate: 80.0,
        totalProductionCount: 3200,
        targetProductionCount: 4000,
        achievementRate: 80.0,
        logCount: 7,
      },
      {
        machineId: "MC-002",
        machineName: "溶接機 B",
        machineType: "溶接機",
        lineName: "ライン2",
        location: "第1工場",
        totalRunningSeconds: 36000,
        totalStoppedSeconds: 10800,
        totalIdleSeconds: 7200,
        totalMaintenanceSeconds: 0,
        totalSeconds: 54000,
        avgOperationRate: 66.7,
        totalProductionCount: 2100,
        targetProductionCount: null,
        achievementRate: null,
        logCount: 7,
      },
    ],
    timeSeriesData: [
      {
        date: "2026/02/15",
        avgOperationRate: 82.0,
        totalProductionCount: 1800,
        totalRunningSeconds: 28800,
        totalStoppedSeconds: 4800,
        totalIdleSeconds: 2400,
      },
      {
        date: "2026/02/16",
        avgOperationRate: 75.5,
        totalProductionCount: 1600,
        totalRunningSeconds: 25200,
        totalStoppedSeconds: 5400,
        totalIdleSeconds: 3600,
      },
    ],
    ...overrides,
  };
}

describe("generateReportHtml", () => {
  it("returns valid HTML string with title", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "週次稼働レポート");
    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain("週次稼働レポート");
  });

  it("includes period label in output", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テストレポート");
    expect(html).toContain("2026/2/14 〜 2026/2/21");
  });

  it("includes overall summary stats", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("78.5%");
    expect(html).toContain("12,500");
  });

  it("includes machine names in table rows", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("プレス機 A");
    expect(html).toContain("溶接機 B");
  });

  it("shows achievement rate when target is set", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("80.0%");
  });

  it("shows dash when achievement rate is null", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    // 溶接機 B has null achievementRate → should show —
    expect(html).toContain("—");
  });

  it("includes time series data when present", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("2026/02/15");
    expect(html).toContain("82.0%");
  });

  it("handles empty machine summaries gracefully", () => {
    const data = makeReportData({ machineSummaries: [] });
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("データなし");
  });

  it("handles empty time series data gracefully", () => {
    // Use different dates to avoid collision with period label
    const data = makeReportData({
      timeSeriesData: [],
      period: { from: new Date("2026-01-01"), to: new Date("2026-01-07"), label: "2026/01/01 〜 2026/01/07" },
    });
    const html = generateReportHtml(data, "テスト");
    // The time series rows (2026/02/15, 2026/02/16) should not appear
    expect(html).not.toContain("2026/02/15");
    expect(html).not.toContain("2026/02/16");
  });

  it("includes time breakdown bar", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("時間内訳");
    expect(html).toContain("運転");
    expect(html).toContain("チョコ停");
    expect(html).toContain("停止");
  });

  it("generates valid HTML structure", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("<html");
    expect(html).toContain("</html>");
    expect(html).toContain("<body>");
    expect(html).toContain("</body>");
  });

  it("includes print-color-adjust style for PDF", () => {
    const data = makeReportData();
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("print-color-adjust");
  });
});

describe("report period calculation", () => {
  it("correctly formats seconds to hours and minutes", () => {
    // Test via HTML output
    const data = makeReportData({
      overallSummary: {
        totalMachines: 1,
        activeMachines: 1,
        avgOperationRate: 80,
        totalProductionCount: 100,
        totalRunningSeconds: 7200, // 2時間
        totalStoppedSeconds: 1800, // 30分
        totalIdleSeconds: 0,
      },
    });
    const html = generateReportHtml(data, "テスト");
    expect(html).toContain("2時間");
  });
});
