import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { COOKIE_NAME } from "../shared/const";

// Mock db functions
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
  getMachines: vi.fn().mockResolvedValue([
    {
      id: 1,
      machineId: "MC-001",
      machineName: "第1プレス機",
      machineType: "プレス機",
      location: "第1工場",
      lineName: "Aライン",
      description: null,
      isActive: true,
      targetProductionCount: 500,
      sortOrder: 1,
      createdAt: new Date("2025-01-01"),
      updatedAt: new Date("2025-01-01"),
    },
  ]),
  getMachineById: vi.fn().mockResolvedValue({
    id: 1,
    machineId: "MC-001",
    machineName: "第1プレス機",
    machineType: "プレス機",
    location: "第1工場",
    lineName: "Aライン",
    description: null,
    isActive: true,
    targetProductionCount: 500,
    sortOrder: 1,
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
  }),
  getDevices: vi.fn().mockResolvedValue([
    {
      id: 1,
      deviceId: "DEV-001",
      deviceName: "Raspberry Pi #1",
      apiKey: "test-api-key-12345678901234",
      machineId: "MC-001",
      ipAddress: "192.168.1.100",
      location: "第1工場",
      isActive: true,
      lastSeenAt: new Date("2025-01-01"),
      createdAt: new Date("2025-01-01"),
      updatedAt: new Date("2025-01-01"),
    },
  ]),
  getDeviceByApiKey: vi.fn().mockResolvedValue(null),
  getDeviceById: vi.fn().mockResolvedValue(null),
  getLatestLogPerMachine: vi.fn().mockResolvedValue([
    {
      id: 1,
      machineId: "MC-001",
      deviceId: "DEV-001",
      periodStart: new Date("2025-01-01T08:00:00"),
      periodEnd: new Date("2025-01-01T17:00:00"),
      state: "running",
      runningSeconds: 28800,
      stoppedSeconds: 1800,
      idleSeconds: 600,
      maintenanceSeconds: 0,
      totalSeconds: 32400,
      operationRate: "88.89",
      productionCount: 450,
      targetProductionCount: 500,
      steamConsumption: null,
      electricityConsumption: null,
      airConsumption: null,
      gasConsumption: null,
      waterConsumption: null,
      hotWaterConsumption: null,
      laborCost: null,
      productionCost: null,
      productionRevenue: null,
      rawData: null,
      createdAt: new Date("2025-01-01"),
    },
  ]),
  getMachineLogHistory: vi.fn().mockResolvedValue([]),
  getDashboardLayout: vi.fn().mockResolvedValue(null),
  saveDashboardLayout: vi.fn().mockResolvedValue({
    id: 1,
    userId: null,
    terminalId: "term_test123",
    layoutName: "デフォルト",
    cardOrder: ["MC-001"],
    visibleMachines: ["MC-001"],
    showTargetProduction: true,
    showActualProductionTime: false,
    showEnergyPlaceholder: false,
    showCostPlaceholder: false,
    refreshInterval: 300000,
    gridColumns: 3,
    createdAt: new Date("2025-01-01"),
    updatedAt: new Date("2025-01-01"),
  }),
  upsertUser: vi.fn().mockResolvedValue(undefined),
  getUserByOpenId: vi.fn().mockResolvedValue(null),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "テストユーザー",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const ctx = createPublicContext();
    const clearedCookies: { name: string; options: Record<string, unknown> }[] = [];
    ctx.res.clearCookie = (name: string, options: Record<string, unknown>) => {
      clearedCookies.push({ name, options });
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
  });
});

describe("machines.list", () => {
  it("returns a list of machines", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.machines.list({});
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("machineId");
    expect(result[0]).toHaveProperty("machineName");
  });

  it("returns active machines only when activeOnly=true", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.machines.list({ activeOnly: true });
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("machines.get", () => {
  it("returns a specific machine by ID", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.machines.get({ machineId: "MC-001" });
    expect(result).toBeDefined();
    expect(result?.machineId).toBe("MC-001");
    expect(result?.machineName).toBe("第1プレス機");
  });
});

describe("devices.list", () => {
  it("returns a list of devices", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.devices.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("deviceId");
    expect(result[0]).toHaveProperty("apiKey");
  });
});

describe("logs.latestPerMachine", () => {
  it("returns the latest log for each machine", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.logs.latestPerMachine();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    const log = result[0];
    expect(log).toHaveProperty("machineId");
    expect(log).toHaveProperty("operationRate");
    expect(log).toHaveProperty("runningSeconds");
    expect(log).toHaveProperty("stoppedSeconds");
    expect(log).toHaveProperty("idleSeconds");
    expect(log).toHaveProperty("productionCount");
  });
});

describe("logs.history", () => {
  it("returns historical logs for a machine", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const from = new Date("2025-01-01");
    const to = new Date("2025-01-07");
    const result = await caller.logs.history({ machineId: "MC-001", from, to });
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("layout.get", () => {
  it("returns default layout when no layout is saved for a terminal", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.layout.get({ terminalId: "term_nonexistent" });
    expect(result).toBeDefined();
    expect(result.terminalId).toBe("term_nonexistent");
    expect(result.layoutName).toBe("default");
    expect(result.gridColumns).toBe(3);
  });
});


describe("layout.save", () => {
  it("saves and returns a dashboard layout", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.layout.save({
      terminalId: "term_test123",
      layoutName: "テスト設定",
      cardOrder: ["MC-001"],
      visibleMachines: ["MC-001"],
      showTargetProduction: true,
      showActualProductionTime: false,
      showEnergyPlaceholder: false,
      showCostPlaceholder: false,
      refreshInterval: 300000,
      gridColumns: 3,
    });
    expect(result).toBeDefined();
    expect(result?.terminalId).toBe("term_test123");
    expect(result?.showTargetProduction).toBe(true);
    expect(result?.gridColumns).toBe(3);
  });
});

describe("machines.create (protected)", () => {
  it("requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.machines.create({
        machineId: "MC-999",
        machineName: "テスト機械",
        machineType: "プレス機",
        isActive: true,
        targetProductionCount: 100,
        sortOrder: 0,
      })
    ).rejects.toThrow();
  });
});

describe("devices.regenerateApiKey (protected)", () => {
  it("requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.devices.regenerateApiKey({ deviceId: "DEV-001" })
    ).rejects.toThrow();
  });
});
