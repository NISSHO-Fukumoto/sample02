import { drizzle } from "drizzle-orm/mysql2";
import {
  dashboardLayouts,
  devices,
  InsertUser,
  machineLogs,
  machines,
  users,
  dailyRecords,
  stopEvents,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== Users =====
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.warn("[Database] Failed to upsert user:", error);
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

// ===== Machines =====
export async function getMachines(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const result = await db.select().from(machines);
  if (activeOnly) return result.filter(m => m.isActive);
  return result;
}

export async function getMachineById(machineId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(machines).where(eq(machines.machineId, machineId)).limit(1);
  return result[0];
}

// ===== Devices =====
export async function getDevices() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(devices);
}

export async function getDeviceByApiKey(apiKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(devices).where(eq(devices.apiKey, apiKey)).limit(1);
  return result[0];
}

export async function getDeviceById(deviceId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(devices).where(eq(devices.deviceId, deviceId)).limit(1);
  return result[0];
}

// ===== Machine Logs =====
export async function getLatestLogPerMachine() {
  const db = await getDb();
  if (!db) return [];
  // 各機械の最新ログを取得
  const allMachines = await getMachines(true);
  const results = [];
  for (const machine of allMachines) {
    const logs = await db
      .select()
      .from(machineLogs)
      .where(eq(machineLogs.machineId, machine.machineId))
      .orderBy(desc(machineLogs.periodEnd))
      .limit(1);
    if (logs[0]) results.push(logs[0]);
  }
  return results;
}

export async function getMachineLogHistory(machineId: string, from: Date, to: Date, limit: number = 200) {
  const db = await getDb();
  if (!db) return [];
  
  // 本日のデータのみを取得（production_count != 0）
  // 時間毎（年月日時）でグループ化して、各時間の最新レコード（row_num = 1）のみを取得
  const logs = await db
    .select()
    .from(machineLogs)
    .where(
      and(
        eq(machineLogs.machineId, machineId),
        gte(machineLogs.createdAt, from),
        lte(machineLogs.createdAt, to)
      )
    )
    .orderBy(desc(machineLogs.createdAt))
    .limit(limit);
  
  // 時間毎（年月日時）でグループ化して、各時間の最新レコードのみをフィルタリング
  const hourlyMap = new Map();
  for (const log of logs) {
    // production_count != 0 の条件をチェック
    if (log.productionCount === 0) continue;
    
    const createdAtDate = new Date(log.createdAt);
    // JST時刻で「年月日時」をキーとする
    const jstDate = new Date(createdAtDate.getTime() + 9 * 60 * 60 * 1000);
    const hourKey = jstDate.toISOString().substring(0, 13); // YYYY-MM-DDTHH
    
    if (!hourlyMap.has(hourKey)) {
      hourlyMap.set(hourKey, log);
    }
  }
  
  // Map の値を配列に変換して、created_at でソート
  return Array.from(hourlyMap.values()).sort((a, b) => 
    b.createdAt.getTime() - a.createdAt.getTime()
  );
}

// ===== Dashboard Layouts =====
export async function getDashboardLayout(terminalId: string) {
  const db = await getDb();
  if (!db) return undefined;
  try {
    const result = await db
      .select()
      .from(dashboardLayouts)
      .where(eq(dashboardLayouts.terminalId, terminalId))
      .limit(1);
    return result[0];
  } catch (error) {
    console.warn("[Database] Failed to get dashboard layout:", error);
    return undefined;
  }
}

export async function saveDashboardLayout(data: {
  terminalId: string;
  layoutName?: string;
  cardOrder?: string[];
  visibleMachines?: string[];
  showTargetProduction: boolean;
  showActualProductionTime: boolean;
  showEnergyPlaceholder: boolean;
  showCostPlaceholder: boolean;
  refreshInterval: number;
  gridColumns: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    const existing = await getDashboardLayout(data.terminalId);
  if (existing) {
    await db
      .update(dashboardLayouts)
      .set({
        layoutName: data.layoutName ?? "デフォルト",
        cardOrder: data.cardOrder ?? [],
        visibleMachines: data.visibleMachines ?? [],
        showTargetProduction: data.showTargetProduction,
        showActualProductionTime: data.showActualProductionTime,
        showEnergyPlaceholder: data.showEnergyPlaceholder,
        showCostPlaceholder: data.showCostPlaceholder,
        refreshInterval: data.refreshInterval,
        gridColumns: data.gridColumns,
      })
      .where(eq(dashboardLayouts.terminalId, data.terminalId));
  } else {
    await db
      .insert(dashboardLayouts)
      .values({
        terminalId: data.terminalId,
        layoutName: data.layoutName ?? "デフォルト",
        cardOrder: data.cardOrder ?? [],
        visibleMachines: data.visibleMachines ?? [],
        showTargetProduction: data.showTargetProduction,
        showActualProductionTime: data.showActualProductionTime,
        showEnergyPlaceholder: data.showEnergyPlaceholder,
        showCostPlaceholder: data.showCostPlaceholder,
        refreshInterval: data.refreshInterval,
        gridColumns: data.gridColumns,
      });
  }
  } catch (error) {
    console.warn("[Database] Failed to save dashboard layout:", error);
  }
}

// ===== Report Data =====
export interface MachineSummary {
  machineId: string;
  machineName: string;
  machineType: string;
  lineName: string | null;
  location: string | null;
  totalRunningSeconds: number;
  totalStoppedSeconds: number;
  totalIdleSeconds: number;
  totalMaintenanceSeconds: number;
  totalSeconds: number;
  avgOperationRate: number;
  totalProductionCount: number;
  targetProductionCount: number | null;
  achievementRate: number | null;
  logCount: number;
}

export interface ReportData {
  period: { from: Date; to: Date };
  generatedAt: Date;
  overallSummary: {
    totalMachines: number;
    activeMachines: number;
    avgOperationRate: number;
    totalProductionCount: number;
    totalRunningSeconds: number;
    totalStoppedSeconds: number;
    totalIdleSeconds: number;
  };
  machineSummaries: MachineSummary[];
  timeSeriesData: {
    date: string;
    avgOperationRate: number;
    totalProductionCount: number;
    totalRunningSeconds: number;
    totalStoppedSeconds: number;
    totalIdleSeconds: number;
  }[];
}

export async function getReportData(from: Date, to: Date): Promise<ReportData> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const allMachines = await getMachines(false);
  
  // SQL ベースのロジック: 時間別・機械別の最新レコードのみを取得
  // production_count != 0 のレコードのみを使用
  // Drizzle ORM の sql 関数を使用して、生の SQL クエリを実行
  // 提供いただいた SQL クエリを使用して、日事別の集計を取得
  const queryResult = await db.execute(sql`
    SELECT
      target_date,
      machine_id,
      SUM(running_seconds) AS total_running_seconds,
      SUM(stopped_seconds) AS total_stopped_seconds,
      SUM(idle_seconds) AS total_idle_seconds,
      SUM(maintenance_seconds) AS total_maintenance_seconds,
      SUM(total_seconds) AS total_time_seconds,
      SUM(production_count) AS total_production_count,
      MAX(target_production_count) AS target_production_count,
      SEC_TO_TIME(SUM(running_seconds)) AS running_time,
      SEC_TO_TIME(SUM(idle_seconds)) AS idle_time,
      SEC_TO_TIME(SUM(stopped_seconds)) AS stop_time,
      SEC_TO_TIME(SUM(maintenance_seconds)) AS maintenance_time
    FROM (
      SELECT
        machine_id,
        running_seconds,
        stopped_seconds,
        idle_seconds,
        maintenance_seconds,
        total_seconds,
        production_count,
        target_production_count,
        DATE(CONVERT_TZ(created_at, '+00:00', '+09:00')) AS target_date,
        ROW_NUMBER() OVER (
          PARTITION BY machine_id, DATE_FORMAT(CONVERT_TZ(created_at, '+00:00', '+09:00'), '%Y-%m-%d %H')
          ORDER BY created_at DESC
        ) AS row_num
      FROM machine_logs
      WHERE production_count != 0
        AND created_at >= ${from}
        AND created_at < ${to}
    ) AS HourlyLatestLogs
    WHERE row_num = 1
    GROUP BY target_date, machine_id
    ORDER BY target_date DESC, machine_id ASC
  `);
  
  let rawLogs = Array.isArray(queryResult) ? queryResult : (queryResult as any).rows || [];
  
  // db.execute() が返すデータが配列の配列の場合、フラット化
  if (Array.isArray(rawLogs[0])) {
    rawLogs = rawLogs.flat();
  }
  
  const logs = rawLogs;
  
  const machineMap = new Map<string, MachineSummary>();
  for (const machine of allMachines) {
    machineMap.set(machine.machineId, {
      machineId: machine.machineId,
      machineName: machine.machineName,
      machineType: machine.machineType,
      lineName: machine.lineName ?? null,
      location: machine.location ?? null,
      totalRunningSeconds: 0,
      totalStoppedSeconds: 0,
      totalIdleSeconds: 0,
      totalMaintenanceSeconds: 0,
      totalSeconds: 0,
      avgOperationRate: 0,
      totalProductionCount: 0,
      targetProductionCount: machine.targetProductionCount ?? null,
      achievementRate: null,
      logCount: 0,
    });
  }
  
  let rateSum = 0;
  let rateCount = 0;
  
  for (const log of logs) {
    const summary = machineMap.get(log.machine_id);
    if (!summary) continue;
    summary.totalRunningSeconds += parseInt(log.total_running_seconds || 0);
    summary.totalStoppedSeconds += parseInt(log.total_stopped_seconds || 0);
    summary.totalIdleSeconds += parseInt(log.total_idle_seconds || 0);
    summary.totalMaintenanceSeconds += parseInt(log.total_maintenance_seconds || 0);
    summary.totalSeconds += parseInt(log.total_time_seconds || 0);
    summary.totalProductionCount += parseInt(log.total_production_count || 0);
    summary.logCount++;
    if (log.total_running_seconds != null && log.total_time_seconds != null) {
      const rate = (parseInt(log.total_running_seconds) / parseInt(log.total_time_seconds)) * 100;
      rateSum += rate;
      rateCount++;
    }
  }
  
  for (const summary of Array.from(machineMap.values())) {
    if (summary.totalSeconds > 0) {
      summary.avgOperationRate = Math.round((summary.totalRunningSeconds / summary.totalSeconds) * 1000) / 10;
    }
    if (summary.targetProductionCount && summary.targetProductionCount > 0) {
      summary.achievementRate = Math.round((summary.totalProductionCount / summary.targetProductionCount) * 1000) / 10;
    }
  }
  
  const machineSummaries = Array.from(machineMap.values())
    .filter((s) => s.logCount > 0)
    .sort((a, b) => b.avgOperationRate - a.avgOperationRate);
  
  const activeMachines = machineSummaries.length;
  const avgOperationRate = activeMachines > 0
    ? Math.round(machineSummaries.reduce((s, m) => s + m.avgOperationRate, 0) / activeMachines * 10) / 10
    : 0;
  const totalProductionCount = machineSummaries.reduce((s, m) => s + m.totalProductionCount, 0);
  const totalRunningSeconds = machineSummaries.reduce((s, m) => s + m.totalRunningSeconds, 0);
  const totalStoppedSeconds = machineSummaries.reduce((s, m) => s + m.totalStoppedSeconds, 0);
  const totalIdleSeconds = machineSummaries.reduce((s, m) => s + m.totalIdleSeconds, 0);
  
  const dayMap = new Map<string, {
    avgOperationRate: number;
    totalProductionCount: number;
    totalRunningSeconds: number;
    totalStoppedSeconds: number;
    totalIdleSeconds: number;
    rateSum: number;
    rateCount: number;
  }>();
  
  for (const log of logs) {
    const dateKey = new Date(log.target_date).toLocaleDateString("ja-JP", {
      year: "numeric", month: "2-digit", day: "2-digit",
    });
    if (!dayMap.has(dateKey)) {
      dayMap.set(dateKey, {
        avgOperationRate: 0,
        totalProductionCount: 0,
        totalRunningSeconds: 0,
        totalStoppedSeconds: 0,
        totalIdleSeconds: 0,
        rateSum: 0,
        rateCount: 0,
      });
    }
    const day = dayMap.get(dateKey)!;
    day.totalProductionCount += parseInt(log.total_production_count || 0);
    day.totalRunningSeconds += parseInt(log.total_running_seconds || 0);
    day.totalStoppedSeconds += parseInt(log.total_stopped_seconds || 0);
    day.totalIdleSeconds += parseInt(log.total_idle_seconds || 0);
    if (log.total_running_seconds != null && log.total_time_seconds != null) {
      const rate = (parseInt(log.total_running_seconds) / parseInt(log.total_time_seconds)) * 100;
      day.rateSum += rate;
      day.rateCount++;
    }
  }
  
  const timeSeriesData = Array.from(dayMap.entries())
    .map(([date, data]) => ({
      date,
      avgOperationRate: data.rateCount > 0 ? Math.round(data.rateSum / data.rateCount * 10) / 10 : 0,
      totalProductionCount: data.totalProductionCount,
      totalRunningSeconds: data.totalRunningSeconds,
      totalStoppedSeconds: data.totalStoppedSeconds,
      totalIdleSeconds: data.totalIdleSeconds,
    }))
    .sort((a, b) => a.date.localeCompare(b.date));
  
  const reportResult = {
    period: { from, to },
    generatedAt: new Date(),
    overallSummary: {
      totalMachines: allMachines.length,
      activeMachines,
      avgOperationRate,
      totalProductionCount,
      totalRunningSeconds,
      totalStoppedSeconds,
      totalIdleSeconds,
    },
    machineSummaries,
    timeSeriesData,
  };
  console.log('[DEBUG] getReportData result:', JSON.stringify({
    activeMachines: reportResult.overallSummary.activeMachines,
    totalMachines: reportResult.overallSummary.totalMachines,
    machineSummariesCount: reportResult.machineSummaries.length,
    timeSeriesDataCount: reportResult.timeSeriesData.length,
  }));
  return reportResult;
}

// ===== Daily Records =====
export async function getTodayDailyRecords() {
  const db = await getDb();
  if (!db) return [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  return db
    .select()
    .from(dailyRecords)
    .where(
      and(
        gte(dailyRecords.recordDate, today),
        lt(dailyRecords.recordDate, tomorrow)
      )
    );
}

export async function getDailyRecordsByMachine(machineId: string) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dailyRecords)
    .where(eq(dailyRecords.machineId, machineId))
    .orderBy(desc(dailyRecords.recordDate));
}

export async function upsertDailyRecord(data: {
  machineId: string;
  recordDate: string;
  utilizationRate: number;
  totalCount: number;
  totalRunTime: number;
  totalChocoTime: number;
  totalDokaTime: number;
  totalStopTime: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const dateObj = new Date(data.recordDate + "T00:00:00.000Z");
  await db
    .insert(dailyRecords)
    .values({
      machineId: data.machineId,
      recordDate: dateObj,
      totalCount: data.totalCount,
      totalRunTime: data.totalRunTime,
      totalChocoTime: data.totalChocoTime,
      totalDokaTime: data.totalDokaTime,
      totalStopTime: data.totalStopTime,
      utilizationRate: String(data.utilizationRate),
    })
    .onDuplicateKeyUpdate({
      set: {
        totalCount: data.totalCount,
        totalRunTime: data.totalRunTime,
        totalChocoTime: data.totalChocoTime,
        totalDokaTime: data.totalDokaTime,
        totalStopTime: data.totalStopTime,
        utilizationRate: String(data.utilizationRate),
      },
    });
}

// ===== Stop Events =====
export async function getStopEvents(machineId: string, from?: Date, to?: Date, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(stopEvents.machineId, machineId)];
  if (from) conditions.push(gte(stopEvents.startTime, from));
  if (to) conditions.push(lte(stopEvents.startTime, to));
  return db
    .select()
    .from(stopEvents)
    .where(and(...conditions))
    .orderBy(desc(stopEvents.startTime))
    .limit(limit);
}

export async function updateStopEventReason(id: number, manualReason: string | null) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(stopEvents)
    .set({ manualReason })
    .where(eq(stopEvents.id, id));
}

export async function insertStopEvent(data: {
  machineId: string;
  stopType: "CHOCO" | "DOKA";
  startTime: Date;
  endTime?: Date | null;
  duration?: number | null;
  manualReason?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db
    .insert(stopEvents)
    .values({
      machineId: data.machineId,
      stopType: data.stopType,
      startTime: data.startTime,
      endTime: data.endTime ?? null,
      duration: data.duration ?? null,
      manualReason: data.manualReason ?? null,
    });
  return result;
}

// Import statements that were missing
import { eq, desc, and, gte, lte, lt, sql } from "drizzle-orm";

// ===== Today's Max Target Production =====
export async function getTodayMaxTargetProduction() {
  const db = await getDb();
  if (!db) return null;
  
  try {
    const result = await db.execute(sql`
      SELECT 
        COALESCE(MAX(target_production_count), 0) AS today_max_target
      FROM machine_logs
      WHERE 
        DATE(CONVERT_TZ(created_at, '+00:00', '+09:00')) = CURDATE()
    `) as any;
    
    const rows = result?.[0] || [];
    const row = Array.isArray(rows) ? rows[0] : rows;
    
    const value = row?.today_max_target;
    console.log('[Database] getTodayMaxTargetProduction:', value);
    
    return value ? parseInt(value, 10) : null;
  } catch (error) {
    console.error("[Database] Failed to get today's max target production:", error);
    return null;
  }
}
