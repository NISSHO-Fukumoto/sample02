/**
 * Tenant Middleware
 * 
 * Extracts tenant information from request and populates context.
 * This middleware should be applied early in the request pipeline.
 */

import { Request, Response, NextFunction } from "express";
import { TenantContext, extractSubdomain } from "./tenant";
import { db } from "./db";
import { tenants } from "../../drizzle/master-schema";
import { eq } from "drizzle-orm";

/**
 * Extend Express Request type to include tenantContext
 */
declare global {
  namespace Express {
    interface Request {
      tenantContext?: TenantContext;
      tenantSubdomain?: string | null;
    }
  }
}

/**
 * In-memory cache for tenant lookups
 * Key: subdomain, Value: TenantContext
 * TTL: 5 minutes
 */
const tenantLookupCache = new Map<
  string,
  { context: TenantContext; expiresAt: number }
>();

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Resolve tenant from subdomain using cache
 */
async function resolveTenantFromSubdomain(
  subdomain: string
): Promise<TenantContext | null> {
  // Check cache
  const cached = tenantLookupCache.get(subdomain);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.context;
  }

  try {
    // Query master database
    const tenantRecord = await db
      .select()
      .from(tenants)
      .where(eq(tenants.subdomain, subdomain))
      .limit(1);

    if (!tenantRecord || tenantRecord.length === 0) {
      return null;
    }

    const tenant = tenantRecord[0];

    // Build context
    const context: TenantContext = {
      tenantId: tenant.id,
      subdomain: tenant.subdomain,
      companyName: tenant.companyName,
      dbHost: tenant.dbHost,
      dbPort: tenant.dbPort,
      dbName: tenant.dbName,
      dbUser: tenant.dbUser,
      status: tenant.status as "active" | "suspended" | "deleted",
    };

    // Cache it
    tenantLookupCache.set(subdomain, {
      context,
      expiresAt: Date.now() + CACHE_TTL_MS,
    });

    return context;
  } catch (error) {
    console.error(`Error resolving tenant for subdomain: ${subdomain}`, error);
    return null;
  }
}

/**
 * Clear tenant lookup cache
 * Useful after tenant updates or for testing
 */
export function clearTenantLookupCache(subdomain?: string): void {
  if (subdomain) {
    tenantLookupCache.delete(subdomain);
  } else {
    tenantLookupCache.clear();
  }
}

/**
 * Tenant middleware
 * 
 * Extracts subdomain from Host header and resolves tenant context.
 * If tenant is not found or is suspended, the request is rejected.
 */
export async function tenantMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void | Response> {
  try {
    const host = req.get("host") || "";
    const subdomain = extractSubdomain(host);

    // Store subdomain in request for later use
    req.tenantSubdomain = subdomain;

    // If no subdomain, this is a root/admin request
    // Allow it to proceed (admin routes will handle authorization)
    if (!subdomain) {
      return next();
    }

    // Resolve tenant context
    const tenantContext = await resolveTenantFromSubdomain(subdomain);

    if (!tenantContext) {
      return res.status(404).json({
        error: "Tenant not found",
        message: `No tenant found for subdomain: ${subdomain}`,
      });
    }

    // Check tenant status
    if (tenantContext.status === "suspended") {
      return res.status(403).json({
        error: "Tenant suspended",
        message: "This tenant has been suspended",
      });
    }

    if (tenantContext.status === "deleted") {
      return res.status(404).json({
        error: "Tenant deleted",
        message: "This tenant has been deleted",
      });
    }

    // Attach tenant context to request
    req.tenantContext = tenantContext;

    next();
  } catch (error) {
    console.error("Tenant middleware error:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to resolve tenant context",
    });
  }
}

/**
 * Middleware to enforce tenant context (for protected routes)
 * 
 * This should be applied to routes that require a tenant context.
 * If no tenant context is found, the request is rejected.
 */
export function requireTenantContext(
  req: Request,
  res: Response,
  next: NextFunction
): void | Response {
  if (!req.tenantContext) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "This route requires a tenant context",
    });
  }

  next();
}

/**
 * Middleware to require admin/ops context (for admin routes)
 * 
 * This should be applied to admin routes.
 * Allows requests without tenant context (admin routes).
 */
export function adminContextMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Admin routes can be accessed from root domain or admin subdomain
  // This is a placeholder for future admin-specific logic
  next();
}
