import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { getDeviceByApiKey, getMachineById, getDb, getReportData } from "../db";
import { devices, machineLogs, dailyRecords } from "../../drizzle/schema";
import { eq, and, gte, lt, ne, desc } from "drizzle-orm";
import { execSync } from "child_process";
import * as fs from "fs";
import * as path from "path";
import { generateReportHtml } from "../reportTemplate";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // OAuth callback
  registerOAuthRoutes(app);

  // ===== /api/ingest: Raspberry Piノードからのデータ受信エンドポイント =====
  app.post("/api/ingest", async (req, res) => {
    try {
      // APIキー認証
      const authHeader = req.headers.authorization;
      const apiKey = authHeader?.replace("Bearer ", "") || req.headers["x-api-key"] as string;

      if (!apiKey) {
        return res.status(401).json({ error: "API key required" });
      }

      const device = await getDeviceByApiKey(apiKey);
      if (!device || !device.isActive) {
        return res.status(403).json({ error: "Invalid or inactive API key" });
      }

      // デバイスの最終接続時刻を更新
      const db = await getDb();
      if (db) {
        await db.update(devices).set({ lastSeenAt: new Date() }).where(eq(devices.deviceId, device.deviceId));
      }

      const body = req.body;

      // machineIdの解決: ボディのmachineIdまたはデバイスに紐付けられたmachineId
      const machineId = body.machineId || device.machineId;
      if (!machineId) {
        return res.status(400).json({ error: "machineId is required. Set it in the request body or assign a machine to this device." });
      }

      // 機械の存在確認
      const machine = await getMachineById(machineId);
      if (!machine) {
        return res.status(404).json({ error: `Machine '${machineId}' not found` });
      }

      // データ検証と保存
      const periodStart = body.periodStart ? new Date(body.periodStart) : new Date(Date.now() - 60000);
      const periodEnd = body.periodEnd ? new Date(body.periodEnd) : new Date();
      const totalSeconds = body.totalSeconds || Math.floor((periodEnd.getTime() - periodStart.getTime()) / 1000);
      const runningSeconds = body.runningSeconds || 0;
      const operationRate = totalSeconds > 0 ? ((runningSeconds / totalSeconds) * 100).toFixed(2) : "0";

      if (!db) return res.status(500).json({ error: "Database not available" });
      await db.insert(machineLogs).values({
        machineId,
        deviceId: device.deviceId,
        periodStart,
        periodEnd,
        state: body.state || "stopped",
        runningSeconds: body.runningSeconds || 0,
        stoppedSeconds: body.stoppedSeconds || 0,
        idleSeconds: body.idleSeconds || 0,
        maintenanceSeconds: body.maintenanceSeconds || 0,
        totalSeconds,
        operationRate,
        productionCount: body.productionCount || 0,
        targetProductionCount: body.targetProductionCount || machine.targetProductionCount || 0,
        // 将来拡張項目
        steamConsumption: body.steamConsumption || null,
        electricityConsumption: body.electricityConsumption || null,
        airConsumption: body.airConsumption || null,
        gasConsumption: body.gasConsumption || null,
        waterConsumption: body.waterConsumption || null,
        hotWaterConsumption: body.hotWaterConsumption || null,
        laborCost: body.laborCost || null,
        productionCost: body.productionCost || null,
        productionRevenue: body.productionRevenue || null,
        rawData: body,
      });

      // daily_records を自動更新（詳細モーダルで表示しているのと同じロジック）
      try {
        console.log(`[Ingest] Starting daily_records update for machine: ${machineId}`);
        // JST ベースで日付を計算（UTC ではなく JST で本日の範囲を決定）
        const nowJst = new Date(new Date().getTime() + 9 * 60 * 60 * 1000);
        const todayJst = new Date(nowJst);
        todayJst.setUTCHours(0, 0, 0, 0);
        const tomorrowJst = new Date(todayJst);
        tomorrowJst.setUTCDate(tomorrowJst.getUTCDate() + 1);
        
        // UTC に変換（DB クエリ用）
        const todayUtc = new Date(todayJst.getTime() - 9 * 60 * 60 * 1000);
        const tomorrowUtc = new Date(tomorrowJst.getTime() - 9 * 60 * 60 * 1000);
        console.log(`[Ingest] JST Date range: ${todayJst.toISOString()} to ${tomorrowJst.toISOString()}`);
        console.log(`[Ingest] UTC Date range: ${todayUtc.toISOString()} to ${tomorrowUtc.toISOString()}`);

        // 本日のログを取得（production_count != 0）
        const todayLogs = await db
          .select()
          .from(machineLogs)
          .where(
            and(
              eq(machineLogs.machineId, machineId),
              gte(machineLogs.createdAt, todayUtc),
              lt(machineLogs.createdAt, tomorrowUtc),
              ne(machineLogs.productionCount, 0)
            )
          )
          .orderBy(desc(machineLogs.createdAt));
        console.log(`[Ingest] Found ${todayLogs.length} logs for today with production_count != 0`);

        // 時間毎の最新レコードのみを抽出
        const hourlyLatest: typeof todayLogs = [];
        const seenHours = new Set<string>();
        for (const log of todayLogs) {
          const createdAtJst = new Date(log.createdAt.getTime() + 9 * 60 * 60 * 1000);
          const hourKey = createdAtJst.toISOString().slice(0, 13); // "YYYY-MM-DDTHH"
          if (!seenHours.has(hourKey)) {
            seenHours.add(hourKey);
            hourlyLatest.push(log);
          }
        }
        console.log(`[Ingest] Hourly latest records: ${hourlyLatest.length}`);

        // 合計値を計算
        const totalRunningSeconds = hourlyLatest.reduce((sum, log) => sum + (log.runningSeconds || 0), 0);
        const totalStoppedSeconds = hourlyLatest.reduce((sum, log) => sum + (log.stoppedSeconds || 0), 0);
        const totalIdleSeconds = hourlyLatest.reduce((sum, log) => sum + (log.idleSeconds || 0), 0);
        const totalMaintenanceSeconds = hourlyLatest.reduce((sum, log) => sum + (log.maintenanceSeconds || 0), 0);
        const totalSeconds = totalRunningSeconds + totalStoppedSeconds + totalIdleSeconds + totalMaintenanceSeconds;
        const totalProductionCount = hourlyLatest.reduce((sum, log) => sum + (log.productionCount || 0), 0);
        const utilizationRate = totalSeconds > 0 ? ((totalRunningSeconds / totalSeconds) * 100).toFixed(2) : "0";
        console.log(`[Ingest] Totals - Running: ${totalRunningSeconds}s, Stopped: ${totalStoppedSeconds}s, Idle: ${totalIdleSeconds}s, Production: ${totalProductionCount}, Utilization: ${utilizationRate}%`);

        // daily_records を UPSERT
        // recordDate は JST ベースの日付を使用
        const recordDate = new Date(todayJst);
        console.log(`[Ingest] Upserting daily_records for ${machineId} on ${recordDate.toISOString()} (JST: ${todayJst.toISOString()})`);
        await db
          .insert(dailyRecords)
          .values({
            machineId,
            recordDate,
            totalCount: totalProductionCount,
            totalRunTime: totalRunningSeconds,
            totalChocoTime: totalIdleSeconds,
            totalDokaTime: totalStoppedSeconds,
            totalStopTime: totalStoppedSeconds + totalIdleSeconds,
            utilizationRate: String(utilizationRate),
          })
          .onDuplicateKeyUpdate({
            set: {
              totalCount: totalProductionCount,
              totalRunTime: totalRunningSeconds,
              totalChocoTime: totalIdleSeconds,
              totalDokaTime: totalStoppedSeconds,
              totalStopTime: totalStoppedSeconds + totalIdleSeconds,
              utilizationRate: String(utilizationRate),
            },
          });
        console.log(`[Ingest] Successfully updated daily_records for machine: ${machineId}`);
      } catch (error) {
        console.error("[Ingest] Error updating daily_records:", JSON.stringify(error));
        console.error("[Ingest] Error stack:", error instanceof Error ? error.stack : "No stack trace");
        // daily_records 更新エラーは無視（machine_logs は正常に保存されているため）
      }

      return res.json({
        success: true,
        machineId,
        deviceId: device.deviceId,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("[Ingest] Error:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  // ===== /api/report/pdf: PDFレポート生成エンドポイント =====
  app.get("/api/report/pdf", async (req, res) => {
    let htmlFile: string | null = null;
    let pdfFile: string | null = null;
    try {
      const fromStr = req.query.from as string;
      const toStr = req.query.to as string;
      const title = (req.query.title as string) || "稼働実績レポート";

      if (!fromStr || !toStr) {
        return res.status(400).json({ error: "from and to query parameters are required" });
      }

      const from = new Date(fromStr);
      const to = new Date(toStr);

      if (isNaN(from.getTime()) || isNaN(to.getTime())) {
        return res.status(400).json({ error: "Invalid date format" });
      }

      const reportData = await getReportData(from, to);

      // HTMLテンプレート生成
      const html = generateReportHtml(reportData, title);

      // 一時ファイルを作成
      const tmpDir = "/tmp";
      const timestamp = Date.now();
      htmlFile = path.join(tmpDir, `report_${timestamp}.html`);
      pdfFile = path.join(tmpDir, `report_${timestamp}.pdf`);

      // HTML ファイルに書き込み
      fs.writeFileSync(htmlFile, html, "utf-8");

      // Python weasyprint を使って PDF に変換
      const scriptPath = path.join(__dirname, "../html-to-pdf.py");
      try {
        execSync(`python3 "${scriptPath}" "${htmlFile}" "${pdfFile}"`, {
          stdio: "pipe",
          timeout: 30000,
        });
      } catch (error) {
        console.error("[PDF] Python execution error:", error);
        throw new Error("PDF generation failed");
      }

      // PDF ファイルを読み込み
      if (!fs.existsSync(pdfFile)) {
        throw new Error("PDF file not generated");
      }
      const pdf = fs.readFileSync(pdfFile);

      const filename = `report_${from.toISOString().slice(0, 10)}_${to.toISOString().slice(0, 10)}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Content-Length", pdf.length);
      return res.end(pdf);
    } catch (error) {
      console.error("[PDF] Error:", error);
      return res.status(500).json({ error: "PDF generation failed" });
    } finally {
      // 一時ファイルをクリーンアップ
      if (htmlFile && fs.existsSync(htmlFile)) {
        fs.unlinkSync(htmlFile);
      }
      if (pdfFile && fs.existsSync(pdfFile)) {
        fs.unlinkSync(pdfFile);
      }
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
