/**
 * Tenant Management Utilities
 * 
 * Handles tenant identification, database connection switching, and tenant context.
 */

import { Request } from "express";
import { createPool, Pool } from "mysql2/promise";
import { drizzle, MySql2Database } from "drizzle-orm/mysql2";
import * as schema from "../../drizzle/schema";

/**
 * Tenant context that is attached to each request
 */
export interface TenantContext {
  tenantId: number;
  subdomain: string;
  companyName: string;
  dbHost: string;
  dbPort: number;
  dbName: string;
  dbUser: string;
  status: "active" | "suspended" | "deleted";
}

/**
 * Extract subdomain from Host header
 * Examples:
 *   - "a.example.com" -> "a"
 *   - "tenant-b.example.com" -> "tenant-b"
 *   - "example.com" -> null (root domain)
 */
export function extractSubdomain(host: string): string | null {
  // Remove port if present
  const hostname = host.split(":")[0];

  // Split by dots
  const parts = hostname.split(".");

  // If only 1 or 2 parts, it's likely root domain or www
  if (parts.length <= 2) {
    return null;
  }

  // First part is the subdomain
  const subdomain = parts[0];

  // Exclude common subdomains
  if (["www", "mail", "ftp", "admin"].includes(subdomain)) {
    return null;
  }

  return subdomain;
}

/**
 * Tenant database connection pool cache
 * Key: tenant_id, Value: { pool, db }
 */
const tenantPoolCache = new Map<
  number,
  { pool: Pool; db: MySql2Database<typeof schema> }
>();

/**
 * Get or create a database connection for a tenant
 */
export async function getTenantDatabase(
  tenantContext: TenantContext
): Promise<MySql2Database<typeof schema>> {
  const { tenantId, dbHost, dbPort, dbName, dbUser } = tenantContext;

  // Check cache
  if (tenantPoolCache.has(tenantId)) {
    return tenantPoolCache.get(tenantId)!.db;
  }

  // Get password from environment (in production, use AWS Secrets Manager)
  // For now, we'll use a convention: TENANT_{TENANT_ID}_DB_PASSWORD
  const passwordEnvKey = `TENANT_${tenantId}_DB_PASSWORD`;
  const dbPassword = process.env[passwordEnvKey];

  if (!dbPassword) {
    throw new Error(
      `Database password not found for tenant ${tenantId}. Set ${passwordEnvKey} environment variable.`
    );
  }

  // Create connection pool
  const pool = await createPool({
    host: dbHost,
    port: dbPort,
    database: dbName,
    user: dbUser,
    password: dbPassword,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  // Create Drizzle instance
  const db = drizzle(pool, { schema, mode: "default" });

  // Cache it
  tenantPoolCache.set(tenantId, { pool, db });

  return db;
}

/**
 * Close all tenant database connections (for graceful shutdown)
 */
export async function closeAllTenantConnections(): Promise<void> {
  const entries = Array.from(tenantPoolCache.values());
  for (const { pool } of entries) {
    await pool.end();
  }
  tenantPoolCache.clear();
}

/**
 * Clear tenant database connection cache (useful for testing or after tenant suspension)
 */
export function clearTenantCache(tenantId?: number): void {
  if (tenantId) {
    tenantPoolCache.delete(tenantId);
  } else {
    tenantPoolCache.clear();
  }
}

/**
 * Validate tenant status
 */
export function validateTenantStatus(tenantContext: TenantContext): void {
  if (tenantContext.status === "suspended") {
    throw new Error("Tenant is suspended");
  }
  if (tenantContext.status === "deleted") {
    throw new Error("Tenant has been deleted");
  }
}

/**
 * Extract tenant context from request
 * This will be called by middleware to populate req.tenantContext
 */
export function extractTenantContextFromRequest(
  req: Request
): { subdomain: string | null } {
  const host = req.get("host") || "";
  const subdomain = extractSubdomain(host);

  return { subdomain };
}
