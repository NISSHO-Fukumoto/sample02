/**
 * Role-Based Access Control (RBAC)
 * 
 * Defines roles, permissions, and access control logic for multi-tenant system.
 */

export type UserRole = "customer_user" | "customer_admin" | "ops" | "engineer";

/**
 * Permission definitions
 * Format: "resource:action"
 */
export const PERMISSIONS = {
  // Tenant management (ops/engineer only)
  TENANT_READ: "tenant:read",
  TENANT_WRITE: "tenant:write",
  TENANT_DELETE: "tenant:delete",
  TENANT_SUSPEND: "tenant:suspend",

  // User management (customer_admin, ops, engineer)
  USER_READ: "user:read",
  USER_WRITE: "user:write",
  USER_DELETE: "user:delete",
  USER_IMPERSONATE: "user:impersonate",

  // Plant management (customer_admin, customer_user)
  PLANT_READ: "plant:read",
  PLANT_WRITE: "plant:write",
  PLANT_DELETE: "plant:delete",

  // Machine management (customer_admin, customer_user)
  MACHINE_READ: "machine:read",
  MACHINE_WRITE: "machine:write",
  MACHINE_DELETE: "machine:delete",

  // Node management (customer_admin, ops, engineer)
  NODE_READ: "node:read",
  NODE_WRITE: "node:write",
  NODE_DELETE: "node:delete",
  NODE_REGISTER: "node:register",

  // Report access (customer_admin, customer_user)
  REPORT_READ: "report:read",
  REPORT_EXPORT: "report:export",

  // System settings (customer_admin, ops, engineer)
  SETTINGS_READ: "settings:read",
  SETTINGS_WRITE: "settings:write",

  // Audit logs (ops, engineer)
  AUDIT_READ: "audit:read",
} as const;

/**
 * Role-to-permissions mapping
 */
export const ROLE_PERMISSIONS: Record<UserRole, Set<string>> = {
  customer_user: new Set([
    PERMISSIONS.PLANT_READ,
    PERMISSIONS.MACHINE_READ,
    PERMISSIONS.NODE_READ,
    PERMISSIONS.REPORT_READ,
    PERMISSIONS.SETTINGS_READ,
  ]),

  customer_admin: new Set([
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_WRITE,
    PERMISSIONS.USER_DELETE,
    PERMISSIONS.PLANT_READ,
    PERMISSIONS.PLANT_WRITE,
    PERMISSIONS.PLANT_DELETE,
    PERMISSIONS.MACHINE_READ,
    PERMISSIONS.MACHINE_WRITE,
    PERMISSIONS.MACHINE_DELETE,
    PERMISSIONS.NODE_READ,
    PERMISSIONS.NODE_WRITE,
    PERMISSIONS.NODE_DELETE,
    PERMISSIONS.NODE_REGISTER,
    PERMISSIONS.REPORT_READ,
    PERMISSIONS.REPORT_EXPORT,
    PERMISSIONS.SETTINGS_READ,
    PERMISSIONS.SETTINGS_WRITE,
  ]),

  ops: new Set([
    PERMISSIONS.TENANT_READ,
    PERMISSIONS.TENANT_WRITE,
    PERMISSIONS.TENANT_SUSPEND,
    PERMISSIONS.USER_READ,
    PERMISSIONS.USER_WRITE,
    PERMISSIONS.USER_IMPERSONATE,
    PERMISSIONS.NODE_READ,
    PERMISSIONS.NODE_WRITE,
    PERMISSIONS.NODE_REGISTER,
    PERMISSIONS.AUDIT_READ,
  ]),

  engineer: new Set([
    PERMISSIONS.TENANT_READ,
    PERMISSIONS.USER_READ,
    PERMISSIONS.NODE_READ,
    PERMISSIONS.NODE_WRITE,
    PERMISSIONS.NODE_REGISTER,
    PERMISSIONS.AUDIT_READ,
  ]),
};

/**
 * Check if a role has a specific permission
 */
export function hasPermission(role: UserRole, permission: string): boolean {
  const permissions = ROLE_PERMISSIONS[role];
  return permissions ? permissions.has(permission) : false;
}

/**
 * Check if a role has any of the specified permissions
 */
export function hasAnyPermission(role: UserRole, permissions: string[]): boolean {
  return permissions.some((permission) => hasPermission(role, permission));
}

/**
 * Check if a role has all of the specified permissions
 */
export function hasAllPermissions(role: UserRole, permissions: string[]): boolean {
  return permissions.every((permission) => hasPermission(role, permission));
}

/**
 * Get all permissions for a role
 */
export function getPermissionsForRole(role: UserRole): string[] {
  const permissions = ROLE_PERMISSIONS[role];
  return permissions ? Array.from(permissions) : [];
}

/**
 * Check if a user can perform an action on a resource
 */
export function canAccessResource(
  userRole: UserRole,
  resourceType: string,
  action: "read" | "write" | "delete"
): boolean {
  const permission = `${resourceType}:${action}`;
  return hasPermission(userRole, permission);
}

/**
 * Check if a user can impersonate another user
 * Only ops and engineer roles can impersonate
 */
export function canImpersonate(userRole: UserRole): boolean {
  return hasPermission(userRole, PERMISSIONS.USER_IMPERSONATE);
}

/**
 * Check if a user can manage tenants
 * Only ops role can fully manage tenants
 */
export function canManageTenants(userRole: UserRole): boolean {
  return hasPermission(userRole, PERMISSIONS.TENANT_WRITE);
}

/**
 * Check if a user is an admin
 */
export function isAdmin(userRole: UserRole): boolean {
  return userRole === "customer_admin" || userRole === "ops" || userRole === "engineer";
}

/**
 * Check if a user is an operator/engineer
 */
export function isOperator(userRole: UserRole): boolean {
  return userRole === "ops" || userRole === "engineer";
}
