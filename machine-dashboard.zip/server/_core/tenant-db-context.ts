/**
 * Tenant Database Context for tRPC
 * 
 * Provides tenant-specific database connections within tRPC procedures.
 */

import { Request } from "express";
import { MySql2Database } from "drizzle-orm/mysql2";
import * as schema from "../../drizzle/schema";
import { TenantContext, getTenantDatabase, validateTenantStatus } from "./tenant";

/**
 * Tenant database context that is passed to tRPC procedures
 */
export interface TenantDbContext {
  tenantContext: TenantContext;
  db: MySql2Database<typeof schema>;
}

/**
 * Get tenant database context from request
 * 
 * This function should be called in the tRPC context creation function.
 * It retrieves the tenant context from the request and creates a database connection.
 */
export async function getTenantDbContext(
  req: Request
): Promise<TenantDbContext | null> {
  // Check if tenant context exists
  if (!req.tenantContext) {
    return null;
  }

  const tenantContext = req.tenantContext;

  // Validate tenant status
  try {
    validateTenantStatus(tenantContext);
  } catch (error) {
    console.error("Tenant validation failed:", error);
    throw error;
  }

  // Get tenant database connection
  const db = await getTenantDatabase(tenantContext);

  return {
    tenantContext,
    db,
  };
}

/**
 * Create a tenant-aware tRPC context
 * 
 * This should be used in the tRPC context creation function.
 * It extends the existing context with tenant database information.
 */
export async function createTenantAwareTrpcContext(
  req: Request,
  existingContext: any
): Promise<any> {
  const tenantDbContext = await getTenantDbContext(req);

  return {
    ...existingContext,
    tenantContext: tenantDbContext?.tenantContext,
    tenantDb: tenantDbContext?.db,
  };
}
