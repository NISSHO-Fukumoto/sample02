/**
 * Protected Procedures with RBAC
 * 
 * Extends tRPC procedures with role-based access control.
 */

import { TRPCError } from "@trpc/server";
import { protectedProcedure } from "./index";
import { UserRole, hasPermission, canImpersonate } from "./rbac";

/**
 * Procedure that requires a specific permission
 */
export function withPermission(permission: string) {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "User role not found",
      });
    }

    if (!hasPermission(userRole, permission)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: `Permission denied: ${permission}`,
      });
    }

    return next({ ctx });
  });
}

/**
 * Procedure that requires admin role
 */
export function adminProcedure() {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "User role not found",
      });
    }

    const adminRoles: UserRole[] = ["customer_admin", "ops", "engineer"];
    if (!adminRoles.includes(userRole)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Admin role required",
      });
    }

    return next({ ctx });
  });
}

/**
 * Procedure that requires operator/engineer role
 */
export function operatorProcedure() {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "User role not found",
      });
    }

    const operatorRoles: UserRole[] = ["ops", "engineer"];
    if (!operatorRoles.includes(userRole)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Operator role required",
      });
    }

    return next({ ctx });
  });
}

/**
 * Procedure that requires tenant admin role
 */
export function tenantAdminProcedure() {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole || userRole !== "customer_admin") {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Tenant admin role required",
      });
    }

    return next({ ctx });
  });
}

/**
 * Procedure that allows impersonation
 */
export function impersonationAwareProcedure() {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "User role not found",
      });
    }

    // Check if user has impersonation permission
    if (!canImpersonate(userRole)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "Impersonation not allowed for this role",
      });
    }

    return next({ ctx });
  });
}

/**
 * Procedure that requires specific role
 */
export function withRole(...roles: UserRole[]) {
  return protectedProcedure.use(({ ctx, next }) => {
    const userRole = ctx.user?.role as UserRole | undefined;

    if (!userRole) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "User role not found",
      });
    }

    if (!roles.includes(userRole)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: `One of these roles required: ${roles.join(", ")}`,
      });
    }

    return next({ ctx });
  });
}
