import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { nanoid } from "nanoid";
import { eq, desc, and } from "drizzle-orm";
import {
  getDb,
  getMachines,
  getMachineById,
  getDevices,
  getDeviceByApiKey,
  getDeviceById,
  getLatestLogPerMachine,
  getMachineLogHistory,
  getDashboardLayout,
  saveDashboardLayout,
  getReportData,
  upsertUser,
  getUserByOpenId,
  getTodayDailyRecords,
  getDailyRecordsByMachine,
  upsertDailyRecord,
  getStopEvents,
  updateStopEventReason,
  insertStopEvent,
  getTodayMaxTargetProduction,
} from "./db";
import { machines, devices, machineLogs, dashboardLayouts, machineTypes, stopEvents } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ===== Machines =====
  machines: router({
    list: publicProcedure
      .input(z.object({ activeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return getMachines(input?.activeOnly ?? false);
      }),

    get: publicProcedure
      .input(z.object({ machineId: z.string() }))
      .query(async ({ input }) => {
        return getMachineById(input.machineId);
      }),

    create: protectedProcedure
      .input(z.object({
        machineId: z.string().min(1).max(50),
        machineName: z.string().min(1).max(100),
        machineType: z.string().min(1).max(100),
        location: z.string().max(100).optional(),
        lineName: z.string().max(100).optional(),
        description: z.string().optional(),
        isActive: z.boolean().default(true),
        targetProductionCount: z.number().int().min(0).default(0),
        sortOrder: z.number().int().default(0),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(machines).values({
          machineId: input.machineId,
          machineName: input.machineName,
          machineType: input.machineType,
          location: input.location ?? null,
          lineName: input.lineName ?? null,
          description: input.description ?? null,
          isActive: input.isActive,
          targetProductionCount: input.targetProductionCount,
          sortOrder: input.sortOrder,
        });
        return getMachineById(input.machineId);
      }),

    update: protectedProcedure
      .input(z.object({
        machineId: z.string(),
        machineName: z.string().min(1).max(100).optional(),
        machineType: z.string().min(1).max(100).optional(),
        location: z.string().max(100).nullable().optional(),
        lineName: z.string().max(100).nullable().optional(),
        description: z.string().nullable().optional(),
        isActive: z.boolean().optional(),
        targetProductionCount: z.number().int().min(0).optional(),
        sortOrder: z.number().int().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const { machineId, ...rest } = input;
        await db.update(machines).set(rest).where(eq(machines.machineId, machineId));
        return getMachineById(machineId);
      }),

    delete: protectedProcedure
      .input(z.object({ machineId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.delete(machines).where(eq(machines.machineId, input.machineId));
        return { success: true };
      }),
  }),

  // ===== Devices =====
  devices: router({
    list: publicProcedure.query(async () => {
      return getDevices();
    }),

    get: publicProcedure
      .input(z.object({ deviceId: z.string() }))
      .query(async ({ input }) => {
        return getDeviceById(input.deviceId);
      }),

    getByApiKey: publicProcedure
      .input(z.object({ apiKey: z.string() }))
      .query(async ({ input }) => {
        return getDeviceByApiKey(input.apiKey);
      }),

    create: protectedProcedure
      .input(z.object({
        deviceId: z.string().min(1).max(50),
        deviceName: z.string().optional(),
        machineId: z.string().optional(),
        ipAddress: z.string().optional(),
        location: z.string().optional(),
        isActive: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const apiKey = nanoid(32);
        await db.insert(devices).values({
          deviceId: input.deviceId,
          deviceName: input.deviceName || null,
          machineId: input.machineId || null,
          ipAddress: input.ipAddress || null,
          location: input.location || null,
          apiKey,
          isActive: input.isActive,
        });
        return getDeviceById(input.deviceId);
      }),

    update: protectedProcedure
      .input(z.object({
        deviceId: z.string().min(1).max(50),
        deviceName: z.string().optional(),
        machineId: z.string().optional(),
        ipAddress: z.string().optional(),
        location: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(devices).set({
          deviceName: input.deviceName || null,
          machineId: input.machineId || null,
          ipAddress: input.ipAddress || null,
          location: input.location || null,
          isActive: input.isActive,
        }).where(eq(devices.deviceId, input.deviceId));
        return getDeviceById(input.deviceId);
      }),

    delete: protectedProcedure
      .input(z.object({ deviceId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.delete(devices).where(eq(devices.deviceId, input.deviceId));
        return { success: true };
      }),

    regenerateApiKey: protectedProcedure
      .input(z.object({ deviceId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const apiKey = nanoid(32);
        await db.update(devices).set({ apiKey }).where(eq(devices.deviceId, input.deviceId));
        return getDeviceById(input.deviceId);
      }),
  }),

  // ===== Logs =====
  logs: router({
    latestPerMachine: publicProcedure.query(async () => {
      return getLatestLogPerMachine();
    }),

    history: publicProcedure
      .input(z.object({
        machineId: z.string(),
        from: z.date(),
        to: z.date(),
        limit: z.number().int().min(1).max(500).default(200),
      }))
      .query(async ({ input }) => {
        return getMachineLogHistory(input.machineId, input.from, input.to, input.limit);
      }),

    todayPerMachine: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      const logs = await db
        .select()
        .from(machineLogs)
        .where(
          and(
            machineLogs.createdAt.gte(today),
            machineLogs.createdAt.lt(tomorrow)
          )
        )
        .orderBy(desc(machineLogs.createdAt));
      
      return logs;
    }),

    todayMaxTarget: publicProcedure.query(async () => {
      return getTodayMaxTargetProduction();
    }),
  }),

  // ===== Reports =====
  reports: router({
    getData: publicProcedure
      .input(z.object({
        from: z.date(),
        to: z.date(),
      }))
      .query(async ({ input }) => {
        return getReportData(input.from, input.to);
      }),
  }),

  // ===== Machine Types (機械種別マスター) =====
  machineTypes: router({
    list: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const { asc } = await import("drizzle-orm");
      return db.select().from(machineTypes).orderBy(asc(machineTypes.sort_order), asc(machineTypes.type_name));
    }),

    create: protectedProcedure
      .input(z.object({
        typeName: z.string().min(1).max(100),
        sortOrder: z.number().int().default(0),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(machineTypes).values({
          type_name: input.typeName,
          sort_order: input.sortOrder,
        });
        return { success: true };
      }),
  }),

  // ===== Dashboard Layout =====
  layout: router({
    get: publicProcedure
      .input(z.object({ terminalId: z.string() }))
      .query(async ({ input }) => {
        const layout = await getDashboardLayout(input.terminalId);
        if (layout) {
          return layout;
        }
        // デフォルトレイアウトを返す
        return {
          id: nanoid(),
          terminalId: input.terminalId,
          userId: null,
          layoutName: "default",
          cardOrder: [],
          visibleMachines: [],
          showTargetProduction: false,
          showActualProductionTime: false,
          showEnergyPlaceholder: false,
          showCostPlaceholder: false,
          refreshInterval: 300000,
          gridColumns: 3,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
      }),

    save: publicProcedure
      .input(z.object({
        terminalId: z.string(),
        layoutName: z.string().optional(),
        cardOrder: z.array(z.string()).optional(),
        visibleMachines: z.array(z.string()).optional(),
        showTargetProduction: z.boolean().default(false),
        showActualProductionTime: z.boolean().default(false),
        showEnergyPlaceholder: z.boolean().default(false),
        showCostPlaceholder: z.boolean().default(false),
        refreshInterval: z.number().int().default(300000),
        gridColumns: z.number().int().min(1).max(5).default(3),
      }))
      .mutation(async ({ input }) => {
        return saveDashboardLayout(input);
      }),
  }),

  // ===== Daily Records =====
  dailyRecords: router({
    todayAll: publicProcedure.query(async () => {
      return getTodayDailyRecords();
    }),

    getByMachine: publicProcedure
      .input(z.object({ machineId: z.string() }))
      .query(async ({ input }) => {
        return getDailyRecordsByMachine(input.machineId);
      }),

    upsert: publicProcedure
      .input(z.object({
        machineId: z.string(),
        recordDate: z.string(),
        utilizationRate: z.number(),
        totalCount: z.number().int(),
        totalRunTime: z.number().int(),
        totalChocoTime: z.number().int(),
        totalDokaTime: z.number().int(),
        totalStopTime: z.number().int(),
      }))
      .mutation(async ({ input }) => {
        return upsertDailyRecord(input);
      }),
  }),

  // ===== Stop Events =====
  stopEvents: router({
    list: publicProcedure
      .input(z.object({
        machineId: z.string(),
        from: z.date().optional(),
        to: z.date().optional(),
        limit: z.number().int().min(1).max(500).default(200),
      }))
      .query(async ({ input }) => {
        return getStopEvents(input.machineId, input.from, input.to, input.limit);
      }),

    updateReason: publicProcedure
      .input(z.object({
        eventId: z.number().int(),
        reason: z.string().max(500),
      }))
      .mutation(async ({ input }) => {
        return updateStopEventReason(input.eventId, input.reason);
      }),

    create: publicProcedure
      .input(z.object({
        machineId: z.string(),
        stopType: z.enum(["CHOCO", "DOKA"]),
        startTime: z.date(),
        endTime: z.date().optional(),
        duration: z.number().int().optional(),
        manualReason: z.string().max(500).optional(),
      }))
      .mutation(async ({ input }) => {
        return insertStopEvent(input);
      }),
  }),
});

export type AppRouter = typeof appRouter;
