#!/usr/bin/env python3
"""
HTML を PDF に変換するスクリプト
使用方法: python3 html-to-pdf.py <input_html_file> <output_pdf_file>
"""

import sys
import os
from weasyprint import HTML, CSS

def html_to_pdf(html_file: str, pdf_file: str) -> None:
    """HTML ファイルを PDF に変換"""
    try:
        # HTML ファイルを読み込み
        html = HTML(filename=html_file)
        
        # PDF に変換
        html.write_pdf(pdf_file)
        
        print(f"PDF generated successfully: {pdf_file}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 html-to-pdf.py <input_html_file> <output_pdf_file>", file=sys.stderr)
        sys.exit(1)
    
    html_file = sys.argv[1]
    pdf_file = sys.argv[2]
    
    if not os.path.exists(html_file):
        print(f"Error: HTML file not found: {html_file}", file=sys.stderr)
        sys.exit(1)
    
    html_to_pdf(html_file, pdf_file)
