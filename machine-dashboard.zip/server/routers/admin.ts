/**
 * Admin Router
 * 
 * Handles tenant management, user management, and system operations.
 * Only accessible to ops and engineer roles.
 */

import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, publicProcedure } from "../_core/index";
import { operatorProcedure } from "../_core/protected-procedures";
import { tenants, tenantUsers, nodeRegistrationTokens, auditLogs } from "../../drizzle/master-schema";
import { getDb } from "../db";
import { eq, desc } from "drizzle-orm";
import crypto from "crypto";

export const adminRouter = router({
  // ===== Tenant Management =====

  /**
   * List all tenants
   */
  tenants: {
    list: operatorProcedure().query(async () => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const allTenants = await db.select().from(tenants).orderBy(desc(tenants.createdAt));
        return allTenants.map((t: any) => ({
          id: t.id,
          subdomain: t.subdomain,
          companyName: t.companyName,
          status: t.status,
          plan: t.plan,
          maxUsers: t.maxUsers,
          maxPlants: t.maxPlants,
          createdAt: t.createdAt,
          updatedAt: t.updatedAt,
        }));
      } catch (error) {
        console.error("Failed to list tenants:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list tenants",
        });
      }
    }),

    /**
     * Get tenant details
     */
    get: operatorProcedure()
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const tenant = await db.select().from(tenants).where(eq(tenants.id, input.tenantId)).limit(1);

          if (!tenant || tenant.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Tenant not found",
            });
          }

          return tenant[0];
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("Failed to get tenant:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to get tenant",
          });
        }
      }),

    /**
     * Suspend tenant
     */
    suspend: operatorProcedure()
      .input(z.object({ tenantId: z.number(), reason: z.string().optional() }))
      .mutation(async ({ input, ctx }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          await db.update(tenants).set({ status: "suspended" }).where(eq(tenants.id, input.tenantId));

          // Log audit
          await db.insert(auditLogs).values({
            tenantId: input.tenantId,
            userId: ctx.user?.id || 0,
            action: "tenant_suspended",
            resourceType: "tenant",
            resourceId: String(input.tenantId),
            details: { reason: input.reason },
          });

          return { success: true };
        } catch (error) {
          console.error("Failed to suspend tenant:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to suspend tenant",
          });
        }
      }),

    /**
     * Reactivate tenant
     */
    reactivate: operatorProcedure()
      .input(z.object({ tenantId: z.number() }))
      .mutation(async ({ input, ctx }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          await db.update(tenants).set({ status: "active" }).where(eq(tenants.id, input.tenantId));

          // Log audit
          await db.insert(auditLogs).values({
            tenantId: input.tenantId,
            userId: ctx.user?.id || 0,
            action: "tenant_reactivated",
            resourceType: "tenant",
            resourceId: String(input.tenantId),
          });

          return { success: true };
        } catch (error) {
          console.error("Failed to reactivate tenant:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to reactivate tenant",
          });
        }
      }),
  },

  // ===== Tenant User Management =====

  users: {
    /**
     * List users for a tenant
     */
    list: operatorProcedure()
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const users = await db
            .select()
            .from(tenantUsers)
            .where(eq(tenantUsers.tenantId, input.tenantId))
            .orderBy(desc(tenantUsers.createdAt));

          return users;
        } catch (error) {
          console.error("Failed to list users:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to list users",
          });
        }
      }),

    /**
     * Update user role
     */
    updateRole: operatorProcedure()
      .input(z.object({ userId: z.number(), role: z.enum(["customer_user", "customer_admin", "ops", "engineer"]) }))
      .mutation(async ({ input, ctx }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const user = await db.select().from(tenantUsers).where(eq(tenantUsers.id, input.userId)).limit(1);

          if (!user || user.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "User not found",
            });
          }

          await db.update(tenantUsers).set({ role: input.role }).where(eq(tenantUsers.id, input.userId));

          // Log audit
          await db.insert(auditLogs).values({
            tenantId: user[0].tenantId,
            userId: ctx.user?.id || 0,
            action: "user_role_updated",
            resourceType: "user",
            resourceId: String(input.userId),
            details: { newRole: input.role },
          });

          return { success: true };
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("Failed to update user role:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update user role",
          });
        }
      }),
  },

  // ===== Node Registration Tokens =====

  tokens: {
    /**
     * List registration tokens for a tenant
     */
    list: operatorProcedure()
      .input(z.object({ tenantId: z.number() }))
      .query(async ({ input }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const tokens = await db
            .select()
            .from(nodeRegistrationTokens)
            .where(eq(nodeRegistrationTokens.tenantId, input.tenantId))
            .orderBy(desc(nodeRegistrationTokens.createdAt));

          return tokens.map((t: any) => ({
            id: t.id,
            token: t.token.substring(0, 10) + "...", // Mask token
            description: t.description,
            isActive: t.isActive,
            expiresAt: t.expiresAt,
            usedAt: t.usedAt,
            usedByNodeId: t.usedByNodeId,
            createdAt: t.createdAt,
          }));
        } catch (error) {
          console.error("Failed to list tokens:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to list tokens",
          });
        }
      }),

    /**
     * Generate new registration token
     */
    generate: operatorProcedure()
      .input(
        z.object({
          tenantId: z.number(),
          description: z.string().optional(),
          expiresInDays: z.number().default(30),
        })
      )
      .mutation(async ({ input, ctx }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const token = crypto.randomBytes(32).toString("hex");
          const expiresAt = new Date();
          expiresAt.setDate(expiresAt.getDate() + input.expiresInDays);

          await db.insert(nodeRegistrationTokens).values({
            tenantId: input.tenantId,
            token,
            description: input.description,
            expiresAt,
            isActive: true,
          });

          // Log audit
          await db.insert(auditLogs).values({
            tenantId: input.tenantId,
            userId: ctx.user?.id || 0,
            action: "token_generated",
            resourceType: "token",
            details: { description: input.description, expiresInDays: input.expiresInDays },
          });

          return { token, expiresAt };
        } catch (error) {
          console.error("Failed to generate token:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to generate token",
          });
        }
      }),

    /**
     * Revoke registration token
     */
    revoke: operatorProcedure()
      .input(z.object({ tokenId: z.number() }))
      .mutation(async ({ input, ctx }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          const token = await db
            .select()
            .from(nodeRegistrationTokens)
            .where(eq(nodeRegistrationTokens.id, input.tokenId))
            .limit(1);

          if (!token || token.length === 0) {
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "Token not found",
            });
          }

          await db.update(nodeRegistrationTokens).set({ isActive: false }).where(eq(nodeRegistrationTokens.id, input.tokenId));

          // Log audit
          await db.insert(auditLogs).values({
            tenantId: token[0].tenantId,
            userId: ctx.user?.id || 0,
            action: "token_revoked",
            resourceType: "token",
            resourceId: String(input.tokenId),
          });

          return { success: true };
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          console.error("Failed to revoke token:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to revoke token",
          });
        }
      }),
  },

  // ===== Audit Logs =====

  logs: {
    /**
     * List audit logs for a tenant
     */
    list: operatorProcedure()
      .input(z.object({ tenantId: z.number().optional(), limit: z.number().default(100) }))
      .query(async ({ input }: any) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");
          let query: any = db.select().from(auditLogs);

          if (input.tenantId) {
            query = query.where(eq(auditLogs.tenantId, input.tenantId));
          }

          const logs = await query.orderBy(desc(auditLogs.createdAt)).limit(input.limit);

          return logs;
        } catch (error) {
          console.error("Failed to list audit logs:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to list audit logs",
          });
        }
      }),
  },
});
