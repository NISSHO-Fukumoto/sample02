import type { ReportData } from "./db";

function formatSeconds(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (h > 0) return `${h}時間${m}分`;
  if (m > 0) return `${m}分`;
  return `${seconds}秒`;
}

function rateColor(rate: number): string {
  if (rate >= 85) return "#10b981";
  if (rate >= 70) return "#f59e0b";
  if (rate >= 50) return "#f97316";
  return "#ef4444";
}

function barWidth(value: number, max: number): string {
  if (max === 0) return "0%";
  return `${Math.min(100, (value / max) * 100).toFixed(1)}%`;
}

export function generateReportHtml(data: ReportData, title: string): string {
  const { overallSummary, machineSummaries, timeSeriesData, period, generatedAt } = data;

  const maxProduction = Math.max(...timeSeriesData.map((d) => d.totalProductionCount), 1);

  const machineRows = machineSummaries
    .map(
      (m, i) => `
    <tr style="background:${i % 2 === 0 ? "#ffffff" : "#f8fafc"}">
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;font-weight:600;color:#1e293b">${m.machineName}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;color:#64748b;font-size:11px">${m.machineType}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;color:#64748b;font-size:11px">${m.lineName ?? "—"}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:center">
        <span style="font-size:15px;font-weight:700;color:${rateColor(m.avgOperationRate)}">${m.avgOperationRate.toFixed(1)}%</span>
      </td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#10b981;font-size:12px">${formatSeconds(m.totalRunningSeconds)}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#ef4444;font-size:12px">${formatSeconds(m.totalStoppedSeconds)}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#f59e0b;font-size:12px">${formatSeconds(m.totalIdleSeconds)}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:right;font-weight:600;color:#1e293b">${m.totalProductionCount.toLocaleString()}</td>
      <td style="padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#64748b;font-size:11px">
        ${m.achievementRate != null ? `${m.achievementRate.toFixed(1)}%` : "—"}
      </td>
    </tr>`
    )
    .join("");

  const timeSeriesRows = timeSeriesData
    .map(
      (d, i) => `
    <tr style="background:${i % 2 === 0 ? "#ffffff" : "#f8fafc"}">
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0;font-size:12px;color:#475569">${d.date}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:center">
        <span style="font-weight:700;color:${rateColor(d.avgOperationRate)}">${d.avgOperationRate.toFixed(1)}%</span>
      </td>
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0">
        <div style="display:flex;align-items:center;gap:6px">
          <div style="flex:1;background:#f1f5f9;border-radius:4px;height:8px;overflow:hidden">
            <div style="height:100%;background:#10b981;width:${barWidth(d.totalRunningSeconds, d.totalRunningSeconds + d.totalStoppedSeconds + d.totalIdleSeconds)};border-radius:4px"></div>
          </div>
          <span style="font-size:11px;color:#10b981;min-width:50px;text-align:right">${formatSeconds(d.totalRunningSeconds)}</span>
        </div>
      </td>
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#ef4444;font-size:11px">${formatSeconds(d.totalStoppedSeconds)}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:right;color:#f59e0b;font-size:11px">${formatSeconds(d.totalIdleSeconds)}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #e2e8f0;text-align:right;font-weight:600;font-size:12px">
        <div style="display:flex;align-items:center;gap:4px;justify-content:flex-end">
          <div style="background:#e0f2fe;border-radius:3px;height:6px;width:${barWidth(d.totalProductionCount, maxProduction)};max-width:60px"></div>
          <span>${d.totalProductionCount.toLocaleString()}</span>
        </div>
      </td>
    </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: "Hiragino Kaku Gothic ProN", "Noto Sans JP", "Yu Gothic", sans-serif;
      font-size: 13px;
      color: #1e293b;
      background: #ffffff;
      line-height: 1.5;
    }
    .page { padding: 0; }
    .header {
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
      color: white;
      padding: 24px 28px 20px;
      margin-bottom: 20px;
    }
    .header-top { display: flex; justify-content: space-between; align-items: flex-start; }
    .header h1 { font-size: 22px; font-weight: 700; letter-spacing: 0.02em; }
    .header .subtitle { font-size: 13px; color: #94a3b8; margin-top: 4px; }
    .header .meta { text-align: right; font-size: 11px; color: #94a3b8; }
    .section { margin: 0 20px 20px; }
    .section-title {
      font-size: 13px;
      font-weight: 700;
      color: #475569;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      border-bottom: 2px solid #e2e8f0;
      padding-bottom: 6px;
      margin-bottom: 12px;
    }
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
      margin-bottom: 20px;
    }
    .summary-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
      text-align: center;
    }
    .summary-card .value {
      font-size: 24px;
      font-weight: 700;
      color: #0f172a;
      line-height: 1.2;
    }
    .summary-card .label {
      font-size: 11px;
      color: #64748b;
      margin-top: 4px;
    }
    .summary-card.highlight .value { color: #2563eb; }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    thead tr {
      background: #0f172a;
      color: white;
    }
    thead th {
      padding: 9px 10px;
      text-align: left;
      font-weight: 600;
      font-size: 11px;
      letter-spacing: 0.04em;
    }
    thead th.right { text-align: right; }
    thead th.center { text-align: center; }
    .rate-bar {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .rate-bar-track {
      flex: 1;
      background: #e2e8f0;
      border-radius: 4px;
      height: 8px;
      overflow: hidden;
    }
    .footer {
      margin-top: 24px;
      padding: 12px 20px;
      border-top: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      font-size: 10px;
      color: #94a3b8;
    }
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
  </style>
</head>
<body>
<div class="page">
  <!-- ヘッダー -->
  <div class="header">
    <div class="header-top">
      <div>
        <h1>${title}</h1>
        <div class="subtitle">集計期間: ${period.from.toLocaleDateString("ja-JP")} 〜 ${period.to.toLocaleDateString("ja-JP")}</div>
      </div>
      <div class="meta">
        <div>生成日時</div>
        <div>${generatedAt.toLocaleString("ja-JP")}</div>
      </div>
    </div>
  </div>

  <!-- 全体サマリー -->
  <div class="section">
    <div class="section-title">全体サマリー</div>
    <div class="summary-grid">
      <div class="summary-card">
        <div class="value">${overallSummary.activeMachines} <span style="font-size:14px;color:#64748b">/ ${overallSummary.totalMachines}</span></div>
        <div class="label">稼働機械台数</div>
      </div>
      <div class="summary-card highlight">
        <div class="value" style="color:${rateColor(overallSummary.avgOperationRate)}">${overallSummary.avgOperationRate.toFixed(1)}%</div>
        <div class="label">平均稼働率</div>
      </div>
      <div class="summary-card">
        <div class="value">${overallSummary.totalProductionCount.toLocaleString()}</div>
        <div class="label">総生産数</div>
      </div>
      <div class="summary-card">
        <div class="value" style="font-size:18px">${formatSeconds(overallSummary.totalRunningSeconds)}</div>
        <div class="label">総運転時間</div>
      </div>
    </div>

    <!-- 時間内訳バー -->
    <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 16px">
      <div style="font-size:11px;color:#64748b;margin-bottom:8px;font-weight:600">時間内訳</div>
      ${(() => {
        const total = overallSummary.totalRunningSeconds + overallSummary.totalStoppedSeconds + overallSummary.totalIdleSeconds;
        if (total === 0) return '<div style="color:#94a3b8;font-size:11px">データなし</div>';
        const runPct = ((overallSummary.totalRunningSeconds / total) * 100).toFixed(1);
        const stopPct = ((overallSummary.totalStoppedSeconds / total) * 100).toFixed(1);
        const idlePct = ((overallSummary.totalIdleSeconds / total) * 100).toFixed(1);
        return `
        <div style="display:flex;height:16px;border-radius:6px;overflow:hidden;margin-bottom:8px">
          <div style="width:${runPct}%;background:#10b981"></div>
          <div style="width:${idlePct}%;background:#f59e0b"></div>
          <div style="width:${stopPct}%;background:#ef4444"></div>
        </div>
        <div style="display:flex;gap:16px;font-size:11px">
          <span style="color:#10b981">■ 運転 ${runPct}% (${formatSeconds(overallSummary.totalRunningSeconds)})</span>
          <span style="color:#f59e0b">■ チョコ停 ${idlePct}% (${formatSeconds(overallSummary.totalIdleSeconds)})</span>
          <span style="color:#ef4444">■ 停止 ${stopPct}% (${formatSeconds(overallSummary.totalStoppedSeconds)})</span>
        </div>`;
      })()}
    </div>
  </div>

  <!-- 機械別集計 -->
  <div class="section">
    <div class="section-title">機械別稼働実績</div>
    <table>
      <thead>
        <tr>
          <th>機械名</th>
          <th>種別</th>
          <th>ライン</th>
          <th class="center">稼働率</th>
          <th class="right">運転時間</th>
          <th class="right">停止時間</th>
          <th class="right">チョコ停</th>
          <th class="right">生産数</th>
          <th class="right">目標達成率</th>
        </tr>
      </thead>
      <tbody>
        ${machineRows || '<tr><td colspan="9" style="padding:16px;text-align:center;color:#94a3b8">データなし</td></tr>'}
      </tbody>
    </table>
  </div>

  <!-- 日別推移 -->
  ${timeSeriesData.length > 0 ? `
  <div class="section">
    <div class="section-title">日別推移</div>
    <table>
      <thead>
        <tr>
          <th>日付</th>
          <th class="center">平均稼働率</th>
          <th>運転時間</th>
          <th class="right">停止時間</th>
          <th class="right">チョコ停</th>
          <th class="right">生産数</th>
        </tr>
      </thead>
      <tbody>
        ${timeSeriesRows}
      </tbody>
    </table>
  </div>
  ` : ""}

  <!-- フッター -->
  <div class="footer">
    <span>製造現場 機械稼働状況ダッシュボード</span>
    <span>集計期間: ${period.from.toLocaleDateString("ja-JP")} 〜 ${period.to.toLocaleDateString("ja-JP")} | 生成: ${generatedAt.toLocaleString("ja-JP")}</span>
  </div>
</div>
</body>
</html>`;
}
