import {
  mysqlTable,
  mysqlEnum,
  int,
  bigint,
  varchar,
  text,
  boolean,
  decimal,
  timestamp,
  json,
  date,
} from "drizzle-orm/mysql-core";

// ===== Users =====
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== Machines (機械マスター) =====
export const machines = mysqlTable("machines", {
  id: int("id").autoincrement().primaryKey(),
  machineId: varchar("machine_id", { length: 50 }).notNull().unique(),
  machineName: varchar("machine_name", { length: 100 }).notNull(),
  machineType: varchar("machine_type", { length: 100 }).notNull(),
  location: varchar("location", { length: 100 }),
  lineName: varchar("line_name", { length: 100 }),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  targetProductionCount: int("target_production_count"),
  sortOrder: int("sort_order").default(0),
  // 閾値・稼働設定
  timeStart: varchar("time_start", { length: 5 }).default("08:00"),
  timeEnd: varchar("time_end", { length: 5 }).default("18:00"),
  durChoco: int("dur_choco").default(60),
  durDoka: int("dur_doka").default(600),
  durEnd: int("dur_end").default(3600),
  breakTimes: json("break_times"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Machine = typeof machines.$inferSelect;
export type InsertMachine = typeof machines.$inferInsert;

// ===== Devices (Raspberry Pi ノード端末) =====
export const devices = mysqlTable("devices", {
  id: int("id").autoincrement().primaryKey(),
  deviceId: varchar("device_id", { length: 50 }).notNull().unique(),
  deviceName: varchar("device_name", { length: 100 }),
  apiKey: varchar("api_key", { length: 128 }).notNull().unique(),
  machineId: varchar("machine_id", { length: 50 }),
  ipAddress: varchar("ip_address", { length: 45 }),
  location: varchar("location", { length: 100 }),
  isActive: boolean("is_active").default(true).notNull(),
  lastSeenAt: timestamp("last_seen_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Device = typeof devices.$inferSelect;
export type InsertDevice = typeof devices.$inferInsert;

// ===== Machine Logs (稼働ログ) =====
export const machineLogs = mysqlTable("machine_logs", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  machineId: varchar("machine_id", { length: 50 }).notNull(),
  deviceId: varchar("device_id", { length: 50 }),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  state: mysqlEnum("state", ["running", "stopped", "idle", "maintenance"]).notNull().default("stopped"),
  runningSeconds: int("running_seconds").default(0).notNull(),
  stoppedSeconds: int("stopped_seconds").default(0).notNull(),
  idleSeconds: int("idle_seconds").default(0).notNull(),
  maintenanceSeconds: int("maintenance_seconds").default(0).notNull(),
  totalSeconds: int("total_seconds").default(0).notNull(),
  operationRate: decimal("operation_rate", { precision: 5, scale: 2 }),
  productionCount: int("production_count").default(0).notNull(),
  targetProductionCount: int("target_production_count"),
  // 将来拡張: エネルギー消費量
  steamConsumption: decimal("steam_consumption", { precision: 10, scale: 3 }),
  electricityConsumption: decimal("electricity_consumption", { precision: 10, scale: 3 }),
  airConsumption: decimal("air_consumption", { precision: 10, scale: 3 }),
  gasConsumption: decimal("gas_consumption", { precision: 10, scale: 3 }),
  waterConsumption: decimal("water_consumption", { precision: 10, scale: 3 }),
  hotWaterConsumption: decimal("hot_water_consumption", { precision: 10, scale: 3 }),
  // 将来拡張: コスト・売上
  laborCost: decimal("labor_cost", { precision: 12, scale: 2 }),
  productionCost: decimal("production_cost", { precision: 12, scale: 2 }),
  productionRevenue: decimal("production_revenue", { precision: 12, scale: 2 }),
  // 生データ
  rawData: json("raw_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type MachineLog = typeof machineLogs.$inferSelect;
export type InsertMachineLog = typeof machineLogs.$inferInsert;

// ===== Dashboard Layouts (端末ごとのレイアウト設定) =====
export const dashboardLayouts = mysqlTable("dashboard_layouts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id"),
  terminalId: varchar("terminal_id", { length: 100 }),
  layoutName: varchar("layout_name", { length: 100 }).default("default"),
  cardOrder: json("card_order"),
  visibleMachines: json("visible_machines"),
  showTargetProduction: boolean("show_target_production").default(false).notNull(),
  showActualProductionTime: boolean("show_actual_production_time").default(false).notNull(),
  showEnergyPlaceholder: boolean("show_energy_placeholder").default(false).notNull(),
  showCostPlaceholder: boolean("show_cost_placeholder").default(false).notNull(),
  refreshInterval: int("refresh_interval").default(300000).notNull(),
  gridColumns: int("grid_columns").default(3).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type DashboardLayout = typeof dashboardLayouts.$inferSelect;
export type InsertDashboardLayout = typeof dashboardLayouts.$inferInsert;

// ===== Machine Types (機械種別マスター) =====
export const machineTypes = mysqlTable("machine_types", {
  id: int("id").autoincrement().primaryKey(),
  type_name: varchar("type_name", { length: 100 }).notNull(),
  sort_order: int("sort_order").default(0),
});

export type MachineType = typeof machineTypes.$inferSelect;
export type InsertMachineType = typeof machineTypes.$inferInsert;

// ===== Daily Records (日報・稼働集計) =====
export const dailyRecords = mysqlTable("daily_records", {
  id: int("id").autoincrement().primaryKey(),
  recordDate: date("record_date").notNull(),
  machineId: varchar("machine_id", { length: 50 }).notNull(),
  totalCount: int("total_count").default(0).notNull(),
  totalRunTime: int("total_run_time").default(0).notNull(),
  totalChocoTime: int("total_choco_time").default(0).notNull(),
  totalDokaTime: int("total_doka_time").default(0).notNull(),
  totalStopTime: int("total_stop_time").default(0).notNull(),
  utilizationRate: decimal("utilization_rate", { precision: 5, scale: 2 }).default("0.00"),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type DailyRecord = typeof dailyRecords.$inferSelect;
export type InsertDailyRecord = typeof dailyRecords.$inferInsert;

// ===== Stop Events (停止イベント明細) =====
export const stopEvents = mysqlTable("stop_events", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  machineId: varchar("machine_id", { length: 50 }).notNull(),
  stopType: mysqlEnum("stop_type", ["CHOCO", "DOKA"]).notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: int("duration"),
  manualReason: varchar("manual_reason", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type StopEvent = typeof stopEvents.$inferSelect;
export type InsertStopEvent = typeof stopEvents.$inferInsert;
