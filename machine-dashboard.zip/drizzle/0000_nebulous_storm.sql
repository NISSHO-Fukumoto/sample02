CREATE TABLE `dashboard_layouts` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`user_id` int,
	`terminal_id` varchar(128),
	`layout_name` varchar(100) DEFAULT 'デフォルト',
	`card_order` json,
	`visible_machines` json,
	`show_target_production` boolean NOT NULL DEFAULT false,
	`show_actual_production_time` boolean NOT NULL DEFAULT false,
	`show_energy_placeholder` boolean NOT NULL DEFAULT false,
	`show_cost_placeholder` boolean NOT NULL DEFAULT false,
	`refresh_interval` int NOT NULL DEFAULT 300000,
	`grid_columns` int NOT NULL DEFAULT 3,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dashboard_layouts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `devices` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`device_id` varchar(64) NOT NULL,
	`device_name` varchar(100),
	`api_key` varchar(128) NOT NULL,
	`machine_id` varchar(50),
	`ip_address` varchar(45),
	`location` varchar(100),
	`is_active` boolean NOT NULL DEFAULT true,
	`last_seen_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `devices_id` PRIMARY KEY(`id`),
	CONSTRAINT `devices_device_id_unique` UNIQUE(`device_id`),
	CONSTRAINT `devices_api_key_unique` UNIQUE(`api_key`)
);
--> statement-breakpoint
CREATE TABLE `machine_logs` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`machine_id` varchar(50) NOT NULL,
	`device_id` varchar(64),
	`period_start` timestamp NOT NULL,
	`period_end` timestamp NOT NULL,
	`state` enum('running','stopped','idle','maintenance') NOT NULL DEFAULT 'stopped',
	`running_seconds` int NOT NULL DEFAULT 0,
	`stopped_seconds` int NOT NULL DEFAULT 0,
	`idle_seconds` int NOT NULL DEFAULT 0,
	`maintenance_seconds` int NOT NULL DEFAULT 0,
	`total_seconds` int NOT NULL DEFAULT 0,
	`operation_rate` decimal(5,2) DEFAULT '0',
	`production_count` int NOT NULL DEFAULT 0,
	`target_production_count` int DEFAULT 0,
	`steam_consumption` decimal(10,3),
	`electricity_consumption` decimal(10,3),
	`air_consumption` decimal(10,3),
	`gas_consumption` decimal(10,3),
	`water_consumption` decimal(10,3),
	`hot_water_consumption` decimal(10,3),
	`labor_cost` decimal(12,2),
	`production_cost` decimal(12,2),
	`production_revenue` decimal(12,2),
	`raw_data` json,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `machine_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `machines` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`machine_id` varchar(50) NOT NULL,
	`machine_name` varchar(100) NOT NULL,
	`machine_type` varchar(50) NOT NULL,
	`location` varchar(100),
	`line_name` varchar(50),
	`description` text,
	`is_active` boolean NOT NULL DEFAULT true,
	`target_production_count` int DEFAULT 0,
	`sort_order` int DEFAULT 0,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `machines_id` PRIMARY KEY(`id`),
	CONSTRAINT `machines_machine_id_unique` UNIQUE(`machine_id`)
);
--> statement-breakpoint
CREATE TABLE `system_settings` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`ingest_api_key` varchar(256) DEFAULT '',
	`default_refresh_interval` int NOT NULL DEFAULT 300000,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `system_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`open_id` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`login_method` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`last_signed_in` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_open_id_unique` UNIQUE(`open_id`)
);
--> statement-breakpoint
CREATE INDEX `idx_machine_logs_machine_period` ON `machine_logs` (`machine_id`,`period_start`);--> statement-breakpoint
CREATE INDEX `idx_machine_logs_device` ON `machine_logs` (`device_id`);