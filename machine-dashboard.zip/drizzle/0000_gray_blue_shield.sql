CREATE TABLE `dashboard_layouts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`terminalId` varchar(100),
	`layoutName` varchar(100) DEFAULT 'デフォルト',
	`cardOrder` json,
	`visibleMachines` json,
	`showTargetProduction` boolean NOT NULL DEFAULT false,
	`showActualProductionTime` boolean NOT NULL DEFAULT false,
	`showEnergyPlaceholder` boolean NOT NULL DEFAULT false,
	`showCostPlaceholder` boolean NOT NULL DEFAULT false,
	`refreshInterval` int NOT NULL DEFAULT 300000,
	`gridColumns` int NOT NULL DEFAULT 3,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dashboard_layouts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `devices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`deviceId` varchar(50) NOT NULL,
	`deviceName` varchar(100),
	`apiKey` varchar(128) NOT NULL,
	`machineId` varchar(50),
	`ipAddress` varchar(45),
	`location` varchar(100),
	`isActive` boolean NOT NULL DEFAULT true,
	`lastSeenAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `devices_id` PRIMARY KEY(`id`),
	CONSTRAINT `devices_deviceId_unique` UNIQUE(`deviceId`),
	CONSTRAINT `devices_apiKey_unique` UNIQUE(`apiKey`)
);
--> statement-breakpoint
CREATE TABLE `machine_logs` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`machineId` varchar(50) NOT NULL,
	`deviceId` varchar(50),
	`periodStart` timestamp NOT NULL,
	`periodEnd` timestamp NOT NULL,
	`state` enum('running','stopped','idle','maintenance') NOT NULL DEFAULT 'stopped',
	`runningSeconds` int NOT NULL DEFAULT 0,
	`stoppedSeconds` int NOT NULL DEFAULT 0,
	`idleSeconds` int NOT NULL DEFAULT 0,
	`maintenanceSeconds` int NOT NULL DEFAULT 0,
	`totalSeconds` int NOT NULL DEFAULT 0,
	`operationRate` decimal(5,2),
	`productionCount` int NOT NULL DEFAULT 0,
	`targetProductionCount` int,
	`steamConsumption` decimal(10,3),
	`electricityConsumption` decimal(10,3),
	`airConsumption` decimal(10,3),
	`gasConsumption` decimal(10,3),
	`waterConsumption` decimal(10,3),
	`hotWaterConsumption` decimal(10,3),
	`laborCost` decimal(12,2),
	`productionCost` decimal(12,2),
	`productionRevenue` decimal(12,2),
	`rawData` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `machine_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `machines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`machineId` varchar(50) NOT NULL,
	`machineName` varchar(100) NOT NULL,
	`machineType` varchar(100) NOT NULL,
	`location` varchar(100),
	`lineName` varchar(100),
	`description` text,
	`isActive` boolean NOT NULL DEFAULT true,
	`targetProductionCount` int,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `machines_id` PRIMARY KEY(`id`),
	CONSTRAINT `machines_machineId_unique` UNIQUE(`machineId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
