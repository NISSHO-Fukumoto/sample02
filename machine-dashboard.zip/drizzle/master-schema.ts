/**
 * Master Database Schema
 * 
 * This schema is used for managing tenants and their database connections.
 * It runs on a separate "master" database that is shared across all tenants.
 */

import {
  mysqlTable,
  mysqlEnum,
  int,
  varchar,
  text,
  boolean,
  timestamp,
  json,
} from "drizzle-orm/mysql-core";

// ===== Tenants (顧客企業マスター) =====
export const tenants = mysqlTable("tenants", {
  id: int("id").autoincrement().primaryKey(),
  tenantId: varchar("tenant_id", { length: 50 }).notNull().unique(),
  companyName: varchar("company_name", { length: 200 }).notNull(),
  subdomain: varchar("subdomain", { length: 100 }).notNull().unique(),
  // DB接続情報
  dbHost: varchar("db_host", { length: 255 }).notNull(),
  dbPort: int("db_port").default(3306).notNull(),
  dbName: varchar("db_name", { length: 100 }).notNull(),
  dbUser: varchar("db_user", { length: 100 }).notNull(),
  dbPasswordSecretId: varchar("db_password_secret_id", { length: 255 }).notNull(), // AWS Secrets Manager等の参照ID
  // ステータス管理
  status: mysqlEnum("status", ["active", "suspended", "deleted"]).default("active").notNull(),
  // プラン情報（将来拡張）
  plan: varchar("plan", { length: 50 }).default("basic"),
  maxUsers: int("max_users").default(10),
  maxPlants: int("max_plants").default(5),
  // メタデータ
  timezone: varchar("timezone", { length: 50 }).default("Asia/Tokyo"),
  memo: text("memo"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Tenant = typeof tenants.$inferSelect;
export type InsertTenant = typeof tenants.$inferInsert;

// ===== Tenant Users (テナント内のユーザー) =====
export const tenantUsers = mysqlTable("tenant_users", {
  id: int("id").autoincrement().primaryKey(),
  tenantId: int("tenant_id").notNull(),
  openId: varchar("open_id", { length: 64 }).notNull(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  // ロール: customer_user, customer_admin, ops, engineer
  role: mysqlEnum("role", ["customer_user", "customer_admin", "ops", "engineer"]).default("customer_user").notNull(),
  // ステータス
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active").notNull(),
  // 代理ログイン用
  impersonationToken: varchar("impersonation_token", { length: 255 }),
  impersonationExpiresAt: timestamp("impersonation_expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type TenantUser = typeof tenantUsers.$inferSelect;
export type InsertTenantUser = typeof tenantUsers.$inferInsert;

// ===== Node Registration Tokens (ノード登録用トークン) =====
export const nodeRegistrationTokens = mysqlTable("node_registration_tokens", {
  id: int("id").autoincrement().primaryKey(),
  tenantId: int("tenant_id").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  isActive: boolean("is_active").default(true).notNull(),
  expiresAt: timestamp("expires_at"),
  usedAt: timestamp("used_at"),
  usedByNodeId: varchar("used_by_node_id", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type NodeRegistrationToken = typeof nodeRegistrationTokens.$inferSelect;
export type InsertNodeRegistrationToken = typeof nodeRegistrationTokens.$inferInsert;

// ===== Audit Logs (監査ログ) =====
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  tenantId: int("tenant_id"),
  userId: int("user_id"),
  action: varchar("action", { length: 100 }).notNull(), // e.g., "tenant_created", "impersonation_login"
  resourceType: varchar("resource_type", { length: 100 }), // e.g., "tenant", "user", "node"
  resourceId: varchar("resource_id", { length: 100 }),
  details: json("details"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// ===== Tenant Cache (テナント情報キャッシュ) =====
export const tenantCache = mysqlTable("tenant_cache", {
  id: int("id").autoincrement().primaryKey(),
  subdomain: varchar("subdomain", { length: 100 }).notNull().unique(),
  tenantId: int("tenant_id").notNull(),
  dbHost: varchar("db_host", { length: 255 }).notNull(),
  dbPort: int("db_port").notNull(),
  dbName: varchar("db_name", { length: 100 }).notNull(),
  dbUser: varchar("db_user", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  cachedAt: timestamp("cached_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

export type TenantCacheEntry = typeof tenantCache.$inferSelect;
export type InsertTenantCacheEntry = typeof tenantCache.$inferInsert;
