/**
 * Tenant Database Schema Extensions
 * 
 * These tables are added to each tenant's database to support multi-tenant architecture.
 * They extend the existing schema with tenant-specific information.
 */

import {
  mysqlTable,
  int,
  varchar,
  text,
  timestamp,
  json,
} from "drizzle-orm/mysql-core";

// ===== Plants (工場マスター) =====
export const plants = mysqlTable("plants", {
  id: int("id").autoincrement().primaryKey(),
  plantId: varchar("plant_id", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  location: varchar("location", { length: 200 }),
  timezone: varchar("timezone", { length: 50 }).default("Asia/Tokyo"),
  memo: text("memo"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Plant = typeof plants.$inferSelect;
export type InsertPlant = typeof plants.$inferInsert;

// ===== Nodes (ラズパイ端末マスター) =====
export const nodes = mysqlTable("nodes", {
  id: int("id").autoincrement().primaryKey(),
  nodeId: varchar("node_id", { length: 100 }).notNull().unique(),
  plantId: int("plant_id").notNull(),
  machineId: varchar("machine_id", { length: 50 }), // 紐づく機械ID（オプション）
  nodeName: varchar("node_name", { length: 100 }),
  location: varchar("location", { length: 100 }),
  firmwareVersion: varchar("firmware_version", { length: 50 }),
  // ノード設定（ノード側が正とする）
  timeStart: varchar("time_start", { length: 5 }).default("08:00"),
  timeEnd: varchar("time_end", { length: 5 }).default("18:00"),
  durChoco: int("dur_choco").default(60), // チョコ停判定秒数
  durDoka: int("dur_doka").default(600), // ドカ停判定秒数
  durEnd: int("dur_end").default(3600), // 終業判定秒数
  breakTimes: json("break_times"), // 休憩時間設定
  // 死活監視
  lastSeenAt: timestamp("last_seen_at"),
  lastConfigSyncAt: timestamp("last_config_sync_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Node = typeof nodes.$inferSelect;
export type InsertNode = typeof nodes.$inferInsert;

/**
 * Extensions to existing tables (to be added via migration):
 * 
 * machines:
 *   - plant_id (int, foreign key to plants)
 * 
 * daily_records:
 *   - plant_id (int, foreign key to plants)
 * 
 * stop_events:
 *   - plant_id (int, foreign key to plants)
 *   - node_id (int, foreign key to nodes) - optional, for data source tracking
 */
