CREATE TABLE `daily_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`plantId` int,
	`recordDate` date NOT NULL,
	`machineId` varchar(50) NOT NULL,
	`totalCount` int NOT NULL DEFAULT 0,
	`totalRunTime` int NOT NULL DEFAULT 0,
	`totalChocoTime` int NOT NULL DEFAULT 0,
	`totalDokaTime` int NOT NULL DEFAULT 0,
	`totalStopTime` int NOT NULL DEFAULT 0,
	`utilizationRate` decimal(5,2) DEFAULT '0.00',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `machine_types` (
	`id` int AUTO_INCREMENT NOT NULL,
	`typeName` varchar(100) NOT NULL,
	`sortOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `machine_types_id` PRIMARY KEY(`id`),
	CONSTRAINT `machine_types_typeName_unique` UNIQUE(`typeName`)
);
--> statement-breakpoint
CREATE TABLE `nodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nodeId` varchar(100) NOT NULL,
	`plantId` int NOT NULL,
	`machineId` varchar(50),
	`nodeName` varchar(100),
	`location` varchar(100),
	`firmwareVersion` varchar(50),
	`timeStart` varchar(5) DEFAULT '08:00',
	`timeEnd` varchar(5) DEFAULT '18:00',
	`durChoco` int DEFAULT 60,
	`durDoka` int DEFAULT 600,
	`durEnd` int DEFAULT 3600,
	`breakTimes` json,
	`lastSeenAt` timestamp,
	`lastConfigSyncAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `nodes_id` PRIMARY KEY(`id`),
	CONSTRAINT `nodes_nodeId_unique` UNIQUE(`nodeId`)
);
--> statement-breakpoint
CREATE TABLE `plants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`plantId` varchar(50) NOT NULL,
	`name` varchar(200) NOT NULL,
	`location` varchar(200),
	`timezone` varchar(50) DEFAULT 'Asia/Tokyo',
	`memo` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `plants_id` PRIMARY KEY(`id`),
	CONSTRAINT `plants_plantId_unique` UNIQUE(`plantId`)
);
--> statement-breakpoint
CREATE TABLE `stop_events` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`plantId` int,
	`machineId` varchar(50) NOT NULL,
	`stopType` enum('CHOCO','DOKA') NOT NULL,
	`startTime` timestamp NOT NULL,
	`endTime` timestamp,
	`duration` int,
	`manualReason` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stop_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `dashboard_layouts` MODIFY COLUMN `layoutName` varchar(100) DEFAULT 'default';--> statement-breakpoint
ALTER TABLE `machine_logs` ADD `plantId` int;--> statement-breakpoint
ALTER TABLE `machines` ADD `plantId` int;--> statement-breakpoint
ALTER TABLE `machines` ADD `timeStart` varchar(5) DEFAULT '08:00';--> statement-breakpoint
ALTER TABLE `machines` ADD `timeEnd` varchar(5) DEFAULT '18:00';--> statement-breakpoint
ALTER TABLE `machines` ADD `durChoco` int DEFAULT 60;--> statement-breakpoint
ALTER TABLE `machines` ADD `durDoka` int DEFAULT 600;--> statement-breakpoint
ALTER TABLE `machines` ADD `durEnd` int DEFAULT 3600;--> statement-breakpoint
ALTER TABLE `machines` ADD `breakTimes` json;