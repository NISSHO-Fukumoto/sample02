import { drizzle } from "drizzle-orm/mysql2/promise";
import mysql from "mysql2/promise";
import { devices, machines, machineLogs } from "./drizzle/schema.ts";

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

// デバイスとマシンが存在するか確認
const existingDevices = await db.select().from(devices).limit(1);
console.log("Existing devices:", existingDevices);

const existingMachines = await db.select().from(machines).limit(1);
console.log("Existing machines:", existingMachines);

if (existingDevices.length > 0 && existingMachines.length > 0) {
  const device = existingDevices[0];
  const machine = existingMachines[0];
  
  console.log(`Using device: ${device.deviceId}, machine: ${machine.machineId}`);
  
  // テストログを挿入
  await db.insert(machineLogs).values({
    machineId: machine.machineId,
    deviceId: device.deviceId,
    periodStart: new Date("2026-03-04T00:00:00Z"),
    periodEnd: new Date("2026-03-04T01:00:00Z"),
    state: "running",
    runningSeconds: 3600,
    stoppedSeconds: 0,
    idleSeconds: 0,
    maintenanceSeconds: 0,
    totalSeconds: 3600,
    operationRate: "100.00",
    productionCount: 100,
    targetProductionCount: 120,
  });
  
  console.log("Test log inserted successfully");
}

await connection.end();
