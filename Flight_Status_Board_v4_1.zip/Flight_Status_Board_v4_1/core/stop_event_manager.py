"""
stop_event_manager.py - 停止イベント管理モジュール（改修版）
pasted_content_2.txt §6 に準拠。

改修ポイント:
  §6-1: StopEventManager 側で open 中イベントの開始時刻を自己保持し
        close 時はそれを用いて duration を計算する
  §6-2: close 時に必ず closeReason を記録する
        recovered / break_transition / shift_end / manual_reset /
        power_off / forced_close
  §6-3: open → update（ドカ停昇格）→ close の更新型を維持

イベントライフサイクル:
  open   → 停止確定時に生成
  update → ドカ停昇格時に更新
  close  → 復旧/休憩突入/終業時にクローズ
"""
import time
from datetime import datetime, timezone, timedelta
from typing import Optional

JST = timezone(timedelta(hours=+9), 'JST')

VALID_CLOSE_REASONS = {
    "recovered",
    "break_transition",
    "shift_end",
    "manual_reset",
    "power_off",
    "forced_close",
}


def _fmt(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, JST).isoformat()


class StopEventManager:
    """
    停止イベントを管理し、API 送信用ペイロードを生成する。
    1停止 = 1 eventId で open / update / close を管理する。
    """

    def __init__(self, machine_id: str):
        self.machine_id = machine_id
        self.current_event: Optional[dict] = None
        # 自己保持: open 時の開始時刻（§6-1）
        self._event_open_ts: Optional[float] = None

    # ------------------------------------------------------------------
    #   イベント ID 生成
    # ------------------------------------------------------------------
    def _generate_event_id(self, start_ts: float) -> str:
        dt = datetime.fromtimestamp(start_ts, JST)
        return f"stop-{self.machine_id}-{dt.strftime('%Y%m%d-%H%M%S')}"

    # ------------------------------------------------------------------
    #   状態機械の状態を受け取りイベントを生成する
    # ------------------------------------------------------------------
    def process(self, state_machine) -> list:
        """
        state_machine の現在状態を評価してイベントペイロードリストを返す。
        呼び出し側は返されたペイロードを API 送信キューに積む。
        """
        events = []
        state     = state_machine.current_state
        stop_class = state_machine.stop_class
        now = time.time()

        if state == "stop":
            if self.current_event is None:
                # ── 停止開始 ──────────────────────────────────────────
                # stop_start_at は StateMachine が補正済みの時刻を持つ
                start_ts = state_machine.stop_start_at or now
                self._event_open_ts = start_ts  # §6-1: 自己保持
                event_id = self._generate_event_id(start_ts)
                self.current_event = {
                    "eventId":        event_id,
                    "machineId":      self.machine_id,
                    "action":         "open",
                    "segmentStart":   _fmt(start_ts),
                    "currentState":   "stop",
                    "stopClass":      stop_class,
                    "reasonCode":     state_machine._reason_code(),
                    "thresholdSec":   state_machine.doka_threshold_sec,
                    "isClosed":       False,
                }
                events.append(self.current_event.copy())

            elif (self.current_event.get("stopClass") != stop_class
                  and stop_class == "doka"):
                # ── ドカ停昇格 ────────────────────────────────────────
                self.current_event["stopClass"] = "doka"
                self.current_event["action"]    = "update"
                doka_ts = state_machine.doka_at or now
                self.current_event["dokaAt"] = _fmt(doka_ts)
                # §6-1: 自己保持の開始時刻から経過時間を計算
                elapsed = int(now - self._event_open_ts) if self._event_open_ts else 0
                self.current_event["currentStopElapsedSec"] = elapsed
                events.append({
                    "eventId":                self.current_event["eventId"],
                    "machineId":              self.machine_id,
                    "action":                 "update",
                    "stopClass":              "doka",
                    "dokaAt":                 self.current_event["dokaAt"],
                    "currentStopElapsedSec":  elapsed,
                })

        elif self.current_event is not None:
            # ── 停止終了（running / planned_stop / off に遷移） ────────
            close_reason = self._determine_close_reason(state, state_machine)
            close_payload = self._build_close_payload(close_reason, now)
            events.append(close_payload)
            self.current_event = None
            self._event_open_ts = None

        return events

    # ------------------------------------------------------------------
    #   §6-2: closeReason の決定
    # ------------------------------------------------------------------
    def _determine_close_reason(self, new_state: str, state_machine) -> str:
        if new_state == "running":
            return "recovered"
        if new_state == "planned_stop":
            if state_machine.in_break_window:
                return "break_transition"
            return "shift_end"
        if new_state == "off":
            return "power_off"
        return "forced_close"

    # ------------------------------------------------------------------
    #   §6-1: 自己保持タイムスタンプを使った close ペイロード生成
    # ------------------------------------------------------------------
    def _build_close_payload(self, close_reason: str, now: float) -> dict:
        # §6-1: open 時の自己保持タイムスタンプを使用
        open_ts = self._event_open_ts or now
        duration = int(now - open_ts)

        return {
            "eventId":              self.current_event["eventId"],
            "machineId":            self.machine_id,
            "action":               "close",
            "segmentEnd":           _fmt(now),
            "finalStopDurationSec": duration,
            "finalStopClass":       self.current_event.get("stopClass"),
            "closeReason":          close_reason,  # §6-2
            "isClosed":             True,
        }

    # ------------------------------------------------------------------
    #   外部から強制クローズ（manual_reset など）
    # ------------------------------------------------------------------
    def force_close(self, reason: str = "manual_reset") -> Optional[dict]:
        """
        手動リセット・電源断などで強制クローズする。
        """
        if self.current_event is None:
            return None
        if reason not in VALID_CLOSE_REASONS:
            reason = "forced_close"
        now = time.time()
        payload = self._build_close_payload(reason, now)
        self.current_event = None
        self._event_open_ts = None
        return payload

    # ------------------------------------------------------------------
    #   現在イベントの取得
    # ------------------------------------------------------------------
    def get_current_event(self) -> Optional[dict]:
        return self.current_event

    def has_open_event(self) -> bool:
        return self.current_event is not None
