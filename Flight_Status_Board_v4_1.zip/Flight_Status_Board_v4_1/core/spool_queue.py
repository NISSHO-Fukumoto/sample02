"""
spool_queue.py - 再送キューモジュール（改修版）
pasted_content_2.txt §10 に準拠。

改修ポイント:
  - JSON Lines の append-only 方式（推奨）
  - 書き込み時の排他制御（threading.Lock）
  - 破損時の復旧処理（行単位パース）
  - 送信済み/未送信の識別（sent フラグ）
  - 再送途中クラッシュ時の安全性（sent=True を書いてから削除）
  - 上限件数超過時は古いものから削除

ファイル形式:
  各行が独立した JSON オブジェクト（JSON Lines / NDJSON）
  {"id": "...", "type": "...", "payload": {...}, "sent": false, "ts": 0.0}
"""
import json
import os
import time
import threading
import uuid
import logging

logger = logging.getLogger(__name__)


class SpoolQueue:
    """
    送信失敗ペイロードを管理する再送キュー。
    JSON Lines 形式の append-only ファイルで電源断に対応する。
    """

    def __init__(self, filepath: str = "spool.jsonl", max_size: int = 500):
        # 旧 .json ファイルとの互換: 拡張子を .jsonl に統一
        if filepath.endswith('.json') and not filepath.endswith('.jsonl'):
            filepath = filepath.replace('.json', '.jsonl')
        self.filepath = filepath
        self.max_size = max_size
        self._lock = threading.Lock()
        self._memory: list = []
        self._load()

    # ------------------------------------------------------------------
    #   ロード（起動時・破損復旧）
    # ------------------------------------------------------------------
    def _load(self):
        """JSON Lines ファイルを行単位でパース。壊れた行はスキップ。"""
        self._memory = []
        if not os.path.exists(self.filepath):
            return
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                for lineno, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                        # sent=True のものは読み込まない（送信済み）
                        if not item.get('sent', False):
                            self._memory.append(item)
                    except json.JSONDecodeError:
                        logger.warning(f"[Spool] Corrupt line {lineno}, skipped.")
            logger.info(f"[Spool] Loaded {len(self._memory)} pending items from {self.filepath}")
        except Exception as e:
            logger.warning(f"[Spool] Failed to load spool file: {e}")
            self._memory = []

    def _rewrite(self):
        """
        未送信アイテムのみでファイルを再書き込みする。
        ファイルが大きくなりすぎた場合の圧縮に使用。
        """
        try:
            tmp = self.filepath + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                for item in self._memory:
                    f.write(json.dumps(item, ensure_ascii=False) + '\n')
            os.replace(tmp, self.filepath)
        except Exception as e:
            logger.warning(f"[Spool] Rewrite failed: {e}")

    # ------------------------------------------------------------------
    #   エンキュー
    # ------------------------------------------------------------------
    def enqueue(self, item_type: str, payload: dict):
        """
        送信失敗したペイロードをキューに追加する。
        item_type: "current_status" | "stop_event" | "period_log"
        """
        with self._lock:
            item = {
                "id":      str(uuid.uuid4()),
                "type":    item_type,
                "payload": payload,
                "sent":    False,
                "ts":      time.time(),
            }
            self._memory.append(item)

            # リングバッファ: 上限超過時は古いものを削除
            if len(self._memory) > self.max_size:
                removed = len(self._memory) - self.max_size
                self._memory = self._memory[removed:]
                logger.warning(f"[Spool] Queue overflow. Removed {removed} oldest items.")
                self._rewrite()
                return

            # append-only: 新アイテムのみ追記
            try:
                with open(self.filepath, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(item, ensure_ascii=False) + '\n')
            except Exception as e:
                logger.warning(f"[Spool] Append failed: {e}")

    # ------------------------------------------------------------------
    #   デキュー（再送用）
    # ------------------------------------------------------------------
    def dequeue_all(self) -> list:
        """
        全未送信アイテムを取り出す。
        クラッシュ安全: 返したアイテムはまだ sent=False のまま。
        mark_sent() で明示的に送信済みにする。
        """
        with self._lock:
            return [item.copy() for item in self._memory if not item.get('sent', False)]

    def mark_sent(self, item_ids: list):
        """
        指定 ID のアイテムを送信済みにする。
        再送途中クラッシュ時の安全性: sent=True を書いてから削除。
        """
        with self._lock:
            id_set = set(item_ids)
            for item in self._memory:
                if item.get('id') in id_set:
                    item['sent'] = True
            # 送信済みをメモリから削除
            self._memory = [i for i in self._memory if not i.get('sent', False)]
            # ファイルを再書き込み（圧縮）
            self._rewrite()

    def peek(self) -> list:
        with self._lock:
            return [item.copy() for item in self._memory if not item.get('sent', False)]

    # ------------------------------------------------------------------
    #   サイズ
    # ------------------------------------------------------------------
    def size(self) -> int:
        with self._lock:
            return len([i for i in self._memory if not i.get('sent', False)])

    def is_empty(self) -> bool:
        return self.size() == 0
