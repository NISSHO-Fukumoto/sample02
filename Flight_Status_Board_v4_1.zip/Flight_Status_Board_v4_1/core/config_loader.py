"""
config_loader.py - 設定ファイル読み込みモジュール
Flight_Status_Board ノード端末用
"""
import configparser
import os
import sys
import json


class ConfigLoader:
    """conf.ini を読み込み、全設定値を管理するクラス"""

    def __init__(self, config_file=None):
        if config_file is None:
            if getattr(sys, 'frozen', False):
                base_dir = os.path.dirname(sys.executable)
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                base_dir = os.path.join(base_dir, '..')
            config_file = os.path.join(base_dir, 'conf.ini')

        self.config_file = os.path.abspath(config_file)
        self.config = configparser.ConfigParser()
        self._parser = self.config   # camera_config_ui.py 用エイリアス
        self._settings = {}
        self.load()

    # ------------------------------------------------------------------
    #   設定読み込み
    # ------------------------------------------------------------------
    def load(self):
        """conf.ini を読み込んで内部辞書に展開する"""
        if os.path.exists(self.config_file):
            try:
                self.config.read(self.config_file, encoding='utf-8')
            except UnicodeDecodeError:
                self.config.read(self.config_file, encoding='cp932')

        c = self.config

        # ── BASIC ──────────────────────────────────────────────────────
        self._settings['product_name']   = c.get('BASIC', 'product_name',   fallback='Flight_Status_Board')
        self._settings['version']        = c.get('BASIC', 'version',        fallback='1.0')
        self._settings['machine_id']     = c.get('BASIC', 'machine_id',     fallback='DEFAULT_MACHINE')
        self._settings['target']         = c.getint('BASIC', 'target',      fallback=100)
        self._settings['input_mode']     = c.get('BASIC', 'input_mode',     fallback='CAMERA').upper()

        # ── TIMEOUT ────────────────────────────────────────────────────
        self._settings['dur_choco_sec']  = c.getint('TIMEOUT', 'dur_choco_sec',  fallback=180)
        self._settings['dur_doka_sec']   = c.getint('TIMEOUT', 'dur_doka_sec',   fallback=600)
        self._settings['dur_poweroff_sec'] = c.getint('TIMEOUT', 'dur_poweroff_sec', fallback=3600)
        self._settings['sleep_timeout']  = c.getint('TIMEOUT', 'timeout_sec',    fallback=5400)

        # ── GPIO ───────────────────────────────────────────────────────
        self._settings['enable_gpio_reset'] = c.getboolean('GPIO', 'enable_gpio_reset', fallback=True)
        self._settings['gpio_reset_pin']    = c.getint('GPIO', 'gpio_reset_pin',        fallback=5)
        gpio_pins, hold_times, bounce_times = [], [], []
        for i in range(1, 6):
            pin_str = c.get('GPIO', f'input0{i}', fallback='').strip()
            if pin_str:
                try:
                    gpio_pins.append(int(pin_str))
                    hold_times.append(c.getfloat('GPIO', f'hold_time0{i}', fallback=0.05))
                    bounce_times.append(c.getfloat('GPIO', f'bounce_time0{i}', fallback=0.05))
                except ValueError:
                    pass
        self._settings['gpio_pins']        = gpio_pins
        self._settings['gpio_hold_times']  = hold_times
        self._settings['gpio_bounce_times'] = bounce_times

        # ── CAMERA ─────────────────────────────────────────────────────
        self._settings['cam_index']        = c.getint('CAMERA', 'camera_device_index', fallback=0)
        self._settings['cam_width']        = c.getint('CAMERA', 'camera_width',        fallback=640)
        self._settings['cam_height']       = c.getint('CAMERA', 'camera_height',       fallback=480)
        self._settings['cam_roi']          = c.get('CAMERA', 'roi_rect',               fallback='0.0, 0.0, 1.0, 1.0')
        self._settings['cam_area_th']      = c.getint('CAMERA', 'motion_area_threshold', fallback=500)
        self._settings['cam_hold_frames']  = c.getint('CAMERA', 'camera_hold_frames',  fallback=3)
        self._settings['cam_cooldown']     = c.getfloat('CAMERA', 'camera_cooldown_sec', fallback=0.5)
        self._settings['area_limit_min']   = c.getint('CAMERA', 'area_limit_min',      fallback=500)
        self._settings['area_limit_max']   = c.getint('CAMERA', 'area_limit_max',      fallback=50000)
        self._settings['stream_port']      = c.getint('CAMERA', 'stream_port',         fallback=5001)
        # 単色 HSV（従来互換）
        try:
            self._settings['l_hsv'] = json.loads(c.get('CAMERA', 'l_hsv', fallback='[100, 64, 64]'))
            self._settings['h_hsv'] = json.loads(c.get('CAMERA', 'h_hsv', fallback='[140, 255, 255]'))
        except Exception:
            self._settings['l_hsv'] = [100, 64, 64]
            self._settings['h_hsv'] = [140, 255, 255]
        # roi_contours（複数形リスト）
        roi_contours_str = c.get('CAMERA', 'roi_contours', fallback='[]')
        try:
            self._settings['roi_contours'] = json.loads(roi_contours_str)
        except Exception:
            self._settings['roi_contours'] = []
        # roi_contour（従来互換）
        roi_contour_str = c.get('CAMERA', 'roi_contour', fallback='[]')
        try:
            self._settings['roi_contour'] = json.loads(roi_contour_str)
        except Exception:
            self._settings['roi_contour'] = []

        # ── SCHEDULE ───────────────────────────────────────────────────
        self._settings['time_start']  = c.get('SCHEDULE', 'time_start',  fallback='').strip()
        self._settings['time_end']    = c.get('SCHEDULE', 'time_end',    fallback='').strip()
        breaks_raw = c.get('SCHEDULE', 'breaks', fallback='').strip()
        self._settings['breaks']      = [b.strip() for b in breaks_raw.split(',') if b.strip()]
        self._settings['cron_sec']    = c.get('SCHEDULE', 'cron_second', fallback='59')
        self._settings['cron_min']    = c.get('SCHEDULE', 'cron_minute', fallback='59')
        self._settings['cron_hour']   = c.get('SCHEDULE', 'cron_hour',   fallback='*')

        # ── INPUT (GPIO エラー入力 将来拡張オプション) ────────────────────
        # error_input_enabled = false の場合は監視しない（既存動作に影響なし）
        # error_input_enabled = true の場合のみ GPIO エラー入力を監視する
        self._settings['error_input_enabled']  = c.getboolean('INPUT', 'error_input_enabled',  fallback=False)
        self._settings['error_input_pin']      = c.getint('INPUT', 'error_input_pin',          fallback=27)
        self._settings['error_active_state']   = c.get('INPUT', 'error_active_state',          fallback='HIGH').strip().upper()

        # ── AUTO_RESET ─────────────────────────────────────────────────
        self._settings['enable_auto_reset']  = c.getboolean('AUTO_RESET', 'enable', fallback=False)
        self._settings['auto_reset_hour']    = c.get('AUTO_RESET', 'hour',   fallback='08')
        self._settings['auto_reset_min']     = c.get('AUTO_RESET', 'minute', fallback='00')

        # ── RESET ──────────────────────────────────────────────────────
        self._settings['enable_keyboard_reset'] = c.getboolean('RESET', 'enable_keyboard_reset', fallback=True)
        self._settings['reset_hold_time']       = c.getfloat('RESET', 'reset_hold_time', fallback=3.0)
        self._settings['exit_hold_time']        = c.getfloat('RESET', 'exit_hold_time',  fallback=2.0)

        # ── DISPLAY ────────────────────────────────────────────────────
        self._settings['font_file']    = c.get('DISPLAY', 'font_file',  fallback='fonts/ShareTechMono-Regular.ttf')
        self._settings['font_color']   = c.get('DISPLAY', 'font_color', fallback='#FFB000')
        self._settings['digit_count']  = c.getint('DISPLAY', 'digit_count', fallback=9)

        # ── CLOUD (サーバーAPI) ─────────────────────────────────────────
        self._settings['api_url']           = c.get('CLOUD', 'api_url',           fallback='http://localhost/api/node')
        self._settings['api_key']           = c.get('CLOUD', 'api_key',           fallback='')
        self._settings['sync_interval_sec'] = c.getint('CLOUD', 'sync_interval_sec', fallback=60)

    # ------------------------------------------------------------------
    #   アクセサ
    # ------------------------------------------------------------------
    def get(self, key, default=None):
        return self._settings.get(key, default)

    def set(self, key, value):
        self._settings[key] = value

    # ------------------------------------------------------------------
    #   設定ファイルへの書き戻し
    # ------------------------------------------------------------------
    def save(self):
        """変更した設定を conf.ini に書き戻す"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                self.config.write(f)
            return True
        except Exception:
            return False

    def update_and_save(self, section, key, value):
        """指定セクション/キーを更新して保存する"""
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, str(value))
        return self.save()
