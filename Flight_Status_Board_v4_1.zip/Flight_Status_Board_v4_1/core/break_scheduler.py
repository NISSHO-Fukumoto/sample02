"""
break_scheduler.py - 休憩スケジューラモジュール
pasted_content.txt §7 の計画停止ロジックを実装する。

設定例 (conf.ini):
  [SCHEDULE]
  breaks = 12:00-12:45, 15:00-15:15
"""
from datetime import datetime, time as dtime
from typing import Optional


class BreakScheduler:
    """
    設定された休憩時間帯を管理し、現在時刻が休憩中かどうかを判定する。
    """

    def __init__(self, config):
        self.config = config
        self._breaks: list[tuple[dtime, dtime]] = []
        self._parse_breaks()

    # ------------------------------------------------------------------
    #   設定パース
    # ------------------------------------------------------------------
    def _parse_breaks(self):
        breaks_list = self.config.get('breaks', [])
        if isinstance(breaks_list, str):
            breaks_list = [b.strip() for b in breaks_list.split(',') if b.strip()]

        self._breaks.clear()
        for b in breaks_list:
            b = b.strip()
            if not b:
                continue
            try:
                start_str, end_str = b.split('-')
                start_t = datetime.strptime(start_str.strip(), "%H:%M").time()
                end_t   = datetime.strptime(end_str.strip(),   "%H:%M").time()
                self._breaks.append((start_t, end_t))
            except Exception:
                pass

    def reload(self):
        """設定が更新された場合に再パースする"""
        self._parse_breaks()

    # ------------------------------------------------------------------
    #   判定
    # ------------------------------------------------------------------
    def is_break_time(self, dt: Optional[datetime] = None) -> bool:
        """現在（または指定日時）が休憩時間帯かどうかを返す"""
        if dt is None:
            dt = datetime.now()
        current_t = dt.time()

        for start_t, end_t in self._breaks:
            if start_t <= end_t:
                # 通常（日をまたがない）
                if start_t <= current_t <= end_t:
                    return True
            else:
                # 日またぎ（例: 23:00-01:00）
                if current_t >= start_t or current_t <= end_t:
                    return True
        return False

    # ------------------------------------------------------------------
    #   休憩リスト取得
    # ------------------------------------------------------------------
    def get_breaks(self) -> list[tuple[dtime, dtime]]:
        return list(self._breaks)

    def get_breaks_str_list(self) -> list[str]:
        return [f"{s.strftime('%H:%M')}-{e.strftime('%H:%M')}"
                for s, e in self._breaks]
