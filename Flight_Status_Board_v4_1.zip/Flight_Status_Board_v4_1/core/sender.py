"""
sender.py - 送信管理モジュール（改修版）
pasted_content_2.txt §7・§8・§9 に準拠。

改修ポイント:
  §7: 補助フラグ（scheduleViolation / alarm / manual / offline 等）の
      変化も状態変化として検知し、即時 current_status を送信する
  §8: current_status ペイロードに補助フラグを含める
  §9: period_log は planned_stop を stop と混ぜない
  §10: spool の mark_sent パターンに対応（クラッシュ安全再送）
"""
import threading
import time
import logging

logger = logging.getLogger(__name__)


class Sender:
    """
    API クライアントと再送キューを使って、
    ハートビート・停止イベント・実績ログを送信する。
    """

    def __init__(self, config, api_client, spool_queue,
                 state_machine, counter_tracker,
                 stop_event_manager, period_aggregator):
        self.config      = config
        self.api         = api_client
        self.spool       = spool_queue
        self.sm          = state_machine
        self.counter     = counter_tracker
        self.stop_mgr    = stop_event_manager
        self.aggregator  = period_aggregator

        self._running    = False
        self._thread     = None

        self._last_heartbeat  = 0.0
        self._last_period_log = 0.0
        self._last_retry      = 0.0
        self._retry_interval  = 30.0

    # ------------------------------------------------------------------
    #   起動 / 停止
    # ------------------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("[Sender] Started.")

    def stop(self):
        self._running = False

    # ------------------------------------------------------------------
    #   メインループ
    # ------------------------------------------------------------------
    def _loop(self):
        while self._running:
            try:
                self._tick()
            except Exception as e:
                logger.error(f"[Sender] Loop error: {e}")
            time.sleep(1.0)

    def _tick(self):
        now = time.time()
        sync_interval   = int(self.config.get('sync_interval_sec', 60))
        period_interval = max(sync_interval, 300)

        if now - self._last_heartbeat >= sync_interval:
            self._send_current_status("periodic")
            self._last_heartbeat = now

        if now - self._last_period_log >= period_interval:
            self._send_period_log()
            self._last_period_log = now

        if not self.spool.is_empty() and now - self._last_retry >= self._retry_interval:
            self._retry_spool()
            self._last_retry = now

    # ------------------------------------------------------------------
    #   状態変化時の即時送信（§7: 補助フラグ変化も対象）
    # ------------------------------------------------------------------
    def on_state_changed(self):
        """状態変化時（補助フラグ含む）に即時 current_status を送信する"""
        self._send_current_status("event")

    def on_stop_events(self, events: list):
        """停止イベントリストを送信する"""
        for event in events:
            ok = self.api.send_stop_event(event)
            if not ok:
                self.spool.enqueue("stop_event", event)
                logger.warning(f"[Sender] stop_event queued: {event.get('eventId')}")

    # ------------------------------------------------------------------
    #   送信実装
    # ------------------------------------------------------------------
    def _send_current_status(self, heartbeat_type: str = "periodic"):
        machine_id = self.config.get('machine_id', 'DEFAULT_MACHINE')
        # §8: to_dict() が補助フラグを含む完全なペイロードを生成
        payload = self.sm.to_dict(machine_id, heartbeat_type)
        payload["productionCount"]       = self.counter.count
        payload["targetProductionCount"] = self.config.get('target', 100)

        ok = self.api.send_current_status(payload)
        if not ok:
            self.spool.enqueue("current_status", payload)
            logger.debug("[Sender] current_status queued to spool.")

    def _send_period_log(self):
        # §9: period_log は planned_stop を stop と混ぜない
        payload = self.aggregator.generate_payload(self.sm)
        ok = self.api.send_period_log(payload)
        if ok:
            self.aggregator.reset_period()
            logger.info(f"[Sender] period_log sent: count={payload.get('productionCount')}")
        else:
            self.spool.enqueue("period_log", payload)
            logger.warning("[Sender] period_log queued to spool.")

    # ------------------------------------------------------------------
    #   再送（§10: mark_sent パターン）
    # ------------------------------------------------------------------
    def _retry_spool(self):
        items = self.spool.dequeue_all()
        if not items:
            return

        logger.info(f"[Sender] Retrying {len(items)} spooled items...")
        sent_ids = []

        for item in items:
            item_type = item.get("type")
            payload   = item.get("payload", {})
            item_id   = item.get("id")
            ok = False

            if item_type == "current_status":
                ok = self.api.send_current_status(payload)
            elif item_type == "stop_event":
                ok = self.api.send_stop_event(payload)
            elif item_type == "period_log":
                ok = self.api.send_period_log(payload)

            if ok and item_id:
                sent_ids.append(item_id)

        # 送信成功したものを mark_sent（クラッシュ安全）
        if sent_ids:
            self.spool.mark_sent(sent_ids)
            logger.info(f"[Sender] {len(sent_ids)} items marked as sent.")

        failed = len(items) - len(sent_ids)
        if failed > 0:
            logger.warning(f"[Sender] {failed} items still failed after retry.")
