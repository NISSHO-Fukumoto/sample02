"""
api_client.py - API クライアントモジュール
pasted_content.txt §12 の推奨エンドポイントへ送信する。

エンドポイント:
  POST /api/node/current-status
  POST /api/node/stop-event
  POST /api/node/period-log
"""
import requests
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class ApiClient:
    """
    ローカルサーバーへの HTTP/JSON 送信クライアント。
    APIキー認証 (Bearer Token) を使用する。
    """

    def __init__(self, config):
        self.config = config
        self._update_from_config()

    def _update_from_config(self):
        base_url = self.config.get('api_url', 'http://localhost/api/node')
        # 末尾スラッシュを除去
        self.base_url = base_url.rstrip('/')
        self.api_key  = self.config.get('api_key', '')
        self.timeout  = 5

    def reload(self):
        """設定変更後に呼び出す"""
        self._update_from_config()

    # ------------------------------------------------------------------
    #   共通ヘッダー
    # ------------------------------------------------------------------
    @property
    def _headers(self) -> dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    # ------------------------------------------------------------------
    #   送信メソッド
    # ------------------------------------------------------------------
    def send_current_status(self, payload: dict) -> bool:
        return self._post("/current-status", payload)

    def send_stop_event(self, payload: dict) -> bool:
        return self._post("/stop-event", payload)

    def send_period_log(self, payload: dict) -> bool:
        return self._post("/period-log", payload, timeout=10)

    # ------------------------------------------------------------------
    #   内部 POST
    # ------------------------------------------------------------------
    def _post(self, path: str, payload: dict, timeout: Optional[int] = None) -> bool:
        if not self.base_url or not self.api_key:
            logger.debug("API URL or key not configured. Skipping send.")
            return False

        url = self.base_url + path
        t = timeout or self.timeout
        try:
            res = requests.post(url, json=payload, headers=self._headers, timeout=t)
            if res.status_code in (200, 201, 204):
                return True
            else:
                logger.warning(f"[API] {path} → HTTP {res.status_code}: {res.text[:200]}")
                return False
        except requests.exceptions.ConnectionError:
            logger.warning(f"[API] Connection failed: {url}")
            return False
        except requests.exceptions.Timeout:
            logger.warning(f"[API] Timeout: {url}")
            return False
        except Exception as e:
            logger.error(f"[API] Unexpected error: {e}")
            return False
