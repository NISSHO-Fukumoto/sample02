"""
input_reader.py - 入力監視モジュール（本命版・表示強化・カウント非同期化）
GPIO / カメラ の入力を監視し、カウント発生コールバックを呼び出す。

改良点:
- CAMERA モード時に roi_contours を優先して監視対象に使用
- 複数 contour をすべて監視対象に使用
- roi_contours が無い場合は roi_rect の矩形ROIを使用
- detect_color が設定されている場合、HSV色マスクで対象輪郭を抽出して安定化
- 輪郭履歴を持ち、安定輪郭を一定期間保持
- motion_area の絶対値だけでなく motion_ratio（監視対象面積に対する比率）でも判定
- 一定時間継続で LOCKED（1カウント）
- プレビュー上で 非検知時:黄枠 / 検知時:赤枠
- DETECT を大きく表示
- FPS 表示
- 検知後の on_count_callback は別スレッドで実行（プレビュー停止対策）

将来拡張: GPIO エラー入力（error_input_enabled = true の場合のみ有効）
"""
import threading
import time
import logging
import json
import queue
from collections import deque

logger = logging.getLogger(__name__)

# ── GPIO ──────────────────────────────────────────────────────────────
try:
    from gpiozero import Button, InputDevice
    HAS_GPIO = True
except (ImportError, RuntimeError):
    Button = None
    InputDevice = None
    HAS_GPIO = False
    logger.warning("gpiozero not found. GPIO input disabled.")

# ── OpenCV ────────────────────────────────────────────────────────────
try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    cv2 = None
    np = None
    HAS_OPENCV = False
    logger.warning("opencv-python not installed. Camera input disabled.")


class InputReader:
    """
    GPIO または カメラ からの入力を監視し、
    カウント発生時に on_count_callback を呼び出す。
    """

    def __init__(self, config, on_count_callback, on_alarm_callback=None):
        self.config = config
        self.on_count_callback = on_count_callback
        self.on_alarm_callback = on_alarm_callback
        self.input_mode = self._cfg(['input_mode'], 'CAMERA')

        self._gpio_buttons = []
        self._error_device = None
        self._camera_thread = None
        self._error_thread = None
        self._running = False
        self._input_lock = threading.Lock()

        # カメラ映像共有（ストリーミング用）
        self.output_frame = None
        self.raw_frame = None
        self._frame_lock = threading.Lock()

        # カウント処理の非同期実行
        self._count_queue = queue.Queue()
        self._count_worker_thread = None

    # ------------------------------------------------------------------
    #   共通設定取得
    # ------------------------------------------------------------------
    def _cfg(self, keys, default=None):
        """
        ConfigLoader の key 名揺れ対策。
        keys: ["cam_index", "camera_device_index"] のように複数候補を渡す。
        """
        for key in keys:
            try:
                value = self.config.get(key, None)
                if value is not None:
                    return value
            except Exception:
                pass
        return default

    # ------------------------------------------------------------------
    #   起動 / 停止
    # ------------------------------------------------------------------
    def start(self):
        self._running = True

        # カウント処理ワーカー起動
        self._count_worker_thread = threading.Thread(
            target=self._count_worker_loop,
            daemon=True
        )
        self._count_worker_thread.start()

        if str(self.input_mode).upper() == 'GPIO':
            self._setup_gpio()
        elif str(self.input_mode).upper() == 'CAMERA':
            self._start_camera()
        else:
            logger.warning(f"Unknown input_mode: {self.input_mode}")

        if self._cfg(['error_input_enabled'], False):
            self._setup_error_input()

    def stop(self):
        self._running = False

    # ------------------------------------------------------------------
    #   非同期カウント処理
    # ------------------------------------------------------------------
    def _count_worker_loop(self):
        while self._running:
            try:
                item = self._count_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            except Exception:
                continue

            if item == "COUNT":
                try:
                    with self._input_lock:
                        self.on_count_callback()
                except Exception as e:
                    logger.error(f"Count worker error: {e}")

    # ------------------------------------------------------------------
    #   GPIO カウント入力
    # ------------------------------------------------------------------
    def _setup_gpio(self):
        if not HAS_GPIO:
            logger.error("GPIO requested but gpiozero is not available.")
            return

        pins = self._cfg(['gpio_pins'], [])
        hold_times = self._cfg(['gpio_hold_times'], [])
        bounce_times = self._cfg(['gpio_bounce_times'], [])

        for i, pin in enumerate(pins):
            try:
                hold_t = hold_times[i] if i < len(hold_times) else 0.0
                bounce_t = bounce_times[i] if i < len(bounce_times) else 0.0
                btn = Button(
                    pin,
                    pull_up=True,
                    hold_time=hold_t,
                    bounce_time=bounce_t if bounce_t > 0 else None
                )
                btn.when_pressed = self._on_gpio_input
                self._gpio_buttons.append(btn)
                logger.info(f"GPIO count pin {pin} configured.")
            except Exception as e:
                logger.error(f"GPIO pin {pin} setup error: {e}")

        if self._cfg(['enable_gpio_reset'], True):
            reset_pin = self._cfg(['gpio_reset_pin'], 5)
            try:
                r_btn = Button(
                    reset_pin,
                    pull_up=True,
                    hold_time=self._cfg(['reset_hold_time'], 3.0)
                )
                r_btn.when_held = self._on_gpio_reset
                self._gpio_buttons.append(r_btn)
                logger.info(f"GPIO reset pin {reset_pin} configured.")
            except Exception as e:
                logger.error(f"GPIO reset pin setup error: {e}")

    def _on_gpio_input(self):
        self._count_queue.put("COUNT")

    def _on_gpio_reset(self):
        logger.info("GPIO reset triggered.")

    # ------------------------------------------------------------------
    #   GPIO エラー入力（将来拡張）
    # ------------------------------------------------------------------
    def _setup_error_input(self):
        if not HAS_GPIO:
            logger.warning("GPIO error input requested but gpiozero is not available.")
            return
        if self.on_alarm_callback is None:
            logger.warning("error_input_enabled=true but no on_alarm_callback provided.")
            return

        pin = self._cfg(['error_input_pin'], 27)
        active_state = str(self._cfg(['error_active_state'], 'HIGH')).upper()
        pull_up = (active_state == 'LOW')

        try:
            self._error_device = InputDevice(pin, pull_up=pull_up)
            logger.info(
                f"GPIO error input pin {pin} configured "
                f"(active_state={active_state}, pull_up={pull_up})."
            )
            self._error_thread = threading.Thread(
                target=self._error_monitor_loop,
                daemon=True
            )
            self._error_thread.start()
        except Exception as e:
            logger.error(f"GPIO error input pin {pin} setup error: {e}")

    def _error_monitor_loop(self):
        prev_state = None
        while self._running:
            try:
                if self._error_device is None:
                    break
                current = self._error_device.is_active
                if current != prev_state:
                    prev_state = current
                    logger.info(f"[ErrorInput] alarm={'ON' if current else 'OFF'}")
                    if self.on_alarm_callback:
                        self.on_alarm_callback(current)
            except Exception as e:
                logger.error(f"[ErrorInput] monitor error: {e}")
            time.sleep(0.1)

    # ------------------------------------------------------------------
    #   カメラ入力
    # ------------------------------------------------------------------
    def _start_camera(self):
        if not HAS_OPENCV:
            logger.error("Camera requested but opencv is not available.")
            return
        self._camera_thread = threading.Thread(
            target=self._camera_monitor_loop,
            daemon=True
        )
        self._camera_thread.start()

    # ---------------------------
    # ROI / Contour 補助関数
    # ---------------------------
    def _safe_parse_contours(self, raw_value):
        if raw_value is None:
            return []

        if isinstance(raw_value, list):
            return raw_value

        if isinstance(raw_value, str):
            raw_value = raw_value.strip()
            if raw_value == "":
                return []
            try:
                parsed = json.loads(raw_value)
                if isinstance(parsed, list):
                    return parsed
            except Exception:
                return []

        return []

    def _build_monitor_contours(self, frame_w, frame_h):
        """
        監視用 contour 一覧を返す。
        優先順位:
          1) roi_contours
          2) roi_rect / cam_roi の矩形
        """
        contours_out = []

        raw_contours = self._cfg(['roi_contours'], [])
        contour_groups = self._safe_parse_contours(raw_contours)

        # roi_contours 優先
        if contour_groups:
            for group in contour_groups:
                pts = []
                try:
                    for p in group:
                        x = int(float(p[0]) * frame_w)
                        y = int(float(p[1]) * frame_h)
                        pts.append([[x, y]])
                    if pts:
                        cnt = np.array(pts, dtype=np.int32)
                        contours_out.append(cnt)
                except Exception:
                    continue

            if contours_out:
                return contours_out

        # fallback: roi_rect / cam_roi
        roi_str = self._cfg(['roi_rect', 'cam_roi'], '0.0, 0.0, 1.0, 1.0')

        try:
            rx, ry, rw, rh = [float(x.strip()) for x in roi_str.split(',')]
        except Exception:
            rx, ry, rw, rh = 0.0, 0.0, 1.0, 1.0

        roi_x = max(0, int(frame_w * rx))
        roi_y = max(0, int(frame_h * ry))
        roi_w = min(frame_w - roi_x, int(frame_w * rw))
        roi_h = min(frame_h - roi_y, int(frame_h * rh))

        if roi_w > 0 and roi_h > 0:
            rect_cnt = np.array(
                [
                    [[roi_x, roi_y]],
                    [[roi_x + roi_w, roi_y]],
                    [[roi_x + roi_w, roi_y + roi_h]],
                    [[roi_x, roi_y + roi_h]],
                ],
                dtype=np.int32
            )
            contours_out.append(rect_cnt)

        return contours_out

    def _build_mask_from_contours(self, frame_w, frame_h, contours):
        mask = np.zeros((frame_h, frame_w), dtype=np.uint8)
        if contours:
            cv2.fillPoly(mask, contours, 255)
        else:
            mask[:, :] = 255
        return mask

    def _get_detect_color(self):
        color = self._cfg(['detect_color'], None)
        if not color:
            return None
        color = str(color).strip().lower()
        if color in ('red', 'green', 'blue'):
            return color
        return None

    def _get_hsv_range(self, color_name):
        try:
            l_raw = self._cfg([f'{color_name}_l_hsv'], '[0,64,64]')
            h_raw = self._cfg([f'{color_name}_h_hsv'], '[10,255,255]')
            l_hsv = np.array(json.loads(l_raw), dtype=np.uint8)
            h_hsv = np.array(json.loads(h_raw), dtype=np.uint8)
            return l_hsv, h_hsv
        except Exception:
            return None, None

    def _find_color_contours(self, frame, base_mask, color_name, area_limit_min):
        """
        base_mask 内だけで色輪郭を探す。
        複数候補は全部返す。
        """
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        l_hsv, h_hsv = self._get_hsv_range(color_name)
        if l_hsv is None or h_hsv is None:
            return []

        # 赤だけは 0-10 度に加え 170-179 度も補助的に見る
        if color_name == 'red':
            mask1 = cv2.inRange(hsv, l_hsv, h_hsv)
            low2 = np.array([170, 64, 64], dtype=np.uint8)
            high2 = np.array([179, 255, 255], dtype=np.uint8)
            mask2 = cv2.inRange(hsv, low2, high2)
            color_mask = cv2.bitwise_or(mask1, mask2)
        else:
            color_mask = cv2.inRange(hsv, l_hsv, h_hsv)

        color_mask = cv2.bitwise_and(color_mask, color_mask, mask=base_mask)

        kernel = np.ones((5, 5), np.uint8)
        color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_OPEN, kernel)
        color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        valid = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area >= area_limit_min:
                valid.append(cnt)
        return valid

    def _camera_monitor_loop(self):
        cam_index = self._cfg(['camera_device_index', 'cam_index'], 0)
        cam_width = self._cfg(['camera_width', 'cam_width'], 640)
        cam_height = self._cfg(['camera_height', 'cam_height'], 480)

        # 感度系
        area_th = self._cfg(['motion_area_threshold', 'cam_area_th'], 300)
        hold_frames = self._cfg(['camera_hold_frames', 'cam_hold_frames'], 5)
        cooldown = self._cfg(['camera_cooldown_sec', 'cam_cooldown'], 0.5)

        # 安定化パラメータ
        area_limit_min = self._cfg(['area_limit_min'], 500)
        motion_ratio_threshold = self._cfg(['motion_ratio_threshold'], 0.03)
        motion_duration_threshold_sec = self._cfg(['motion_duration_threshold_sec'], 0.15)
        contour_history_size = self._cfg(['contour_history_size'], 20)
        exit_frames_threshold = self._cfg(['exit_frames_threshold'], 10)

        cap = cv2.VideoCapture(cam_index)
        if not cap.isOpened():
            logger.error(f"Cannot open camera index {cam_index}")
            return

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam_width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam_height)

        fgbg = cv2.createBackgroundSubtractorMOG2(
            history=500,
            varThreshold=25,
            detectShadows=True
        )

        frames_with_motion = 0
        frames_without_motion = 0
        is_object_present = False
        last_count_time = 0.0
        motion_start_time = None

        contour_history = deque(maxlen=contour_history_size)
        stable_contours = []

        # 赤表示保持
        detect_hold_until = 0.0

        # FPS
        fps_display = 0.0
        fps_frame_count = 0
        fps_start_time = time.time()

        logger.info(
            f"Camera monitoring started on device {cam_index} "
            f"({cam_width}x{cam_height})"
        )

        while self._running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.2)
                continue

            fps_frame_count += 1
            elapsed_fps = time.time() - fps_start_time
            if elapsed_fps >= 1.0:
                fps_display = fps_frame_count / elapsed_fps
                fps_frame_count = 0
                fps_start_time = time.time()

            with self._frame_lock:
                self.raw_frame = frame.copy()

            h, w = frame.shape[:2]

            # 1. ベース監視領域
            base_contours = self._build_monitor_contours(w, h)
            base_mask = self._build_mask_from_contours(w, h, base_contours)

            # 2. detect_color があれば色輪郭を抽出
            detect_color = self._get_detect_color()
            current_target_contours = []

            if detect_color:
                current_target_contours = self._find_color_contours(
                    frame=frame,
                    base_mask=base_mask,
                    color_name=detect_color,
                    area_limit_min=area_limit_min
                )
                if current_target_contours:
                    contour_history.append(current_target_contours)

            if contour_history:
                stable_contours = contour_history[-1]

            if stable_contours:
                active_contours = stable_contours
            else:
                active_contours = base_contours

            active_mask = self._build_mask_from_contours(w, h, active_contours)

            # 3. 監視対象内だけで動体検知
            masked_frame = cv2.bitwise_and(frame, frame, mask=active_mask)

            fgmask = fgbg.apply(masked_frame)
            _, fgmask = cv2.threshold(fgmask, 200, 255, cv2.THRESH_BINARY)
            fgmask = cv2.morphologyEx(
                fgmask,
                cv2.MORPH_OPEN,
                np.ones((5, 5), np.uint8)
            )
            fgmask = cv2.bitwise_and(fgmask, fgmask, mask=active_mask)

            motion_area = cv2.countNonZero(fgmask)
            monitored_area = max(1, cv2.countNonZero(active_mask))
            motion_ratio = motion_area / monitored_area

            motion_detected = (motion_area >= area_th) or (motion_ratio >= motion_ratio_threshold)

            if motion_detected:
                frames_with_motion += 1
                frames_without_motion = 0
                if motion_start_time is None:
                    motion_start_time = time.time()
            else:
                frames_with_motion = 0
                frames_without_motion += 1
                motion_start_time = None

            now = time.time()

            state_label = "SCANNING"
            detected_display = False

            if motion_detected and motion_start_time is not None:
                elapsed_motion = now - motion_start_time
                if elapsed_motion >= motion_duration_threshold_sec and frames_with_motion >= hold_frames:
                    state_label = "LOCKED"
                    detected_display = True
                else:
                    state_label = "VERIFYING"

            # 4. 1回入ったら1カウント（別スレッド処理）
            if not is_object_present:
                if detected_display:
                    if now - last_count_time >= cooldown:
                        self._count_queue.put("COUNT")
                        last_count_time = now
                        detect_hold_until = now + 0.5
                        logger.info("Object ENTERED / Count +1")
                    is_object_present = True
            else:
                detected_display = True
                state_label = "LOCKED"
                if frames_without_motion >= exit_frames_threshold:
                    is_object_present = False
                    motion_start_time = None
                    logger.info("Object EXITED")

            # 5. 表示フレーム
            display = frame.copy()

            display_detect = detected_display or (now < detect_hold_until)
            draw_color = (0, 0, 255) if display_detect else (0, 255, 255)

            if active_contours:
                cv2.drawContours(display, active_contours, -1, draw_color, 2)

            cv2.putText(
                display,
                f"Area: {motion_area}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )
            cv2.putText(
                display,
                f"Ratio: {motion_ratio:.3f}",
                (10, 60),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )
            cv2.putText(
                display,
                f"FPS: {fps_display:.1f}",
                (10, 90),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )

            if display_detect:
                big_text = "DETECT"
            else:
                big_text = state_label

            cv2.putText(
                display,
                big_text,
                (int(w * 0.22), int(h * 0.16)),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.6,
                draw_color,
                4
            )

            with self._frame_lock:
                self.output_frame = display

            # ここは短め
            time.sleep(0.005)

        cap.release()
        logger.info("Camera monitoring stopped.")

    def get_frame_jpeg(self):
        """MJPEG ストリーム用 JPEG バイト列を返す"""
        if not HAS_OPENCV:
            return None

        with self._frame_lock:
            frame = self.output_frame

        if frame is None:
            return None

        try:
            _, jpeg = cv2.imencode('.jpg', frame)
            return jpeg.tobytes()
        except Exception:
            return None