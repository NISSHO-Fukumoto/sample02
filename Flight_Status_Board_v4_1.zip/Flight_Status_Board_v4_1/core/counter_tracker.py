"""
counter_tracker.py - カウント追跡モジュール（最終区分一括集計版）

仕様:
- 生産カウントの累計を管理する
- 停止時間は「途中帯域で分割」せず、最終確定区分へ全時間を寄せる
  例:
    dur_choco_sec = 180
    dur_doka_sec  = 600
    700秒停止した場合:
      accumulated_choco_sec += 0
      accumulated_doka_sec  += 700
- count 到着で停止が終了した場合は、前回カウントから今回カウントまでの全時間を
  最終区分（work/choco/doka）として一括加算する
- break_transition / shift_end / power_off のように
  「count を伴わず stop が閉じる」ケース用に finalize_closed_stop() を用意
"""

import time


class CounterTracker:
    """
    生産カウントを管理するクラス。

    管理対象:
    - 累計カウント
    - 稼働時間
    - チョコ停時間
    - ドカ停時間

    重要:
    - 停止時間は途中経過で分割せず、最終確定区分へ全時間を一括計上する
    """

    def __init__(self, config):
        self.config = config
        self.count: int = 0
        self.target: int = config.get('target', 100)

        # 最終確定済み累計（秒）
        self.accumulated_work_sec: float = 0.0
        self.accumulated_choco_sec: float = 0.0
        self.accumulated_doka_sec: float = 0.0

        # 前回カウント時刻
        self._last_ts: float | None = None

    # ------------------------------------------------------------------
    #   内部ユーティリティ
    # ------------------------------------------------------------------
    def _get_thresholds(self):
        dur_choco = self.config.get('dur_choco_sec', 180)
        dur_doka = self.config.get('dur_doka_sec', 600)
        return dur_choco, dur_doka

    def _classify_gap(self, diff_sec: float) -> str:
        """
        前回カウントから今回カウントまでの停止/稼働区分を最終判定する。

        ルール:
        - diff <= dur_choco : work
        - dur_choco < diff <= dur_doka : choco
        - diff > dur_doka : doka
        """
        dur_choco, dur_doka = self._get_thresholds()

        if diff_sec <= dur_choco:
            return "work"
        elif diff_sec <= dur_doka:
            return "choco"
        else:
            return "doka"

    def _add_by_final_class(self, final_class: str, duration_sec: float):
        """
        最終区分に応じて累計へ一括加算する。
        """
        if duration_sec <= 0:
            return

        if final_class == "work":
            self.accumulated_work_sec += duration_sec
        elif final_class == "choco":
            self.accumulated_choco_sec += duration_sec
        elif final_class == "doka":
            self.accumulated_doka_sec += duration_sec

    # ------------------------------------------------------------------
    #   カウント発生
    # ------------------------------------------------------------------
    def on_count(self, state_machine=None):
        """
        カウント発生時に呼び出す。

        前回カウントから今回カウントまでの時間を、
        最終区分（work/choco/doka）として一括計上する。

        例:
        - 100秒後に次カウント → work += 100
        - 300秒後に次カウント → choco += 300
        - 700秒後に次カウント → doka += 700
        """
        now = time.time()

        if self._last_ts is not None:
            diff = now - self._last_ts
            final_class = self._classify_gap(diff)
            self._add_by_final_class(final_class, diff)

        self._last_ts = now
        self.count += 1

    # ------------------------------------------------------------------
    #   stop_event_manager 連携用
    # ------------------------------------------------------------------
    def finalize_closed_stop(self, final_stop_class: str, final_stop_duration_sec: float):
        """
        count を伴わず stop が close したケース用。

        想定例:
        - break_transition
        - shift_end
        - power_off
        - forced_close

        注意:
        count 復帰で終了した stop については on_count() 側で既に集計される想定なので、
        同じ停止イベントに対して二重に呼ばないこと。
        """
        if final_stop_duration_sec <= 0:
            return

        if final_stop_class == "choco":
            self.accumulated_choco_sec += final_stop_duration_sec
        elif final_stop_class == "doka":
            self.accumulated_doka_sec += final_stop_duration_sec

    # ------------------------------------------------------------------
    #   現在の稼働時間（リアルタイム表示用）
    # ------------------------------------------------------------------
    def get_current_work_sec(self) -> float:
        """
        表示用の現在稼働時間。

        まだ dur_choco_sec 以内であれば、
        「今はまだ停止未確定」とみなし work 側に表示する。
        """
        total = self.accumulated_work_sec

        if self._last_ts is not None:
            dur_choco, _ = self._get_thresholds()
            diff = time.time() - self._last_ts
            if diff <= dur_choco:
                total += diff

        return total

    def get_current_choco_sec(self) -> float:
        """
        表示用の現在チョコ停時間。

        今まさに dur_choco_sec を超え、dur_doka_sec 以下なら、
        「現時点で最終的にチョコ停になったと仮定した全停止時間」を表示する。
        """
        total = self.accumulated_choco_sec

        if self._last_ts is not None:
            dur_choco, dur_doka = self._get_thresholds()
            diff = time.time() - self._last_ts
            if dur_choco < diff <= dur_doka:
                total += diff

        return total

    def get_current_doka_sec(self) -> float:
        """
        表示用の現在ドカ停時間。

        今まさに dur_doka_sec を超えているなら、
        「現時点で最終的にドカ停になったと仮定した全停止時間」を表示する。
        """
        total = self.accumulated_doka_sec

        if self._last_ts is not None:
            _, dur_doka = self._get_thresholds()
            diff = time.time() - self._last_ts
            if diff > dur_doka:
                total += diff

        return total

    # ------------------------------------------------------------------
    #   リセット
    # ------------------------------------------------------------------
    def reset(self):
        self.count = 0
        self._last_ts = None
        self.accumulated_work_sec = 0.0
        self.accumulated_choco_sec = 0.0
        self.accumulated_doka_sec = 0.0

    # ------------------------------------------------------------------
    #   進捗率
    # ------------------------------------------------------------------
    def get_percent(self) -> int:
        if self.target <= 0:
            return 0
        return int(self.count / self.target * 100)

    # ------------------------------------------------------------------
    #   平均生産数（個/時）
    # ------------------------------------------------------------------
    def get_avg_per_hour(self) -> int:
        total_sec = (
            self.get_current_work_sec() +
            self.get_current_choco_sec() +
            self.get_current_doka_sec()
        )
        if self.count < 2 or total_sec <= 0:
            return 0
        return int(self.count * 3600 / total_sec)