"""
period_aggregator.py - 実績集計モジュール（v3）

集計責務の整理:
  - planned_stop の累計は本モジュールが state_machine.time_zone を見て自己集計する
  - app.py 側の _accumulated_planned_sec / _planned_stop_start は不要（削除済み）
  - period_log への反映元は本モジュールの _planned_sec_in_period のみ

時間帯区分と planned_stop の関係:
  - time_zone が break_time または pre_shift の場合を計画停止として累計
  - post_shift（終業後）は off 扱いのため planned_stop には含めない
"""
import time
from datetime import datetime, timezone, timedelta
from typing import Optional

JST = timezone(timedelta(hours=+9), 'JST')

# planned_stop とみなす time_zone
PLANNED_STOP_ZONES = {"break_time", "pre_shift"}


class PeriodAggregator:
    """
    一定期間ごとの生産実績を集計し、API 送信用ペイロードを生成する。

    planned_stop の累計は update() を定期的に呼び出すことで自己集計する。
    """

    def __init__(self, config, counter_tracker):
        self.config  = config
        self.counter = counter_tracker
        self.machine_id = config.get('machine_id', 'DEFAULT_MACHINE')
        self.target     = config.get('target', 100)

        # 前回集計時点のスナップショット
        self._period_start_ts:     float = time.time()
        self._baseline_count:      int   = 0
        self._baseline_work_sec:   float = 0.0
        self._baseline_choco_sec:  float = 0.0
        self._baseline_doka_sec:   float = 0.0

        # 計画停止累計（本モジュールが自己集計）
        self._planned_sec_in_period: float = 0.0
        self._planned_stop_start:    Optional[float] = None

    # ------------------------------------------------------------------
    #   定期更新（background_loop から毎秒呼び出す）
    # ------------------------------------------------------------------
    def update(self, state_machine):
        """
        state_machine.time_zone を見て計画停止時間を自己集計する。
        background_loop から毎秒（または適切な間隔で）呼び出すこと。
        """
        now = time.time()
        in_planned = state_machine.time_zone in PLANNED_STOP_ZONES

        if in_planned:
            if self._planned_stop_start is None:
                self._planned_stop_start = now
        else:
            if self._planned_stop_start is not None:
                self._planned_sec_in_period += now - self._planned_stop_start
                self._planned_stop_start = None

    # ------------------------------------------------------------------
    #   集計ペイロード生成
    # ------------------------------------------------------------------
    def generate_payload(self, state_machine) -> dict:
        """
        現在の集計期間の実績ペイロードを生成する。
        """
        now = time.time()
        period_start = datetime.fromtimestamp(self._period_start_ts, JST)
        period_end   = datetime.fromtimestamp(now, JST)

        run_sec    = max(0.0, self.counter.get_current_work_sec()  - self._baseline_work_sec)
        choco_sec  = max(0.0, self.counter.get_current_choco_sec() - self._baseline_choco_sec)
        doka_sec   = max(0.0, self.counter.get_current_doka_sec()  - self._baseline_doka_sec)
        prod_count = max(0,   self.counter.count                   - self._baseline_count)

        # 計画停止: 進行中の分も加算
        planned_sec = self._planned_sec_in_period
        if self._planned_stop_start is not None:
            planned_sec += now - self._planned_stop_start

        # 停止時間 = チョコ停 + ドカ停（計画停止は含めない）
        stop_sec = choco_sec + doka_sec

        return {
            "machineId":             self.machine_id,
            "periodStart":           period_start.isoformat(),
            "periodEnd":             period_end.isoformat(),
            "runningSeconds":        int(run_sec),
            "stopSeconds":           int(stop_sec),
            "plannedStopSeconds":    int(planned_sec),
            "chocoSeconds":          int(choco_sec),
            "dokaSeconds":           int(doka_sec),
            "productionCount":       prod_count,
            "targetProductionCount": self.target,
        }

    # ------------------------------------------------------------------
    #   集計リセット（送信後に呼び出す）
    # ------------------------------------------------------------------
    def reset_period(self):
        now = self.time()
        self._period_start_ts    = now
        self._baseline_count     = self.counter.count
        self._baseline_work_sec  = self.counter.get_current_work_sec()
        self._baseline_choco_sec = self.counter.get_current_choco_sec()
        self._baseline_doka_sec  = self.counter.get_current_doka_sec()

        # 計画停止累計をリセット（進行中の場合は継続）
        self._planned_sec_in_period = 0.0
        if self._planned_stop_start is not None:
            # 進行中の計画停止は今から再計測
            self._planned_stop_start = now

    @staticmethod
    def time() -> float:
        return time.time()
