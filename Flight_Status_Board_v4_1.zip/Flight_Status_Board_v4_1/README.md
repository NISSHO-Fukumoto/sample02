# Flight_Status_Board

ラズパイ400で実行する見える化システムのエントリーモデル用ノード端末ソフトウェアです。
Webカメラ若しくはGPIOにて生産設備のカウントを計測し、ローカルサーバーへ情報を送信します。

## 特徴
- **エントリーモデル設計**: DBを持たず、サーバーへの push を主動作とします
- **状態推定**: 最後のカウントからの経過時間で「稼働」「チョコ停」「ドカ停」を推定
- **計画停止対応**: 休憩時間帯を設定可能
- **1停止 = 1イベント**: 停止開始から終了までを1つのイベントIDで管理
- **再送機能**: 通信失敗時は軽量な JSON スプールに保存し、復旧時に再送

## モジュール構成
```text
Flight_Status_Board/
├── app.py                     # メインアプリケーション (Flask)
├── conf.ini                   # 設定ファイル
├── requirements.txt           # 依存パッケージ
├── core/                      # コアロジック
│   ├── config_loader.py       # 設定読込
│   ├── state_machine.py       # 状態機械 (経過時間による状態推定)
│   ├── counter_tracker.py     # カウント・時間累計管理
│   ├── input_reader.py        # GPIO/カメラ入力監視
│   ├── break_scheduler.py     # 休憩時間判定
│   ├── stop_event_manager.py  # 停止イベント管理
│   ├── period_aggregator.py   # 実績集計生成
│   ├── api_client.py          # サーバー送信
│   ├── spool_queue.py         # 再送キュー
│   └── sender.py              # 送信・再送統括
├── templates/
│   └── index.html             # GUIダッシュボード
└── static/
    ├── fonts/
    └── icon/
```

## インストールと起動
```bash
# 依存関係のインストール
pip install -r requirements.txt

# アプリケーションの起動
python3 app.py
```

ブラウザで `http://<ラズパイのIP>:5000` にアクセスするとダッシュボードが表示されます。
GUI上の「SETTINGS」からサーバーのAPI URLやAPIキー、閾値を設定できます。
