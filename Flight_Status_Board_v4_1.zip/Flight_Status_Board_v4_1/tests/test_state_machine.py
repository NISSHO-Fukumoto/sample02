"""
test_state_machine.py - 状態機械テストスイート
pasted_content_2.txt §12・§13 の必須ケースを網羅する。

テスト分類:
  1. 状態遷移テスト（基本的な running/stop/planned_stop/off）
  2. 時刻境界テスト（チョコ停/ドカ停の閾値前後）
  3. 休憩跨ぎテスト（ケース1〜4）
  4. 始業前/終業後テスト（ケース5〜6）
  5. 補助フラグテスト
  6. StopEventManager テスト
  7. SpoolQueue 再送テスト
"""
import sys
import os
import time
import unittest
import tempfile
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.state_machine import StateMachine
from core.stop_event_manager import StopEventManager
from core.spool_queue import SpoolQueue

JST = timezone(timedelta(hours=+9), 'JST')


# ── テスト用設定 ──────────────────────────────────────────────────────
class MockConfig:
    def __init__(self, **kwargs):
        self._data = {
            'dur_choco_sec': 180,    # 3分
            'dur_doka_sec':  600,    # 10分
            'dur_poweroff_sec': 3600,
            'time_start': '08:00',
            'time_end':   '17:00',
            'breaks': ['12:00-12:45', '15:00-15:15'],
        }
        self._data.update(kwargs)

    def get(self, key, default=None):
        return self._data.get(key, default)


def make_ts(hour: int, minute: int, second: int = 0) -> float:
    """JST の今日の指定時刻の UNIX タイムスタンプを返す"""
    now = datetime.now(JST)
    dt = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
    return dt.timestamp()


# ── 1. 状態遷移テスト ─────────────────────────────────────────────────
class TestStateTransitions(unittest.TestCase):

    def setUp(self):
        self.config = MockConfig()
        self.sm = StateMachine(self.config)

    def test_initial_state_is_off(self):
        """初期状態は off"""
        self.assertEqual(self.sm.current_state, "off")

    def test_running_after_count(self):
        """カウント直後は running"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        state = self.sm.update(now=now + 1)
        self.assertEqual(state, "running")
        self.assertIsNone(self.sm.stop_class)

    def test_choco_stop_after_threshold(self):
        """チョコ停閾値超過後は stop + choco"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        # 3分+1秒後（稼働時間内）
        state = self.sm.update(now=now + 181)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "choco")

    def test_doka_stop_after_threshold(self):
        """ドカ停閾値超過後は stop + doka"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        # 10分+1秒後
        state = self.sm.update(now=now + 601)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "doka")

    def test_recovery_from_stop(self):
        """停止中にカウントが来たら running に戻る"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        self.assertEqual(self.sm.current_state, "stop")

        # 復旧
        recovery_ts = now + 300
        self.sm.on_count(recovery_ts)
        state = self.sm.update(now=recovery_ts + 1)
        self.assertEqual(state, "running")
        self.assertIsNone(self.sm.stop_class)

    def test_off_without_count(self):
        """カウントなし・稼働時間外は off"""
        # 終業後
        now = make_ts(18, 0, 0)
        state = self.sm.update(now=now)
        self.assertEqual(state, "off")


# ── 2. 時刻境界テスト ─────────────────────────────────────────────────
class TestTimeBoundary(unittest.TestCase):

    def setUp(self):
        self.config = MockConfig(dur_choco_sec=180, dur_doka_sec=600)
        self.sm = StateMachine(self.config)

    def test_just_before_choco_threshold(self):
        """チョコ停閾値の1秒前は running"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        state = self.sm.update(now=now + 179)
        self.assertEqual(state, "running")

    def test_exactly_at_choco_threshold(self):
        """チョコ停閾値ちょうどは stop + choco"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        state = self.sm.update(now=now + 180)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "choco")

    def test_just_before_doka_threshold(self):
        """ドカ停閾値の1秒前は stop + choco"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        state = self.sm.update(now=now + 599)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "choco")

    def test_exactly_at_doka_threshold(self):
        """ドカ停閾値ちょうどは stop + doka"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        state = self.sm.update(now=now + 600)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "doka")

    def test_stop_start_at_is_corrected(self):
        """停止開始時刻は 最後のカウント + 閾値 で補正される"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        expected_stop_start = now + 180
        self.assertAlmostEqual(self.sm.stop_start_at, expected_stop_start, delta=1)


# ── 3. 休憩跨ぎテスト ─────────────────────────────────────────────────
class TestBreakBoundary(unittest.TestCase):
    """
    §12 の必須ケース1〜4を検証する。
    設定: チョコ停閾値=3分, 休憩=12:00-12:45
    """

    def setUp(self):
        self.config = MockConfig(
            dur_choco_sec=180,
            dur_doka_sec=600,
            breaks=['12:00-12:45'],
        )
        self.sm = StateMachine(self.config)

    # ── ケース1: 停止未確定で休憩に入り、休憩中にカウント ──────────────
    def test_case1_count_during_break_no_stop_event(self):
        """
        ケース1: 11:58カウント → 12:00休憩開始 → 12:00:20にカウント
        期待: stop event は作成しない / 12:00時点で stop にしない
        """
        # 11:58 カウント
        t_count = make_ts(11, 58, 0)
        self.sm.on_count(t_count)

        # 12:00 時点（休憩開始、経過2分=120秒 < 閾値180秒）
        t_break = make_ts(12, 0, 0)
        state = self.sm.update(now=t_break)
        # 12:00時点では stop にしてはいけない
        self.assertNotEqual(state, "stop",
            "12:00時点で stop にしてはいけない（停止未確定）")

        # 12:00:20 にカウント発生
        t_count2 = make_ts(12, 0, 20)
        self.sm.on_count(t_count2)
        state2 = self.sm.update(now=t_count2 + 1)
        # running になるべき（scheduleViolation=break_overrun が付く場合あり）
        self.assertEqual(state2, "running")

    # ── ケース2: 休憩中に停止条件を満たした場合 ────────────────────────
    def test_case2_stop_confirmed_during_break_absorbed(self):
        """
        ケース2: 11:58カウント → 12:00休憩開始 → 12:01になってもカウントなし
        期待: 通常 stop event を作成しない / planned_stop に吸収
        """
        t_count = make_ts(11, 58, 0)
        self.sm.on_count(t_count)

        # 12:01 時点（経過3分=180秒 = 閾値ちょうど、停止確定時刻は12:01=休憩中）
        t_check = make_ts(12, 1, 0)
        state = self.sm.update(now=t_check)
        # 停止確定時刻が休憩中なので planned_stop に吸収される
        self.assertNotEqual(state, "stop",
            "休憩中に停止確定した場合は stop にしてはいけない")
        self.assertEqual(state, "planned_stop",
            "休憩中の停止確定は planned_stop に吸収されるべき")

    # ── ケース3: 休憩前に停止確定済み ──────────────────────────────────
    def test_case3_stop_confirmed_before_break_then_break_transition(self):
        """
        ケース3: 11:56カウント → 11:59に stop+choco確定 → 12:00休憩開始
        期待: stop event を 12:00 で close / closeReason = break_transition
        """
        sem = StopEventManager("TEST")

        # 11:56 カウント
        t_count = make_ts(11, 56, 0)
        self.sm.on_count(t_count)

        # 11:59 時点（経過3分=180秒 = 閾値ちょうど、稼働時間内）
        t_stop = make_ts(11, 59, 0)
        state = self.sm.update(now=t_stop)
        self.assertEqual(state, "stop")
        self.assertEqual(self.sm.stop_class, "choco")

        # stop event を open
        events = sem.process(self.sm)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["action"], "open")

        # 12:00 休憩開始 → planned_stop に遷移
        t_break = make_ts(12, 0, 0)
        state2 = self.sm.update(now=t_break)
        self.assertEqual(state2, "planned_stop")

        # stop event が close される
        events2 = sem.process(self.sm)
        self.assertEqual(len(events2), 1)
        self.assertEqual(events2[0]["action"], "close")
        self.assertEqual(events2[0]["closeReason"], "break_transition",
            "closeReason は break_transition であるべき")

    # ── ケース4: 休憩中にカウント継続 ──────────────────────────────────
    def test_case4_count_continues_during_break(self):
        """
        ケース4: 休憩開始後もカウント継続
        期待: 主状態は running / scheduleViolation = break_overrun
        """
        # 12:05 にカウント（休憩中）
        t_count = make_ts(12, 5, 0)
        self.sm.on_count(t_count)
        state = self.sm.update(now=t_count + 1)
        self.assertEqual(state, "running")
        self.assertEqual(self.sm.schedule_violation, "break_overrun")


# ── 4. 始業前/終業後テスト ────────────────────────────────────────────
class TestShiftBoundary(unittest.TestCase):

    def setUp(self):
        self.config = MockConfig(
            dur_choco_sec=180,
            dur_doka_sec=600,
            time_start='08:00',
            time_end='17:00',
            breaks=[],
        )
        self.sm = StateMachine(self.config)

    # ── ケース5: 始業前にカウント発生 ──────────────────────────────────
    def test_case5_count_before_shift_start(self):
        """
        ケース5: 始業前にカウント発生
        期待: 主状態は running / scheduleViolation = early_start
        """
        t_count = make_ts(7, 30, 0)
        self.sm.on_count(t_count)
        state = self.sm.update(now=t_count + 1)
        self.assertEqual(state, "running")
        self.assertEqual(self.sm.schedule_violation, "early_start")

    # ── 始業前に未稼働 ──────────────────────────────────────────────────
    def test_pre_shift_no_count_not_stop(self):
        """
        §5-2: 始業前に未稼働で停止閾値超過相当でもカウントなし
        期待: 通常停止にしない / planned_stop
        """
        # カウントなしで 7:30 に更新
        t_check = make_ts(7, 30, 0)
        state = self.sm.update(now=t_check)
        self.assertNotEqual(state, "stop",
            "始業前の未稼働を stop にしてはいけない")

    # ── ケース6: 終業後に稼働継続 ──────────────────────────────────────
    def test_case6_count_after_shift_end(self):
        """
        ケース6: 終業後に稼働継続
        期待: 主状態は running / overtime または scheduleViolation を付与
        """
        t_count = make_ts(17, 30, 0)
        self.sm.on_count(t_count)
        state = self.sm.update(now=t_count + 1)
        self.assertEqual(state, "running")
        # overtime_run または overtime が付与されているべき
        self.assertIsNotNone(self.sm.schedule_violation,
            "終業後の稼働には scheduleViolation が付与されるべき")

    # ── 終業後に未稼働 ──────────────────────────────────────────────────
    def test_post_shift_no_count_not_stop(self):
        """
        §5-4: 終業後に未稼働継続
        期待: 停止確定時刻が終業後の場合は stop にしない

        シナリオ: 17:05 に最後のカウント。
          停止確定時刻 = 17:05 + 3分 = 17:08（終業後）
          17:15 時点で評価 → stop にしてはいけない
        """
        # 17:05 にカウント（終業後）
        t_count = make_ts(17, 5, 0)
        self.sm.on_count(t_count)
        # 17:15 時点（経過10分 > 閘値３分）
        # 停止確定時刻 = 17:05 + 3分 = 17:08（終業後 overtime）
        t_check = make_ts(17, 15, 0)
        state = self.sm.update(now=t_check)
        # 停止確定時刻が overtime なので stop にしてはいけない
        self.assertNotEqual(state, "stop",
            "終業後 overtime の停止確定を stop にしてはいけない")


# ── 5. 補助フラグテスト ───────────────────────────────────────────────
class TestAuxiliaryFlags(unittest.TestCase):

    def setUp(self):
        self.config = MockConfig(breaks=['12:00-12:45'])
        self.sm = StateMachine(self.config)

    def test_in_break_window_flag(self):
        """休憩時間中は inBreakWindow = True"""
        t = make_ts(12, 15, 0)
        self.sm.update(now=t)
        self.assertTrue(self.sm.in_break_window)

    def test_in_pre_shift_window_flag(self):
        """始業前は inPreShiftWindow = True"""
        t = make_ts(7, 0, 0)
        self.sm.update(now=t)
        self.assertTrue(self.sm.in_pre_shift_window)

    def test_in_overtime_window_flag(self):
        """終業後は inOvertimeWindow = True"""
        t = make_ts(18, 0, 0)
        self.sm.update(now=t)
        self.assertTrue(self.sm.in_overtime_window)

    def test_alarm_flag_survives_state_change(self):
        """alarm フラグは状態変化後も保持される（§11）"""
        self.sm.alarm = True
        t = make_ts(12, 15, 0)
        self.sm.update(now=t)
        self.assertTrue(self.sm.alarm,
            "alarm フラグは planned_stop 中も保持されるべき")

    def test_manual_flag_survives_break(self):
        """manual フラグは休憩中も保持される（§11）"""
        self.sm.manual = True
        t = make_ts(12, 15, 0)
        self.sm.update(now=t)
        self.assertTrue(self.sm.manual)

    def test_has_changed_detects_schedule_violation(self):
        """scheduleViolation の変化を has_changed() が検知する（§7）"""
        # 稼働時間内にカウント → running, scheduleViolation=None
        t_count = make_ts(10, 0, 0)
        self.sm.on_count(t_count)
        self.sm.update(now=t_count + 1)
        # 最初の変化を消費
        self.sm.has_changed()

        # 休憩中にカウント → scheduleViolation=break_overrun に変化
        t_break_count = make_ts(12, 5, 0)
        self.sm.on_count(t_break_count)
        self.sm.update(now=t_break_count + 1)
        self.assertTrue(self.sm.has_changed(),
            "scheduleViolation の変化を has_changed() が検知すべき")

    def test_to_dict_contains_all_required_fields(self):
        """to_dict() が §8 の必須フィールドを含む"""
        t = make_ts(10, 0, 0)
        self.sm.on_count(t)
        self.sm.update(now=t + 1)
        d = self.sm.to_dict("TEST_MACHINE")
        required = [
            "machineId", "sampleTime", "currentState", "stopClass",
            "reasonCode", "alarm", "manual", "offline",
            "scheduleViolation", "currentSegmentStart", "elapsedSec", "lastCountAt"
        ]
        for field in required:
            self.assertIn(field, d, f"to_dict() に {field} が含まれていない")


# ── 6. StopEventManager テスト ────────────────────────────────────────
class TestStopEventManager(unittest.TestCase):

    def setUp(self):
        self.config = MockConfig(dur_choco_sec=180, dur_doka_sec=600)
        self.sm = StateMachine(self.config)
        self.sem = StopEventManager("TEST")

    def test_open_on_stop_confirmed(self):
        """停止確定時に open イベントが生成される"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        events = self.sem.process(self.sm)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["action"], "open")

    def test_update_on_doka_escalation(self):
        """ドカ停昇格時に update イベントが生成される"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        # チョコ停確定
        self.sm.update(now=now + 181)
        self.sem.process(self.sm)
        # ドカ停昇格
        self.sm.update(now=now + 601)
        events = self.sem.process(self.sm)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["action"], "update")
        self.assertEqual(events[0]["stopClass"], "doka")

    def test_close_on_recovery(self):
        """復旧時に close イベントが生成される"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        self.sem.process(self.sm)
        # 復旧
        recovery = now + 300
        self.sm.on_count(recovery)
        self.sm.update(now=recovery + 1)
        events = self.sem.process(self.sm)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["action"], "close")
        self.assertEqual(events[0]["closeReason"], "recovered")

    def test_close_reason_break_transition(self):
        """休憩突入時の closeReason は break_transition"""
        sem = StopEventManager("TEST2")
        config = MockConfig(dur_choco_sec=180, breaks=['12:00-12:45'])
        sm = StateMachine(config)

        # 11:56 カウント → 11:59 停止確定
        t_count = make_ts(11, 56, 0)
        sm.on_count(t_count)
        sm.update(now=make_ts(11, 59, 0))
        sem.process(sm)

        # 12:00 休憩開始
        sm.update(now=make_ts(12, 0, 0))
        events = sem.process(sm)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["closeReason"], "break_transition")

    def test_duration_uses_self_held_timestamp(self):
        """§6-1: duration は StopEventManager 自己保持タイムスタンプで計算"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        self.sem.process(self.sm)

        # 5分後に復旧
        recovery = now + 181 + 300
        self.sm.on_count(recovery)
        self.sm.update(now=recovery + 1)
        events = self.sem.process(self.sm)
        self.assertEqual(events[0]["action"], "close")
        # duration は約300秒（±5秒の誤差許容）
        self.assertGreater(events[0]["finalStopDurationSec"], 290)

    def test_force_close_manual_reset(self):
        """force_close() で manual_reset の close イベントが生成される"""
        now = make_ts(10, 0, 0)
        self.sm.on_count(now)
        self.sm.update(now=now + 181)
        self.sem.process(self.sm)
        payload = self.sem.force_close("manual_reset")
        self.assertIsNotNone(payload)
        self.assertEqual(payload["closeReason"], "manual_reset")
        self.assertFalse(self.sem.has_open_event())


# ── 7. SpoolQueue 再送テスト ──────────────────────────────────────────
class TestSpoolQueue(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.filepath = os.path.join(self.tmpdir, 'test_spool.jsonl')

    def test_enqueue_and_dequeue(self):
        """enqueue したアイテムが dequeue_all で取得できる"""
        sq = SpoolQueue(self.filepath)
        sq.enqueue("stop_event", {"eventId": "e1"})
        sq.enqueue("period_log", {"count": 10})
        items = sq.dequeue_all()
        self.assertEqual(len(items), 2)

    def test_mark_sent_removes_items(self):
        """mark_sent 後はアイテムが削除される"""
        sq = SpoolQueue(self.filepath)
        sq.enqueue("stop_event", {"eventId": "e1"})
        items = sq.dequeue_all()
        ids = [i["id"] for i in items]
        sq.mark_sent(ids)
        self.assertEqual(sq.size(), 0)

    def test_persistence_across_reload(self):
        """再起動後も未送信アイテムが復元される"""
        sq = SpoolQueue(self.filepath)
        sq.enqueue("stop_event", {"eventId": "e1"})
        sq.enqueue("period_log", {"count": 5})

        # 再ロード（新しいインスタンス）
        sq2 = SpoolQueue(self.filepath)
        self.assertEqual(sq2.size(), 2)

    def test_corrupt_line_recovery(self):
        """壊れた行があっても他の行は正常に読み込まれる"""
        # 壊れた行を含むファイルを作成
        with open(self.filepath, 'w') as f:
            f.write('{"id":"1","type":"stop_event","payload":{},"sent":false,"ts":0}\n')
            f.write('CORRUPT_LINE\n')
            f.write('{"id":"2","type":"period_log","payload":{},"sent":false,"ts":0}\n')

        sq = SpoolQueue(self.filepath)
        self.assertEqual(sq.size(), 2)  # 壊れた行はスキップ

    def test_sent_items_not_reloaded(self):
        """sent=True のアイテムは再起動後に読み込まれない"""
        with open(self.filepath, 'w') as f:
            f.write('{"id":"1","type":"stop_event","payload":{},"sent":true,"ts":0}\n')
            f.write('{"id":"2","type":"period_log","payload":{},"sent":false,"ts":0}\n')

        sq = SpoolQueue(self.filepath)
        self.assertEqual(sq.size(), 1)  # sent=True は除外

    def test_max_size_ring_buffer(self):
        """max_size を超えたら古いアイテムが削除される"""
        sq = SpoolQueue(self.filepath, max_size=3)
        for i in range(5):
            sq.enqueue("stop_event", {"n": i})
        self.assertEqual(sq.size(), 3)

    def test_crash_safe_retry(self):
        """再送途中クラッシュ時: dequeue_all 後に mark_sent しなければ残る"""
        sq = SpoolQueue(self.filepath)
        sq.enqueue("stop_event", {"eventId": "e1"})

        # dequeue_all はアイテムを返すが削除しない
        items = sq.dequeue_all()
        self.assertEqual(len(items), 1)
        self.assertEqual(sq.size(), 1)  # まだ残っている

        # mark_sent で初めて削除
        sq.mark_sent([items[0]["id"]])
        self.assertEqual(sq.size(), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
