"""
camera_config_ui.py - カメラROI設定UI（Flight_Status_Board v4）

ポート 5001 で起動する独立した Flask アプリ。
input_mode = CAMERA の場合のみ app.py から起動される。

機能:
  - ライブMJPEGストリーム表示（ROIオーバーレイ付き）
  - 手動ROI: ブラウザ上でドラッグ矩形指定 → roi_rect に保存
  - 自動ROI: R/G/B ごとのHSV設定でカラー領域を自動検出 → roi_contours に保存
    - 小さすぎる領域（area_limit_min 未満）は除外
    - 複数候補は全て採用
  - ROIクリア: roi_rect を全画面に、roi_contours を空にリセット

エンドポイント:
  GET  /            : 設定UI HTML
  GET  /video_feed  : MJPEGストリーム（ROIオーバーレイ付き）
  POST /api/set_roi         : 手動ROI保存 { roi: [x, y, w, h] (normalized) }
  POST /api/auto_detect/<color> : 自動ROI検出 (color: red/green/blue)
  POST /api/clear_roi       : ROIクリア

conf.ini [CAMERA] セクションに以下を読み書きする:
  roi_rect        = 0.0, 0.0, 1.0, 1.0   (正規化 x,y,w,h)
  roi_contours    = []                    (正規化ポリゴンリスト JSON)
  red_l_hsv       = [0,64,64]
  red_h_hsv       = [10,255,255]
  green_l_hsv     = [50,64,64]
  green_h_hsv     = [90,255,255]
  blue_l_hsv      = [100,64,64]
  blue_h_hsv      = [140,255,255]
  area_limit_min  = 500
  stream_port     = 5001
"""

import threading
import time
import json
import logging

from flask import Flask, Response, jsonify, request

try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

logger = logging.getLogger('Flight_Status_Board.camera_config_ui')


class CameraConfigUI:
    """
    カメラROI設定UIサーバー。

    Parameters
    ----------
    config : ConfigLoader
        Flight_Status_Board の ConfigLoader インスタンス。
        conf.ini の [CAMERA] セクションを読み書きする。
    config_file : str
        conf.ini の絶対パス。
    lock : threading.Lock
        rawFrame へのアクセスを保護する既存ロック。
    state_refs : dict
        {
            "rawFrame": callable -> 最新フレーム (np.ndarray) または None,
            "cam_width": int,
            "cam_height": int,
            "stream_port": int,
        }
    """

    def __init__(self, config, config_file: str, lock: threading.Lock, state_refs: dict):
        self.config      = config
        self.config_file = config_file
        self.lock        = lock
        self.state_refs  = state_refs

        self.app = Flask("camera_config_ui")
        self.latest_overlay_contours = []   # 最後に検出したコンター（表示用）
        self._register_routes()

    # ----------------------------------------------------------------
    # conf.ini ヘルパー
    # ----------------------------------------------------------------
    def _ensure_camera_section(self):
        """[CAMERA] セクションが存在しない場合は追加する"""
        if not self.config._parser.has_section("CAMERA"):
            self.config._parser.add_section("CAMERA")

    def _save_config(self):
        """conf.ini に書き戻す"""
        with open(self.config_file, "w", encoding="utf-8") as f:
            self.config._parser.write(f)

    def _get_camera_value(self, key: str, fallback: str = "") -> str:
        self._ensure_camera_section()
        return self.config._parser.get("CAMERA", key, fallback=fallback)

    def _set_camera_value(self, key: str, value: str):
        self._ensure_camera_section()
        self.config._parser.set("CAMERA", key, value)

    def _parse_hsv(self, color_name: str):
        """
        conf.ini の {color}_l_hsv / {color}_h_hsv を読み込んで
        numpy 配列として返す。
        """
        l_key = f"{color_name}_l_hsv"
        h_key = f"{color_name}_h_hsv"

        # デフォルト値（色ごとに適切な初期値）
        defaults = {
            "red":   ("[0,64,64]",   "[10,255,255]"),
            "green": ("[50,64,64]",  "[90,255,255]"),
            "blue":  ("[100,64,64]", "[140,255,255]"),
        }
        dl, dh = defaults.get(color_name, ("[0,0,0]", "[180,255,255]"))

        l_raw = self._get_camera_value(l_key, dl)
        h_raw = self._get_camera_value(h_key, dh)

        l_hsv = np.array(json.loads(l_raw), dtype=np.uint8)
        h_hsv = np.array(json.loads(h_raw), dtype=np.uint8)
        return l_hsv, h_hsv

    def _get_area_limit_min(self) -> int:
        try:
            return self.config._parser.getint("CAMERA", "area_limit_min", fallback=500)
        except Exception:
            return 500

    # ----------------------------------------------------------------
    # フレーム取得
    # ----------------------------------------------------------------
    def _get_frame(self):
        """最新フレームのコピーを返す。取得できない場合は None。"""
        getter = self.state_refs.get("outputFrame") or self.state_refs.get("rawFrame")
        with self.lock:
            frame = getter()
            if frame is None:
                return None
            return frame.copy()

    # ----------------------------------------------------------------
    # ROI 正規化・保存
    # ----------------------------------------------------------------
    def _normalize_rect(self, x1, y1, x2, y2, w, h):
        """
        ピクセル座標の矩形を正規化 [left, top, width, height] に変換する。
        無効な矩形の場合は None を返す。
        """
        left   = max(0, min(x1, x2))
        top    = max(0, min(y1, y2))
        right  = min(w, max(x1, x2))
        bottom = min(h, max(y1, y2))

        rw = max(0, right  - left)
        rh = max(0, bottom - top)

        if rw <= 0 or rh <= 0:
            return None

        return [
            round(left / w, 4),
            round(top  / h, 4),
            round(rw   / w, 4),
            round(rh   / h, 4),
        ]

    def _save_manual_roi(self, roi_rect: list):
        """
        手動ROIを conf.ini に保存する。
        roi_rect = [x, y, w, h] (正規化済み)
        """
        self._set_camera_value(
            "roi_rect",
            f"{roi_rect[0]:.4f}, {roi_rect[1]:.4f}, {roi_rect[2]:.4f}, {roi_rect[3]:.4f}"
        )
        self._set_camera_value("roi_contours", "[]")
        self._save_config()

    def _save_auto_contours(self, contours: list, frame_w: int, frame_h: int):
        """
        自動検出したコンターを正規化して conf.ini に保存する。
        代表矩形（全コンターを包む外接矩形）も roi_rect に保存する。
        """
        normalized_all = []
        all_points     = []

        for cnt in contours:
            pts = cnt.reshape(-1, 2).tolist()
            norm_pts = []
            for x, y in pts:
                nx = round(float(x) / frame_w, 4)
                ny = round(float(y) / frame_h, 4)
                norm_pts.append([nx, ny])
                all_points.append((x, y))
            normalized_all.append(norm_pts)

        if not all_points:
            raise ValueError("No contour points")

        xs = [p[0] for p in all_points]
        ys = [p[1] for p in all_points]
        roi_rect = self._normalize_rect(min(xs), min(ys), max(xs), max(ys), frame_w, frame_h)
        if roi_rect is None:
            raise ValueError("Invalid roi rect from contours")

        self._set_camera_value(
            "roi_rect",
            f"{roi_rect[0]:.4f}, {roi_rect[1]:.4f}, {roi_rect[2]:.4f}, {roi_rect[3]:.4f}"
        )
        self._set_camera_value(
            "roi_contours",
            json.dumps(normalized_all, ensure_ascii=False)
        )
        self._save_config()

    # ----------------------------------------------------------------
    # オーバーレイ読み込み（ストリーム表示用）
    # ----------------------------------------------------------------
    def _load_saved_overlays(self, frame_w: int, frame_h: int) -> list:
        """
        保存済みの roi_contours / roi_rect をピクセル座標のコンター配列として返す。
        roi_contours が存在する場合はそちらを優先する。
        """
        raw = self._get_camera_value("roi_contours", "[]")
        try:
            contour_groups = json.loads(raw)
        except Exception:
            contour_groups = []

        if contour_groups:
            overlays = []
            for group in contour_groups:
                pts = [
                    [[int(float(p[0]) * frame_w), int(float(p[1]) * frame_h)]]
                    for p in group
                ]
                if pts:
                    overlays.append(np.array(pts, dtype=np.int32))
            return overlays

        # roi_contours が空の場合は roi_rect を矩形コンターに変換
        roi_rect_raw = self._get_camera_value("roi_rect", "0.0, 0.0, 1.0, 1.0")
        try:
            rx, ry, rw, rh = [float(v.strip()) for v in roi_rect_raw.split(",")]
            x1 = int(rx * frame_w)
            y1 = int(ry * frame_h)
            x2 = int((rx + rw) * frame_w)
            y2 = int((ry + rh) * frame_h)
            rect_cnt = np.array(
                [[[x1, y1]], [[x2, y1]], [[x2, y2]], [[x1, y2]]],
                dtype=np.int32
            )
            return [rect_cnt]
        except Exception:
            return []

    # ----------------------------------------------------------------
    # 自動カラー検出
    # ----------------------------------------------------------------
    def _auto_detect_color(self, color_name: str):
        """
        HSV 色空間でカラー領域を検出し、有効なコンターを roi_contours に保存する。

        Returns
        -------
        (dict, int) : (レスポンス辞書, HTTPステータスコード)
        """
        frame = self._get_frame()
        if frame is None:
            return {"status": "error", "message": "No camera frame available"}, 400

        h, w = frame.shape[:2]
        l_hsv, h_hsv = self._parse_hsv(color_name)
        area_limit_min = self._get_area_limit_min()

        # HSV 変換 → マスク生成
        hsv  = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, l_hsv, h_hsv)

        # ノイズ除去（オープニング → クロージング）
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 面積フィルタ（小さすぎる領域を除外）、複数候補は全て採用
        valid_contours = [cnt for cnt in contours if cv2.contourArea(cnt) >= area_limit_min]

        if not valid_contours:
            return {
                "status":  "error",
                "message": f"No valid {color_name} region found (area_limit_min={area_limit_min})"
            }, 404

        self.latest_overlay_contours = valid_contours
        self._save_auto_contours(valid_contours, w, h)

        logger.info(f"[CameraConfigUI] Auto detect {color_name}: {len(valid_contours)} region(s)")
        return {
            "status":  "success",
            "message": f"{color_name.capitalize()} regions detected",
            "count":   len(valid_contours),
        }, 200

    # ----------------------------------------------------------------
    # MJPEGストリーム生成
    # ----------------------------------------------------------------
    def _generate_frames(self):
        """
        ROI オーバーレイを描画した MJPEG フレームを yield する。
        """
        while True:
            frame = self._get_frame()
            if frame is None:
                time.sleep(0.05)
                continue

            h, w = frame.shape[:2]

            # 最新の検出結果があればそれを使用、なければ保存済みを使用
            if self.latest_overlay_contours:
                contours = self.latest_overlay_contours
            else:
                contours = self._load_saved_overlays(w, h)

            for cnt in contours:
                cv2.drawContours(frame, [cnt], -1, (0, 255, 255), 2)

            ok, encoded = cv2.imencode(".jpg", frame)
            if not ok:
                time.sleep(0.05)
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n" +
                bytearray(encoded) +
                b"\r\n"
            )
            time.sleep(0.05)

    # ----------------------------------------------------------------
    # Flask ルート登録
    # ----------------------------------------------------------------
    def _register_routes(self):

        @self.app.route("/")
        def index():
            return _CAMERA_CONFIG_HTML

        @self.app.route("/video_feed")
        def video_feed():
            return Response(
                self._generate_frames(),
                mimetype="multipart/x-mixed-replace; boundary=frame"
            )

        @self.app.route("/api/set_roi", methods=["POST"])
        def set_roi():
            data = request.get_json(force=True)
            roi  = data.get("roi")
            if not roi or len(roi) != 4:
                return jsonify({"status": "error", "message": "Invalid ROI: must be [x, y, w, h]"}), 400
            try:
                rx, ry, rw, rh = [float(v) for v in roi]
                self._save_manual_roi([rx, ry, rw, rh])
                self.latest_overlay_contours = []
                logger.info(f"[CameraConfigUI] Manual ROI saved: {rx:.4f},{ry:.4f},{rw:.4f},{rh:.4f}")
                return jsonify({"status": "success", "message": "ROI saved"})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/clear_roi", methods=["POST"])
        def clear_roi():
            try:
                self._set_camera_value("roi_rect",     "0.0000, 0.0000, 1.0000, 1.0000")
                self._set_camera_value("roi_contours", "[]")
                self._save_config()
                self.latest_overlay_contours = []
                logger.info("[CameraConfigUI] ROI cleared")
                return jsonify({"status": "success", "message": "ROI cleared"})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/auto_detect/<color_name>", methods=["POST"])
        def auto_detect(color_name):
            color_name = color_name.lower()
            if color_name not in ("red", "green", "blue"):
                return jsonify({"status": "error", "message": "Unsupported color (use red/green/blue)"}), 400
            data, code = self._auto_detect_color(color_name)
            return jsonify(data), code

    # ----------------------------------------------------------------
    # サーバー起動
    # ----------------------------------------------------------------
    def run(self):
        """別スレッドから呼び出す。ポートは state_refs["stream_port"] を使用。"""
        port = int(self.state_refs.get("stream_port", 5001))
        logger.info(f"[CameraConfigUI] Starting on port {port}")
        self.app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)


# ----------------------------------------------------------------
# カメラ設定UI HTML（インライン）
# ----------------------------------------------------------------
_CAMERA_CONFIG_HTML = """<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Camera Config - Flight Status Board</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  background: #111;
  color: #eee;
  font-family: Arial, sans-serif;
  padding: 16px;
  text-align: center;
}
h2 {
  margin: 8px 0 16px;
  font-size: 1.2rem;
  color: #8fd;
  letter-spacing: 0.05em;
}
#wrap {
  display: inline-block;
  position: relative;
  border: 2px solid #444;
  max-width: 100%;
}
#video {
  display: block;
  max-width: 90vw;
  max-height: 72vh;
}
#overlay {
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  cursor: crosshair;
}
.toolbar {
  margin-top: 12px;
  display: flex;
  gap: 8px;
  justify-content: center;
  flex-wrap: wrap;
}
button {
  padding: 10px 16px;
  background: #222;
  color: #fff;
  border: 1px solid #555;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background 0.15s;
}
button:hover { background: #333; }
button.active { background: #1a3a1a; border-color: #4f4; color: #4f4; }
button.btn-red   { border-color: #f66; }
button.btn-green { border-color: #6f6; }
button.btn-blue  { border-color: #66f; }
button.btn-clear { border-color: #fa0; }
#status {
  margin-top: 12px;
  min-height: 24px;
  font-size: 0.9rem;
  color: #8fd;
}
.hint {
  margin-top: 8px;
  font-size: 0.78rem;
  color: #666;
}
</style>
</head>
<body>
  <h2>&#x1F4F7; Camera Config &mdash; Flight Status Board (Port 5001)</h2>

  <div id="wrap">
    <img id="video" src="/video_feed" alt="Camera stream" />
    <canvas id="overlay"></canvas>
  </div>

  <div class="toolbar">
    <button id="btnManual" onclick="toggleEdit()">Manual ROI</button>
    <button class="btn-red"   onclick="autoDetect('red')">Auto Detect Red (R)</button>
    <button class="btn-green" onclick="autoDetect('green')">Auto Detect Green (G)</button>
    <button class="btn-blue"  onclick="autoDetect('blue')">Auto Detect Blue (B)</button>
    <button class="btn-clear" onclick="clearROI()">Clear ROI</button>
  </div>

  <div id="status">Ready</div>
  <div class="hint">Keyboard shortcuts: R = Red auto detect &nbsp;|&nbsp; G = Green &nbsp;|&nbsp; B = Blue &nbsp;|&nbsp; M = Toggle manual ROI</div>

<script>
const video    = document.getElementById("video");
const canvas   = document.getElementById("overlay");
const ctx      = canvas.getContext("2d");
const statusEl = document.getElementById("status");
const btnManual = document.getElementById("btnManual");

let editMode   = false;
let dragging   = false;
let startX = 0, startY = 0;
let currentRect = null;

// キャンバスをビデオサイズに合わせる
function resizeCanvas() {
  canvas.width  = video.clientWidth;
  canvas.height = video.clientHeight;
  draw();
}
video.addEventListener("load", resizeCanvas);
window.addEventListener("resize", resizeCanvas);

function setStatus(msg, color = "#8fd") {
  statusEl.textContent = msg;
  statusEl.style.color = color;
}

function toggleEdit() {
  editMode = !editMode;
  dragging = false;
  currentRect = null;
  draw();
  btnManual.classList.toggle("active", editMode);
  setStatus(editMode ? "Manual ROI mode ON: drag to select area" : "Manual ROI mode OFF");
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (currentRect) {
    ctx.strokeStyle = "#ffb000";
    ctx.lineWidth   = 2;
    ctx.strokeRect(currentRect.x, currentRect.y, currentRect.w, currentRect.h);
  }
}

// マウスドラッグで矩形指定
canvas.addEventListener("mousedown", (e) => {
  if (!editMode) return;
  const r = canvas.getBoundingClientRect();
  startX = e.clientX - r.left;
  startY = e.clientY - r.top;
  dragging = true;
  currentRect = { x: startX, y: startY, w: 0, h: 0 };
  draw();
});

canvas.addEventListener("mousemove", (e) => {
  if (!editMode || !dragging) return;
  const r = canvas.getBoundingClientRect();
  const x = e.clientX - r.left;
  const y = e.clientY - r.top;
  currentRect = {
    x: Math.min(startX, x),
    y: Math.min(startY, y),
    w: Math.abs(x - startX),
    h: Math.abs(y - startY),
  };
  draw();
});

canvas.addEventListener("mouseup", async () => {
  if (!editMode || !dragging || !currentRect) return;
  dragging = false;
  if (currentRect.w < 5 || currentRect.h < 5) {
    setStatus("ROI too small, please drag a larger area", "#f88");
    return;
  }
  const rx = currentRect.x / canvas.width;
  const ry = currentRect.y / canvas.height;
  const rw = currentRect.w / canvas.width;
  const rh = currentRect.h / canvas.height;
  try {
    const res  = await fetch("/api/set_roi", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roi: [rx, ry, rw, rh] }),
    });
    const data = await res.json();
    if (res.ok) {
      setStatus("ROI saved (" + rw.toFixed(3) + " x " + rh.toFixed(3) + ")", "#8f8");
      editMode = false;
      btnManual.classList.remove("active");
      currentRect = null;
      draw();
    } else {
      setStatus(data.message || "Failed to save ROI", "#f88");
    }
  } catch (e) {
    setStatus("Failed to save ROI", "#f88");
  }
});

// タッチ対応（ラズパイのタッチスクリーン向け）
canvas.addEventListener("touchstart", (e) => {
  if (!editMode) return;
  e.preventDefault();
  const r = canvas.getBoundingClientRect();
  const t = e.touches[0];
  startX = t.clientX - r.left;
  startY = t.clientY - r.top;
  dragging = true;
  currentRect = { x: startX, y: startY, w: 0, h: 0 };
  draw();
}, { passive: false });

canvas.addEventListener("touchmove", (e) => {
  if (!editMode || !dragging) return;
  e.preventDefault();
  const r = canvas.getBoundingClientRect();
  const t = e.touches[0];
  const x = t.clientX - r.left;
  const y = t.clientY - r.top;
  currentRect = {
    x: Math.min(startX, x),
    y: Math.min(startY, y),
    w: Math.abs(x - startX),
    h: Math.abs(y - startY),
  };
  draw();
}, { passive: false });

canvas.addEventListener("touchend", (e) => {
  canvas.dispatchEvent(new MouseEvent("mouseup"));
});

async function autoDetect(color) {
  setStatus("Detecting " + color + " ...", "#fd8");
  try {
    const res  = await fetch("/api/auto_detect/" + color, { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      setStatus(data.message + " (" + data.count + " region(s))", "#8f8");
    } else {
      setStatus(data.message || "Detection failed", "#f88");
    }
  } catch (e) {
    setStatus("Detection failed", "#f88");
  }
}

async function clearROI() {
  try {
    const res  = await fetch("/api/clear_roi", { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      currentRect = null;
      draw();
      setStatus("ROI cleared", "#8f8");
    } else {
      setStatus(data.message || "Clear failed", "#f88");
    }
  } catch (e) {
    setStatus("Clear failed", "#f88");
  }
}

// キーボードショートカット
document.addEventListener("keydown", (e) => {
  if (e.key === "r" || e.key === "R") autoDetect("red");
  if (e.key === "g" || e.key === "G") autoDetect("green");
  if (e.key === "b" || e.key === "B") autoDetect("blue");
  if (e.key === "m" || e.key === "M") toggleEdit();
});
</script>
</body>
</html>
"""
