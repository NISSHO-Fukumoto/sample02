"""
app.py - Flight_Status_Board メインアプリケーション（v4）
Raspberry Pi 400 エントリーモデル ノード端末

起動:
  python3 app.py

アーキテクチャ:
  pasted_content.txt §14 に準拠したモジュール構成

v4 変更点:
  - プロジェクト名を Frite_Status_Board → Flight_Status_Board に修正
  - camera_config_ui.py を追加（CAMERA モード時にポート 5001 で起動）
  - CameraConfigUI が ROI 設定・自動カラー検出・MJPEGストリームを提供
  - conf.ini [CAMERA] に roi_contours / HSV / area_limit_min / stream_port を追加
"""
import sys
import os
import time
import threading
import logging
import socket
from datetime import datetime, timedelta, timezone
from flask import Flask, render_template, jsonify, request, Response
JST = timezone(timedelta(hours=9))



# ── パス設定 ──────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, BASE_DIR)

# ── ログ設定 ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('Flight_Status_Board')
# Werkzeug のログを抑制
logging.getLogger('werkzeug').setLevel(logging.ERROR)

# ── コアモジュール ────────────────────────────────────────────────────
from core.config_loader    import ConfigLoader
from core.state_machine    import StateMachine
from core.counter_tracker  import CounterTracker
from core.input_reader     import InputReader
from core.break_scheduler  import BreakScheduler
try:
    from camera_config_ui import CameraConfigUI
    HAS_CAMERA_UI = True
except ImportError:
    HAS_CAMERA_UI = False
from core.stop_event_manager import StopEventManager
from core.period_aggregator  import PeriodAggregator
from core.api_client       import ApiClient
from core.spool_queue      import SpoolQueue
from core.sender           import Sender

# ── 設定読み込み ──────────────────────────────────────────────────────
config_file = os.path.join(BASE_DIR, 'conf.ini')
config = ConfigLoader(config_file)

# ── コアオブジェクト生成 ──────────────────────────────────────────────
state_machine    = StateMachine(config)
counter          = CounterTracker(config)
break_scheduler  = BreakScheduler(config)
stop_event_mgr   = StopEventManager(config.get('machine_id', 'DEFAULT_MACHINE'))
period_aggregator = PeriodAggregator(config, counter)
api_client       = ApiClient(config)
spool_queue      = SpoolQueue(os.path.join(BASE_DIR, 'spool.json'))
sender           = Sender(config, api_client, spool_queue,
                          state_machine, counter,
                          stop_event_mgr, period_aggregator)

# ── Flask アプリ ──────────────────────────────────────────────────────
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR   = os.path.join(BASE_DIR, 'static')
app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

# ── ユーティリティ ────────────────────────────────────────────────────
def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def format_duration(seconds: float) -> str:
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h:02}:{m:02}:{sec:02}"


def get_status_key() -> str:
    """フロントエンド用のステータスキーを返す"""
    state = state_machine.current_state
    if state == "stop":
        return "stop_doka" if state_machine.stop_class == "doka" else "stop_choco"
    return state


# ── カウント発生コールバック ──────────────────────────────────────────
_input_lock = threading.Lock()


def on_count():
    """入力モジュールからカウント発生時に呼ばれる"""
    with _input_lock:
        # 先に状態を更新
        state_machine.on_count()

        # その後、カウントと時間集計
        counter.on_count(state_machine)
        logger.info(f"[COUNT] count={counter.count}")

        # 停止イベント処理（復旧）
        events = stop_event_mgr.process(state_machine)

        # close イベントのうち、count復帰以外は counter に反映
        apply_closed_stop_events_to_counter(events)

        if events:
            sender.on_stop_events(events)

        # 即時 current_status 送信
        sender.on_state_changed()


def on_alarm(active: bool):
    """
    GPIO エラー入力コールバック（将来拡張: error_input_enabled=true の場合のみ呼ばれる）
    active=True  : エラー入力 ON → alarm=True
    active=False : エラー入力 OFF → alarm=False
    """
    state_machine.alarm = active
    logger.info(f"[ALARM] alarm={'ON' if active else 'OFF'}")
    sender.on_state_changed()

def apply_closed_stop_events_to_counter(events):
    """
    stop_event_manager から返る close イベントのうち、
    count 復帰ではない close だけ counter に反映する。

    対象:
      - break_transition
      - shift_end
      - power_off
      - forced_close
      - その他 recovered 以外

    対象外:
      - recovered
        -> count 復帰時は counter.on_count() 側で既に集計済み
    """
    if not events:
        return

    for ev in events:
        if ev.get("action") != "close":
            continue

        close_reason = ev.get("closeReason")
        if close_reason == "recovered":
            # count 復帰は on_count() 側で既に集計済み
            continue

        final_class = ev.get("finalStopClass")
        final_duration = ev.get("finalStopDurationSec", 0)

        if final_class in ("choco", "doka") and final_duration > 0:
            counter.finalize_closed_stop(final_class, final_duration)
            logger.info(
                f"[COUNTER] finalized closed stop: "
                f"class={final_class}, duration={final_duration}, reason={close_reason}"
            )

# ── バックグラウンド監視ループ ─────────────────────────────────────────
def background_loop():
    while True:
        try:
            state_machine.update()

            # 計画停止時間の自己集計（period_aggregator が state_machine.time_zone を見る）
            period_aggregator.update(state_machine)

            # 停止イベント処理
            events = stop_event_mgr.process(state_machine)

            # close イベントのうち、count復帰以外は counter に反映
            apply_closed_stop_events_to_counter(events)

            if events:
                sender.on_stop_events(events)

            # 状態変化時の即時送信
            if state_machine.has_changed():
                sender.on_state_changed()
                logger.info(
                    f"[STATE] {state_machine.current_state} / "
                    f"stop_class={state_machine.stop_class} / "
                    f"zone={state_machine.time_zone} / "
                    f"violation={state_machine.schedule_violation}"
                )
        except Exception as e:
            logger.error(f"[BG] Error: {e}")
        time.sleep(0.5)


# ── Flask ルート ──────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template(
        'index.html',
        product_name=config.get('product_name', 'Flight_Status_Board'),
        model_number='Entry Model',
        current_ip=get_local_ip(),
        enable_keyboard_reset=config.get('enable_keyboard_reset', True),
        reset_hold_time=config.get('reset_hold_time', 3.0),
        exit_hold_time=config.get('exit_hold_time', 2.0),
    )


@app.route('/api/data')
def api_data():
    """ダッシュボード用データ API"""
    try:
        now = time.time()

        # 停止経過秒
        stop_elapsed = 0
        if state_machine.stop_start_at:
            stop_elapsed = int(now - state_machine.stop_start_at)

        # 計画停止時間（period_aggregator から取得）
        planned_sec = period_aggregator._planned_sec_in_period
        if period_aggregator._planned_stop_start is not None:
            planned_sec += now - period_aggregator._planned_stop_start

        # 最終カウント時刻
        last_count_str = "--"
        if state_machine.last_count_at:
            last_count_str = datetime.fromtimestamp(
                state_machine.last_count_at, JST).strftime('%H:%M:%S')

        return jsonify({
            "count":              counter.count,
            "target":             config.get('target', 100),
            "percent":            counter.get_percent(),
            "avg_count":          counter.get_avg_per_hour(),
            "status":             get_status_key(),
            "stop_elapsed_sec":   stop_elapsed,
            "last_count_at":      last_count_str,
            "op_time":            format_duration(counter.get_current_work_sec()),
            "choco_time":         format_duration(counter.get_current_choco_sec()),
            "doka_time":          format_duration(counter.get_current_doka_sec()),
            "planned_time":       format_duration(planned_sec),
            # 補助情報（v3 追加）
            "alarm":              state_machine.alarm,
            "schedule_violation": state_machine.schedule_violation,
            "time_zone":          state_machine.time_zone,
            "machine_id":         config.get('machine_id', '--'),
            "input_mode":         config.get('input_mode', '--'),
            "stop_detect_sec":    config.get('dur_choco_sec', 180),
            "doka_threshold_sec": config.get('dur_doka_sec', 600),
            "spool_size":         spool_queue.size(),
            "timestamp":          datetime.now().strftime('%H:%M:%S'),
        })
    except Exception as e:
        logger.error(f"[API /data] {e}")
        return jsonify({"count": 0, "status": "off"})


@app.route('/api/settings', methods=['GET'])
def api_settings_get():
    """設定値取得"""
    return jsonify({
        "machine_id":          config.get('machine_id'),
        "input_mode":          config.get('input_mode'),
        "target":              config.get('target'),
        "dur_choco_sec":       config.get('dur_choco_sec'),
        "dur_doka_sec":        config.get('dur_doka_sec'),
        "api_url":             config.get('api_url'),
        "sync_interval_sec":   config.get('sync_interval_sec'),
        "time_start":          config.get('time_start'),
        "time_end":            config.get('time_end'),
        "breaks":              config.get('breaks', []),
        "error_input_enabled": config.get('error_input_enabled', False),
        "error_input_pin":     config.get('error_input_pin', 27),
        "error_active_state":  config.get('error_active_state', 'HIGH'),
    })


@app.route('/api/settings', methods=['POST'])
def api_settings_post():
    """設定値保存"""
    try:
        data = request.get_json()

        # BASIC
        config.update_and_save('BASIC', 'machine_id', data.get('machine_id', config.get('machine_id')))
        config.update_and_save('BASIC', 'input_mode', data.get('input_mode', config.get('input_mode')))
        config.update_and_save('BASIC', 'target',     str(data.get('target', config.get('target'))))

        # TIMEOUT
        config.update_and_save('TIMEOUT', 'dur_choco_sec', str(data.get('dur_choco_sec', config.get('dur_choco_sec'))))
        config.update_and_save('TIMEOUT', 'dur_doka_sec',  str(data.get('dur_doka_sec',  config.get('dur_doka_sec'))))

        # CLOUD
        config.update_and_save('CLOUD', 'api_url', data.get('api_url', config.get('api_url')))
        if data.get('api_key'):
            config.update_and_save('CLOUD', 'api_key', data['api_key'])
        config.update_and_save('CLOUD', 'sync_interval_sec', str(data.get('sync_interval_sec', config.get('sync_interval_sec'))))

        # SCHEDULE
        config.update_and_save('SCHEDULE', 'time_start', data.get('time_start', config.get('time_start', '')))
        config.update_and_save('SCHEDULE', 'time_end',   data.get('time_end',   config.get('time_end', '')))
        breaks_val = data.get('breaks', '')
        if isinstance(breaks_val, list):
            breaks_val = ', '.join(breaks_val)
        config.update_and_save('SCHEDULE', 'breaks', breaks_val)
        # INPUT (GPIO エラー入力 将来拡張)
        if 'error_input_enabled' in data:
            config.update_and_save('INPUT', 'error_input_enabled', str(data['error_input_enabled']).lower())
        if 'error_input_pin' in data:
            config.update_and_save('INPUT', 'error_input_pin', str(data['error_input_pin']))
        if 'error_active_state' in data:
            config.update_and_save('INPUT', 'error_active_state', str(data['error_active_state']).upper())

        # 設定を再読み込み
        config.load()
        break_scheduler.reload()
        api_client.reload()

        logger.info("[Settings] Saved and reloaded.")
        return jsonify({"status": "ok"})
    except Exception as e:
        logger.error(f"[Settings] Save error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route('/api/manual_reset', methods=['POST'])
def api_manual_reset():
    if not config.get('enable_keyboard_reset', True):
        return jsonify({"status": "disabled"}), 403

    counter.reset()
    state_machine.last_count_at = None
    state_machine.stop_start_at = None
    state_machine.current_state = "off"
    state_machine.stop_class    = None
    state_machine.alarm         = False
    logger.info("[Reset] Manual reset performed.")
    return jsonify({"status": "reset_completed"})


@app.route('/api/shutdown', methods=['POST'])
def api_shutdown():
    logger.info("[Shutdown] Shutdown requested.")
    threading.Thread(target=lambda: (time.sleep(1), os._exit(0)), daemon=True).start()
    return jsonify({"status": "shutdown"})


# ── カメラストリーム ──────────────────────────────────────────────────
def generate_frame(reader):
    while True:
        jpeg = reader.get_frame_jpeg()
        if jpeg:
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + jpeg + b'\r\n')
        time.sleep(0.05)


# ── メイン ────────────────────────────────────────────────────────────
def main():
    logger.info("=" * 55)
    logger.info(f"  Flight_Status_Board v4 Starting...")
    logger.info(f"  Machine ID : {config.get('machine_id')}")
    logger.info(f"  Input Mode : {config.get('input_mode')}")
    logger.info(f"  API URL    : {config.get('api_url')}")
    err_enabled = config.get('error_input_enabled', False)
    if err_enabled:
        logger.info(
            f"  Error Input: GPIO pin {config.get('error_input_pin')} "
            f"({config.get('error_active_state')} active)"
        )
    else:
        logger.info(f"  Error Input: disabled")
    logger.info("=" * 55)

    # 入力リーダー起動（alarm コールバックを渡す）
    input_reader = InputReader(config, on_count, on_alarm_callback=on_alarm)
    input_reader.start()

    # カメラモード時の追加処理
    if config.get('input_mode') == 'CAMERA':
        # メインUI用のMJPEGストリーム（ポート5000）
        @app.route('/video_feed')
        def video_feed():
            return Response(generate_frame(input_reader),
                            mimetype='multipart/x-mixed-replace; boundary=frame')
        # カメラ設定UI（ポート5001）を別スレッドで起動
        if HAS_CAMERA_UI:
            try:
                camera_ui = CameraConfigUI(
                    config=config,
                    config_file=os.path.join(BASE_DIR, 'conf.ini'),
                    lock=input_reader._frame_lock,
                    state_refs={
                                    'rawFrame':     lambda: input_reader.raw_frame,
                                    'outputFrame':  lambda: input_reader.output_frame,
                                    'cam_width':    config.get('cam_width',  640),
                                    'cam_height':   config.get('cam_height', 480),
                                    'stream_port':  config.get('stream_port', 5001),
                    }
                )
                threading.Thread(target=camera_ui.run, daemon=True).start()
                logger.info(f"  Camera Config UI: http://{get_local_ip()}:{config.get('stream_port', 5001)}")
            except Exception as e:
                logger.warning(f"  Camera Config UI failed to start: {e}")
    # バックグラウンドループ起動
    threading.Thread(target=background_loop, daemon=True).start()

    # 送信モジュール起動
    sender.start()

    # Flask 起動
    logger.info(f"  Web UI     : http://{get_local_ip()}:5000")
    logger.info("=" * 55)
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)


if __name__ == '__main__':
    main()
