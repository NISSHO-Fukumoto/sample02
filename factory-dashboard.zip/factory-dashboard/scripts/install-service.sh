#!/bin/bash
# =============================================================================
# systemd サービス登録スクリプト
# 工場機械稼働状況ダッシュボードをシステムサービスとして登録します
# =============================================================================
# 使用方法: sudo bash scripts/install-service.sh
# =============================================================================

set -e

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# root チェック
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}❌ このスクリプトは sudo で実行してください${NC}"
  echo "   使用方法: sudo bash scripts/install-service.sh"
  exit 1
fi

# プロジェクトパスを取得
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CURRENT_USER="${SUDO_USER:-$(whoami)}"
NODE_PATH=$(su - "$CURRENT_USER" -c "which node" 2>/dev/null || which node)

echo -e "${BOLD}systemd サービス登録${NC}"
echo "  プロジェクトパス: $PROJECT_DIR"
echo "  実行ユーザー: $CURRENT_USER"
echo "  Node.js パス: $NODE_PATH"
echo ""

# dist/index.js が存在するか確認
if [ ! -f "$PROJECT_DIR/dist/index.js" ]; then
  echo -e "${RED}❌ dist/index.js が見つかりません${NC}"
  echo "   先にビルドを実行してください: npm run build"
  exit 1
fi

# .env ファイルが存在するか確認
if [ ! -f "$PROJECT_DIR/.env" ]; then
  echo -e "${RED}❌ .env ファイルが見つかりません${NC}"
  echo "   先に setup-local.sh を実行してください"
  exit 1
fi

# systemd サービスファイルを作成
cat > /etc/systemd/system/factory-dashboard.service << EOF
[Unit]
Description=Factory Machine Monitoring Dashboard
Documentation=https://github.com/your-org/factory-dashboard
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${CURRENT_USER}
WorkingDirectory=${PROJECT_DIR}
EnvironmentFile=${PROJECT_DIR}/.env
ExecStart=${NODE_PATH} dist/index.js
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=factory-dashboard

# セキュリティ設定
NoNewPrivileges=yes
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF

echo -e "${GREEN}✓ サービスファイルを作成しました: /etc/systemd/system/factory-dashboard.service${NC}"

# systemd をリロードしてサービスを有効化
systemctl daemon-reload
systemctl enable factory-dashboard
systemctl start factory-dashboard

# ステータス確認
sleep 2
if systemctl is-active --quiet factory-dashboard; then
  echo -e "${GREEN}✓ サービスが正常に起動しました${NC}"
else
  echo -e "${RED}❌ サービスの起動に失敗しました${NC}"
  echo "ログを確認してください: sudo journalctl -u factory-dashboard -n 50"
  exit 1
fi

echo ""
echo -e "${BOLD}${GREEN}✅ systemd サービス登録完了${NC}"
echo ""
echo "サービス管理コマンド:"
echo "  状態確認:  sudo systemctl status factory-dashboard"
echo "  停止:      sudo systemctl stop factory-dashboard"
echo "  起動:      sudo systemctl start factory-dashboard"
echo "  再起動:    sudo systemctl restart factory-dashboard"
echo "  ログ確認:  sudo journalctl -u factory-dashboard -f"
echo "  無効化:    sudo systemctl disable factory-dashboard"
