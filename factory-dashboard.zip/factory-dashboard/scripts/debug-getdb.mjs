// Test the exact same connection pattern as server/db.ts
import { drizzle } from "drizzle-orm/mysql2";
import { mysqlTable, serial, varchar, text, mysqlEnum, boolean, timestamp } from "drizzle-orm/mysql-core";

const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: mysqlEnum("role", ["admin", "operator", "viewer"]).default("operator").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// This is exactly how getDb() creates the connection
const db = drizzle(process.env.DATABASE_URL);

try {
  console.log("Attempting insert via drizzle(url)...");
  await db.insert(users).values({
    username: "admin_url_test",
    passwordHash: "testhash3",
    role: "admin",
    isActive: true,
  });
  console.log("Insert succeeded");

  const result = await db.select().from(users);
  console.log("Users count:", result.length);
  console.log("Latest:", result[result.length - 1]);
} catch (e) {
  console.error("Error:", e.message);
  console.error("Stack:", e.stack?.split('\n').slice(0, 5).join('\n'));
}

process.exit(0);
