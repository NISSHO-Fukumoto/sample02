/**
 * PostgreSQL セットアップスクリプト
 * ローカルLinuxサーバー向けデプロイ用
 *
 * 使用方法:
 *   DATABASE_URL=postgresql://user:pass@localhost:5432/factory_db node scripts/setup-db.mjs
 *
 * または .env ファイルがある場合:
 *   node scripts/setup-db.mjs
 */
import pg from "pg";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { createRequire } from "module";

const __dirname = dirname(fileURLToPath(import.meta.url));

// .env ファイルを手動ロード（dotenv が使えない場合の fallback）
function loadEnv() {
  const envPath = join(__dirname, "../.env");
  try {
    const content = readFileSync(envPath, "utf-8");
    for (const line of content.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      const value = trimmed.slice(eqIdx + 1).trim().replace(/^["']|["']$/g, "");
      if (!process.env[key]) process.env[key] = value;
    }
  } catch {
    // .env ファイルがない場合は環境変数から直接読む
  }
}

loadEnv();

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error("❌ DATABASE_URL が設定されていません");
  console.error("   .env ファイルを作成するか、環境変数を設定してください");
  console.error("   例: DATABASE_URL=postgresql://factory_user:factory_pass@localhost:5432/factory_db");
  process.exit(1);
}

const sqlPath = join(__dirname, "../drizzle/migrations/0001_factory_init.sql");
const sql = readFileSync(sqlPath, "utf-8");

const { Pool } = pg;
const pool = new Pool({ connectionString });

console.log("🔌 PostgreSQL に接続中...");
const client = await pool.connect();

try {
  // テスト接続
  await client.query("SELECT 1");
  console.log("✅ 接続成功");

  // SQL文を分割して実行
  // コメント行を除去し、セミコロンで分割
  const statements = sql
    .split("\n")
    .filter(line => !line.trim().startsWith("--"))
    .join("\n")
    .split(";")
    .map(s => s.trim())
    .filter(s => s.length > 0);

  let success = 0;
  let errors = 0;

  console.log("\n📋 テーブルを作成中...");
  for (const stmt of statements) {
    try {
      await client.query(stmt);
      // CREATE TABLE / CREATE INDEX のみ表示
      const tableMatch = stmt.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)/i);
      const indexMatch = stmt.match(/CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)/i);
      const typeMatch = stmt.match(/CREATE\s+TYPE\s+(\w+)/i);
      if (tableMatch) console.log(`  ✓ テーブル: ${tableMatch[1]}`);
      else if (indexMatch) console.log(`  ✓ インデックス: ${indexMatch[1]}`);
      else if (typeMatch) console.log(`  ✓ 型: ${typeMatch[1]}`);
      success++;
    } catch (err) {
      // 既に存在する場合はスキップ（IF NOT EXISTS を使っているので通常は発生しない）
      if (err.code === "42P07" || err.message.includes("already exists")) {
        // 無視
      } else {
        console.error(`  ✗ エラー: ${err.message}`);
        console.error(`    SQL: ${stmt.substring(0, 80)}...`);
        errors++;
      }
    }
  }

  console.log(`\n✅ セットアップ完了: ${success} 件成功, ${errors} 件失敗`);

  if (errors > 0) {
    console.error("❌ エラーが発生しました。上記のエラーメッセージを確認してください。");
    process.exit(1);
  }

  console.log("\n🚀 次のステップ:");
  console.log("  1. サーバーを起動: npm start");
  console.log("  2. ブラウザで http://localhost:3000/setup にアクセス");
  console.log("  3. 管理者アカウントを作成してログイン");

} catch (err) {
  console.error("❌ データベース接続エラー:", err.message);
  console.error("\nPostgreSQL の設定を確認してください:");
  console.error("  - PostgreSQL サービスが起動しているか: sudo systemctl status postgresql");
  console.error("  - DATABASE_URL が正しいか");
  console.error("  - データベースとユーザーが存在するか");
  process.exit(1);
} finally {
  client.release();
  await pool.end();
}
