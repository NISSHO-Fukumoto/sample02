import mysql from "mysql2/promise";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const sqlPath = join(__dirname, "../drizzle/migrate-factory.sql");
const sql = readFileSync(sqlPath, "utf-8");

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

const conn = await mysql.createConnection(connectionString);

// Remove comment lines and split by semicolons
const cleanedSql = sql
  .split("\n")
  .filter(line => !line.trim().startsWith("--"))
  .join("\n");

const statements = cleanedSql
  .split(";")
  .map(s => s.trim())
  .filter(s => s.length > 0);

let success = 0;
let errors = 0;

for (const stmt of statements) {
  try {
    await conn.execute(stmt);
    const tableName = stmt.match(/TABLE\s+(?:IF NOT EXISTS\s+)?`?(\w+)`?/i)?.[1];
    if (tableName) console.log(`✓ ${tableName}`);
    success++;
  } catch (err) {
    console.error(`✗ Error: ${err.message}`);
    console.error(`  Statement: ${stmt.substring(0, 80)}...`);
    errors++;
  }
}

await conn.end();
console.log(`\nMigration complete: ${success} succeeded, ${errors} failed`);
if (errors > 0) process.exit(1);
