import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { mysqlTable, serial, varchar, text, mysqlEnum, boolean, timestamp } from "drizzle-orm/mysql-core";

const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: mysqlEnum("role", ["admin", "operator", "viewer"]).default("operator").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

const conn = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(conn);

try {
  console.log("Attempting drizzle insert...");
  await db.insert(users).values({
    username: "admin_drizzle",
    passwordHash: "testhash2",
    role: "admin",
    isActive: true,
  });
  console.log("Insert succeeded");

  const result = await db.select().from(users);
  console.log("Users:", JSON.stringify(result, null, 2));
} catch (e) {
  console.error("Error:", e.message, e.stack);
}

conn.end();
