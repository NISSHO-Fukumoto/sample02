import { createContext, useContext, useState, ReactNode } from "react";
import { startOfDay, endOfDay } from "date-fns";

type PresetRange = "daily" | "weekly" | "this_month" | "last_month" | "all_time" | "custom";

interface ReportsState {
  selectedMachineId: string;
  preset: PresetRange;
  groupBy: "daily" | "weekly" | "monthly";
  closingDay: number;
  fromDate: Date;
  toDate: Date;
}

interface ReportsContextValue extends ReportsState {
  setSelectedMachineId: (v: string) => void;
  setPreset: (v: PresetRange) => void;
  setGroupBy: (v: "daily" | "weekly" | "monthly") => void;
  setClosingDay: (v: number) => void;
  setFromDate: (v: Date) => void;
  setToDate: (v: Date) => void;
}

const defaultFrom = (() => { const d = new Date(); d.setDate(d.getDate() - 6); return startOfDay(d); })();
const defaultTo = endOfDay(new Date());

const ReportsContext = createContext<ReportsContextValue | null>(null);

export function ReportsProvider({ children }: { children: ReactNode }) {
  const [selectedMachineId, setSelectedMachineId] = useState("all");
  const [preset, setPreset] = useState<PresetRange>("daily");
  const [groupBy, setGroupBy] = useState<"daily" | "weekly" | "monthly">("daily");
  const [closingDay, setClosingDay] = useState(0);
  const [fromDate, setFromDate] = useState<Date>(defaultFrom);
  const [toDate, setToDate] = useState<Date>(defaultTo);

  return (
    <ReportsContext.Provider value={{
      selectedMachineId, setSelectedMachineId,
      preset, setPreset,
      groupBy, setGroupBy,
      closingDay, setClosingDay,
      fromDate, setFromDate,
      toDate, setToDate,
    }}>
      {children}
    </ReportsContext.Provider>
  );
}

export function useReportsContext() {
  const ctx = useContext(ReportsContext);
  if (!ctx) throw new Error("useReportsContext must be used within ReportsProvider");
  return ctx;
}
