import { useState } from "react";
import { useLocation } from "wouter";
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { trpc } from "../lib/trpc";
import { MachineCard } from "../components/MachineCard";
import { Button } from "../components/ui/button";
import { RefreshCw, GripVertical, LayoutGrid } from "lucide-react";
import { Skeleton } from "../components/ui/skeleton";
import { formatDuration } from "../lib/machineState"; // ★時間フォーマットをインポート

// ★新規追加: サマリー表示用のカードコンポーネント
function SummaryCard({ title, value, colorClass = "text-foreground" }: { title: string, value: string, colorClass?: string }) {
  return (
    <div className="bg-card border rounded-lg p-3 text-center shadow-sm">
      <div className={`text-2xl font-bold font-mono ${colorClass}`}>
        {value}
      </div>
      <div className="text-[11px] text-muted-foreground mt-1">
        {title}
      </div>
    </div>
  );
}

// 並べ替え可能なカードコンポーネント
function SortableMachineCard({ machine, isDragging }: { machine: any; isDragging?: boolean }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: machine.machineId });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const [, navigate] = useLocation();

  return (
    <div ref={setNodeRef} style={style} className="relative group">
      <div
        {...attributes}
        {...listeners}
        className="absolute top-2 left-2 z-10 opacity-0 group-hover:opacity-60 cursor-grab active:cursor-grabbing transition-opacity"
      >
        <GripVertical className="w-4 h-4 text-muted-foreground" />
      </div>
      <MachineCard
        machineId={machine.machineId}
        displayName={machine.displayName}
        location={machine.location}
        currentStatus={machine.currentStatus}
        todaySummary={machine.todaySummary}
        dragging={isDragging}
        onClick={() => navigate(`/machines/${machine.machineId}`)}
      />
    </div>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const { data: machines, isLoading, refetch } = trpc.dashboard.overview.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  const { data: layout } = trpc.dashboard.getLayout.useQuery();
  const saveLayout = trpc.dashboard.saveLayout.useMutation();

  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  if (isLoading || !machines) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 w-full" />
          ))}
        </div>
      </div>
    );
  }

  // ====== ★新規追加: 全ノードの合算計算 ======
  const totalMachines = machines.length;
  // currentStateが "running" または "run" のものを稼働中とする
  const runningMachines = machines.filter(m => m.currentStatus?.currentState === "running" || m.currentStatus?.currentState === "run").length;

  let totalProd = 0;
  let totalRun = 0;
  let totalChoco = 0;
  let totalDoka = 0;
  let totalPlan = 0;

  machines.forEach(m => {
    if (m.todaySummary) {
      totalProd += m.todaySummary.productionCount || 0;
      totalRun += m.todaySummary.runningSeconds || 0;
      // anyキャストでコンパイルエラー回避 (ダッシュボードルーターの型が更新されるまで)
      totalChoco += (m.todaySummary as any).chocoSeconds || 0; 
      totalDoka += (m.todaySummary as any).dokaSeconds || 0;
      totalPlan += m.todaySummary.plannedStopSeconds || 0;
    }
  });

  const totalTimeForRate = totalRun + totalChoco + totalDoka;
  const globalOperatingRate = totalTimeForRate > 0 
    ? ((totalRun / totalTimeForRate) * 100).toFixed(1) 
    : "--";
  // ============================================

  // レイアウトに基づいて並べ替え
  const sortedMachines = [...machines].sort((a, b) => {
    const aLayout = layout?.find(l => l.machineId === a.machineId);
    const bLayout = layout?.find(l => l.machineId === b.machineId);
    if (!aLayout || !bLayout) return 0;
    return aLayout.position - bLayout.position;
  });

  const handleDragStart = (event: any) => {
    setActiveId(event.active.id);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (over && active.id !== over.id) {
      const oldIndex = sortedMachines.findIndex(m => m.machineId === active.id);
      const newIndex = sortedMachines.findIndex(m => m.machineId === over.id);
      
      const newSorted = arrayMove(sortedMachines, oldIndex, newIndex);
      const newLayout = newSorted.map((m, index) => ({
        machineId: m.machineId,
        position: index,
        visible: true
      }));

      await saveLayout.mutateAsync({ layout: newLayout });
      utils.dashboard.getLayout.setData(undefined, newLayout);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* ページタイトルと更新ボタン */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <LayoutGrid className="w-6 h-6 text-primary" />
            稼働状況ダッシュボード
          </h1>
          <p className="text-muted-foreground text-sm">
            全 {machines.length} 台 — 30秒ごとに自動更新
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            className="h-9"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            更新
          </Button>
        </div>
      </div>

      {/* ★入れ替え箇所: サマリー統計セクション（7項目） */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <SummaryCard 
          title="稼働台数" 
          value={`${runningMachines}/${totalMachines}`} 
          colorClass="text-green-500" 
        />
        <SummaryCard 
          title="総生産数" 
          value={totalProd.toLocaleString()} 
        />
        <SummaryCard 
          title="全体稼働率" 
          value={globalOperatingRate !== "--" ? `${globalOperatingRate}%` : "--"} 
          colorClass="text-green-500" 
        />
        <SummaryCard 
          title="稼働時間" 
          value={formatDuration(totalRun)} 
          colorClass="text-green-500" 
        />
        <SummaryCard 
          title="チョコ停" 
          value={formatDuration(totalChoco)} 
          colorClass="text-yellow-500" 
        />
        <SummaryCard 
          title="ドカ停" 
          value={formatDuration(totalDoka)} 
          colorClass="text-red-500" 
        />
        <SummaryCard 
          title="計画停止" 
          value={formatDuration(totalPlan)} 
          colorClass="text-blue-400" 
        />
      </div>

      {/* 機械カードグリッド (既存のまま) */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={sortedMachines.map(m => m.machineId)}
          strategy={verticalListSortingStrategy}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
            {sortedMachines.map((machine) => (
              <SortableMachineCard 
                key={machine.machineId} 
                machine={machine} 
                isDragging={activeId === machine.machineId}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}