import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import { MachineCard } from "../components/MachineCard";
import { MachineCard02 } from "../components/MachineCard02";
import { Button } from "../components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { RefreshCw, LayoutGrid, ArrowUpDown } from "lucide-react";
import { Skeleton } from "../components/ui/skeleton";
import { formatDuration } from "../lib/machineState";

// ソート種別
type SortKey = "rate_asc" | "rate_desc" | "id_asc" | "id_desc";
type LayoutKey = "default" | "cyber";

// サマリー表示用のカードコンポーネント
function SummaryCard({ title, value, colorClass = "text-foreground" }: { title: string, value: string, colorClass?: string }) {
  return (
    <div className="bg-card border rounded-lg p-3 text-center shadow-sm">
      <div className={`text-2xl font-bold font-mono ${colorClass}`}>
        {value}
      </div>
      <div className="text-[11px] text-muted-foreground mt-1">
        {title}
      </div>
    </div>
  );
}

// 稼働率を計算するヘルパー
function getAvailabilityRate(machine: any): number {
  const s = machine.todaySummary;
  if (!s) return -1;
  const run = s.runningSeconds || 0;
  const choco = (s as any).chocoSeconds || 0;
  const doka = (s as any).dokaSeconds || 0;
  const total = run + choco + doka;
  if (total === 0) return -1;
  return run / total;
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: machines, isLoading, refetch } = trpc.dashboard.overview.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  const [sortKey, setSortKey] = useState<SortKey>("id_asc");
  const [layoutKey, setLayoutKeyRaw] = useState<LayoutKey>(() =>
    (sessionStorage.getItem("dashboard_layout") as LayoutKey) ?? "default"
  );
  const setLayoutKey = (v: LayoutKey) => {
    setLayoutKeyRaw(v);
    sessionStorage.setItem("dashboard_layout", v);
  };

  if (isLoading || !machines) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 w-full" />
          ))}
        </div>
      </div>
    );
  }

  // 全ノードの合算計算
  const totalMachines = machines.length;
  const runningMachines = machines.filter(m => m.currentStatus?.currentState === "running" || m.currentStatus?.currentState === "run").length;

  let totalProd = 0;
  let totalRun = 0;
  let totalChoco = 0;
  let totalDoka = 0;
  let totalPlan = 0;

  machines.forEach(m => {
    if (m.todaySummary) {
      totalProd += m.todaySummary.productionCount || 0;
      totalRun += m.todaySummary.runningSeconds || 0;
      totalChoco += (m.todaySummary as any).chocoSeconds || 0;
      totalDoka += (m.todaySummary as any).dokaSeconds || 0;
      totalPlan += m.todaySummary.plannedStopSeconds || 0;
    }
  });

  const totalTimeForRate = totalRun + totalChoco + totalDoka;
  const globalOperatingRate = totalTimeForRate > 0
    ? ((totalRun / totalTimeForRate) * 100).toFixed(1)
    : "--";

  // ソートキーに応じた並べ替え
  const sortedMachines = (() => {
    switch (sortKey) {
      case "rate_asc":
        return [...machines].sort((a, b) => getAvailabilityRate(a) - getAvailabilityRate(b));
      case "rate_desc":
        return [...machines].sort((a, b) => getAvailabilityRate(b) - getAvailabilityRate(a));
      case "id_asc":
        return [...machines].sort((a, b) => a.machineId.localeCompare(b.machineId));
      case "id_desc":
        return [...machines].sort((a, b) => b.machineId.localeCompare(a.machineId));
    }
  })();

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* ページタイトルと操作ボタン */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <LayoutGrid className="w-6 h-6 text-primary" />
            稼働状況ダッシュボード
          </h1>
          <p className="text-muted-foreground text-sm">
            全 {machines.length} 台 — 30秒ごとに自動更新
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* レイアウト切替 */}
          <Select value={layoutKey} onValueChange={(v) => setLayoutKey(v as LayoutKey)}>
            <SelectTrigger className="h-9 w-[160px] text-sm">
              <LayoutGrid className="w-3.5 h-3.5 mr-1.5 text-muted-foreground shrink-0" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="default">デフォルト</SelectItem>
              <SelectItem value="cyber">サイバー</SelectItem>
            </SelectContent>
          </Select>

          {/* ソートプルダウン */}
          <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
            <SelectTrigger className="h-9 w-[180px] text-sm">
              <ArrowUpDown className="w-3.5 h-3.5 mr-1.5 text-muted-foreground shrink-0" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rate_asc">稼働率（昇順）</SelectItem>
              <SelectItem value="rate_desc">稼働率（降順）</SelectItem>
              <SelectItem value="id_asc">機械ID（昇順）</SelectItem>
              <SelectItem value="id_desc">機械ID（降順）</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            className="h-9"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            更新
          </Button>
        </div>
      </div>

      {/* サマリー統計セクション */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        <SummaryCard
          title="稼働台数"
          value={`${runningMachines}/${totalMachines}`}
          colorClass="text-green-500"
        />
        <SummaryCard
          title="総生産数"
          value={totalProd.toLocaleString()}
        />
        <SummaryCard
          title="全体稼働率"
          value={globalOperatingRate !== "--" ? `${globalOperatingRate}%` : "--"}
          colorClass="text-green-500"
        />
        <SummaryCard
          title="稼働時間"
          value={formatDuration(totalRun)}
          colorClass="text-green-500"
        />
        <SummaryCard
          title="チョコ停"
          value={formatDuration(totalChoco)}
          colorClass="text-yellow-500"
        />
        <SummaryCard
          title="ドカ停"
          value={formatDuration(totalDoka)}
          colorClass="text-red-500"
        />
        <SummaryCard
          title="計画停止"
          value={formatDuration(totalPlan)}
          colorClass="text-blue-400"
        />
      </div>

      {/* 機械カードグリッド */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
        {sortedMachines.map((machine) =>
          layoutKey === "default" ? (
            <MachineCard
              key={machine.machineId}
              machineId={machine.machineId}
              displayName={machine.displayName}
              location={machine.location}
              currentStatus={machine.currentStatus}
              todaySummary={machine.todaySummary}
              operatingRateLowerLimit={machine.operatingRateLowerLimit}
              operatingRateUpperLimit={machine.operatingRateUpperLimit}
              onClick={() => navigate(`/machines/${machine.machineId}`)}
            />
          ) : (
            <MachineCard02
              key={machine.machineId}
              machineId={machine.machineId}
              displayName={machine.displayName}
              location={machine.location}
              currentStatus={machine.currentStatus}
              todaySummary={machine.todaySummary}
              operatingRateLowerLimit={machine.operatingRateLowerLimit}
              operatingRateUpperLimit={machine.operatingRateUpperLimit}
              onClick={() => navigate(`/machines/${machine.machineId}`)}
            />
          )
        )}
      </div>
    </div>
  );
}
