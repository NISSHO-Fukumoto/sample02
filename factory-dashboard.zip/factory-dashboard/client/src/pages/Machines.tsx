import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Edit2, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface MachineFormData {
  machineId: string;
  displayName: string;
  description: string;
  location: string;
  durChocoSec: string;
  durDokaSec: string;
}

const EMPTY_FORM: MachineFormData = {
  machineId: "",
  displayName: "",
  description: "",
  location: "",
  durChocoSec: "",
  durDokaSec: "",
};

export default function Machines() {
  const utils = trpc.useUtils();
  const { data: machines, isLoading } = trpc.machines.list.useQuery();
  const createMutation = trpc.machines.create.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      utils.dashboard.overview.invalidate();
      toast.success("機械を登録しました");
      setDialogOpen(false);
    },
    onError: err => toast.error(err.message),
  });
  const updateMutation = trpc.machines.update.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      utils.dashboard.overview.invalidate();
      toast.success("機械情報を更新しました");
      setDialogOpen(false);
    },
    onError: err => toast.error(err.message),
  });
  const deleteMutation = trpc.machines.delete.useMutation({
    onSuccess: () => {
      utils.machines.list.invalidate();
      utils.dashboard.overview.invalidate();
      toast.success("機械を削除しました");
    },
    onError: err => toast.error(err.message),
  });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<MachineFormData>(EMPTY_FORM);

  const openCreate = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  };

  const openEdit = (m: {
    id: number;
    machineId: string;
    displayName: string;
    description?: string | null;
    location?: string | null;
    durChocoSec?: number | null;
    durDokaSec?: number | null;
  }) => {
    setEditingId(m.id);
    setForm({
      machineId: m.machineId,
      displayName: m.displayName,
      description: m.description ?? "",
      location: m.location ?? "",
      durChocoSec: m.durChocoSec != null ? String(m.durChocoSec) : "",
      durDokaSec: m.durDokaSec != null ? String(m.durDokaSec) : "",
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      machineId: form.machineId,
      displayName: form.displayName,
      description: form.description || null,
      location: form.location || null,
      durChocoSec: form.durChocoSec ? parseInt(form.durChocoSec) : undefined,
      durDokaSec: form.durDokaSec ? parseInt(form.durDokaSec) : undefined,
    };
    if (editingId != null) {
      updateMutation.mutate({ id: editingId, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (id: number, name: string) => {
    if (!confirm(`「${name}」を削除しますか？`)) return;
    deleteMutation.mutate({ id });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground">機械マスター管理</h1>
          <p className="text-sm text-muted-foreground mt-0.5">機械の登録・編集・削除</p>
        </div>
        <Button onClick={openCreate} className="gap-1.5">
          <Plus className="w-4 h-4" />
          機械を追加
        </Button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">機械ID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">表示名</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">設置場所</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">チョコ停閾値</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">ドカ停閾値</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">状態</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {(machines ?? []).map(m => (
                <tr key={m.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{m.machineId}</td>
                  <td className="px-4 py-3 font-medium text-foreground">{m.displayName}</td>
                  <td className="px-4 py-3 text-muted-foreground">{m.location ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {m.durChocoSec != null ? `${m.durChocoSec}秒` : "—"}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {m.durDokaSec != null ? `${m.durDokaSec}秒` : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant="outline"
                      className={m.isActive
                        ? "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]"
                        : "border-border text-muted-foreground"}
                    >
                      {m.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 justify-end">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEdit(m)}
                        className="h-7 w-7 p-0"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(m.id, m.displayName)}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {(machines ?? []).length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    機械が登録されていません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>{editingId ? "機械情報を編集" : "機械を追加"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label>機械ID *</Label>
              <Input
                value={form.machineId}
                onChange={e => setForm(f => ({ ...f, machineId: e.target.value }))}
                placeholder="MACHINE-001"
                required
                disabled={editingId != null}
              />
            </div>
            <div className="space-y-1.5">
              <Label>表示名 *</Label>
              <Input
                value={form.displayName}
                onChange={e => setForm(f => ({ ...f, displayName: e.target.value }))}
                placeholder="第1ライン 射出成形機"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>設置場所</Label>
              <Input
                value={form.location}
                onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
                placeholder="第1工場 A棟"
              />
            </div>
            <div className="space-y-1.5">
              <Label>説明</Label>
              <Input
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="機械の説明（任意）"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>チョコ停閾値（秒）</Label>
                <Input
                  type="number"
                  value={form.durChocoSec}
                  onChange={e => setForm(f => ({ ...f, durChocoSec: e.target.value }))}
                  placeholder="300"
                  min={1}
                />
              </div>
              <div className="space-y-1.5">
                <Label>ドカ停閾値（秒）</Label>
                <Input
                  type="number"
                  value={form.durDokaSec}
                  onChange={e => setForm(f => ({ ...f, durDokaSec: e.target.value }))}
                  placeholder="1800"
                  min={1}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                キャンセル
              </Button>
              <Button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {editingId ? "更新" : "登録"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
