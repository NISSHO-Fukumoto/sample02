import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import OperationTimeline from "@/components/OperationTimeline";
import {
  calcOperatingRate,
  formatDuration,
  getCommStatus,
  getCommStatusColor,
  getCommStatusLabel,
  getStateLabel,
  getStateStyle,
} from "@/lib/machineState";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Clock,
  Package,
  Wifi,
  WifiOff,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation, useParams } from "wouter";

/**
 * DBから届くJST時刻がUTCと誤認されて+9時間ズレる問題を補正する内部関数
 */
function fixJstOffset(dateInput: Date | string | number | null | undefined): Date {
  if (!dateInput) return new Date();
  const date = new Date(dateInput);
  // 9時間分（32,400,000ミリ秒）を差し引いて表示上のズレを相殺する
  return new Date(date.getTime() - (9 * 60 * 60 * 1000));
}

export default function MachineDetail() {
  const { machineId } = useParams<{ machineId: string }>();
  const [, navigate] = useLocation();
  const [todayDate] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [todayEnd] = useState(() => {
    const d = new Date();
    d.setHours(23, 59, 59, 999);
    return d;
  });

  const { data: overview } = trpc.dashboard.overview.useQuery();
  const { data: machinesList } = trpc.machines.list.useQuery();
  // ★重要: machineId が未確定（undefined）のままクエリが発火すると、
  // サーバー側のフィルタが素通りして「全マシン合算」のデータが返って
  // しまう可能性がある。enabled で machineId 確定後にしか発火しないよう
  // 明示的にガードする。
  const { data: stopEvents } = trpc.stopEvents.list.useQuery({
    machineId,
    from: todayDate,
    to: todayEnd,
    limit: 50,
  }, { enabled: !!machineId });
  const { data: periodLogs } = trpc.reports.exportCsv.useQuery({
    machineId,
    from: todayDate,
    to: todayEnd,
  }, { enabled: !!machineId });
  const { data: periodLogsRaw } = trpc.reports.periodLogsRaw.useQuery({
    machineId,
    from: todayDate,
    to: todayEnd,
  }, { enabled: !!machineId });

  const machine = useMemo(
    () => overview?.find(m => m.machineId === machineId),
    [overview, machineId]
  );

  // machines.list（機械マスター）から、このページの overview には含まれない
  // スケジュール情報（稼働時間帯・休憩時刻）を取得する
  const machineMaster = useMemo(
    () => machinesList?.find((m: any) => m.machineId === machineId),
    [machinesList, machineId]
  );

  const todayLog = useMemo(() => {
    if (!periodLogs || periodLogs.length === 0) return null;
    return periodLogs[periodLogs.length - 1];
  }, [periodLogs]);

  if (!machine) {
    return (
      <div className="p-6">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-1" /> 戻る
        </Button>
        <p className="text-muted-foreground">機械が見つかりません: {machineId}</p>
      </div>
    );
  }

  const state = machine.currentStatus?.currentState ?? "off";
  const stopClass = machine.currentStatus?.stopClass;
  const style = getStateStyle(state, stopClass);
  
  // 通信状態判定の引数にも補正を適用
  const commStatus = getCommStatus(
    machine.currentStatus?.updatedAt ? fixJstOffset(machine.currentStatus.updatedAt) : null
  );
  
  // =========================================================================
  // ★ 修正箇所1: 計画停止を除外した稼働率計算（稼働 ÷ (稼働＋停止)）
  // =========================================================================
  const runSec = todayLog?.runningSeconds || 0;
  const stopSec = todayLog?.stoppedSeconds || 0; // ※stoppedSecondsにはチョコ・ドカの合計が入っています
  const totalSec = runSec + stopSec;
  const operatingRate = totalSec > 0 ? ((runSec / totalSec) * 100).toFixed(1) : "--";

  const openEvents = stopEvents?.filter(e => e.lifecycleState !== "closed") ?? [];
  const closedEvents = stopEvents?.filter(e => e.lifecycleState === "closed") ?? [];

  // ── グラフ用: チョコ停・ドカ停の合計秒数を stop_events から算出 ──────
  // period_logs 側の chocoSeconds/dokaSeconds は、ドカ停昇格時の遡り訂正
  // （マイナス値のインサート）による不自然な値を含みうるため、
  // 既に eventId で正しく管理されている stop_events の開始〜終了
  // （未終了なら現在時刻）から計算する。
  const stopEventTotals = useMemo(() => {
    const now = Date.now();
    let choco = 0, doka = 0;
    for (const e of stopEvents ?? []) {
      const cls = (e as any).finalStopClass ?? e.stopClass;
      const start = e.startTime ? fixJstOffset(e.startTime).getTime() : null;
      const endSource = e.endTime ?? (e.lifecycleState !== "closed" ? new Date(now) : null);
      const end = endSource ? fixJstOffset(endSource).getTime() : null;
      if (start == null || end == null || end <= start) continue;
      const sec = (end - start) / 1000;
      if (cls === "choco") choco += sec;
      else if (cls === "doka") doka += sec;
    }
    return { chocoSeconds: Math.round(choco), dokaSeconds: Math.round(doka) };
  }, [stopEvents]);

  return (
    <div className="p-6 space-y-6">
      <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="gap-1">
        <ArrowLeft className="w-4 h-4" /> ダッシュボードに戻る
      </Button>

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">{machine.displayName}</h1>
          <p className="text-sm text-muted-foreground">{machine.machineId}</p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <Badge
            variant="outline"
            className={`text-sm font-medium px-3 py-1 border ${style.badgeClass}`}
          >
            <span className={`inline-block w-2 h-2 rounded-full mr-2 ${style.dotClass}`} />
            {getStateLabel(state, stopClass)}
          </Badge>
          <div className={`flex items-center gap-1.5 text-sm ${getCommStatusColor(commStatus)}`}>
            {commStatus === "ok" ? (
              <Wifi className="w-4 h-4" />
            ) : commStatus === "delayed" ? (
              <AlertTriangle className="w-4 h-4" />
            ) : (
              <WifiOff className="w-4 h-4" />
            )}
            {getCommStatusLabel(commStatus)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">稼働率（本日）</span>
            </div>
            <p className={`text-3xl font-bold ${style.textClass}`}>
              {operatingRate != null ? `${operatingRate}%` : "--"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-[oklch(0.65_0.18_145)]" />
              <span className="text-xs text-muted-foreground">稼働時間</span>
            </div>
            <p className="text-2xl font-mono font-bold text-foreground">
              {formatDuration(todayLog?.runningSeconds)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-[oklch(0.55_0.22_25)]" />
              <span className="text-xs text-muted-foreground">停止時間</span>
            </div>
            <p className="text-2xl font-mono font-bold text-foreground">
              {formatDuration(todayLog?.stoppedSeconds)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Package className="w-4 h-4 text-[oklch(0.75_0.18_85)]" />
              <span className="text-xs text-muted-foreground">生産数</span>
            </div>
            <p className="text-2xl font-bold text-foreground">
              {todayLog?.productionCount != null
                ? todayLog.productionCount.toLocaleString()
                : "--"}
            </p>
          </CardContent>
        </Card>
      </div>

      <OperationTimeline
        title={machine.displayName}
        timeStart={machineMaster?.timeStart ?? null}
        timeEnd={machineMaster?.timeEnd ?? null}
        periodLogs={periodLogsRaw ?? []}
        stopEvents={stopEvents ?? []}
        runningSeconds={todayLog?.runningSeconds}
        chocoSeconds={stopEventTotals.chocoSeconds}
        dokaSeconds={stopEventTotals.dokaSeconds}
        plannedStopSeconds={todayLog?.plannedStopSeconds}
        operatingRate={operatingRate}
        fixOffset={fixJstOffset}
      />

      {openEvents.length > 0 && (
        <Card className="bg-card border-[oklch(0.55_0.22_25/0.3)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-[oklch(0.65_0.22_25)]" />
              進行中の停止イベント ({openEvents.length}件)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {openEvents.map(evt => (
              <div key={evt.id} className="flex items-center justify-between bg-muted/30 rounded-lg px-3 py-2 border border-[oklch(0.55_0.22_25/0.2)]">
                <div>
                  <p className="text-xs font-mono text-muted-foreground">{evt.eventId}</p>
                  <p className="text-sm text-foreground">
                    {evt.stopClass ?? "不明"} —{" "}
                    {evt.startTime ? fixJstOffset(evt.startTime).toLocaleTimeString("ja-JP") : "時刻不明"}
                  </p>
                </div>
                <Badge variant="outline" className="text-xs border-[oklch(0.55_0.22_25/0.4)] text-[oklch(0.65_0.22_25)]">
                  {evt.lifecycleState}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            本日の停止イベント（確定済み: {closedEvents.length}件）
          </CardTitle>
        </CardHeader>
        <CardContent>
          {closedEvents.length === 0 ? (
            <p className="text-sm text-muted-foreground">本日の停止イベントはありません</p>
          ) : (
            <div className="space-y-2">
              {closedEvents.map(evt => (
                <div key={evt.id} className="flex items-center justify-between bg-muted/20 rounded-lg px-3 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-mono text-muted-foreground truncate">{evt.eventId}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-sm text-foreground">{evt.finalStopClass ?? evt.stopClass ?? "不明"}</span>
                      {evt.finalStopDurationSec != null && (
                        <span className="text-xs text-muted-foreground">{formatDuration(evt.finalStopDurationSec)}</span>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground text-right ml-2">
                    {evt.startTime && fixJstOffset(evt.startTime).toLocaleTimeString("ja-JP")}
                    {evt.endTime && ` ~ ${fixJstOffset(evt.endTime).toLocaleTimeString("ja-JP")}`}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {machine.currentStatus?.updatedAt && (
        <p className="text-xs text-muted-foreground text-right">
          最終更新: {fixJstOffset(machine.currentStatus.updatedAt).toLocaleString("ja-JP")}
        </p>
      )}
    </div>
  );
}