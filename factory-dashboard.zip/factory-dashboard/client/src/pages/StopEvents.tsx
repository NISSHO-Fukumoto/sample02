import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDuration, getStateStyle } from "@/lib/machineState";
import { trpc } from "@/lib/trpc";
import { AlertTriangle, ChevronDown, ChevronUp, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function StopEvents() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [stateFilter, setStateFilter] = useState<string>("all");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [noteEdit, setNoteEdit] = useState<{ id: number; value: string } | null>(null);

  const { data: events, isLoading } = trpc.stopEvents.list.useQuery({ limit: 100 });
  const { data: reasons } = trpc.stopEvents.listReasons.useQuery();

  const updateMetaMutation = trpc.stopEvents.updateMeta.useMutation({
    onSuccess: () => {
      utils.stopEvents.list.invalidate();
      toast.success("更新しました");
      setNoteEdit(null);
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const filtered = (events ?? []).filter(e => {
    if (search && !e.machineId.includes(search) && !e.eventId.includes(search)) return false;
    if (stateFilter !== "all" && e.lifecycleState !== stateFilter) return false;
    return true;
  });

  const getLifecycleBadge = (state: string) => {
    if (state === "closed") return "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]";
    if (state === "open") return "border-[oklch(0.55_0.22_25/0.4)] text-[oklch(0.65_0.22_25)]";
    return "border-[oklch(0.75_0.18_85/0.4)] text-[oklch(0.80_0.18_85)]";
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-[oklch(0.65_0.22_25)]" />
          停止イベント管理
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">eventId 単位で停止イベントを管理します</p>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="機械ID / イベントID で検索"
            className="pl-9"
          />
        </div>
        <Select value={stateFilter} onValueChange={setStateFilter}>
          <SelectTrigger className="w-36">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value="open">進行中</SelectItem>
            <SelectItem value="updating">更新中</SelectItem>
            <SelectItem value="closed">確定済み</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">イベントID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">機械ID</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">種別</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">開始時刻</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">停止時間</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">理由</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">状態</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {filtered.map(evt => {
                const stopStyle = getStateStyle(evt.finalStopClass ?? evt.stopClass ?? "off");
                const isExpanded = expandedId === evt.id;
                return (
                  <>
                    <tr
                      key={evt.id}
                      className="border-b border-border/50 hover:bg-muted/20 transition-colors"
                    >
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                        {evt.eventId}
                      </td>
                      <td className="px-4 py-3 text-foreground">{evt.machineId}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={`text-xs ${stopStyle.badgeClass}`}>
                          {evt.finalStopClass ?? evt.stopClass ?? "不明"}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground text-xs">
                        {evt.startTime ? new Date(evt.startTime).toLocaleString("ja-JP") : "—"}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-foreground">
                        {formatDuration(evt.finalStopDurationSec)}
                      </td>
                      <td className="px-4 py-3">
                        <Select
                          value={evt.reasonCode ?? "none"}
                          onValueChange={val =>
                            updateMetaMutation.mutate({
                              id: evt.id,
                              reasonCode: val === "none" ? null : val,
                            })
                          }
                        >
                          <SelectTrigger className="h-7 text-xs w-32">
                            <SelectValue placeholder="未設定" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">未設定</SelectItem>
                            {(reasons ?? []).map(r => (
                              <SelectItem key={r.id} value={r.reasonCode}>
                                {r.displayName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant="outline"
                          className={`text-xs ${getLifecycleBadge(evt.lifecycleState)}`}
                        >
                          {evt.lifecycleState}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0"
                          onClick={() => setExpandedId(isExpanded ? null : evt.id)}
                        >
                          {isExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </Button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr key={`${evt.id}-detail`} className="bg-muted/10">
                        <td colSpan={8} className="px-6 py-4">
                          <div className="space-y-3">
                            <div className="grid grid-cols-3 gap-4 text-xs">
                              <div>
                                <p className="text-muted-foreground mb-1">終了時刻</p>
                                <p className="text-foreground">
                                  {evt.endTime ? new Date(evt.endTime).toLocaleString("ja-JP") : "—"}
                                </p>
                              </div>
                              <div>
                                <p className="text-muted-foreground mb-1">経過秒数</p>
                                <p className="text-foreground font-mono">
                                  {evt.finalStopDurationSec != null ? `${evt.finalStopDurationSec}秒` : "—"}
                                </p>
                              </div>
                              <div>
                                <p className="text-muted-foreground mb-1">クローズ理由</p>
                                <p className="text-foreground">{evt.closeReason ?? "—"}</p>
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground mb-1">ノート</p>
                              {noteEdit?.id === evt.id ? (
                                <div className="flex gap-2">
                                  <Input
                                    value={noteEdit.value}
                                    onChange={e => setNoteEdit({ id: evt.id, value: e.target.value })}
                                    className="text-xs h-8"
                                    placeholder="停止の詳細メモ..."
                                  />
                                  <Button
                                    size="sm"
                                    className="h-8"
                                    onClick={() =>
                                      updateMetaMutation.mutate({ id: evt.id, operatorNote: noteEdit.value })
                                    }
                                    disabled={updateMetaMutation.isPending}
                                  >
                                    保存
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-8"
                                    onClick={() => setNoteEdit(null)}
                                  >
                                    キャンセル
                                  </Button>
                                </div>
                              ) : (
                                <div
                                  className="text-xs text-foreground bg-muted/30 rounded px-3 py-2 cursor-pointer hover:bg-muted/50 transition-colors"
                                  onClick={() => setNoteEdit({ id: evt.id, value: evt.operatorNote ?? "" })}
                                >
                                  {evt.operatorNote ?? (
                                    <span className="text-muted-foreground">クリックしてメモを追加...</span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    停止イベントがありません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
