import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, Tag, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function StopReasons() {
  const utils = trpc.useUtils();
  const { data: reasons, isLoading } = trpc.stopReasons.list.useQuery();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ reasonCode: "", displayName: "", stopClass: "choco" as "choco" | "doka" | "planned_stop" | "other" });

  const createMutation = trpc.stopReasons.create.useMutation({
    onSuccess: () => {
      utils.stopReasons.list.invalidate();
      setDialogOpen(false);
      setForm({ reasonCode: "", displayName: "", stopClass: "choco" });
      toast.success("停止理由を追加しました");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const deactivateMutation = trpc.stopReasons.update.useMutation({
    onSuccess: () => {
      utils.stopReasons.list.invalidate();
      toast.success("停止理由を無効化しました");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(form);
  };

  const stopClassColors: Record<string, string> = {
    choco: "border-[oklch(0.75_0.18_85/0.4)] text-[oklch(0.80_0.18_85)]",
    doka: "border-[oklch(0.55_0.22_25/0.4)] text-[oklch(0.65_0.22_25)]",
    planned_stop: "border-[oklch(0.55_0.18_220/0.4)] text-[oklch(0.65_0.18_220)]",
    other: "border-border text-muted-foreground",
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Tag className="w-5 h-5 text-primary" />
            停止理由マスター
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">停止イベントに付与する理由タグの管理</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5">
          <Plus className="w-4 h-4" />
          理由を追加
        </Button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">理由コード</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">表示名</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">停止種別</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">状態</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {(reasons ?? []).map(r => (
                <tr key={r.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{r.reasonCode}</td>
                  <td className="px-4 py-3 font-medium text-foreground">{r.displayName}</td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${stopClassColors[r.stopClass ?? "other"] ?? stopClassColors.other}`}>
                      {r.stopClass ?? "other"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant="outline"
                      className={r.isActive
                        ? "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]"
                        : "border-border text-muted-foreground"}
                    >
                      {r.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    {r.isActive && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (!confirm(`「${r.displayName}」を無効化しますか？`)) return;
                          deactivateMutation.mutate({ id: r.id });
                        }}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {(reasons ?? []).length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    停止理由がありません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>停止理由を追加</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="space-y-1.5">
              <Label>理由コード *</Label>
              <Input
                value={form.reasonCode}
                onChange={e => setForm(f => ({ ...f, reasonCode: e.target.value }))}
                placeholder="MATERIAL_SHORTAGE"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>表示名 *</Label>
              <Input
                value={form.displayName}
                onChange={e => setForm(f => ({ ...f, displayName: e.target.value }))}
                placeholder="材料切れ"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>停止種別</Label>
              <Select
                value={form.stopClass}
                onValueChange={v => setForm(f => ({ ...f, stopClass: v as typeof form.stopClass }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="choco">choco（チョコ停）</SelectItem>
                  <SelectItem value="doka">doka（ドカ停）</SelectItem>
                  <SelectItem value="planned_stop">planned_stop（計画停止）</SelectItem>
                  <SelectItem value="other">other（その他）</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                キャンセル
              </Button>
              <Button type="submit" disabled={createMutation.isPending}>
                追加
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
