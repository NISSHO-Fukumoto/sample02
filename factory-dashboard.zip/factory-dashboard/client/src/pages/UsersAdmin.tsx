import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Plus, Shield, Trash2, UserCog } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function UsersAdmin() {
  const utils = trpc.useUtils();
  const { data: users, isLoading } = trpc.usersAdmin.list.useQuery();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ username: "", password: "", role: "operator" as "admin" | "operator" | "viewer" });

  const createMutation = trpc.usersAdmin.create.useMutation({
    onSuccess: () => {
      utils.usersAdmin.list.invalidate();
      setDialogOpen(false);
      setForm({ username: "", password: "", role: "operator" });
      toast.success("ユーザーを作成しました");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const updateMutation = trpc.usersAdmin.update.useMutation({
    onSuccess: () => {
      utils.usersAdmin.list.invalidate();
      toast.success("更新しました");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(form);
  };

  const getRoleBadge = (role: string) => {
    if (role === "admin") return "border-[oklch(0.65_0.18_220/0.4)] text-[oklch(0.65_0.18_220)]";
    if (role === "operator") return "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]";
    return "border-border text-muted-foreground";
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <UserCog className="w-5 h-5 text-primary" />
            ユーザー管理
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">ユーザーアカウントとロールの管理</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5">
          <Plus className="w-4 h-4" />
          ユーザーを追加
        </Button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">ユーザー名</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">ロール</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">最終ログイン</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">状態</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {(users ?? []).map(u => (
                <tr key={u.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground flex items-center gap-2">
                    {u.role === "admin" && <Shield className="w-3.5 h-3.5 text-[oklch(0.65_0.18_220)]" />}
                    {u.username}
                  </td>
                  <td className="px-4 py-3">
                    <Select
                      value={u.role}
                      onValueChange={v =>
                        updateMutation.mutate({ id: u.id, role: v as "admin" | "operator" | "viewer" })
                      }
                    >
                      <SelectTrigger className="h-7 text-xs w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">admin</SelectItem>
                        <SelectItem value="operator">operator</SelectItem>
                        <SelectItem value="viewer">viewer</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">
                    {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString("ja-JP") : "未ログイン"}
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant="outline"
                      className={u.isActive
                        ? "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]"
                        : "border-border text-muted-foreground"}
                    >
                      {u.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    {u.isActive && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (!confirm(`「${u.username}」を無効化しますか？`)) return;
                          updateMutation.mutate({ id: u.id, isActive: false });
                        }}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {(users ?? []).length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    ユーザーがいません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>ユーザーを追加</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="space-y-1.5">
              <Label>ユーザー名 *</Label>
              <Input
                value={form.username}
                onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                placeholder="username"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>パスワード *</Label>
              <Input
                type="password"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder="8文字以上"
                required
                minLength={8}
              />
            </div>
            <div className="space-y-1.5">
              <Label>ロール</Label>
              <Select
                value={form.role}
                onValueChange={v => setForm(f => ({ ...f, role: v as "admin" | "operator" | "viewer" }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">admin（管理者）</SelectItem>
                  <SelectItem value="operator">operator（オペレーター）</SelectItem>
                  <SelectItem value="viewer">viewer（閲覧のみ）</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                キャンセル
              </Button>
              <Button type="submit" disabled={createMutation.isPending}>
                作成
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
