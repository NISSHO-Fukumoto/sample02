import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Settings, Save, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function SystemSettings() {
  const [lowerLimit, setLowerLimit] = useState<number>(30);
  const [upperLimit, setUpperLimit] = useState<number>(80);

  // 現在の設定を取得
  const { data: settings, isLoading } = trpc.reports.getSettings.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (settings) {
      setLowerLimit(settings.lowerLimit);
      setUpperLimit(settings.upperLimit);
    }
  }, [settings]);

  const utils = trpc.useUtils();
  
  // 設定を保存する処理
  const mutation = trpc.reports.updateSettings.useMutation({
    onSuccess: () => {
      utils.reports.getSettings.invalidate();
      toast.success("システム設定を保存しました。");
    },
    onError: (err) => {
      toast.error(`保存に失敗しました: ${err.message}`);
    }
  });

  const handleSave = () => {
    mutation.mutate({ lowerLimit, upperLimit });
  };

  if (isLoading) {
    return <div className="p-6 flex items-center gap-2"><Loader2 className="animate-spin" />読み込み中...</div>;
  }

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-bold">システム設定</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>稼働率のカラー閾値設定</CardTitle>
          <CardDescription>
            レポートやダッシュボードのグラフ・文字色を判定するための基準値を設定します。
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2 border-b border-border/50 pb-6">
            <Label className="text-base font-semibold" style={{ color: "oklch(0.55 0.22 25)" }}>下限 (これ以下で赤色)</Label>
            <div className="flex items-center gap-2">
              <Input 
                type="number" 
                value={lowerLimit} 
                onChange={(e) => setLowerLimit(Number(e.target.value))}
                className="w-32 font-mono text-lg"
              />
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">例: 30を指定した場合、稼働率30%以下は赤色で警告表示されます。</p>
          </div>

          <div className="space-y-2 pb-2">
            <Label className="text-base font-semibold" style={{ color: "oklch(0.65 0.18 145)" }}>上限 (これ以上で緑色)</Label>
            <div className="flex items-center gap-2">
              <Input 
                type="number" 
                value={upperLimit} 
                onChange={(e) => setUpperLimit(Number(e.target.value))}
                className="w-32 font-mono text-lg"
              />
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-muted-foreground mt-2">例: 80を指定した場合、稼働率80%以上は緑色で良好表示されます。<br/>※下限と上限の間は「黄色」になります。</p>
          </div>

          <div className="pt-4 flex justify-end">
            <Button onClick={handleSave} disabled={mutation.isPending} className="gap-2">
              {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              設定を保存
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
