import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Settings, Save, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

type MachineThreshold = {
  id: number;
  lower: string;
  upper: string;
};

export default function SystemSettings() {
  const utils = trpc.useUtils();
  const { data: machines, isLoading } = trpc.machines.list.useQuery();

  // 全機械の閾値を一つの state で管理: { [id]: { lower, upper } }
  const [thresholds, setThresholds] = useState<Record<number, MachineThreshold>>({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (machines) {
      const init: Record<number, MachineThreshold> = {};
      machines.forEach((m) => {
        init[m.id] = {
          id: m.id,
          lower: m.operatingRateLowerLimit != null ? String(m.operatingRateLowerLimit) : "",
          upper: m.operatingRateUpperLimit != null ? String(m.operatingRateUpperLimit) : "",
        };
      });
      setThresholds(init);
    }
  }, [machines]);

  const updateMachine = trpc.machines.update.useMutation();

  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      await Promise.all(
        Object.values(thresholds).map((t) =>
          updateMachine.mutateAsync({
            id: t.id,
            operatingRateLowerLimit: t.lower !== "" ? Number(t.lower) : null,
            operatingRateUpperLimit: t.upper !== "" ? Number(t.upper) : null,
          })
        )
      );
      await utils.machines.list.invalidate();
      toast.success("閾値を保存しました");
    } catch (err: any) {
      toast.error(`保存に失敗しました: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const setField = (id: number, field: "lower" | "upper", value: string) => {
    setThresholds((prev) => ({
      ...prev,
      [id]: { ...prev[id], [field]: value },
    }));
  };

  if (isLoading) {
    return (
      <div className="p-6 flex items-center gap-2">
        <Loader2 className="animate-spin" />読み込み中...
      </div>
    );
  }

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      {/* ヘッダー */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Settings className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold">システム設定</h1>
        </div>
        <Button onClick={handleSaveAll} disabled={isSaving} className="gap-2">
          {isSaving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          保存
        </Button>
      </div>

      {/* 機械別閾値テーブル */}
      <Card>
        <CardHeader>
          <CardTitle>稼働率カラー閾値（機械別）</CardTitle>
          <CardDescription>
            機械ごとに稼働率の色分け基準を設定します。空欄の場合はデフォルト値（下限30% / 上限80%）が使用されます。
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!machines || machines.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              登録されている機械がありません
            </p>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {[machines.slice(0, 10), machines.slice(10, 20)].map((group, gi) =>
                group.length === 0 ? null : (
                  <Card key={gi} className="bg-muted/20">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <CardTitle className="text-sm text-muted-foreground font-medium">
                        {gi === 0 ? `1〜${group.length}台目` : `11〜${10 + group.length}台目`}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-4 pb-4">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border text-muted-foreground">
                            <th className="text-left pb-2 pr-3 font-medium">機械</th>
                            <th className="text-left pb-2 pr-2 font-medium" style={{ color: "oklch(0.55 0.22 25)" }}>
                              下限（赤）
                            </th>
                            <th className="text-left pb-2 font-medium" style={{ color: "oklch(0.65 0.18 145)" }}>
                              上限（緑）
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {group.map((machine) => {
                            const t = thresholds[machine.id];
                            if (!t) return null;
                            return (
                              <tr key={machine.id} className="border-b border-border/40 last:border-0">
                                <td className="py-2 pr-3">
                                  <div className="font-medium text-sm">{machine.displayName}</div>
                                  <div className="text-xs text-muted-foreground">{machine.machineId}</div>
                                </td>
                                <td className="py-2 pr-2">
                                  <div className="flex items-center gap-1">
                                    <Input
                                      type="number"
                                      placeholder="30"
                                      value={t.lower}
                                      onChange={(e) => setField(machine.id, "lower", e.target.value)}
                                      className="w-16 h-7 font-mono text-sm px-2"
                                      min={0}
                                      max={100}
                                    />
                                    <span className="text-muted-foreground text-xs">%</span>
                                  </div>
                                </td>
                                <td className="py-2">
                                  <div className="flex items-center gap-1">
                                    <Input
                                      type="number"
                                      placeholder="80"
                                      value={t.upper}
                                      onChange={(e) => setField(machine.id, "upper", e.target.value)}
                                      className="w-16 h-7 font-mono text-sm px-2"
                                      min={0}
                                      max={100}
                                    />
                                    <span className="text-muted-foreground text-xs">%</span>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </CardContent>
                  </Card>
                )
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
