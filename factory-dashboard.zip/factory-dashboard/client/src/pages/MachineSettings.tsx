import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Save, Settings2, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export default function MachineSettings() {
  const utils = trpc.useUtils();
  
  const { data: machines, isLoading } = trpc.machines.list.useQuery();
  const [drafts, setDrafts] = useState<Record<number, { lower: string; upper: string }>>({});

  useEffect(() => {
    if (machines) {
      const initialDrafts: Record<number, { lower: string; upper: string }> = {};
      machines.forEach((m: any) => {
        initialDrafts[m.id] = {
          lower: m.operatingRateLowerLimit != null ? String(m.operatingRateLowerLimit) : "",
          upper: m.operatingRateUpperLimit != null ? String(m.operatingRateUpperLimit) : "",
        };
      });
      setDrafts(initialDrafts);
    }
  }, [machines]);

  const updateMachineMutation = trpc.machines.update.useMutation({
    onSuccess: (_, variables) => {
      utils.machines.list.invalidate();
      utils.dashboard.overview.invalidate();
      const targetMachine = machines?.find(m => m.id === variables.id);
      toast.success(`${targetMachine?.displayName || '設備'} の設定を保存しました`);
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleInputChange = (id: number, field: "lower" | "upper", value: string) => {
    setDrafts(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value,
      }
    }));
  };

  const handleSave = (id: number) => {
    const draft = drafts[id];
    if (!draft) return;

    const lowerVal = draft.lower === "" ? null : Number(draft.lower);
    const upperVal = draft.upper === "" ? null : Number(draft.upper);

    updateMachineMutation.mutate({
      id,
      operatingRateLowerLimit: lowerVal,
      operatingRateUpperLimit: upperVal,
    });
  };

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-[1200px] mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-primary/10 rounded-lg">
          <Settings2 className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-foreground">設備別 稼働率設定</h1>
          <p className="text-sm text-muted-foreground mt-1">
            設備ごとにグラフやバッジの色が変わる基準値（閾値）を個別設定します。
          </p>
        </div>
      </div>

      <Card className="border-muted/40 shadow-sm">
        <CardHeader className="bg-muted/10 border-b pb-4">
          <CardTitle className="text-lg">個別閾値の一覧</CardTitle>
          <CardDescription className="flex items-center gap-1 mt-1">
            <AlertCircle className="w-4 h-4" />
            空欄にした項目は、システム全体のデフォルト設定が適用されます。
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-muted/30 text-muted-foreground">
                <tr>
                  <th className="px-6 py-4 font-medium w-[25%]">設備名</th>
                  <th className="px-6 py-4 font-medium w-[20%]">マシンID</th>
                  <th className="px-6 py-4 font-medium text-[oklch(0.55_0.22_25)] w-[20%]">下限 (赤色)</th>
                  <th className="px-6 py-4 font-medium text-[oklch(0.65_0.18_145)] w-[20%]">上限 (緑色)</th>
                  <th className="px-6 py-4 font-medium text-right w-[15%]">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {machines?.map((machine: any) => {
                  const draft = drafts[machine.id] || { lower: "", upper: "" };
                  const isUpdating = updateMachineMutation.isPending && updateMachineMutation.variables?.id === machine.id;

                  return (
                    <tr key={machine.id} className="hover:bg-muted/10 transition-colors">
                      <td className="px-6 py-4 font-medium text-foreground">{machine.displayName}</td>
                      <td className="px-6 py-4 text-muted-foreground font-mono text-xs">{machine.machineId}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            value={draft.lower}
                            onChange={(e) => handleInputChange(machine.id, "lower", e.target.value)}
                            placeholder="デフォルト"
                            className="w-24 h-9"
                          />
                          <span className="text-muted-foreground">% 以下</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            value={draft.upper}
                            onChange={(e) => handleInputChange(machine.id, "upper", e.target.value)}
                            placeholder="デフォルト"
                            className="w-24 h-9"
                          />
                          <span className="text-muted-foreground">% 以上</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button 
                          size="sm" 
                          onClick={() => handleSave(machine.id)}
                          disabled={isUpdating}
                          className="min-w-[80px]"
                        >
                          {isUpdating ? (
                            <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                          ) : (
                            <>
                              <Save className="w-4 h-4 mr-1.5" />
                              保存
                            </>
                          )}
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}