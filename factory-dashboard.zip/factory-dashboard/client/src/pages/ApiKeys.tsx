import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Copy, Key, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ApiKeys() {
  const utils = trpc.useUtils();
  const { data: keys, isLoading } = trpc.apiKeys.list.useQuery();
  const { data: machines } = trpc.machines.list.useQuery();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [newKeyDialog, setNewKeyDialog] = useState<{ key: string; name: string } | null>(null);
  const [form, setForm] = useState({ name: "", machineId: "" });

  const createMutation = trpc.apiKeys.create.useMutation({
    onSuccess: result => {
      utils.apiKeys.list.invalidate();
      setDialogOpen(false);
      setNewKeyDialog({ key: result.apiKey, name: form.name });
      setForm({ name: "", machineId: "" });
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const revokeMutation = trpc.apiKeys.revoke.useMutation({
    onSuccess: () => {
      utils.apiKeys.list.invalidate();
      toast.success("APIキーを無効化しました");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      name: form.name,
      machineId: form.machineId || undefined,
    });
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("クリップボードにコピーしました");
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            APIキー管理
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">ノード端末認証用APIキーの発行・管理</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5">
          <Plus className="w-4 h-4" />
          APIキーを発行
        </Button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">名称</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">APIキー（先頭8文字）</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">対象機械</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">最終使用</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">状態</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {(keys ?? []).map(k => (
                <tr key={k.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{k.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                    {k.apiKey.slice(0, 8)}...
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{k.machineId ?? "全機械"}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">
                    {k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString("ja-JP") : "未使用"}
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant="outline"
                      className={k.isActive
                        ? "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]"
                        : "border-border text-muted-foreground"}
                    >
                      {k.isActive ? "有効" : "無効"}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    {k.isActive && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          if (!confirm(`「${k.name}」のAPIキーを無効化しますか？`)) return;
                          revokeMutation.mutate({ id: k.id });
                        }}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {(keys ?? []).length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    APIキーがありません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Create dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>APIキーを発行</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="space-y-1.5">
              <Label>名称 *</Label>
              <Input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="ライン1 ノード端末"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>対象機械（省略可）</Label>
              <Select
                value={form.machineId || "all"}
                onValueChange={v => setForm(f => ({ ...f, machineId: v === "all" ? "" : v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="全機械（制限なし）" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全機械（制限なし）</SelectItem>
                  {(machines ?? []).map(m => (
                    <SelectItem key={m.machineId} value={m.machineId}>
                      {m.displayName} ({m.machineId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                キャンセル
              </Button>
              <Button type="submit" disabled={createMutation.isPending}>
                発行
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* New key display dialog */}
      <Dialog open={!!newKeyDialog} onOpenChange={() => setNewKeyDialog(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle>APIキーが発行されました</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              このAPIキーは一度しか表示されません。必ずコピーして安全な場所に保管してください。
            </p>
            <div className="bg-muted/30 rounded-lg p-3 flex items-center gap-2">
              <code className="text-sm font-mono text-foreground flex-1 break-all">
                {newKeyDialog?.key}
              </code>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleCopy(newKeyDialog?.key ?? "")}
                className="shrink-0"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Authorization: Bearer {newKeyDialog?.key}
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setNewKeyDialog(null)}>閉じる</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
