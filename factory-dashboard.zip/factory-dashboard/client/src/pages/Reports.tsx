import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { formatDuration } from "@/lib/machineState";
import { trpc } from "@/lib/trpc";
import { BarChart3, Download, RefreshCw, CalendarIcon } from "lucide-react";
import { useMemo, useState, useEffect } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
} from "recharts";
import { startOfMonth, endOfMonth, subMonths, format, startOfDay, endOfDay, addDays, startOfWeek, eachDayOfInterval } from "date-fns";
import { ja } from "date-fns/locale";

type PresetRange = "daily" | "weekly" | "this_month" | "last_month" | "all_time" | "custom";

function getOperatingRateColor(rate: number, lowerLimit: number, upperLimit: number) {
  if (rate >= upperLimit) return "oklch(0.65 0.18 145)"; 
  if (rate <= lowerLimit) return "oklch(0.55 0.22 25)";  
  return "oklch(0.75 0.18 85)"; 
}

function calcCustomOperatingRate(runSec?: number | null, stopSec?: number | null): number | null {
  const r = runSec || 0;
  const s = stopSec || 0;
  const total = r + s;
  return total > 0 ? Number(((r / total) * 100).toFixed(1)) : null;
}

function formatPeriodLabel(label: string, key: string, groupBy: string, closingDay: number = 0, isShort: boolean = false) {
  if (groupBy === "daily") {
    if (isShort) return `${parseInt(key.split("-")[1], 10)}/${parseInt(key.split("-")[2], 10)}`;
    return key.replace(/-/g, "/");
  }
  if (groupBy === "weekly") {
    const cleanKey = key.startsWith('w') ? key.substring(1) : key;
    const baseDate = new Date(cleanKey.replace(/-/g, "/") + " 12:00:00");
    if (!isNaN(baseDate.getTime())) {
      const start = startOfWeek(baseDate, { weekStartsOn: 0 }); 
      const end = addDays(start, 6);
      if (isShort) return `${start.getMonth() + 1}/${start.getDate()}〜${end.getMonth() + 1}/${end.getDate()}`;
      return `${format(start, "yyyy/MM/dd")} 〜 ${format(end, "yyyy/MM/dd")}`;
    }
  }
  if (groupBy === "monthly") {
    const [yearStr, monthStr] = key.split("-");
    const year = parseInt(yearStr, 10);
    const month = parseInt(monthStr, 10) - 1; 
    if (isShort) return `${month + 1}月度`;
    if (closingDay === 0) {
      const start = new Date(year, month, 1);
      const end = new Date(year, month + 1, 0);
      return `${format(start, "yyyy/MM/dd")} 〜 ${format(end, "yyyy/MM/dd")}`;
    } else {
      const start = new Date(year, month - 1, closingDay + 1);
      const end = new Date(year, month, closingDay);
      return `${format(start, "yyyy/MM/dd")} 〜 ${format(end, "yyyy/MM/dd")}`;
    }
  }
  return label;
}

export default function Reports() {
  const [selectedMachineId, setSelectedMachineId] = useState<string>("all");
  const [preset, setPreset] = useState<PresetRange>("this_month");
  const [groupBy, setGroupBy] = useState<"daily" | "weekly" | "monthly">("daily");
  const [closingDay, setClosingDay] = useState<number>(0);

  const [fromDate, setFromDate] = useState<Date>(startOfMonth(new Date()));
  const [toDate, setToDate] = useState<Date>(endOfMonth(new Date()));
  const [isFromOpen, setIsFromOpen] = useState(false);
  const [isToOpen, setIsToOpen] = useState(false);

  const { data: machines } = trpc.machines.list.useQuery();
  
  const { data: dbSettings } = trpc.reports.getSettings.useQuery();
  const lowerLimit = dbSettings?.operatingRateLowerLimit ?? 30;
  const upperLimit = dbSettings?.operatingRateUpperLimit ?? 80;

  useEffect(() => {
    const today = new Date();
    if (preset === "daily") {
      const prev = new Date(); prev.setDate(today.getDate() - 6);
      setFromDate(startOfDay(prev)); setToDate(endOfDay(today)); setGroupBy("daily");
    } else if (preset === "weekly") {
      const prev = new Date(); prev.setDate(today.getDate() - 27);
      setFromDate(startOfDay(prev)); setToDate(endOfDay(today)); setGroupBy("weekly");
    } else if (preset === "this_month") {
      setGroupBy("daily");
      if (closingDay === 0) {
        setFromDate(startOfMonth(today)); setToDate(endOfMonth(today));
      } else {
        if (today.getDate() > closingDay) {
          setFromDate(new Date(today.getFullYear(), today.getMonth(), closingDay + 1, 0, 0, 0));
          setToDate(new Date(today.getFullYear(), today.getMonth() + 1, closingDay, 23, 59, 59));
        } else {
          setFromDate(new Date(today.getFullYear(), today.getMonth() - 1, closingDay + 1, 0, 0, 0));
          setToDate(new Date(today.getFullYear(), today.getMonth(), closingDay, 23, 59, 59));
        }
      }
    } else if (preset === "last_month") {
      setGroupBy("daily");
      if (closingDay === 0) {
        const last = subMonths(today, 1);
        setFromDate(startOfMonth(last)); setToDate(endOfMonth(last));
      } else {
        let refDate = new Date(today);
        if (today.getDate() <= closingDay) refDate.setMonth(today.getMonth() - 1);
        setFromDate(new Date(refDate.getFullYear(), refDate.getMonth() - 1, closingDay + 1, 0, 0, 0));
        setToDate(new Date(refDate.getFullYear(), refDate.getMonth(), closingDay, 23, 59, 59));
      }
    } else if (preset === "all_time") {
      setFromDate(new Date(2020, 0, 1)); setToDate(endOfMonth(today)); setGroupBy("monthly");
    } else if (preset === "custom") {
      setGroupBy("daily");
      setFromDate(startOfMonth(today)); setToDate(endOfMonth(today));
    }
  }, [preset, closingDay]);

  const { data: rawReportData, isLoading, isFetching, refetch } = trpc.reports.aggregate.useQuery({
    machineId: selectedMachineId === "all" ? undefined : selectedMachineId,
    from: fromDate,
    to: toDate,
    groupBy: groupBy,
  });

  const reportData = useMemo(() => {
    const mergedMap = new Map<string, any>();
    const rightNow = new Date(); 

    try {
      const allDaysInRange = eachDayOfInterval({ start: fromDate, end: toDate });
      allDaysInRange.forEach(day => {
        let key = "";
        if (groupBy === "daily") key = format(day, "yyyy-MM-dd");
        else if (groupBy === "weekly") key = `w${format(startOfWeek(day, { weekStartsOn: 0 }), "yyyy-MM-dd")}`;
        else if (groupBy === "monthly") {
          let y = day.getFullYear(); let m = day.getMonth() + 1;
          if (closingDay > 0 && day.getDate() > closingDay) { m += 1; if (m > 12) { m = 1; y += 1; } }
          key = `${y}-${String(m).padStart(2, '0')}`;
        }
        if (!mergedMap.has(key)) {
          mergedMap.set(key, {
            periodKey: key, periodLabel: key,
            totalRunningSeconds: 0, totalStoppedSeconds: 0,
            totalPlannedStopSeconds: 0, totalProductionCount: 0
          });
        }
      });
    } catch (e) {
      console.warn("Invalid date range", e);
    }

    if (rawReportData) {
      rawReportData.forEach((r: any) => {
        const cleanKey = r.periodKey.startsWith('w') ? r.periodKey.substring(1) : r.periodKey;
        let dateStrForCheck = cleanKey;
        if (groupBy === "monthly") dateStrForCheck += "-01";
        
        const dataDate = new Date(dateStrForCheck.replace(/-/g, "/") + " 00:00:00");
        if (dataDate > endOfDay(rightNow)) return;

        let correctKey = r.periodKey;
        if (groupBy === "weekly") {
          const baseDate = new Date(cleanKey.replace(/-/g, "/") + " 12:00:00");
          if (!isNaN(baseDate.getTime())) correctKey = `w${format(startOfWeek(baseDate, { weekStartsOn: 0 }), "yyyy-MM-dd")}`;
        }

        const run = Number(r.totalRunningSeconds ?? r.runningSeconds ?? 0);
        const stop = Number(r.totalStoppedSeconds ?? r.stoppedSeconds ?? 0);
        const planned = Number(r.totalPlannedStopSeconds ?? r.plannedStopSeconds ?? 0);
        const prod = Number(r.totalProductionCount ?? r.productionCount ?? 0);

        const existing = mergedMap.get(correctKey);
        if (existing) {
          // 選択された枠の中にきれいに収まるデータのみを加算
          existing.totalRunningSeconds += run; 
          existing.totalStoppedSeconds += stop;
          existing.totalPlannedStopSeconds += planned; 
          existing.totalProductionCount += prod;
          if (r.periodLabel) existing.periodLabel = r.periodLabel;
        } else {
          // ⚠️【バグ根絶】指定された期間の空枠（mergedMap）に存在しない古いデータ（3月、4月など）は、
          // ここで map にセットせず、完全に無視（スルー）して強制排除します。
        }
      });
    }

    return Array.from(mergedMap.values()).sort((a, b) => a.periodKey.localeCompare(b.periodKey));
  }, [rawReportData, groupBy, fromDate, toDate, closingDay]);

  const summary = useMemo(() => {
    let totalRun = 0; let totalStop = 0;
    reportData.forEach((r: any) => {
      totalRun += Number(r.totalRunningSeconds ?? 0);
      totalStop += Number(r.totalStoppedSeconds ?? 0);
    });
    return {
      avgRate: calcCustomOperatingRate(totalRun, totalStop) ?? 0,
      totalRun, totalStop, isTodayScope: false
    };
  }, [reportData]);

  const handleExportCsv = () => {
    if (!reportData?.length) return;
    const headers = ["期間", "稼働率(%)", "稼働時間(秒)", "停止時間(秒)", "計画停止(秒)", "生産数"];
    const rows = reportData.map((r: any) => {
      const run = Number(r.totalRunningSeconds ?? r.runningSeconds ?? 0);
      const stop = Number(r.totalStoppedSeconds ?? r.stoppedSeconds ?? 0);
      const planned = Number(r.totalPlannedStopSeconds ?? r.plannedStopSeconds ?? 0);
      const prod = Number(r.totalProductionCount ?? r.productionCount ?? 0);
      return [
        formatPeriodLabel(r.periodLabel, r.periodKey, groupBy, closingDay),
        calcCustomOperatingRate(run, stop) ?? "",
        run, stop, planned, prod,
      ];
    });
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `factory-report-${format(new Date(), "yyyyMMdd")}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const chartData = useMemo(() => {
    if (!reportData) return [];
    return reportData.map((r: any) => {
      const run = Number(r.totalRunningSeconds ?? r.runningSeconds ?? 0);
      const stop = Number(r.totalStoppedSeconds ?? r.stoppedSeconds ?? 0);
      return {
        label: formatPeriodLabel(r.periodLabel, r.periodKey, groupBy, closingDay, true),
        fullLabel: formatPeriodLabel(r.periodLabel, r.periodKey, groupBy, closingDay, false),
        稼働率: calcCustomOperatingRate(run, stop) ?? 0,
        稼働時間: Math.round(run / 3600 * 10) / 10,
        停止時間: Math.round(stop / 3600 * 10) / 10,
      };
    });
  }, [reportData, groupBy, closingDay]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            集計・レポート
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">稼働データの可視化とCSV出力</p>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isFetching} className="gap-1.5">
            <RefreshCw className={cn("w-3.5 h-3.5", isFetching && "animate-spin")} />
            {isFetching ? "更新中..." : "更新"}
          </Button>
          <Button size="sm" onClick={handleExportCsv} disabled={!reportData?.length} className="gap-1.5">
            <Download className="w-3.5 h-3.5" />CSV出力
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 bg-muted/20 p-3 rounded-lg border border-border">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground font-medium ml-1">表示:</span>
          <Select value={preset} onValueChange={v => setPreset(v as PresetRange)}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">日次</SelectItem>
              <SelectItem value="weekly">週次</SelectItem>
              <SelectItem value="this_month">今月</SelectItem>
              <SelectItem value="last_month">先月</SelectItem>
              <SelectItem value="all_time">全期間</SelectItem>
              <SelectItem value="custom">カスタム</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {(preset === "this_month" || preset === "last_month" || preset === "all_time") && (
          <div className="flex items-center gap-2 animate-in fade-in zoom-in-95">
            <span className="text-sm text-muted-foreground font-medium">締め日:</span>
            <Select value={closingDay.toString()} onValueChange={v => setClosingDay(parseInt(v))}>
              <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">月末</SelectItem>
                <SelectItem value="20">20日</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground font-medium">対象:</span>
          <Select value={selectedMachineId} onValueChange={setSelectedMachineId}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全機械</SelectItem>
              {(machines ?? []).map(m => (
                <SelectItem key={m.machineId} value={m.machineId}>{m.displayName}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {preset === "custom" && (
          <div className="flex items-center gap-2 animate-in fade-in slide-in-from-left-2 ml-auto">
            <Popover open={isFromOpen} onOpenChange={setIsFromOpen}>
              <PopoverTrigger asChild>
                <Button variant={"outline"} className="w-[130px] h-9 text-xs justify-start px-2 bg-background font-normal">
                  <CalendarIcon className="mr-2 h-3 w-3" />
                  {fromDate ? format(fromDate, "yyyy/MM/dd") : "開始日"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar mode="single" selected={fromDate} onSelect={d => { if(d){ setFromDate(startOfDay(d)); setIsFromOpen(false); }}} locale={ja} />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground">〜</span>
            <Popover open={isToOpen} onOpenChange={setIsToOpen}>
              <PopoverTrigger asChild>
                <Button variant={"outline"} className="w-[130px] h-9 text-xs justify-start px-2 bg-background font-normal">
                  <CalendarIcon className="mr-2 h-3 w-3" />
                  {toDate ? format(toDate, "yyyy/MM/dd") : "終了日"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar mode="single" selected={toDate} onSelect={d => { if(d){ setToDate(endOfDay(d)); setIsToOpen(false); }}} locale={ja} />
              </PopoverContent>
            </Popover>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64 text-muted-foreground">読み込み中...</div>
      ) : (
        <>
          {reportData?.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground space-y-2 border border-dashed border-border rounded-xl">
              <BarChart3 className="w-8 h-8 opacity-20" />
              <p>指定された期間のデータはありません</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      期間平均稼働率
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div 
                      className="text-2xl font-bold transition-colors duration-300" 
                      style={{ color: getOperatingRateColor(summary.avgRate, lowerLimit, upperLimit) }}
                    >
                      {summary.avgRate}%
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      合計稼働時間
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatDuration(summary.totalRun)}</div>
                  </CardContent>
                </Card>
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      合計停止時間
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatDuration(summary.totalStop)}</div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">稼働率推移 (%)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" />
                        <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                        <Tooltip 
                          cursor={{fill: 'rgba(255,255,255,0.05)'}} 
                          contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #374151", borderRadius: "8px", fontSize: "12px", color: "#f3f4f6" }}
                          itemStyle={{ color: "#f3f4f6" }}
                          labelFormatter={(label, payload) => payload?.[0]?.payload?.fullLabel || label}
                        />
                        <Bar dataKey="稼働率" radius={[4, 4, 0, 0]} animationDuration={300}>
                          {chartData.map((entry: any, index: number) => (
                            <Cell 
                              key={`cell-${index}`} 
                              fill={getOperatingRateColor(entry.稼働率, lowerLimit, upperLimit)} 
                              style={{ transition: 'fill 0.3s ease' }}
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">稼働 vs 停止 (時間)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" />
                        <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                        <Tooltip 
                          cursor={{fill: 'rgba(255,255,255,0.05)'}} 
                          contentStyle={{ backgroundColor: "#1f2937", border: "1px solid #374151", borderRadius: "8px", fontSize: "12px", color: "#f3f4f6" }}
                          itemStyle={{ color: "#f3f4f6" }}
                          labelFormatter={(label, payload) => payload?.[0]?.payload?.fullLabel || label}
                        />
                        <Bar dataKey="稼働時間" fill="oklch(0.65 0.18 145)" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="停止時間" fill="oklch(0.55 0.22 25)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-card border rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50 border-b">
                      <th className="text-left p-4 font-medium text-muted-foreground">期間</th>
                      <th className="text-right p-4 font-medium text-muted-foreground">稼働率</th>
                      <th className="text-right p-4 font-medium text-muted-foreground">稼働時間</th>
                      <th className="text-right p-4 font-medium text-muted-foreground">停止時間</th>
                      <th className="text-right p-4 font-medium text-muted-foreground">計画停止</th>
                      <th className="text-right p-4 font-medium text-muted-foreground">生産数</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y border-border">
                    {reportData.map((r: any, i: number) => {
                      const run = Number(r.totalRunningSeconds ?? r.runningSeconds ?? 0);
                      const stop = Number(r.totalStoppedSeconds ?? r.stoppedSeconds ?? 0);
                      const planned = Number(r.totalPlannedStopSeconds ?? r.plannedStopSeconds ?? 0);
                      const prod = Number(r.totalProductionCount ?? r.productionCount ?? 0);
                      const rate = calcCustomOperatingRate(run, stop);
                      
                      return (
                        <tr key={i} className="hover:bg-muted/30 transition-colors">
                          <td className="p-4 text-foreground">{formatPeriodLabel(r.periodLabel, r.periodKey, groupBy, closingDay)}</td>
                          <td 
                            className="p-4 text-right font-bold transition-colors duration-300" 
                            style={{ color: rate != null ? getOperatingRateColor(rate, lowerLimit, upperLimit) : "inherit" }}
                          >
                            {rate != null ? `${rate}%` : "—"}
                          </td>
                          <td className="p-4 text-right font-bold text-foreground">{formatDuration(run)}</td>
                          <td className="p-4 text-right font-bold text-foreground">{formatDuration(stop)}</td>
                          <td className="p-4 text-right font-bold text-foreground">{formatDuration(planned)}</td>
                          <td className="p-4 text-right text-foreground">{prod.toLocaleString() || "0"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
