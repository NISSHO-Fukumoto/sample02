import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDuration } from "@/lib/machineState";
import { trpc } from "@/lib/trpc";
import { BarChart3, Download, RefreshCw } from "lucide-react";
import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type Period = "daily" | "weekly" | "monthly";

// =========================================================================
// ★ 新規追加: 計画停止を除外した稼働率を計算する専用関数（稼働 ÷ (稼働＋停止)）
// =========================================================================
function calcCustomOperatingRate(runSec?: number | null, stopSec?: number | null): number | null {
  const r = runSec || 0;
  const s = stopSec || 0;
  const total = r + s;
  return total > 0 ? Number(((r / total) * 100).toFixed(1)) : null;
}

export default function Reports() {
  const [period, setPeriod] = useState<Period>("daily");
  const [selectedMachineId, setSelectedMachineId] = useState<string>("all");

  const { data: machines } = trpc.machines.list.useQuery();

  const now = useMemo(() => new Date(), []);
  const dateRange = useMemo(() => {
    const to = new Date(now);
    const from = new Date(now);
    if (period === "daily") {
      from.setDate(from.getDate() - 7);
    } else if (period === "weekly") {
      from.setDate(from.getDate() - 28);
    } else {
      from.setMonth(from.getMonth() - 6);
    }
    return { from, to };
  }, [period, now]);

  const { data: reportData, isLoading, refetch } = trpc.reports.aggregate.useQuery({
    machineId: selectedMachineId === "all" ? undefined : selectedMachineId,
    from: dateRange.from,
    to: dateRange.to,
    groupBy: period,
  });

  const { data: csvData } = trpc.reports.exportCsv.useQuery({
    machineId: selectedMachineId === "all" ? undefined : selectedMachineId,
    from: dateRange.from,
    to: dateRange.to,
  });

  const handleExportCsv = () => {
    if (!csvData || (csvData as unknown[]).length === 0) return;
    const headers = [
      "機械ID",
      "期間開始",
      "期間終了",
      "稼働秒数",
      "停止秒数",
      "計画停止秒数",
      "アイドル秒数",
      "稼働率(%)",
      "生産数",
      "目標生産数",
    ];
    const rows = (csvData as Array<{
      machineId: string;
      periodStart: Date | string;
      periodEnd: Date | string;
      runningSeconds?: number | null;
      stoppedSeconds?: number | null;
      plannedStopSeconds?: number | null;
      idleSeconds?: number | null;
      productionCount?: number | null;
      targetProductionCount?: number | null;
    }>).map(r => [
      r.machineId,
      new Date(r.periodStart).toLocaleString("ja-JP"),
      new Date(r.periodEnd).toLocaleString("ja-JP"),
      r.runningSeconds ?? "",
      r.stoppedSeconds ?? "",
      r.plannedStopSeconds ?? "",
      r.idleSeconds ?? "",
      // ★ CSV出力時も新しい計算式を適用
      calcCustomOperatingRate(r.runningSeconds, r.stoppedSeconds) ?? "",
      r.productionCount ?? "",
      r.targetProductionCount ?? "",
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `factory-report-${period}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Chart data
  const chartData = useMemo(() => {
    if (!reportData) return [];
    return reportData.map(r => ({
      label: r.periodLabel,
      // ★ グラフ表示時も新しい計算式で上書き
      稼働率: calcCustomOperatingRate(r.totalRunningSeconds, r.totalStoppedSeconds) ?? 0,
      稼働時間: Math.round((r.totalRunningSeconds ?? 0) / 3600 * 10) / 10,
      停止時間: Math.round((r.totalStoppedSeconds ?? 0) / 3600 * 10) / 10,
    }));
  }, [reportData]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            集計・レポート
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">稼働率・停止時間の集計とCSV出力</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => refetch()}
            className="gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            更新
          </Button>
          <Button
            size="sm"
            onClick={handleExportCsv}
            disabled={!csvData || csvData.length === 0}
            className="gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            CSV出力
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={period} onValueChange={v => setPeriod(v as Period)}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="daily">日次</SelectItem>
            <SelectItem value="weekly">週次</SelectItem>
            <SelectItem value="monthly">月次</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedMachineId} onValueChange={setSelectedMachineId}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全機械</SelectItem>
            {(machines ?? []).map(m => (
              <SelectItem key={m.machineId} value={m.machineId}>
                {m.displayName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Charts */}
      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Operating rate chart */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">稼働率推移 (%)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 240)" />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 10, fill: "oklch(0.55 0.01 240)" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fontSize: 10, fill: "oklch(0.55 0.01 240)" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.14 0.01 240)",
                      border: "1px solid oklch(0.22 0.01 240)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                    formatter={(v: number) => [`${v}%`, "稼働率"]}
                  />
                  <Bar dataKey="稼働率" fill="oklch(0.65 0.18 145)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Running vs stopped time chart */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">稼働時間 vs 停止時間 (時間)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.01 240)" />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 10, fill: "oklch(0.55 0.01 240)" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 10, fill: "oklch(0.55 0.01 240)" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.14 0.01 240)",
                      border: "1px solid oklch(0.22 0.01 240)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                    formatter={(v: number) => [`${v}h`, ""]}
                  />
                  <Bar dataKey="稼働時間" fill="oklch(0.65 0.18 145)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="停止時間" fill="oklch(0.55 0.22 25)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Data table */}
      {reportData && (reportData as unknown[]).length > 0 && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">期間</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">稼働率</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">稼働時間</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">停止時間</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">計画停止</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground">生産数</th>
              </tr>
            </thead>
            <tbody>
              {(reportData as Array<{
                periodLabel: string;
                periodKey: string;
                totalRunningSeconds: number;
                totalStoppedSeconds: number;
                totalPlannedStopSeconds: number;
                totalProductionCount: number;
                operatingRate: number | null;
              }>).map((r, i) => {
                // ★ 表の表示用にも新しい計算式を適用
                const rate = calcCustomOperatingRate(r.totalRunningSeconds, r.totalStoppedSeconds);
                
                return (
                  <tr key={i} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3 text-foreground">{r.periodLabel}</td>
                    <td className="px-4 py-3 text-right">
                      <span
                        className="font-semibold"
                        style={{
                          color: (rate ?? 0) >= 80
                            ? "oklch(0.65 0.18 145)"
                            : (rate ?? 0) >= 60
                            ? "oklch(0.75 0.18 85)"
                            : "oklch(0.55 0.22 25)",
                        }}
                      >
                        {rate != null ? `${rate}%` : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-xs text-foreground">
                      {formatDuration(r.totalRunningSeconds)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-xs text-foreground">
                      {formatDuration(r.totalStoppedSeconds)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-xs text-foreground">
                      {formatDuration(r.totalPlannedStopSeconds)}
                    </td>
                    <td className="px-4 py-3 text-right text-foreground">
                      {r.totalProductionCount != null ? r.totalProductionCount.toLocaleString() : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}