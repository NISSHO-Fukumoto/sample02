import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ClipboardList, Search } from "lucide-react";
import { useState } from "react";

export default function AuditLogs() {
  const [search, setSearch] = useState("");
  const { data: logs, isLoading } = trpc.auditLogs.list.useQuery({ limit: 200 });

  const filtered = (logs ?? []).filter(l => {
    if (!search) return true;
    return (
      l.action.includes(search) ||
      (l.targetType ?? "").includes(search) ||
      (l.targetId ?? "").includes(search)
    );
  });

  const getActionColor = (action: string) => {
    if (action.includes("delete") || action.includes("revoke"))
      return "border-[oklch(0.55_0.22_25/0.4)] text-[oklch(0.65_0.22_25)]";
    if (action.includes("create") || action.includes("login"))
      return "border-[oklch(0.65_0.18_145/0.4)] text-[oklch(0.65_0.18_145)]";
    return "border-border text-muted-foreground";
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-primary" />
          監査ログ
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">ユーザー操作の履歴</p>
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="アクション / 対象で検索"
          className="pl-9"
        />
      </div>

      {isLoading ? (
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      ) : (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">日時</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">ユーザー</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">アクション</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">対象</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground">IPアドレス</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(log => (
                <tr key={log.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                    {new Date(log.createdAt).toLocaleString("ja-JP")}
                  </td>
                  <td className="px-4 py-3 text-foreground text-xs">
                    {log.userId ?? "—"}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${getActionColor(log.action)}`}>
                      {log.action}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">
                    {log.targetType && (
                      <span className="mr-1">{log.targetType}</span>
                    )}
                    {log.targetId && (
                      <span className="font-mono">#{log.targetId}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs font-mono">
                    {log.ipAddress ?? "—"}
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground text-sm">
                    ログがありません
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
