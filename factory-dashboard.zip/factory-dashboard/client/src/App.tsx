import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import DashboardLayout from "./components/DashboardLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import AuditLogs from "./pages/AuditLogs";
import ApiKeys from "./pages/ApiKeys";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import MachineDetail from "./pages/MachineDetail";
import Machines from "./pages/Machines";
import Reports from "./pages/Reports";
import Setup from "./pages/Setup";
import StopEvents from "./pages/StopEvents";
import StopReasons from "./pages/StopReasons";
import UsersAdmin from "./pages/UsersAdmin";

function DashboardRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/machines" component={Machines} />
        <Route path="/machines/:machineId" component={MachineDetail} />
        <Route path="/stop-events" component={StopEvents} />
        <Route path="/reports" component={Reports} />
        <Route path="/users" component={UsersAdmin} />
        <Route path="/api-keys" component={ApiKeys} />
        <Route path="/audit-logs" component={AuditLogs} />
        <Route path="/stop-reasons" component={StopReasons} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/setup" component={Setup} />
      <Route path="/404" component={NotFound} />
      {/* All other routes go through DashboardLayout with auth check */}
      <Route component={DashboardRoutes} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
