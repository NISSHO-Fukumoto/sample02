/**
 * Machine state utilities
 * State colors: running=green / choco=yellow / doka=red / planned_stop=blue / off=gray
 */

export type MachineState = "running" | "choco" | "doka" | "planned_stop" | "off" | string;

export interface StateStyle {
  label: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  dotClass: string;
  glowClass: string;
  badgeClass: string;
}

const STATE_STYLES: Record<string, StateStyle> = {
  running: {
    label: "稼働中",
    bgClass: "bg-[oklch(0.65_0.18_145/0.12)]",
    textClass: "text-[oklch(0.75_0.18_145)]",
    borderClass: "border-[oklch(0.65_0.18_145/0.45)]",
    dotClass: "bg-[oklch(0.65_0.18_145)]",
    glowClass: "shadow-[0_0_12px_oklch(0.65_0.18_145/0.4)]",
    badgeClass: "bg-[oklch(0.65_0.18_145/0.2)] text-[oklch(0.75_0.18_145)] border-[oklch(0.65_0.18_145/0.4)]",
  },
  choco: {
    label: "チョコ停",
    bgClass: "bg-[oklch(0.75_0.18_85/0.12)]",
    textClass: "text-[oklch(0.80_0.18_85)]",
    borderClass: "border-[oklch(0.75_0.18_85/0.45)]",
    dotClass: "bg-[oklch(0.75_0.18_85)]",
    glowClass: "shadow-[0_0_12px_oklch(0.75_0.18_85/0.4)]",
    badgeClass: "bg-[oklch(0.75_0.18_85/0.2)] text-[oklch(0.80_0.18_85)] border-[oklch(0.75_0.18_85/0.4)]",
  },
  doka: {
    label: "ドカ停",
    bgClass: "bg-[oklch(0.55_0.22_25/0.12)]",
    textClass: "text-[oklch(0.65_0.22_25)]",
    borderClass: "border-[oklch(0.55_0.22_25/0.45)]",
    dotClass: "bg-[oklch(0.55_0.22_25)]",
    glowClass: "shadow-[0_0_12px_oklch(0.55_0.22_25/0.4)]",
    badgeClass: "bg-[oklch(0.55_0.22_25/0.2)] text-[oklch(0.65_0.22_25)] border-[oklch(0.55_0.22_25/0.4)]",
  },
  planned_stop: {
    label: "計画停止",
    bgClass: "bg-[oklch(0.60_0.15_255/0.12)]",
    textClass: "text-[oklch(0.70_0.15_255)]",
    borderClass: "border-[oklch(0.60_0.15_255/0.45)]",
    dotClass: "bg-[oklch(0.60_0.15_255)]",
    glowClass: "shadow-[0_0_12px_oklch(0.60_0.15_255/0.4)]",
    badgeClass: "bg-[oklch(0.60_0.15_255/0.2)] text-[oklch(0.70_0.15_255)] border-[oklch(0.60_0.15_255/0.4)]",
  },
  off: {
    label: "停止",
    bgClass: "bg-[oklch(0.50_0.02_240/0.12)]",
    textClass: "text-[oklch(0.60_0.02_240)]",
    borderClass: "border-[oklch(0.50_0.02_240/0.45)]",
    dotClass: "bg-[oklch(0.50_0.02_240)]",
    glowClass: "",
    badgeClass: "bg-[oklch(0.50_0.02_240/0.2)] text-[oklch(0.60_0.02_240)] border-[oklch(0.50_0.02_240/0.4)]",
  },
};

const DEFAULT_STYLE: StateStyle = STATE_STYLES.off;

export function getStateStyle(state: MachineState, stopClass?: string | null): StateStyle {
  // stopClass が choco/doka の場合はそちらを優先
  if (stopClass === "choco") return STATE_STYLES.choco;
  if (stopClass === "doka") return STATE_STYLES.doka;
  const normalized = (state ?? "off").toLowerCase().replace(/-/g, "_");
  return STATE_STYLES[normalized] ?? DEFAULT_STYLE;
}

export function getStateLabel(state: MachineState, stopClass?: string | null): string {
  return getStateStyle(state, stopClass).label;
}

/** 通信状態の判定 (updatedAt からの経過時間) */
export type CommStatus = "ok" | "delayed" | "lost";

export function getCommStatus(updatedAt: Date | null | undefined): CommStatus {
  if (!updatedAt) return "lost";
  const elapsed = Date.now() - new Date(updatedAt).getTime();
  if (elapsed < 5 * 60 * 1000) return "ok";
  if (elapsed < 15 * 60 * 1000) return "delayed";
  return "lost";
}

export function getCommStatusLabel(status: CommStatus): string {
  if (status === "ok") return "通信正常";
  if (status === "delayed") return "通信遅延";
  return "通信断";
}

export function getCommStatusColor(status: CommStatus): string {
  if (status === "ok") return "text-[oklch(0.65_0.18_145)]";
  if (status === "delayed") return "text-[oklch(0.80_0.18_85)]";
  return "text-[oklch(0.65_0.22_25)]";
}

/** 秒数を HH:mm:ss 形式に変換 */
export function formatDuration(seconds: number | null | undefined): string {
  if (seconds == null) return "--:--:--";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return [h, m, s].map(v => String(v).padStart(2, "0")).join(":");
}

/** 稼働率計算 */
export function calcOperatingRate(
  runningSeconds: number | null | undefined,
  stoppedSeconds: number | null | undefined,
  plannedStopSeconds: number | null | undefined
): number | null {
  const r = runningSeconds ?? 0;
  const s = stoppedSeconds ?? 0;
  const p = plannedStopSeconds ?? 0;
  const total = r + s + p;
  if (total === 0) return null;
  return Math.round((r / total) * 1000) / 10;
}
