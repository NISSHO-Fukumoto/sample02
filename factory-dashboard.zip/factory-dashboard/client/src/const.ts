export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Local auth: always redirect to /login page (no Manus OAuth required)
export const getLoginUrl = (_returnPath?: string) => "/login";
