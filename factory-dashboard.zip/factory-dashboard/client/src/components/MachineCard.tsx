import {
  formatDuration,
  getCommStatus,
  getCommStatusLabel,
  getStateLabel,
  getStateStyle,
} from "@/lib/machineState";
import { AlertTriangle, Wifi, WifiOff } from "lucide-react";
import { useLocation } from "wouter";

interface CurrentStatus {
  machineId: string;
  currentState: string;
  stopClass?: string | null;
  eventTime?: Date | string | null;
  updatedAt: Date | string;
}

interface PeriodSummary {
  runningSeconds?: number | null;
  stoppedSeconds?: number | null;
  plannedStopSeconds?: number | null;
  productionCount?: number | null;
  targetProductionCount?: number | null;
}

interface MachineCardProps {
  machineId: string;
  displayName: string;
  location?: string | null;
  currentStatus?: CurrentStatus | null;
  todaySummary?: PeriodSummary | null;
  dragging?: boolean;
  onClick?: () => void;
  operatingRateLowerLimit?: number | null;
  operatingRateUpperLimit?: number | null;
}

function getRateColor(rate: number | null, lower: number, upper: number): string {
  if (rate === null) return "#ffffff";
  if (rate >= upper) return "#22c55e";
  if (rate > lower)  return "#eab308";
  return "#ef4444";
}

export function MachineCard({
  machineId,
  displayName,
  location,
  currentStatus,
  todaySummary,
  dragging,
  onClick,
  operatingRateLowerLimit,
  operatingRateUpperLimit,
}: MachineCardProps) {
  const [, navigate] = useLocation();
  const state = currentStatus?.currentState ?? "off";
  const stopClass = currentStatus?.stopClass;
  const style = getStateStyle(state, stopClass);
  const commStatus = getCommStatus(
    currentStatus?.updatedAt ? new Date(currentStatus.updatedAt) : null
  );

  const runSec  = todaySummary?.runningSeconds  || 0;
  const stopSec = todaySummary?.stoppedSeconds  || 0;
  const totalSec = runSec + stopSec;
  const rateNum: number | null = totalSec > 0 ? Math.round((runSec / totalSec) * 100) : null;
  const rateColor = getRateColor(rateNum, operatingRateLowerLimit ?? 30, operatingRateUpperLimit ?? 80);

  const isRunning = state === "running" || state === "run";
  const stateLabel = getStateLabel(state, stopClass);
  const stateBg    = isRunning ? "#16a34a" : "#dc2626";
  const commOk     = commStatus === "ok";
  const commLabel  = getCommStatusLabel(commStatus);
  const commBg     = commOk ? "#16a34a" : "#dc2626";

  const borderColor = commStatus !== "ok" ? "#4b5563"
    : rateNum !== null ? rateColor : "#4b5563";

  const updatedStr = (() => {
    if (!currentStatus?.updatedAt) return "--:--:--";
    const d = new Date(currentStatus.updatedAt);
    const c = new Date(d.getTime() - 9 * 3600 * 1000);
    return c.toLocaleTimeString("ja-JP");
  })();

  const handleClick = () => {
    if (onClick) onClick();
    else navigate(`/machines/${machineId}`);
  };

  return (
    <div
      onClick={handleClick}
      className={dragging ? "opacity-50 scale-95" : "hover:brightness-110"}
      style={{
        background: "#0a0a0a",
        border: `2px solid ${borderColor}`,
        borderRadius: "8px",
        cursor: "pointer",
        transition: "all 0.2s",
        boxShadow: commOk && isRunning ? `0 0 8px ${borderColor}55` : "none",
        display: "flex",
        flexDirection: "row",
        overflow: "hidden",
      }}
    >
      {/* ── 左ブロック: 機械名 + 稼働率 ── */}
      <div style={{
        flex: "6 1 0",
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "10px 12px",
        gap: "6px",
      }}>
        {/* 機械名エリア */}
        <div>
          <div style={{ fontSize: "10px", color: "#ffffff" }}>機械名</div>
          <div style={{
            fontSize: "clamp(14px, 2vw, 22px)",
            fontWeight: "900",
            color: "#ffffff",
            lineHeight: 1.1,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}>
            {displayName}
          </div>
          {location && (
            <div style={{ fontSize: "10px", color: "#ffffff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {location}
            </div>
          )}
          <div style={{ fontSize: "10px", color: "#9ca3af" }}>{machineId}</div>
        </div>

        {/* 稼働率エリア */}
        <div>
          <div style={{ fontSize: "10px", color: "#ffffff" }}>稼働率</div>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "center" }}>
            <span style={{
              fontSize: "clamp(28px, 4vw, 48px)",
              fontWeight: "900",
              color: rateNum !== null ? rateColor : "#4b5563",
              lineHeight: 1,
              textShadow: rateNum !== null ? `0 0 12px ${rateColor}88` : "none",
              display: "inline-block",
              width: "3ch",
              textAlign: "right",
              fontVariantNumeric: "tabular-nums",
              fontFamily: "monospace",
            }}>
              {rateNum !== null ? String(rateNum) : "--"}
            </span>
            {rateNum !== null && (
              <span style={{
                fontSize: "clamp(14px, 2vw, 22px)",
                fontWeight: "900",
                color: rateColor,
                lineHeight: 1,
                textShadow: `0 0 12px ${rateColor}88`,
                marginLeft: "2px",
              }}>%</span>
            )}
          </div>
        </div>
      </div>

      {/* ── 縦仕切り線 ── */}
      <div style={{ width: "1px", background: "#1f2937", flexShrink: 0 }} />

      {/* ── 右ブロック: 状態バッジ + 時間 ── */}
      <div style={{
        flex: "4 0 0",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        padding: "10px 12px",
        gap: "6px",
        minWidth: 0,
      }}>
        {/* 状態バッジ2つ */}
        <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
          <div style={{
            background: stateBg,
            borderRadius: "4px",
            padding: "3px 8px",
            display: "flex",
            alignItems: "center",
            gap: "5px",
            justifyContent: "center",
          }}>
            <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#fff", flexShrink: 0, boxShadow: "0 0 4px #fff" }} />
            <span style={{ fontSize: "12px", fontWeight: "700", color: "#fff", whiteSpace: "nowrap" }}>{stateLabel}</span>
          </div>
          <div style={{
            background: commBg,
            borderRadius: "4px",
            padding: "3px 8px",
            display: "flex",
            alignItems: "center",
            gap: "5px",
            justifyContent: "center",
          }}>
            {commOk ? <Wifi style={{ width: "10px", height: "10px", color: "#fff" }} />
              : commStatus === "delayed" ? <AlertTriangle style={{ width: "10px", height: "10px", color: "#fff" }} />
              : <WifiOff style={{ width: "10px", height: "10px", color: "#fff" }} />}
            <span style={{ fontSize: "12px", fontWeight: "700", color: "#fff", whiteSpace: "nowrap" }}>{commLabel}</span>
          </div>
        </div>

        {/* 停止時間・稼働時間 */}
        <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "8px" }}>
            <span style={{ fontSize: "10px", color: "#ffffff", whiteSpace: "nowrap" }}>停止時間</span>
            <span style={{ fontSize: "13px", fontWeight: "700", color: "#e5e7eb", fontFamily: "monospace" }}>
              {formatDuration(todaySummary?.stoppedSeconds)}
            </span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "8px" }}>
            <span style={{ fontSize: "10px", color: "#ffffff", whiteSpace: "nowrap" }}>稼働時間</span>
            <span style={{ fontSize: "13px", fontWeight: "700", color: "#e5e7eb", fontFamily: "monospace" }}>
              {formatDuration(todaySummary?.runningSeconds)}
            </span>
          </div>
          <div style={{ fontSize: "9px", color: "#9ca3af", textAlign: "right" }}>
            更新: {updatedStr}
          </div>
        </div>
      </div>
    </div>
  );
}
