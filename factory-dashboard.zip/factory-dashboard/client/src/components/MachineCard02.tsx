import {
  formatDuration,
  getCommStatus,
  getCommStatusLabel,
  getStateLabel,
  getStateStyle,
} from "@/lib/machineState";
import { useLocation } from "wouter";

interface CurrentStatus {
  machineId: string;
  currentState: string;
  stopClass?: string | null;
  eventTime?: Date | string | null;
  updatedAt: Date | string;
}

interface PeriodSummary {
  runningSeconds?: number | null;
  stoppedSeconds?: number | null;
  plannedStopSeconds?: number | null;
  productionCount?: number | null;
  targetProductionCount?: number | null;
}

interface MachineCardProps {
  machineId: string;
  displayName: string;
  location?: string | null;
  currentStatus?: CurrentStatus | null;
  todaySummary?: PeriodSummary | null;
  dragging?: boolean;
  onClick?: () => void;
  operatingRateLowerLimit?: number | null;
  operatingRateUpperLimit?: number | null;
}

function getRateColor(rate: number | null, lower: number, upper: number): string {
  if (rate === null) return "#4b5563";
  if (rate >= upper) return "#22c55e";
  if (rate > lower)  return "#eab308";
  return "#ef4444";
}

export function MachineCard02({
  machineId,
  displayName,
  location,
  currentStatus,
  todaySummary,
  dragging,
  onClick,
  operatingRateLowerLimit,
  operatingRateUpperLimit,
}: MachineCardProps) {
  const [, navigate] = useLocation();
  const state = currentStatus?.currentState ?? "off";
  const stopClass = currentStatus?.stopClass;
  const commStatus = getCommStatus(
    currentStatus?.updatedAt ? new Date(currentStatus.updatedAt) : null
  );

  const runSec  = todaySummary?.runningSeconds  || 0;
  const stopSec = todaySummary?.stoppedSeconds  || 0;
  const totalSec = runSec + stopSec;
  const rateNum: number | null = totalSec > 0 ? Math.round((runSec / totalSec) * 100) : null;
  const rateColor = getRateColor(rateNum, operatingRateLowerLimit ?? 30, operatingRateUpperLimit ?? 80);

  const isRunning = state === "running" || state === "run";
  const stateLabel = getStateLabel(state, stopClass);
  const commOk    = commStatus === "ok";
  const commLabel = getCommStatusLabel(commStatus);

  // ボーダーグロー色：稼働率の色を使用、データなしの場合はグレー
  const glowColor = rateNum !== null ? rateColor : "#6b7280";

  const updatedStr = (() => {
    if (!currentStatus?.updatedAt) return "--:--:--";
    const d = new Date(currentStatus.updatedAt);
    const c = new Date(d.getTime() - 9 * 3600 * 1000);
    return c.toLocaleTimeString("ja-JP");
  })();

  const handleClick = () => {
    if (onClick) onClick();
    else navigate(`/machines/${machineId}`);
  };

  return (
    <div
      onClick={handleClick}
      className={dragging ? "opacity-50 scale-95" : ""}
      style={{
        position: "relative",
        cursor: "pointer",
        transition: "all 0.2s",
        borderRadius: "0",
        padding: "2px",
        background: `linear-gradient(135deg, ${glowColor}cc, #1f2937 40%, ${glowColor}88)`,
        boxShadow: `0 0 12px ${glowColor}66, 0 0 24px ${glowColor}33`,
        clipPath: "polygon(12px 0%, calc(100% - 12px) 0%, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0% calc(100% - 12px), 0% 12px)",
      }}
    >
      {/* 内側カード */}
      <div style={{
        background: "linear-gradient(160deg, #0f0f1a 0%, #0a0a12 60%, #111122 100%)",
        borderRadius: "0",
        padding: "10px 12px",
        display: "flex",
        flexDirection: "column",
        gap: "0",
        overflow: "hidden",
        height: "100%",
        clipPath: "polygon(11px 0%, calc(100% - 11px) 0%, 100% 11px, 100% calc(100% - 11px), calc(100% - 11px) 100%, 11px 100%, 0% calc(100% - 11px), 0% 11px)",
        position: "relative",
      }}>
        {/* 上部台形装飾 */}
        <div style={{
          position: "absolute",
          top: 0,
          left: "50%",
          transform: "translateX(-50%)",
          width: "100px",
          height: "10px",
          background: `linear-gradient(180deg, ${glowColor}dd, transparent)`,
          clipPath: "polygon(0% 0%, 100% 0%, calc(100% - 15px) 100%, 15px 100%)",
          zIndex: 1,
        }} />

        {/* コンテンツ（横並び） */}
        <div style={{ display: "flex", flexDirection: "row", flex: 1, gap: 0, paddingTop: "4px" }}>
        {/* 左ブロック: 機械名 + 稼働率 */}
        <div style={{
          flex: "6 1 0",
          minWidth: 0,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          gap: "4px",
        }}>
          {/* 機械名 */}
          <div>
            <div style={{ fontSize: "10px", color: "#ffffff", letterSpacing: "0.05em" }}>機械名</div>
            <div style={{
              fontSize: "clamp(14px, 2vw, 22px)",
              fontWeight: "900",
              color: "#ffffff",
              lineHeight: 1.1,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
              letterSpacing: "-0.01em",
            }}>
              {displayName}
            </div>
            {location && (
              <div style={{ fontSize: "10px", color: "#6b7280", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {location}
              </div>
            )}
          </div>

          {/* 稼働率 */}
          <div>
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "center" }}>
              <span style={{
                fontSize: "clamp(28px, 4vw, 48px)",
                fontWeight: "900",
                color: rateColor,
                lineHeight: 1,
                textShadow: rateNum !== null ? `0 0 16px ${rateColor}, 0 0 30px ${rateColor}66` : "none",
                display: "inline-block",
                width: "3ch",
                textAlign: "right",
                fontVariantNumeric: "tabular-nums",
                fontFamily: "monospace",
              }}>
                {rateNum !== null ? String(rateNum) : "--"}
              </span>
              {rateNum !== null && (
                <span style={{
                  fontSize: "clamp(14px, 2vw, 22px)",
                  fontWeight: "900",
                  color: rateColor,
                  lineHeight: 1,
                  textShadow: `0 0 16px ${rateColor}`,
                  marginLeft: "2px",
                }}>%</span>
              )}
            </div>
            <div style={{ fontSize: "10px", color: "#ffffff", textAlign: "center" }}>稼働率</div>
          </div>
        </div>

        {/* 縦仕切り */}
        <div style={{ width: "1px", background: "#1f2937", flexShrink: 0, margin: "0 10px" }} />

        {/* 右ブロック: バッジ + 時間 */}
        <div style={{
          flex: "4 0 0",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          gap: "6px",
          minWidth: 0,
        }}>
          {/* 状態バッジ2つ */}
          <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
            {/* 稼働状態 */}
            <div style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              background: isRunning ? "#052e16" : "#2d0a0a",
              border: `1px solid ${isRunning ? "#16a34a" : "#dc2626"}`,
              borderRadius: "5px",
              padding: "3px 8px",
            }}>
              {/* アイコン: 再生▶ or 停止■ */}
              <span style={{
                width: "14px",
                height: "14px",
                borderRadius: "50%",
                background: isRunning ? "#16a34a" : "#dc2626",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
                boxShadow: `0 0 6px ${isRunning ? "#16a34a" : "#dc2626"}`,
                fontSize: "8px",
              }}>
                {isRunning ? "▶" : "■"}
              </span>
              <span style={{ fontSize: "11px", fontWeight: "700", color: "#ffffff", whiteSpace: "nowrap" }}>
                {stateLabel}
              </span>
            </div>

            {/* 通信状態 */}
            <div style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              background: commOk ? "#052e16" : "#2d0a0a",
              border: `1px solid ${commOk ? "#16a34a" : "#dc2626"}`,
              borderRadius: "5px",
              padding: "3px 8px",
            }}>
              {/* WiFiアイコン風 */}
              <span style={{
                width: "14px",
                height: "14px",
                borderRadius: "50%",
                background: commOk ? "#16a34a" : "#dc2626",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
                boxShadow: `0 0 6px ${commOk ? "#16a34a" : "#dc2626"}`,
                fontSize: "8px",
              }}>
                {commOk ? "📶" : "✕"}
              </span>
              <span style={{ fontSize: "11px", fontWeight: "700", color: "#ffffff", whiteSpace: "nowrap" }}>
                {commLabel}
              </span>
            </div>
          </div>

          {/* 停止時間・稼働時間 */}
          <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "4px" }}>
              <span style={{ fontSize: "10px", color: "#ffffff", whiteSpace: "nowrap" }}>停止時間</span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: "#e5e7eb", fontFamily: "monospace" }}>
                {formatDuration(todaySummary?.stoppedSeconds)}
              </span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "4px" }}>
              <span style={{ fontSize: "10px", color: "#ffffff", whiteSpace: "nowrap" }}>稼働時間</span>
              <span style={{ fontSize: "12px", fontWeight: "700", color: "#e5e7eb", fontFamily: "monospace" }}>
                {formatDuration(todaySummary?.runningSeconds)}
              </span>
            </div>
            <div style={{ fontSize: "9px", color: "#374151", textAlign: "right" }}>
              更新: {updatedStr}
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}

// デフォルトエクスポートも提供（既存の MachineCard と差し替え可能）
