import { Card, CardContent } from "@/components/ui/card";
import { formatDuration } from "@/lib/machineState";
import { useMemo, useState } from "react";

/**
 * OperationTimeline
 * ------------------------------------------------------------------
 * 「本日の稼働帯」を1本の横長バーで、実際に起きた時系列順に可視化する。
 *
 * ★データソースの方針（変更）:
 *   - 稼働・計画停止: period_logs から算出（変更なし）
 *   - チョコ停・ドカ停: stop_events から算出（変更）
 *     理由: period_logs 側で「昇格時の遡り訂正（マイナス値のインサート）」
 *     による不自然な値が生じるため、既に eventId で綺麗に upsert されている
 *     stop_events（開始・終了時刻、最終確定した分類）を正とする。
 *     ただし stop_events には稼働・計画停止の情報は含まれないため、
 *     そちらは引き続き period_logs から取得する。
 *
 * ★色の幅について（重要）:
 *   各色ブロックの幅は、実際の秒数に忠実な比率で描画する。
 *   「短い停止でも見えるように」といった最低幅の強制は行わない。
 *
 * 表示範囲（開始〜終了）の考え方:
 *   - 開始は常に machine.timeStart（既定 08:00）
 *   - 終了は「設定上の終業時刻（既定18:00）」と
 *     「実際に確認できた最新の活動時刻（period_logs・stop_events 双方の
 *      最新時刻）」の遅い方を採用する。
 *
 * 色の考え方:
 *   - 背景は既定で「グレー（データなし）」。
 *   - 稼働・計画停止は period_logs の該当秒数がある区間だけ、
 *     チョコ停・ドカ停は stop_events の開始〜終了（未終了なら現在時刻）
 *     の区間だけを、対応する色で描画する。
 */

export type TimelineStopEvent = {
  id: number | string;
  stopClass: string | null;
  finalStopClass?: string | null;
  startTime: Date | string | null;
  endTime: Date | string | null;
  lifecycleState?: string;
};

export type TimelinePeriodLog = {
  id?: number | string;
  periodStart: Date | string | null;
  periodEnd: Date | string | null;
  runningSeconds?: number | null;
  plannedStopSeconds?: number | null;
};

type Props = {
  title: string;
  /** "HH:mm" or "HH:mm:ss" 形式。null の場合は 08:00 を既定とする */
  timeStart?: string | null;
  /** 設定上の終業時刻。"HH:mm" or "HH:mm:ss" 形式。null の場合は 17:00 を既定とする */
  timeEnd?: string | null;
  /** period_logs の生レコード一覧（稼働・計画停止のデータソース） */
  periodLogs?: TimelinePeriodLog[];
  /** stop_events の一覧（チョコ停・ドカ停のデータソース） */
  stopEvents?: TimelineStopEvent[];
  runningSeconds?: number | null;
  chocoSeconds?: number | null;
  dokaSeconds?: number | null;
  plannedStopSeconds?: number | null;
  operatingRate?: number | string | null;
  /** DBのJST時刻がUTCと誤認されるズレを補正する関数（呼び出し元と同じロジックを渡す） */
  fixOffset?: (d: Date | string | number | null | undefined) => Date;
};

const COLOR = {
  running: "oklch(0.65 0.18 145)",
  choco: "oklch(0.75 0.18 85)",
  doka: "oklch(0.55 0.22 25)",
  planned: "oklch(0.60 0.15 255)",
  noData: "oklch(0.32 0.01 260)", // グレー（データなし）
};

function parseHHmm(s: string | null | undefined, fallback: string): { h: number; m: number } {
  const src = s && /^\d{1,2}:\d{2}/.test(s) ? s : fallback;
  const [h, m] = src.split(":").map(v => parseInt(v, 10));
  return { h: h || 0, m: m || 0 };
}

function toMinutesOfDay(d: Date): number {
  return d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
}

function clampPct(v: number): number {
  return Math.max(0, Math.min(100, v));
}

export default function OperationTimeline({
  title,
  timeStart,
  timeEnd,
  periodLogs,
  stopEvents,
  runningSeconds,
  chocoSeconds,
  dokaSeconds,
  plannedStopSeconds,
  operatingRate,
  fixOffset,
}: Props) {
  const applyOffset = fixOffset ?? ((d) => (d ? new Date(d) : new Date()));

  // ── period_logs の生レコードから区間ブロックを再構築する汎用ヘルパー ──
  // （稼働・計画停止用。隣接する区間（1分以内の隙間）は1つのブロックに結合）
  type Block = { s: number; e: number; records: { s: number; e: number }[] };

  function buildBlocksFromLogs(
    logs: TimelinePeriodLog[] | undefined,
    getSeconds: (p: TimelinePeriodLog) => number | null | undefined
  ): Block[] {
    if (!logs || logs.length === 0) return [];

    // ★重要: 幅は「記録区間(periodStart〜periodEnd)の長さ」ではなく、
    // 「その区間内で実際に発生した秒数(getSecondsの値)」から算出する。
    const intervals = logs
      .filter(p => (getSeconds(p) ?? 0) > 0 && p.periodStart)
      .map(p => {
        const sec = getSeconds(p) ?? 0;
        const s = toMinutesOfDay(applyOffset(p.periodStart));
        return { s, e: s + sec / 60 };
      })
      .filter(iv => iv.e > iv.s)
      .sort((a, b) => a.s - b.s);

    const merged: Block[] = [];
    for (const iv of intervals) {
      const last = merged[merged.length - 1];
      if (last && iv.s - last.e <= 1) {
        last.e = Math.max(last.e, iv.e);
        last.records.push(iv);
      } else {
        merged.push({ s: iv.s, e: iv.e, records: [iv] });
      }
    }
    return merged;
  }

  // ── stop_events から区間ブロックを再構築するヘルパー ──────────────
  // （チョコ停・ドカ停用。stop_events は eventId で1件=1停止として
  //   綺麗に upsert されているため、period_logs のような「記録区間内の
  //   実秒数への換算」は不要で、開始〜終了（未終了なら現在時刻）を
  //   そのまま使えばよい。）
  function buildBlocksFromStopEvents(
    events: TimelineStopEvent[] | undefined,
    targetClass: "choco" | "doka"
  ): Block[] {
    if (!events || events.length === 0) return [];
    const now = new Date();

    const intervals = events
      .filter(e => (e.finalStopClass ?? e.stopClass) === targetClass)
      .map(e => {
        const s = e.startTime ? toMinutesOfDay(applyOffset(e.startTime)) : null;
        const endSource = e.endTime ?? (e.lifecycleState !== "closed" ? now : null);
        const eMin = endSource ? toMinutesOfDay(applyOffset(endSource)) : null;
        return s != null && eMin != null ? { s, e: eMin } : null;
      })
      .filter((iv): iv is { s: number; e: number } => iv != null && iv.e > iv.s)
      .sort((a, b) => a.s - b.s);

    const merged: Block[] = [];
    for (const iv of intervals) {
      const last = merged[merged.length - 1];
      if (last && iv.s - last.e <= 1) {
        last.e = Math.max(last.e, iv.e);
        last.records.push(iv);
      } else {
        merged.push({ s: iv.s, e: iv.e, records: [iv] });
      }
    }
    return merged;
  }

  const runningBlocksMinRaw = useMemo(
    () => buildBlocksFromLogs(periodLogs, p => p.runningSeconds),
    [periodLogs]
  );
  const chocoBlocksMinRaw = useMemo(
    () => buildBlocksFromStopEvents(stopEvents, "choco"),
    [stopEvents]
  );
  const dokaBlocksMinRaw = useMemo(
    () => buildBlocksFromStopEvents(stopEvents, "doka"),
    [stopEvents]
  );
  const plannedBlocksMinRaw = useMemo(
    () => buildBlocksFromLogs(periodLogs, p => p.plannedStopSeconds),
    [periodLogs]
  );

  // ── 短い空白（隣接ブロック間の隙間）を「直前の状態が継続していた」と
  // みなして埋める ──────────────────────────────────────────
  // period_logs の1レコード内で、稼働/チョコ停/ドカ停/計画停止の合計が
  // 記録区間の長さに満たない場合（ノード側の未分類の端数時間）、
  // その分だけ隣接ブロックの間に短い空白ができる。これは大抵の場合、
  // 実際には状態が変わっていない（直前の状態がそのまま続いていた）と
  // 考えられるため、一定時間（既定5分）未満の空白は直前のブロックを
  // 延長して埋める。
  // ★あくまで表示上の補完であり、凡例の合計時間（実データそのまま）には
  // 一切影響しない。長時間の空白（始業前など、本当にデータが無い期間）
  // は対象外とし、グレーのまま残す。
  const FILL_GAP_THRESHOLD_MIN = 5;
  const { runningBlocksMin, chocoBlocksMin, dokaBlocksMin, plannedBlocksMin } = useMemo(() => {
    type Tagged = { type: "running" | "choco" | "doka" | "planned"; block: Block };
    const tagged: Tagged[] = [
      ...runningBlocksMinRaw.map((block): Tagged => ({ type: "running", block: { ...block } })),
      ...chocoBlocksMinRaw.map((block): Tagged => ({ type: "choco", block: { ...block } })),
      ...dokaBlocksMinRaw.map((block): Tagged => ({ type: "doka", block: { ...block } })),
      ...plannedBlocksMinRaw.map((block): Tagged => ({ type: "planned", block: { ...block } })),
    ].sort((a, b) => a.block.s - b.block.s);

    for (let i = 0; i < tagged.length - 1; i++) {
      const gap = tagged[i + 1].block.s - tagged[i].block.e;
      if (gap > 0 && gap <= FILL_GAP_THRESHOLD_MIN) {
        // 直前のブロックを、次のブロックが始まるところまで延長する
        tagged[i].block.e = tagged[i + 1].block.s;
      }
    }

    return {
      runningBlocksMin: tagged.filter(t => t.type === "running").map(t => t.block),
      chocoBlocksMin: tagged.filter(t => t.type === "choco").map(t => t.block),
      dokaBlocksMin: tagged.filter(t => t.type === "doka").map(t => t.block),
      plannedBlocksMin: tagged.filter(t => t.type === "planned").map(t => t.block),
    };
  }, [runningBlocksMinRaw, chocoBlocksMinRaw, dokaBlocksMinRaw, plannedBlocksMinRaw]);

  // ── 「実際に確認できた最新の活動時刻」を算出 ──────────────────
  // ★重要: period_logs に実際のレコードがあるかどうかだけで判定する。
  // 以前は「現在のステータスが稼働中(isRunning)なら現在時刻まで活動している」
  // とみなしていたが、これは誤り。current_status は自己申告の最新状態で
  // あり、通信が切れた後も「最後に生きていた時の状態」が残り続ける
  // （例: 通信断でも稼働中の表示が残る）。その古い状態を根拠に「今も
  // 活動している」と判定してしまうと、実際には10時台でデータが途絶えて
  // いるのに、グラフの表示範囲だけ現在時刻まで無駄に引き伸ばされてしまう。
  const lastActivityMin = useMemo(() => {
    const now = new Date();
    const candidates: number[] = [];
    for (const p of periodLogs ?? []) {
      const t = p.periodEnd ?? p.periodStart;
      if (t) candidates.push(toMinutesOfDay(applyOffset(t)));
    }
    for (const e of stopEvents ?? []) {
      const t = e.endTime ?? (e.lifecycleState !== "closed" ? now : e.startTime);
      if (t) candidates.push(toMinutesOfDay(applyOffset(t)));
    }
    if (candidates.length === 0) return null;
    return Math.max(...candidates);
  }, [periodLogs, stopEvents]);

  const { startMin, endMin, spanMin, ticks } = useMemo(() => {
    const start = parseHHmm(timeStart, "08:00");
    const configuredEnd = parseHHmm(timeEnd, "18:00");
    const startMin = start.h * 60 + start.m;
    const configuredEndMin = configuredEnd.h * 60 + configuredEnd.m;

    // ★方針変更: 「設定上の勤務時間帯（既定 8:00-18:00）」を常にデフォルトの
    // 表示枠とする。実際の記録が無い時間帯はグレーになるだけで、枠自体は
    // 縮めない。残業等で実際の記録（lastActivityMin）が設定終業時刻を
    // 超えている場合だけ、その分だけ枠を延長する。
    // （period_logs は実際に記録された過去のデータのみなので、
    //   lastActivityMin が「現在時刻」を超えることはなく、
    //   現在時刻によるキャップは不要）
    const endMin = Math.max(configuredEndMin, lastActivityMin ?? configuredEndMin);

    const spanMin = Math.max(endMin - startMin, 1);

    // 1時間刻みの目盛り（分の情報は表示しないため、終端に半端な時刻の
    // 目盛りを追加することはしない。あくまで正時のみを並べる）
    const ticks: number[] = [];
    for (let t = startMin; t <= endMin; t += 60) ticks.push(t);

    return { startMin, endMin, spanMin, ticks };
  }, [timeStart, timeEnd, lastActivityMin]);

  const toPct = (minOfDay: number) => clampPct(((minOfDay - startMin) / spanMin) * 100);

  // ── ホバー／クリック（タップ）で内訳を表示するための状態 ──────────
  // タッチモニターでは hover が効かないため、クリック（タップ）でも
  // 同じ内訳パネルを開けるようにする。クリックは「固定表示」として扱い、
  // マウスが離れても消えない（もう一度同じブロックをクリックすると閉じる）。
  type ActiveBlock = { type: "running" | "choco" | "doka" | "planned"; block: Block };
  const [hoverBlock, setHoverBlock] = useState<ActiveBlock | null>(null);
  const [pinnedBlock, setPinnedBlock] = useState<ActiveBlock | null>(null);
  const activeBlock = pinnedBlock ?? hoverBlock;

  const TYPE_LABEL: Record<ActiveBlock["type"], string> = {
    running: "稼働",
    choco: "チョコ停",
    doka: "ドカ停",
    planned: "計画停止",
  };

  const fmtMinPrecise = (min: number) => {
    const h = Math.floor(min / 60);
    const m = Math.floor(min % 60);
    const s = Math.round((min % 1) * 60);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };
  const fmtDurationMin = (min: number) => formatDuration(Math.round(min * 60));

  function handleBlockClick(type: ActiveBlock["type"], block: Block) {
    setPinnedBlock(prev =>
      prev && prev.type === type && prev.block === block ? null : { type, block }
    );
  }

  // ★変更: 回数は stop_events を数えるのではなく、グラフのブロック数
  // （= period_logs から連続区間を結合した結果）をそのまま使う。
  // グラフ上で1つの塊に見えているものは「1回の停止」として数える方針に
  // 統一し、stop_events 由来の値との食い違いが起きないようにする。
  const chocoCount = chocoBlocksMin.length;
  const dokaCount = dokaBlocksMin.length;

  const fmtHM = (min: number) => {
    const h = Math.floor(min / 60);
    const m = Math.round(min % 60);
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  };

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <p className="text-sm text-muted-foreground">{title} — 本日の稼働帯</p>
          {operatingRate != null && (
            <div className="text-right leading-none">
              <span className="text-xs text-muted-foreground mr-1">本日の稼働率</span>
              <span className="text-3xl font-bold text-foreground">{operatingRate}</span>
              <span className="text-lg text-muted-foreground ml-0.5">%</span>
            </div>
          )}
        </div>

        <div className="relative h-10 rounded-md overflow-hidden" style={{ background: COLOR.noData }}>
          {/* 各色の幅は実際の秒数に忠実な比率（最低幅の水増しは行わない）。
              ホバー／クリックの両方で内訳パネルを開けるようにする
              （タッチモニターではホバーが効かないため）。 */}
          {runningBlocksMin.map((b, i) => (
            <div
              key={`run-${i}`}
              className="absolute inset-y-0 cursor-pointer"
              style={{ left: `${toPct(b.s)}%`, width: `${clampPct(((b.e - b.s) / spanMin) * 100)}%`, background: COLOR.running }}
              onMouseEnter={() => setHoverBlock({ type: "running", block: b })}
              onMouseLeave={() => setHoverBlock(null)}
              onClick={() => handleBlockClick("running", b)}
            />
          ))}
          {plannedBlocksMin.map((b, i) => (
            <div
              key={`planned-${i}`}
              className="absolute inset-y-0 cursor-pointer"
              style={{ left: `${toPct(b.s)}%`, width: `${clampPct(((b.e - b.s) / spanMin) * 100)}%`, background: COLOR.planned }}
              onMouseEnter={() => setHoverBlock({ type: "planned", block: b })}
              onMouseLeave={() => setHoverBlock(null)}
              onClick={() => handleBlockClick("planned", b)}
            />
          ))}
          {chocoBlocksMin.map((b, i) => (
            <div
              key={`choco-${i}`}
              className="absolute inset-y-0 cursor-pointer"
              style={{ left: `${toPct(b.s)}%`, width: `${clampPct(((b.e - b.s) / spanMin) * 100)}%`, background: COLOR.choco }}
              onMouseEnter={() => setHoverBlock({ type: "choco", block: b })}
              onMouseLeave={() => setHoverBlock(null)}
              onClick={() => handleBlockClick("choco", b)}
            />
          ))}
          {dokaBlocksMin.map((b, i) => (
            <div
              key={`doka-${i}`}
              className="absolute inset-y-0 cursor-pointer"
              style={{ left: `${toPct(b.s)}%`, width: `${clampPct(((b.e - b.s) / spanMin) * 100)}%`, background: COLOR.doka }}
              onMouseEnter={() => setHoverBlock({ type: "doka", block: b })}
              onMouseLeave={() => setHoverBlock(null)}
              onClick={() => handleBlockClick("doka", b)}
            />
          ))}
        </div>

        <div className="flex justify-between mt-1.5">
          {ticks.map((t, i) => (
            <span key={i} className="text-xs text-muted-foreground font-mono">
              {fmtHM(t)}
            </span>
          ))}
        </div>

        {/* ── 内訳パネル: ホバー中 or クリックで固定表示中のブロックの詳細 ── */}
        <div className="mt-2 min-h-[52px] rounded-md border border-border bg-muted/20 px-3 py-2">
          {activeBlock ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className="inline-block w-2.5 h-2.5 rounded-sm"
                  style={{ background: COLOR[activeBlock.type] }}
                />
                <span className="text-sm font-semibold text-foreground">
                  {TYPE_LABEL[activeBlock.type]}
                </span>
                <span className="text-xs text-muted-foreground font-mono">
                  {fmtMinPrecise(activeBlock.block.s)} - {fmtMinPrecise(activeBlock.block.e)}
                  {"　"}({fmtDurationMin(activeBlock.block.e - activeBlock.block.s)})
                </span>
              </div>
              {pinnedBlock && (
                <button
                  className="text-xs text-muted-foreground hover:text-foreground"
                  onClick={() => setPinnedBlock(null)}
                >
                  閉じる ✕
                </button>
              )}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              バー上のブロックにカーソルを合わせるか、タップすると内訳を表示します
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 mt-4">
          <LegendItem color={COLOR.running} label="稼働" value={formatDuration(runningSeconds)} />
          <LegendItem
            color={COLOR.choco}
            label="チョコ停"
            value={`${chocoCount} 回 / ${formatDuration(chocoSeconds)}`}
          />
          <LegendItem
            color={COLOR.doka}
            label="ドカ停"
            value={`${dokaCount} 回 / ${formatDuration(dokaSeconds)}`}
          />
          <LegendItem color={COLOR.planned} label="計画停止" value={formatDuration(plannedStopSeconds)} />
        </div>
      </CardContent>
    </Card>
  );
}

function LegendItem({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="inline-block w-3 h-3 rounded-sm" style={{ background: color }} />
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono font-semibold text-foreground">{value}</span>
    </div>
  );
}
