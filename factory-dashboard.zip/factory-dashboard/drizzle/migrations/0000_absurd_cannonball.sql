CREATE TYPE "public"."lifecycle_state" AS ENUM('open', 'updating', 'closed');--> statement-breakpoint
CREATE TYPE "public"."role" AS ENUM('admin', 'operator', 'viewer');--> statement-breakpoint
CREATE TYPE "public"."stop_class_enum" AS ENUM('choco', 'doka', 'planned_stop', 'other');--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer,
	"action" varchar(128) NOT NULL,
	"target_type" varchar(64),
	"target_id" varchar(256),
	"detail" json,
	"ip_address" varchar(64),
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "current_statuses" (
	"id" serial PRIMARY KEY NOT NULL,
	"machine_id" varchar(128) NOT NULL,
	"current_state" varchar(64) NOT NULL,
	"stop_class" varchar(64),
	"event_time" timestamp,
	"alarm" text,
	"schedule_violation" text,
	"time_zone" varchar(64),
	"schema_version" varchar(32),
	"raw_payload_json" json,
	"last_received_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "current_statuses_machine_id_unique" UNIQUE("machine_id")
);
--> statement-breakpoint
CREATE TABLE "dashboard_layouts" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"layout_name" varchar(128) DEFAULT 'default' NOT NULL,
	"layout_json" json NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "machines" (
	"id" serial PRIMARY KEY NOT NULL,
	"machine_id" varchar(128) NOT NULL,
	"display_name" varchar(256) NOT NULL,
	"description" text,
	"location" varchar(256),
	"sort_order" integer DEFAULT 0 NOT NULL,
	"dur_choco_sec" integer DEFAULT 300 NOT NULL,
	"dur_doka_sec" integer DEFAULT 1800 NOT NULL,
	"time_start" time,
	"time_end" time,
	"break_times" json,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "machines_machine_id_unique" UNIQUE("machine_id")
);
--> statement-breakpoint
CREATE TABLE "node_api_keys" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(256) DEFAULT '' NOT NULL,
	"api_key" varchar(64) NOT NULL,
	"machine_id" varchar(128),
	"description" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"last_used_at" timestamp,
	"created_by" integer,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "node_api_keys_api_key_unique" UNIQUE("api_key")
);
--> statement-breakpoint
CREATE TABLE "period_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"machine_id" varchar(128) NOT NULL,
	"period_start" timestamp NOT NULL,
	"period_end" timestamp NOT NULL,
	"running_seconds" integer,
	"idle_seconds" integer,
	"stopped_seconds" integer,
	"choco_seconds" integer,
	"doka_seconds" integer,
	"planned_stop_seconds" integer,
	"production_count" integer,
	"target_production_count" integer,
	"schema_version" varchar(32),
	"raw_payload_json" json,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "period_logs_unique" UNIQUE("machine_id","period_start","period_end")
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" varchar(64) PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stop_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"event_id" varchar(256) NOT NULL,
	"machine_id" varchar(128) NOT NULL,
	"lifecycle_state" "lifecycle_state" DEFAULT 'open' NOT NULL,
	"stop_class" varchar(64),
	"final_stop_class" varchar(64),
	"start_time" timestamp,
	"end_time" timestamp,
	"doka_at" timestamp,
	"last_update_time" timestamp,
	"elapsed_sec" integer,
	"final_stop_duration_sec" integer,
	"close_reason" varchar(256),
	"reason_code" varchar(128),
	"operator_note" text,
	"tags" text,
	"raw_payload_json" json,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "stop_events_event_id_unique" UNIQUE("event_id")
);
--> statement-breakpoint
CREATE TABLE "stop_reason_master" (
	"id" serial PRIMARY KEY NOT NULL,
	"reason_code" varchar(128) NOT NULL,
	"display_name" varchar(256) NOT NULL,
	"stop_class" "stop_class_enum",
	"sort_order" integer DEFAULT 0 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "stop_reason_master_reason_code_unique" UNIQUE("reason_code")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" varchar(64) NOT NULL,
	"password_hash" text NOT NULL,
	"role" "role" DEFAULT 'operator' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"last_login_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
