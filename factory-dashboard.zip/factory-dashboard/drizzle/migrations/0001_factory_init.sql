-- Factory Dashboard - PostgreSQL Initial Migration
-- Run this against your PostgreSQL database to create all tables.
-- Usage: psql -U factory_user -d factory_db -f 0001_factory_init.sql

-- ─────────────────────────────────────────────
-- users
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  username    VARCHAR(64) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name VARCHAR(128),
  role        VARCHAR(16) NOT NULL DEFAULT 'operator'
                CHECK (role IN ('admin', 'operator', 'viewer')),
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- sessions
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id          VARCHAR(128) PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);

-- ─────────────────────────────────────────────
-- machines
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS machines (
  id            SERIAL PRIMARY KEY,
  machine_id    VARCHAR(64) NOT NULL UNIQUE,
  display_name  VARCHAR(128) NOT NULL,
  description   TEXT,
  location      VARCHAR(128),
  sort_order    INTEGER NOT NULL DEFAULT 0,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  -- 停止判定閾値（秒）
  dur_choco_sec INTEGER NOT NULL DEFAULT 300,
  dur_doka_sec  INTEGER NOT NULL DEFAULT 1800,
  -- 稼働時間帯（HH:MM 形式）
  time_start    VARCHAR(5),
  time_end      VARCHAR(5),
  -- 休憩時間帯 JSON: [{"start":"12:00","end":"13:00"}]
  break_times   JSONB,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- node_api_keys
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS node_api_keys (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(128),
  api_key     VARCHAR(256) NOT NULL UNIQUE,
  machine_id  VARCHAR(64),
  description TEXT,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  last_used_at TIMESTAMPTZ,
  created_by  INTEGER REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- current_statuses  (machine_id 単位で最新1件)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS current_statuses (
  id              SERIAL PRIMARY KEY,
  machine_id      VARCHAR(64) NOT NULL UNIQUE,
  event_time      TIMESTAMPTZ,
  current_state   VARCHAR(32) NOT NULL DEFAULT 'off',
  stop_class      VARCHAR(32),
  alarm           VARCHAR(64),
  time_zone       VARCHAR(64),
  schedule_violation VARCHAR(128),
  schema_version  VARCHAR(16),
  raw_payload_json JSONB,
  last_received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- stop_events  (eventId 単位 lifecycle 管理)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stop_events (
  id                    SERIAL PRIMARY KEY,
  event_id              VARCHAR(128) NOT NULL UNIQUE,
  machine_id            VARCHAR(64) NOT NULL,
  lifecycle_state       VARCHAR(16) NOT NULL DEFAULT 'open'
                          CHECK (lifecycle_state IN ('open', 'updating', 'closed')),
  stop_class            VARCHAR(32),
  final_stop_class      VARCHAR(32),
  start_time            TIMESTAMPTZ,
  end_time              TIMESTAMPTZ,
  doka_at               TIMESTAMPTZ,
  last_update_time      TIMESTAMPTZ,
  elapsed_sec           INTEGER,
  final_stop_duration_sec INTEGER,
  close_reason          TEXT,
  reason_code           VARCHAR(64),
  tags                  TEXT,
  operator_note         TEXT,
  schema_version        VARCHAR(16),
  raw_payload_json      JSONB,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_stop_events_machine_id ON stop_events(machine_id);
CREATE INDEX IF NOT EXISTS idx_stop_events_lifecycle ON stop_events(lifecycle_state);
CREATE INDEX IF NOT EXISTS idx_stop_events_created_at ON stop_events(created_at);

-- ─────────────────────────────────────────────
-- period_logs  (machine_id + period_start + period_end で upsert)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS period_logs (
  id                      SERIAL PRIMARY KEY,
  machine_id              VARCHAR(64) NOT NULL,
  period_start            TIMESTAMPTZ NOT NULL,
  period_end              TIMESTAMPTZ NOT NULL,
  running_seconds         INTEGER,
  idle_seconds            INTEGER,
  stopped_seconds         INTEGER,
  choco_seconds           INTEGER,
  doka_seconds            INTEGER,
  planned_stop_seconds    INTEGER,
  production_count        INTEGER,
  target_production_count INTEGER,
  schema_version          VARCHAR(16),
  raw_payload_json        JSONB,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (machine_id, period_start, period_end)
);
CREATE INDEX IF NOT EXISTS idx_period_logs_machine_id ON period_logs(machine_id);
CREATE INDEX IF NOT EXISTS idx_period_logs_period_start ON period_logs(period_start);

-- ─────────────────────────────────────────────
-- stop_reason_master
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stop_reason_master (
  id           SERIAL PRIMARY KEY,
  reason_code  VARCHAR(64) NOT NULL UNIQUE,
  display_name VARCHAR(128) NOT NULL,
  stop_class   VARCHAR(32),
  sort_order   INTEGER NOT NULL DEFAULT 0,
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────
-- dashboard_layouts  (ユーザーごとの並び順保存)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dashboard_layouts (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  layout_name VARCHAR(64) NOT NULL DEFAULT 'default',
  layout_json JSONB NOT NULL DEFAULT '[]',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, layout_name)
);

-- ─────────────────────────────────────────────
-- audit_logs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  username    VARCHAR(64),
  action      VARCHAR(128) NOT NULL,
  target_type VARCHAR(64),
  target_id   VARCHAR(128),
  detail      JSONB,
  ip_address  VARCHAR(64),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
