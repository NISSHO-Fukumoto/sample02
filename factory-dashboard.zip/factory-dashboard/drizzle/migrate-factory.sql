-- Factory Dashboard Schema Migration
-- Drop old tables if they exist (from template)
DROP TABLE IF EXISTS `users`;

-- ─────────────────────────────────────────────
-- users (local auth)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `username` varchar(64) NOT NULL,
  `password_hash` text NOT NULL,
  `role` enum('admin','operator','viewer') NOT NULL DEFAULT 'operator',
  `is_active` boolean NOT NULL DEFAULT true,
  `last_login_at` timestamp NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `users_id` PRIMARY KEY(`id`),
  CONSTRAINT `users_username_unique` UNIQUE(`username`)
);

-- ─────────────────────────────────────────────
-- sessions
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(64) NOT NULL,
  `user_id` int NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `sessions_id` PRIMARY KEY(`id`)
);

-- ─────────────────────────────────────────────
-- machines
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `machines` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `machine_id` varchar(128) NOT NULL,
  `display_name` varchar(256) NOT NULL,
  `description` text,
  `location` varchar(256),
  `sort_order` int NOT NULL DEFAULT 0,
  `is_active` boolean NOT NULL DEFAULT true,
  `dur_choco_sec` int NOT NULL DEFAULT 300,
  `dur_doka_sec` int NOT NULL DEFAULT 1800,
  `time_start` time,
  `time_end` time,
  `break_times` json,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `machines_id` PRIMARY KEY(`id`),
  CONSTRAINT `machines_machine_id_unique` UNIQUE(`machine_id`)
);

-- ─────────────────────────────────────────────
-- node_api_keys
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `node_api_keys` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `name` varchar(256),
  `api_key` varchar(128) NOT NULL,
  `machine_id` varchar(128),
  `is_active` boolean NOT NULL DEFAULT true,
  `last_used_at` timestamp NULL,
  `created_by` int,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `node_api_keys_id` PRIMARY KEY(`id`),
  CONSTRAINT `node_api_keys_api_key_unique` UNIQUE(`api_key`)
);

-- ─────────────────────────────────────────────
-- current_statuses (machine_id 単位で最新1件)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `current_statuses` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `machine_id` varchar(128) NOT NULL,
  `current_state` varchar(64) NOT NULL DEFAULT 'off',
  `stop_class` varchar(64),
  `event_time` timestamp NULL,
  `alarm` varchar(256),
  `schedule_violation` varchar(256),
  `time_zone` varchar(64),
  `schema_version` varchar(32),
  `raw_payload_json` json,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `current_statuses_id` PRIMARY KEY(`id`),
  CONSTRAINT `current_statuses_machine_id_unique` UNIQUE(`machine_id`)
);

-- ─────────────────────────────────────────────
-- stop_events
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `stop_events` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `event_id` varchar(128) NOT NULL,
  `machine_id` varchar(128) NOT NULL,
  `lifecycle_state` enum('open','updating','closed') NOT NULL DEFAULT 'open',
  `stop_class` varchar(64),
  `final_stop_class` varchar(64),
  `start_time` timestamp NULL,
  `end_time` timestamp NULL,
  `elapsed_sec` int,
  `final_stop_duration_sec` int,
  `close_reason` varchar(256),
  `reason_code` varchar(128),
  `operator_note` text,
  `tags` json,
  `raw_payload_json` json,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `stop_events_id` PRIMARY KEY(`id`),
  CONSTRAINT `stop_events_event_id_unique` UNIQUE(`event_id`)
);

-- ─────────────────────────────────────────────
-- period_logs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `period_logs` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `machine_id` varchar(128) NOT NULL,
  `period_start` timestamp NOT NULL,
  `period_end` timestamp NOT NULL,
  `running_seconds` int,
  `idle_seconds` int,
  `stopped_seconds` int,
  `planned_stop_seconds` int,
  `production_count` int,
  `target_production_count` int,
  `schema_version` varchar(32),
  `raw_payload_json` json,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `period_logs_id` PRIMARY KEY(`id`),
  UNIQUE KEY `period_logs_machine_period_unique` (`machine_id`, `period_start`, `period_end`)
);

-- ─────────────────────────────────────────────
-- stop_reason_master
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `stop_reason_master` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `reason_code` varchar(128) NOT NULL,
  `display_name` varchar(256) NOT NULL,
  `stop_class` enum('choco','doka','planned_stop','other'),
  `sort_order` int NOT NULL DEFAULT 0,
  `is_active` boolean NOT NULL DEFAULT true,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `stop_reason_master_id` PRIMARY KEY(`id`),
  CONSTRAINT `stop_reason_master_reason_code_unique` UNIQUE(`reason_code`)
);

-- ─────────────────────────────────────────────
-- dashboard_layouts (ユーザー別保存)
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `dashboard_layouts` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `user_id` int NOT NULL,
  `layout_json` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `dashboard_layouts_id` PRIMARY KEY(`id`),
  CONSTRAINT `dashboard_layouts_user_id_unique` UNIQUE(`user_id`)
);

-- ─────────────────────────────────────────────
-- audit_logs
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` bigint unsigned AUTO_INCREMENT NOT NULL,
  `user_id` int,
  `action` varchar(128) NOT NULL,
  `target_type` varchar(64),
  `target_id` varchar(256),
  `detail` json,
  `ip_address` varchar(64),
  `created_at` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
