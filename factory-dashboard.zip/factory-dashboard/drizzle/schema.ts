/**
 * PostgreSQL schema using drizzle-orm/pg-core.
 * Designed for local Linux server deployment with PostgreSQL.
 */
import {
  boolean,
  integer,
  json,
  pgEnum,
  pgTable,
  serial,
  text,
  time,
  timestamp,
  unique,
  varchar,
} from "drizzle-orm/pg-core";

// ─────────────────────────────────────────────
// Enums
// ─────────────────────────────────────────────
export const roleEnum = pgEnum("role", ["admin", "operator", "viewer"]);
export const lifecycleStateEnum = pgEnum("lifecycle_state", ["open", "updating", "closed"]);
export const stopClassEnum = pgEnum("stop_class_enum", ["choco", "doka", "planned_stop", "other"]);

// ─────────────────────────────────────────────
// users
// ─────────────────────────────────────────────
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  displayName: varchar("display_name", { length: 256 }), // ★DBに合わせて復活
  passwordHash: text("password_hash").notNull(),
  role: roleEnum("role").default("operator").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─────────────────────────────────────────────
// sessions  (Cookie セッション管理)
// ─────────────────────────────────────────────
export const sessions = pgTable("sessions", {
  id: varchar("id", { length: 64 }).primaryKey(), // nanoid(32)
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type Session = typeof sessions.$inferSelect;
export type InsertSession = typeof sessions.$inferInsert;

// ─────────────────────────────────────────────
// machines
// ─────────────────────────────────────────────
export const machines = pgTable("machines", {
  id: serial("id").primaryKey(),
  machineId: varchar("machine_id", { length: 128 }).notNull().unique(),
  displayName: varchar("display_name", { length: 256 }).notNull(),
  description: text("description"),
  location: varchar("location", { length: 256 }),
  sortOrder: integer("sort_order").default(0).notNull(),
  durChocoSec: integer("dur_choco_sec").default(300).notNull(),
  durDokaSec: integer("dur_doka_sec").default(1800).notNull(),
  timeStart: time("time_start"),
  timeEnd: time("time_end"),
  // breakTimes: [{ start: "HH:mm", end: "HH:mm" }]
  breakTimes: json("break_times").$type<Array<{ start: string; end: string }>>(),
  // 稼働率カラー閾値（null = システム設定を使用）
  operatingRateLowerLimit: integer("operating_rate_lower_limit"),
  operatingRateUpperLimit: integer("operating_rate_upper_limit"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type Machine = typeof machines.$inferSelect;
export type InsertMachine = typeof machines.$inferInsert;

// ─────────────────────────────────────────────
// node_api_keys
// ─────────────────────────────────────────────
export const nodeApiKeys = pgTable("node_api_keys", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 256 }).notNull().default(""),
  apiKey: varchar("api_key", { length: 64 }).notNull().unique(),
  machineId: varchar("machine_id", { length: 128 }), // nullable: 複数機械共用キーも許容
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  lastUsedAt: timestamp("last_used_at"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type NodeApiKey = typeof nodeApiKeys.$inferSelect;
export type InsertNodeApiKey = typeof nodeApiKeys.$inferInsert;

// ─────────────────────────────────────────────
// current_statuses  (machine_id 単位で最新1件のみ保持)
// ─────────────────────────────────────────────
export const currentStatuses = pgTable("current_statuses", {
  id: serial("id").primaryKey(),
  machineId: varchar("machine_id", { length: 128 }).notNull().unique(),
  currentState: varchar("current_state", { length: 64 }).notNull(),
  stopClass: varchar("stop_class", { length: 64 }),
  eventTime: timestamp("event_time"),
  // alarm: boolean/string 両方受信するため text で保存
  alarm: text("alarm"),
  // schedule_violation: string/null で受信するため text で保存（boolean ではない）
  scheduleViolation: text("schedule_violation"),
  timeZone: varchar("time_zone", { length: 64 }),
  schemaVersion: varchar("schema_version", { length: 32 }),
  // raw_payload_json: 正規化前の req.body をそのまま保存
  rawPayloadJson: json("raw_payload_json"),
  lastReceivedAt: timestamp("last_received_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type CurrentStatus = typeof currentStatuses.$inferSelect;
export type InsertCurrentStatus = typeof currentStatuses.$inferInsert;

// ─────────────────────────────────────────────
// stop_events  (eventId 単位で lifecycle 管理)
// ─────────────────────────────────────────────
export const stopEvents = pgTable("stop_events", {
  id: serial("id").primaryKey(),
  eventId: varchar("event_id", { length: 256 }).notNull().unique(),
  machineId: varchar("machine_id", { length: 128 }).notNull(),
  lifecycleState: lifecycleStateEnum("lifecycle_state").default("open").notNull(),
  stopClass: varchar("stop_class", { length: 64 }),
  finalStopClass: varchar("final_stop_class", { length: 64 }),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  // dokaAt: ドカ停移行時刻（ノード互換拡張フィールド）
  dokaAt: timestamp("doka_at"),
  lastUpdateTime: timestamp("last_update_time"),
  elapsedSec: integer("elapsed_sec"),
  finalStopDurationSec: integer("final_stop_duration_sec"),
  closeReason: varchar("close_reason", { length: 256 }),
  // reason_code: stop_reason_master.reason_code を参照（外部キー制約なし・柔軟性優先）
  reasonCode: varchar("reason_code", { length: 128 }),
  operatorNote: text("operator_note"),
  tags: text("tags"),
  // raw_payload_json: 正規化前の req.body をそのまま保存
  rawPayloadJson: json("raw_payload_json"),
  schemaVersion: varchar("schema_version", { length: 32 }), // ★DBに合わせて復活
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type StopEvent = typeof stopEvents.$inferSelect;
export type InsertStopEvent = typeof stopEvents.$inferInsert;

// ─────────────────────────────────────────────
// period_logs  (machine_id + period_start + period_end で upsert)
// ─────────────────────────────────────────────
export const periodLogs = pgTable(
  "period_logs",
  {
    id: serial("id").primaryKey(),
    machineId: varchar("machine_id", { length: 128 }).notNull(),
    periodStart: timestamp("period_start").notNull(),
    periodEnd: timestamp("period_end").notNull(),
    runningSeconds: integer("running_seconds"),
    idleSeconds: integer("idle_seconds"),
    // stopped_seconds: stoppedSeconds / stopSeconds どちらで受信しても正規化して保存
    stoppedSeconds: integer("stopped_seconds"),
    // choco_seconds / doka_seconds: ノード互換拡張フィールド（raw_payload_json にも保存）
    chocoSeconds: integer("choco_seconds"),
    dokaSeconds: integer("doka_seconds"),
    plannedStopSeconds: integer("planned_stop_seconds"),
    productionCount: integer("production_count"),
    targetProductionCount: integer("target_production_count"),
    schemaVersion: varchar("schema_version", { length: 32 }),
    // raw_payload_json: 正規化前の req.body（chocoSeconds/dokaSeconds 等を含む）
    rawPayloadJson: json("raw_payload_json"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  table => [unique("period_logs_unique").on(table.machineId, table.periodStart, table.periodEnd)]
);
export type PeriodLog = typeof periodLogs.$inferSelect;
export type InsertPeriodLog = typeof periodLogs.$inferInsert;

// ─────────────────────────────────────────────
// stop_reason_master
// ─────────────────────────────────────────────
export const stopReasonMaster = pgTable("stop_reason_master", {
  id: serial("id").primaryKey(),
  reasonCode: varchar("reason_code", { length: 128 }).notNull().unique(),
  displayName: varchar("display_name", { length: 256 }).notNull(),
  stopClass: stopClassEnum("stop_class"),
  sortOrder: integer("sort_order").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type StopReasonMaster = typeof stopReasonMaster.$inferSelect;
export type InsertStopReasonMaster = typeof stopReasonMaster.$inferInsert;

// ─────────────────────────────────────────────
// dashboard_layouts  (ユーザーごとの並び順・表示/非表示を保存)
// ─────────────────────────────────────────────
export const dashboardLayouts = pgTable("dashboard_layouts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  layoutName: varchar("layout_name", { length: 128 }).default("default").notNull(),
  // layout_json: [{ machineId: string, position: number, visible: boolean }]
  layoutJson: json("layout_json")
    .$type<Array<{ machineId: string; position: number; visible: boolean }>>()
    .notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type DashboardLayout = typeof dashboardLayouts.$inferSelect;
export type InsertDashboardLayout = typeof dashboardLayouts.$inferInsert;

// ─────────────────────────────────────────────
// audit_logs
// ─────────────────────────────────────────────
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"), // nullable: システム操作・ノードAPI受信はnull
  username: varchar("username", { length: 64 }), // ★DBに合わせて復活
  action: varchar("action", { length: 128 }).notNull(),
  targetType: varchar("target_type", { length: 64 }),
  targetId: varchar("target_id", { length: 256 }),
  detail: json("detail"),
  ipAddress: varchar("ip_address", { length: 64 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// ─────────────────────────────────────────────
// system_settings (システム全体の共通設定) ★今回追加したい機能
// ─────────────────────────────────────────────
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  operatingRateLowerLimit: integer("operating_rate_lower_limit").default(30).notNull(), // 下限のデフォルト 30%
  operatingRateUpperLimit: integer("operating_rate_upper_limit").default(80).notNull(), // 上限のデフォルト 80%
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;
