# Factory Dashboard - TODO

## Phase 2: Project Setup & DB Config
- [x] PostgreSQL対応（drizzle postgres設定）※ 環境はTiDB Cloud/MySQL互換で実装、スキーマはPostgreSQL準拠設計
- [x] DBスキーマ全テーブル定義（users, machines, node_api_keys, current_statuses, stop_events, period_logs, stop_reason_master, dashboard_layouts, audit_logs）
- [x] 任意テーブル方針確認：daily_records（日次集計キャッシュ）は将来拡張用として設計のみ記録
- [x] マイグレーション実行（SQLスクリプト直接実行）
- [x] 初回起動時adminユーザー自動作成ロジック（/setup エンドポイント）

## Phase 3: Backend API

### 認証（Cookie セッション方式）
- [x] ローカル認証：username/password + bcrypt ハッシュ
- [x] HttpOnly Cookie セッション発行（JWT ではなくセッションID）
- [x] logout でセッション破棄
- [x] 認証tRPCルーター（login/logout/me）
- [x] 未認証ガード（protectedProcedure）

### ノード端末向け REST API（tRPC 化しない・明示的な REST 契約）
- [x] POST /api/node/current-status（Bearer API Key 認証）
  - [x] zod スキーマ定義（passthrough で unknown field 許容）
  - [x] 必須: machineId, currentState
  - [x] タイムスタンプ: eventTime または sampleTime のどちらかを受理（両方来た場合は eventTime 優先、なければサーバー時刻）
  - [x] optional: stopClass, alarm（boolean/string 両方受理）, timeZone, scheduleViolation（string/null）, schemaVersion
  - [x] raw_payload_json にバリデーション前の生データを保存
  - [x] machine_id 単位で upsert（最新1件保持）
  - [x] event_time 更新条件の整理（古いデータで上書きしない）
- [x] POST /api/node/stop-event（Bearer API Key 認証）
  - [x] zod スキーマ定義（passthrough で unknown field 許容）
  - [x] 必須: eventId, machineId, action
  - [x] optional（既存）: startTime, updateTime, endTime, stopClass, finalStopClass, elapsedSec, finalStopDurationSec, closeReason, reasonCode, schemaVersion
  - [x] optional（ノード互換）: segmentStart, dokaAt, segmentEnd, currentStopElapsedSec, thresholdSec, isClosed
  - [x] サーバー側正規化: start_time = startTime ?? segmentStart、end_time = endTime ?? segmentEnd
  - [x] raw_payload_json にバリデーション前の生データを保存
  - [x] eventId 単位 lifecycle 管理（open=新規作成 / update=更新 / close=確定）
- [x] POST /api/node/period-log（Bearer API Key 認証）
  - [x] zod スキーマ定義（passthrough で unknown field 許容）
  - [x] 必須: machineId, periodStart, periodEnd
  - [x] optional（既存）: runningSeconds, idleSeconds, stoppedSeconds, plannedStopSeconds, productionCount, targetProductionCount, schemaVersion
  - [x] optional（ノード互換）: stopSeconds（stoppedSeconds の別名）, chocoSeconds, dokaSeconds
  - [x] サーバー側正規化: stopped_seconds = stoppedSeconds ?? stopSeconds
  - [x] chocoSeconds / dokaSeconds は choco_seconds/doka_seconds カラムに保存（raw_payload_json にも保存）
  - [x] raw_payload_json にバリデーション前の生データを保存
  - [x] machineId + periodStart + periodEnd で upsert
- [x] ノードAPIキー認証ミドルウェア（Authorization: Bearer <api_key>、失敗時401）

### 管理 UI 向け tRPC ルーター
- [x] 機械マスターCRUD tRPCルーター
- [x] 停止イベント管理tRPCルーター（UI側のみ：一覧取得・詳細取得・タグ付け・note更新・reasonCode更新）
  ※ open/update/close はノードREST APIの責務、UI側では行わない
- [x] current_statuses 取得tRPCルーター
  - [x] machine_id 単位で最新1件取得
  - [x] 最終受信時刻から通信状態判定（例：5分以上未受信 = 通信断）
- [x] ダッシュボードレイアウト保存tRPCルーター
  - [x] ユーザーごとの並び順保存
  - [x] 表示/非表示保存
  - [x] 次回ログイン時に同じ配置で復元
- [x] APIキー管理tRPCルーター（発行・無効化・一覧）
- [x] 集計tRPCルーター（日次・週次・月次・期間指定）
- [x] CSV出力エンドポイント
- [x] 監査ログ記録ヘルパー（ユーザー操作・ログイン履歴・変更履歴）
- [x] ユーザー管理tRPCルーター（Admin専用）
- [x] 停止理由マスターtRPCルーター

## Phase 4: Frontend
- [x] グローバルデザインテーマ設定（ダークテーマ、elegant style）
- [x] ローカルログイン画面（username/password、Manus OAuth不使用）
- [x] DashboardLayout（サイドバーナビゲーション）
- [x] ダッシュボード（カンバンボード）画面
- [x] 機械カードコンポーネント（状態色分け：running=緑/choco=黄/doka=赤/planned_stop=青/off=灰）
- [x] ドラッグ&ドロップ並び替え機能（@dnd-kit）
- [x] 機械詳細画面（稼働率・各状態時間・生産数・通信状態）
- [x] 停止イベント一覧・タグ付け・備考更新画面
- [x] 機械マスター管理画面
- [x] ユーザー管理画面（Admin専用）
- [x] APIキー管理画面
- [x] 集計・レポート画面（日次・週次・月次・期間指定）
- [x] CSV出力ボタン
- [x] 監査ログ閲覧画面

## Phase 5: Testing & Polish
- [x] Vitestユニットテスト（Cookie認証・ノードAPI受信・集計ロジック）24テストパス
- [x] 通信状態インジケーター（最終更新からの経過時間）
- [x] エラーハンドリング・ローディング状態
- [ ] レスポンシブ対応確認（タブレット・モバイル）

## 将来拡張
- [ ] daily_records テーブル実装（日次集計キャッシュ）
- [ ] chocoSeconds/dokaSeconds を daily_records で活用
- [ ] WebSocket/SSE によるリアルタイムプッシュ通知
- [ ] 停止理由マスターとの自動マッチング

## バグ修正
- [ ] setupページが何度もアクセスできる（admin存在チェックが機能していない）
- [ ] setupで作成したユーザーでログインできない（DB書き込みまたはセッション発行の不具合）
- [ ] setupページのリダイレクト先修正

## ローカル独立稼働対応
- [x] Manus OAuth依存を完全除去（VITE_OAUTH_PORTAL_URL等の参照を削除）
- [x] フロントエンドのInvalid URLエラー修正（Manus OAuth URL参照箇所を全て除去）
- [x] DBをローカルPostgreSQL対応に変更（drizzle postgres-js ドライバー使用）
- [x] .env.example ファイル作成（ローカル起動に必要な環境変数一覧）
- [x] JWT_SECRET をローカル環境変数から読み込む（Manus注入に依存しない）
- [x] セッションCookieのSameSite設定をローカル環境向けに修正（Lax/Strict）
- [x] setupページのadmin存在チェック修正（DB接続前に正しく判定）
- [x] ローカル起動手順README作成（PostgreSQL準備・.env設定・npm run build・npm start）
- [x] npm run build が通ることを確認（Manus固有プラグイン依存を除去）
- [x] TypeScriptエラー修正（ENV型にforgeApiUrl等を追加）
- [x] セットアップスクリプト作成（setup-local.sh, scripts/setup-db.mjs）
- [x] systemdサービス登録スクリプト作成（scripts/install-service.sh）
- [x] E2Eテスト全12項目パス（login/auth/current-status/stop-event/period-log/invalid-key等）
