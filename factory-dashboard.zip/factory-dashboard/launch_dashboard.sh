#!/bin/bash

# 1. サーバー(localhost:3000)が立ち上がるまで1秒おきにチェック
echo "Waiting for Node.js server..."
until $(curl --output /dev/null --silent --head --fail http://localhost:3000); do
    sleep 1
done

echo "Server is ready! Launching Chromium..."

# 2. Chromiumをキオスクモードで起動
# --kiosk: 全画面
# --incognito: 終了時のエラー警告などを防ぐ
# --noerrdialogs: エラーダイアログ非表示
chromium --kiosk --incognito --noerrdialogs --disable-infobars http://localhost:3000
