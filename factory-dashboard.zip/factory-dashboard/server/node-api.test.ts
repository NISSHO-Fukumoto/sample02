/**
 * Node API schema validation tests
 * Tests the zod schemas used in the node REST API endpoints
 */
import { describe, expect, it } from "vitest";
import { z } from "zod";

// ── Replicate the zod schemas from server/routes/nodeApi.ts ──────────────────

const currentStatusSchema = z
  .object({
    machineId: z.string().min(1),
    currentState: z.string().min(1),
    // Accept both eventTime and sampleTime; eventTime takes priority
    eventTime: z.string().datetime({ offset: true }).optional().nullable(),
    sampleTime: z.string().datetime({ offset: true }).optional().nullable(),
    stopClass: z.string().optional().nullable(),
    alarm: z.union([z.boolean(), z.string()]).optional().nullable(),
    timeZone: z.string().optional().nullable(),
    scheduleViolation: z.string().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
  })
  .passthrough();

const stopEventSchema = z
  .object({
    eventId: z.string().min(1),
    machineId: z.string().min(1),
    action: z.enum(["open", "update", "close"]),
    startTime: z.string().datetime({ offset: true }).optional().nullable(),
    updateTime: z.string().datetime({ offset: true }).optional().nullable(),
    endTime: z.string().datetime({ offset: true }).optional().nullable(),
    segmentStart: z.string().datetime({ offset: true }).optional().nullable(),
    segmentEnd: z.string().datetime({ offset: true }).optional().nullable(),
    dokaAt: z.string().datetime({ offset: true }).optional().nullable(),
    stopClass: z.string().optional().nullable(),
    finalStopClass: z.string().optional().nullable(),
    elapsedSec: z.number().optional().nullable(),
    currentStopElapsedSec: z.number().optional().nullable(),
    finalStopDurationSec: z.number().optional().nullable(),
    thresholdSec: z.number().optional().nullable(),
    isClosed: z.boolean().optional().nullable(),
    closeReason: z.string().optional().nullable(),
    reasonCode: z.string().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
  })
  .passthrough();

const periodLogSchema = z
  .object({
    machineId: z.string().min(1),
    periodStart: z.string().datetime({ offset: true }),
    periodEnd: z.string().datetime({ offset: true }),
    runningSeconds: z.number().optional().nullable(),
    idleSeconds: z.number().optional().nullable(),
    stoppedSeconds: z.number().optional().nullable(),
    stopSeconds: z.number().optional().nullable(), // alias for stoppedSeconds
    plannedStopSeconds: z.number().optional().nullable(),
    productionCount: z.number().optional().nullable(),
    targetProductionCount: z.number().optional().nullable(),
    chocoSeconds: z.number().optional().nullable(),
    dokaSeconds: z.number().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
  })
  .passthrough();

// ── Tests ────────────────────────────────────────────────────────────────────

describe("current-status schema", () => {
  it("accepts minimal required fields", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "running",
    });
    expect(result.success).toBe(true);
  });

  it("accepts eventTime and sampleTime both present", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "stopped",
      eventTime: "2025-01-01T00:00:00+09:00",
      sampleTime: "2025-01-01T00:00:01+09:00",
    });
    expect(result.success).toBe(true);
  });

  it("accepts alarm as boolean", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "stopped",
      alarm: true,
    });
    expect(result.success).toBe(true);
  });

  it("accepts alarm as string", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "stopped",
      alarm: "E-001",
    });
    expect(result.success).toBe(true);
  });

  it("accepts scheduleViolation as string", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "running",
      scheduleViolation: "OVERTIME",
    });
    expect(result.success).toBe(true);
  });

  it("passes through unknown fields", () => {
    const result = currentStatusSchema.safeParse({
      machineId: "MC-001",
      currentState: "running",
      unknownField: "value",
      anotherField: 42,
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect((result.data as Record<string, unknown>).unknownField).toBe("value");
    }
  });

  it("rejects missing machineId", () => {
    const result = currentStatusSchema.safeParse({
      currentState: "running",
    });
    expect(result.success).toBe(false);
  });
});

describe("stop-event schema", () => {
  it("accepts open action with startTime", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "open",
      startTime: "2025-01-01T08:00:00+09:00",
    });
    expect(result.success).toBe(true);
  });

  it("accepts segmentStart as alternative to startTime", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "open",
      segmentStart: "2025-01-01T08:00:00+09:00",
    });
    expect(result.success).toBe(true);
  });

  it("accepts close action with isClosed flag", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "close",
      isClosed: true,
      endTime: "2025-01-01T09:00:00+09:00",
      finalStopDurationSec: 3600,
    });
    expect(result.success).toBe(true);
  });

  it("accepts update action with currentStopElapsedSec and thresholdSec", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "update",
      currentStopElapsedSec: 120,
      thresholdSec: 300,
    });
    expect(result.success).toBe(true);
  });

  it("rejects invalid action", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "invalid",
    });
    expect(result.success).toBe(false);
  });

  it("passes through unknown fields", () => {
    const result = stopEventSchema.safeParse({
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "open",
      customField: "custom_value",
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect((result.data as Record<string, unknown>).customField).toBe("custom_value");
    }
  });
});

describe("period-log schema", () => {
  it("accepts minimal required fields", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
    });
    expect(result.success).toBe(true);
  });

  it("accepts stopSeconds as alias for stoppedSeconds", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
      stopSeconds: 1800,
    });
    expect(result.success).toBe(true);
  });

  it("accepts both stoppedSeconds and stopSeconds", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
      stoppedSeconds: 1800,
      stopSeconds: 1800,
    });
    expect(result.success).toBe(true);
  });

  it("accepts chocoSeconds and dokaSeconds", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
      chocoSeconds: 600,
      dokaSeconds: 1200,
    });
    expect(result.success).toBe(true);
  });

  it("passes through unknown fields", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
      extraField: "extra",
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect((result.data as Record<string, unknown>).extraField).toBe("extra");
    }
  });

  it("rejects missing periodStart", () => {
    const result = periodLogSchema.safeParse({
      machineId: "MC-001",
      periodEnd: "2025-01-01T08:00:00+09:00",
    });
    expect(result.success).toBe(false);
  });
});

describe("server-side normalization logic", () => {
  it("eventTime takes priority over sampleTime", () => {
    const raw = {
      machineId: "MC-001",
      currentState: "running",
      eventTime: "2025-01-01T08:00:00+09:00",
      sampleTime: "2025-01-01T08:00:01+09:00",
    };
    const parsed = currentStatusSchema.parse(raw);
    // Normalization: use eventTime if present
    const resolvedTime = parsed.eventTime ?? parsed.sampleTime ?? null;
    expect(resolvedTime).toBe("2025-01-01T08:00:00+09:00");
  });

  it("falls back to sampleTime when eventTime is absent", () => {
    const raw = {
      machineId: "MC-001",
      currentState: "running",
      sampleTime: "2025-01-01T08:00:01+09:00",
    };
    const parsed = currentStatusSchema.parse(raw);
    const resolvedTime = parsed.eventTime ?? parsed.sampleTime ?? null;
    expect(resolvedTime).toBe("2025-01-01T08:00:01+09:00");
  });

  it("normalizes stopSeconds to stoppedSeconds", () => {
    const raw = {
      machineId: "MC-001",
      periodStart: "2025-01-01T00:00:00+09:00",
      periodEnd: "2025-01-01T08:00:00+09:00",
      stopSeconds: 1800,
    };
    const parsed = periodLogSchema.parse(raw);
    const resolvedStopped = parsed.stoppedSeconds ?? parsed.stopSeconds ?? null;
    expect(resolvedStopped).toBe(1800);
  });

  it("normalizes segmentStart to startTime for stop events", () => {
    const raw = {
      eventId: "EVT-001",
      machineId: "MC-001",
      action: "open" as const,
      segmentStart: "2025-01-01T08:00:00+09:00",
    };
    const parsed = stopEventSchema.parse(raw);
    const resolvedStart = parsed.startTime ?? parsed.segmentStart ?? null;
    expect(resolvedStart).toBe("2025-01-01T08:00:00+09:00");
  });
});
