import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import { createApiKey, listApiKeys, revokeApiKey, writeAuditLog } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const apiKeysRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    return listApiKeys();
  }),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(256),
        machineId: z.string().max(128).optional().nullable(),
        description: z.string().max(256).optional().nullable(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const apiKey = `fk_${nanoid(40)}`;
      const record = await createApiKey({
        name: input.name,
        machineId: input.machineId ?? null,
        apiKey,
        description: input.description ?? null,
        isActive: true,
      });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "apiKey.create",
        targetType: "node_api_key",
        targetId: String(record.id),
        detail: { name: input.name, description: input.description, machineId: input.machineId },
        ipAddress: ctx.req.ip,
      });
      // Return full key only on creation
      return { ...record, apiKey };
    }),

  revoke: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const record = await revokeApiKey(input.id);
      if (!record) throw new TRPCError({ code: "NOT_FOUND" });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "apiKey.revoke",
        targetType: "node_api_key",
        targetId: String(input.id),
        detail: {},
        ipAddress: ctx.req.ip,
      });
      return { success: true };
    }),
});
