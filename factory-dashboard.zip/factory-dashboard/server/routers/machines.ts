import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createMachine, deleteMachine, getMachineById, listMachines, updateMachine, writeAuditLog } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const machinesRouter = router({
  list: protectedProcedure.query(async () => {
    return listMachines(false);
  }),
  create: protectedProcedure.input(z.any()).mutation(async ({ input, ctx }) => {
    const machine = await createMachine(input);
    await writeAuditLog({
      userId: ctx.user.id,
      action: "machine.create",
      targetType: "machine",
      targetId: machine.machineId,
      detail: input,
      ipAddress: ctx.req.ip,
    });
    return machine;
  }),
  update: protectedProcedure.input(z.object({ id: z.number().int() }).passthrough()).mutation(async ({ input, ctx }) => {
    const { id, ...data } = input;
    const updated = await updateMachine(id, data);
    await writeAuditLog({
      userId: ctx.user.id,
      action: "machine.update",
      targetType: "machine",
      targetId: updated.machineId,
      detail: data,
      ipAddress: ctx.req.ip,
    });
    return updated;
  }),
  delete: protectedProcedure.input(z.object({ id: z.number().int() })).mutation(async ({ input, ctx }) => {
    const existing = await getMachineById(input.id);
    if (!existing) throw new TRPCError({ code: "NOT_FOUND" });

    // 物理的に削除
    await deleteMachine(input.id);

    await writeAuditLog({
      userId: ctx.user.id,
      action: "machine.delete",
      targetType: "machine",
      targetId: existing.machineId,
      detail: { displayName: existing.displayName },
      ipAddress: ctx.req.ip,
    });
    return { success: true };
  }),
});
