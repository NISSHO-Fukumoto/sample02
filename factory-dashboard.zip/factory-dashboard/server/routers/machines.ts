import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createMachine,
  deleteMachine,
  getMachineById,
  listMachines,
  updateMachine,
  writeAuditLog,
} from "../db";
import { protectedProcedure, router } from "../_core/trpc";

const breakTimeSchema = z.object({ start: z.string(), end: z.string() });

const machineInputSchema = z.object({
  machineId: z.string().min(1).max(128),
  displayName: z.string().min(1).max(256),
  description: z.string().optional().nullable(),
  location: z.string().max(256).optional().nullable(),
  sortOrder: z.number().int().optional(),
  durChocoSec: z.number().int().positive().optional(),
  durDokaSec: z.number().int().positive().optional(),
  timeStart: z.string().optional().nullable(),
  timeEnd: z.string().optional().nullable(),
  breakTimes: z.array(breakTimeSchema).optional().nullable(),
  isActive: z.boolean().optional(),
});

export const machinesRouter = router({
  list: protectedProcedure
    .input(z.object({ activeOnly: z.boolean().optional() }).optional())
    .query(async ({ input }) => {
      return listMachines(input?.activeOnly ?? false);
    }),

  create: protectedProcedure
    .input(machineInputSchema)
    .mutation(async ({ input, ctx }) => {
      const machine = await createMachine(input);
      await writeAuditLog({
        userId: ctx.user.id,
        action: "machine.create",
        targetType: "machine",
        targetId: machine.machineId,
        detail: { displayName: machine.displayName },
        ipAddress: ctx.req.ip,
      });
      return machine;
    }),

  update: protectedProcedure
    .input(z.object({ id: z.number().int() }).merge(machineInputSchema.partial()))
    .mutation(async ({ input, ctx }) => {
      const { id, ...data } = input;
      const existing = await getMachineById(id);
      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
      const updated = await updateMachine(id, data);
      await writeAuditLog({
        userId: ctx.user.id,
        action: "machine.update",
        targetType: "machine",
        targetId: existing.machineId,
        detail: data,
        ipAddress: ctx.req.ip,
      });
      return updated;
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input, ctx }) => {
      const existing = await getMachineById(input.id);
      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
      // 物理削除の代わりに is_active = false で論理削除
      await updateMachine(input.id, { isActive: false });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "machine.delete",
        targetType: "machine",
        targetId: existing.machineId,
        detail: { displayName: existing.displayName },
        ipAddress: ctx.req.ip,
      });
      return { success: true };
    }),
});
