import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { createUser, listUsers, updateUser, deleteUser, getUserById, writeAuditLog } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const usersAdminRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const users = await listUsers();
    return users.map(({ passwordHash: _ph, ...safe }) => safe);
  }),
  create: protectedProcedure.input(z.any()).mutation(async ({ input, ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await createUser({
      username: input.username,
      passwordHash,
      role: input.role,
      isActive: true,
    });
    return user;
  }),
  update: protectedProcedure.input(z.object({ id: z.number().int() }).passthrough()).mutation(async ({ input, ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const { id, password, ...rest } = input;
    const data: any = { ...rest };
    if (password) {
      data.passwordHash = await bcrypt.hash(password, 12);
    }
    return await updateUser(id, data);
  }),
  delete: protectedProcedure.input(z.object({ id: z.number().int() })).mutation(async ({ input, ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const target = await getUserById(input.id);
    if (!target) throw new TRPCError({ code: "NOT_FOUND" });

    if (target.username === "admin") {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "デフォルトの管理者(admin)は削除できません。",
      });
    }

    // 物理的に削除
    await deleteUser(input.id);

    await writeAuditLog({
      userId: ctx.user.id,
      action: "user.delete",
      targetType: "user",
      targetId: String(input.id),
      detail: { username: target.username },
      ipAddress: ctx.req.ip,
    });
    return { success: true };
  }),
});
