import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { createUser, listUsers, updateUser, writeAuditLog } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const usersAdminRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
    const users = await listUsers();
    return users.map(({ passwordHash: _ph, ...safe }) => safe);
  }),

  create: protectedProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(8).max(128),
        role: z.enum(["admin", "operator", "viewer"]).default("operator"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const passwordHash = await bcrypt.hash(input.password, 12);
      const user = await createUser({
        username: input.username,
        passwordHash,
        role: input.role,
        isActive: true,
      });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "user.create",
        targetType: "user",
        targetId: String(user.id),
        detail: { username: input.username, role: input.role },
        ipAddress: ctx.req.ip,
      });
      const { passwordHash: _ph, ...safe } = user;
      return safe;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number().int(),
        role: z.enum(["admin", "operator", "viewer"]).optional(),
        isActive: z.boolean().optional(),
        password: z.string().min(8).max(128).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const { id, password, ...rest } = input;
      const updateData: Record<string, unknown> = { ...rest };
      if (password) {
        updateData.passwordHash = await bcrypt.hash(password, 12);
      }
      const updated = await updateUser(id, updateData as Parameters<typeof updateUser>[1]);
      if (!updated) throw new TRPCError({ code: "NOT_FOUND" });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "user.update",
        targetType: "user",
        targetId: String(id),
        detail: rest,
        ipAddress: ctx.req.ip,
      });
      const { passwordHash: _ph, ...safe } = updated;
      return safe;
    }),
});
