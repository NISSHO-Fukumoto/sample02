import { z } from "zod";
import {
  getDashboardLayout,
  listCurrentStatuses,
  listMachines,
  listPeriodLogs,
  saveDashboardLayout,
} from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const dashboardRouter = router({
  /** ダッシュボード表示用: 機械一覧 + 最新ステータス + 本日の集計を結合して返す */
  overview: protectedProcedure.query(async () => {
    const [machines, statuses] = await Promise.all([
      listMachines(true),
      listCurrentStatuses(),
    ]);

    // =================================================================
    // 1. データベース(period_logs)から「本日の真の実績」を計算する
    // =================================================================
    const today = new Date();
    today.setHours(0, 0, 0, 0); 
    const todayLogs = await listPeriodLogs({ from: today });

    // ★修正箇所: choco と doka を集計用の型に追加
    const trueSums = new Map<string, { prod: number, run: number, stop: number, plan: number, idle: number, choco: number, doka: number }>();
    
    for (const log of todayLogs) {
      if (!trueSums.has(log.machineId)) {
        // ★修正箇所: 初期値に choco: 0, doka: 0 を追加
        trueSums.set(log.machineId, { prod: 0, run: 0, stop: 0, plan: 0, idle: 0, choco: 0, doka: 0 });
      }
      const s = trueSums.get(log.machineId)!;
      s.prod += log.productionCount ?? 0;
      s.run += log.runningSeconds ?? 0;
      s.stop += log.stoppedSeconds ?? 0;
      s.plan += log.plannedStopSeconds ?? 0;
      s.idle += log.idleSeconds ?? 0;
      // ★修正箇所: DBのログから chocoSeconds と dokaSeconds を合算する
      s.choco += log.chocoSeconds ?? 0;
      s.doka += log.dokaSeconds ?? 0;
    }

    const statusMap = new Map(statuses.map((s) => [s.machineId, s]));

    // =================================================================
    // 2. 画面に渡すデータを組み立てる
    // =================================================================
    return machines.map(m => {
      // ★修正箇所: fallbackの初期値にも choco: 0, doka: 0 を追加
      const sums = trueSums.get(m.machineId) || { prod: 0, run: 0, stop: 0, plan: 0, idle: 0, choco: 0, doka: 0 };
      const status = statusMap.get(m.machineId);

      return {
        ...m,
        // currentStatus 内の updatedAt を ISO 形式 (Z付き) に変換
        // これによりブラウザ側で正しい日本時間に復元されます
        currentStatus: status ? {
          ...status,
          updatedAt: status.updatedAt instanceof Date 
            ? status.updatedAt.toISOString() 
            : new Date(status.updatedAt).toISOString()
        } : null,
        
        todaySummary: {
          runningSeconds: sums.run,
          stoppedSeconds: sums.stop,
          plannedStopSeconds: sums.plan,
          idleSeconds: sums.idle,
          productionCount: sums.prod,
          // ★修正箇所: フロントエンドにチョコ停とドカ停の秒数を渡す
          chocoSeconds: sums.choco,
          dokaSeconds: sums.doka,
        }
      };
    });
  }),

  /** ユーザー別レイアウト取得 */
  getLayout: protectedProcedure
    .input(z.object({ layoutName: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => {
      return getDashboardLayout(ctx.user.id, input?.layoutName ?? "default");
    }),

  /** ユーザー別レイアウト保存 */
  saveLayout: protectedProcedure
    .input(
      z.object({
        layoutName: z.string().optional(),
        layout: z.array(
          z.object({
            machineId: z.string(),
            position: z.number(),
            visible: z.boolean(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      return saveDashboardLayout(
        ctx.user.id,
        input.layout,
        input.layoutName ?? "default"
      );
    }),
});