import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  getStopEventByEventId,
  listStopEvents,
  listStopReasons,
  updateStopEventMeta,
  writeAuditLog,
  upsertStopEvent, // ★新規追加: db.tsから書き込み関数をインポート
} from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const stopEventsRouter = router({
  /** 停止イベント一覧（フィルタ付き） */
  list: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        lifecycleState: z.enum(["open", "updating", "closed"]).optional(),
        from: z.date().optional(),
        to: z.date().optional(),
        limit: z.number().int().min(1).max(500).optional(),
        offset: z.number().int().min(0).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      return listStopEvents(input);
    }),

  /** 停止イベント詳細 */
  get: protectedProcedure
    .input(z.object({ eventId: z.string() }))
    .query(async ({ input }) => {
      const event = await getStopEventByEventId(input.eventId);
      if (!event) throw new TRPCError({ code: "NOT_FOUND" });
      return event;
    }),

  /** タグ・ノート・理由コード更新（UI側のみ） */
  updateMeta: protectedProcedure
    .input(
      z.object({
        id: z.number().int(),
        tags: z.string().max(256).optional().nullable(),
        operatorNote: z.string().optional().nullable(),
        reasonCode: z.string().max(128).optional().nullable(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { id, ...data } = input;
      const updated = await updateStopEventMeta(id, data);
      if (!updated) throw new TRPCError({ code: "NOT_FOUND" });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "stopEvent.updateMeta",
        targetType: "stop_event",
        targetId: String(id),
        detail: data,
        ipAddress: ctx.req.ip,
      });
      return updated;
    }),

  /** 停止理由マスター一覧 */
  listReasons: protectedProcedure
    .input(z.object({ activeOnly: z.boolean().optional() }).optional())
    .query(async ({ input }) => {
      return listStopReasons(input?.activeOnly ?? true);
    }),

  // =======================================================================
  // ★新規追加: 外部ノード（Python等）からの停止イベント送信（UPSERT）窓口
  // =======================================================================
  upsertStopEvent: protectedProcedure
    .input(
      z.object({
        eventId: z.string(),
        machineId: z.string(),
        action: z.string(), // "open" または "close"
        data: z.any().optional(), // 停止理由などの付加データ
      })
    )
    .mutation(async ({ input }) => {
      await upsertStopEvent(input.eventId, input.machineId, input.action, input.data);
      return { success: true };
    }),
});