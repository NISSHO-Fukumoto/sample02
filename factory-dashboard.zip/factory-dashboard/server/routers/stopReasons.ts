import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createStopReason, listStopReasons, updateStopReason, writeAuditLog } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const stopReasonsRouter = router({
  list: protectedProcedure
    .input(z.object({ activeOnly: z.boolean().optional() }).optional())
    .query(async ({ input }) => {
      return listStopReasons(input?.activeOnly ?? true);
    }),

  create: protectedProcedure
    .input(
      z.object({
        reasonCode: z.string().min(1).max(128),
        displayName: z.string().min(1).max(256),
        stopClass: z.enum(["choco", "doka", "planned_stop", "other"]).optional(),
        sortOrder: z.number().int().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const record = await createStopReason(input);
      await writeAuditLog({
        userId: ctx.user.id,
        action: "stopReason.create",
        targetType: "stop_reason_master",
        targetId: record.reasonCode,
        detail: input,
        ipAddress: ctx.req.ip,
      });
      return record;
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number().int(),
        displayName: z.string().min(1).max(256).optional(),
        sortOrder: z.number().int().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      const { id, ...data } = input;
      const updated = await updateStopReason(id, data);
      if (!updated) throw new TRPCError({ code: "NOT_FOUND" });
      await writeAuditLog({
        userId: ctx.user.id,
        action: "stopReason.update",
        targetType: "stop_reason_master",
        targetId: String(id),
        detail: data,
        ipAddress: ctx.req.ip,
      });
      return updated;
    }),
});
