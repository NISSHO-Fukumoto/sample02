import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { listAuditLogs } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const auditLogsRouter = router({
  list: protectedProcedure
    .input(
      z.object({
        limit: z.number().int().min(1).max(500).optional(),
        offset: z.number().int().min(0).optional(),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      return listAuditLogs(input);
    }),
});
