import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";
import { z } from "zod";
import { COOKIE_NAME } from "../../shared/const";
import {
  countAdminUsers,
  createSession,
  createUser,
  deleteSession,
  getUserByUsername,
  getUserById,
} from "../db";
import { getSessionCookieOptions } from "../_core/cookies";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

export const authRouter = router({
  /** ログイン中ユーザー情報取得 */
  me: publicProcedure.query(opts => {
    if (!opts.ctx.user) return null;
    const { passwordHash: _ph, ...safe } = opts.ctx.user;
    return safe;
  }),

  /** ローカルログイン（username + password） */
  login: publicProcedure
    .input(z.object({ username: z.string().min(1), password: z.string().min(1) }))
    .mutation(async ({ input, ctx }) => {
      const user = await getUserByUsername(input.username);
      if (!user || !user.isActive) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }
      const ok = await bcrypt.compare(input.password, user.passwordHash);
      if (!ok) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }
      const sessionId = nanoid(32);
      const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
      await createSession({ id: sessionId, userId: user.id, expiresAt });

      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionId, {
        ...cookieOptions,
        maxAge: SESSION_TTL_MS,
      });

      const { passwordHash: _ph, ...safe } = user;
      return { success: true, user: safe };
    }),

  /** ログアウト（セッション削除） */
  logout: publicProcedure.mutation(async ({ ctx }) => {
    const cookieHeader = ctx.req.headers.cookie ?? "";
    const pairs = cookieHeader.split(";").map(s => s.trim().split("="));
    const sessionId = pairs.find(p => p[0] === COOKIE_NAME)?.[1];
    if (sessionId) {
      await deleteSession(sessionId);
    }
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true };
  }),

  /** 初回セットアップ: admin ユーザーが存在しない場合のみ作成可能 */
  setupAdmin: publicProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(8).max(128),
      })
    )
    .mutation(async ({ input }) => {
      const adminCount = await countAdminUsers();
      if (adminCount > 0) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Admin user already exists",
        });
      }
      const passwordHash = await bcrypt.hash(input.password, 12);
      const user = await createUser({
        username: input.username,
        passwordHash,
        role: "admin",
        isActive: true,
      });
      const { passwordHash: _ph, ...safe } = user;
      return { success: true, user: safe };
    }),

  /** パスワード変更（自分自身のみ） */
  changePassword: protectedProcedure
    .input(
      z.object({
        currentPassword: z.string().min(1),
        newPassword: z.string().min(8).max(128),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const user = await getUserById(ctx.user.id);
      if (!user) throw new TRPCError({ code: "NOT_FOUND" });
      const ok = await bcrypt.compare(input.currentPassword, user.passwordHash);
      if (!ok) throw new TRPCError({ code: "UNAUTHORIZED", message: "Wrong current password" });
      const newHash = await bcrypt.hash(input.newPassword, 12);
      const { updateUser } = await import("../db");
      await updateUser(user.id, { passwordHash: newHash });
      return { success: true };
    }),
});
