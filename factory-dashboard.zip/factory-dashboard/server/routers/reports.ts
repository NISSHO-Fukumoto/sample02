import { z } from "zod";
import { listMachines, listPeriodLogs, listStopEvents, getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";
import { systemSettings } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

function startOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(0, 0, 0, 0);
  return r;
}
function endOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(23, 59, 59, 999);
  return r;
}

function getPeriodLabel(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" });
  } else if (groupBy === "weekly") {
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    return weekStart.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" }) + "週";
  } else {
    return date.toLocaleDateString("ja-JP", { year: "numeric", month: "2-digit" });
  }
}

function getPeriodKey(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toISOString().slice(0, 10);
  } else if (groupBy === "weekly") {
    const d = new Date(date);
    d.setDate(d.getDate() - d.getDay());
    return d.toISOString().slice(0, 10);
  } else {
    return date.toISOString().slice(0, 7);
  }
}

export const reportsRouter = router({
  /**
   * period_logs の生レコード一覧を返す（区間ごとの periodStart/periodEnd 付き）。
   * タイムライン表示で「実際にノードからデータが届いていた区間」を
   * 正確に再構築するために使用する（exportCsv は集計済みの1行しか
   * 返さないため、区間の位置情報が失われてしまう）。
   */
  periodLogsRaw: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      return listPeriodLogs({
        machineId: input.machineId,
        from: input.from,
        to: input.to,
      });
    }),

  getSettings: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("DB not available");

    let settings = await db.select().from(systemSettings).limit(1);
    if (settings.length === 0) {
      const [newSettings] = await db.insert(systemSettings).values({
        operatingRateLowerLimit: 30,
        operatingRateUpperLimit: 80,
        createdAt: new Date(),
        updatedAt: new Date()
      }).returning();
      return { lowerLimit: newSettings.operatingRateLowerLimit, upperLimit: newSettings.operatingRateUpperLimit };
    }
    return { lowerLimit: settings[0].operatingRateLowerLimit, upperLimit: settings[0].operatingRateUpperLimit };
  }),

  updateSettings: protectedProcedure
    .input(z.object({
      lowerLimit: z.number().min(0).max(100),
      upperLimit: z.number().min(0).max(100),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("DB not available");

      let settings = await db.select().from(systemSettings).limit(1);
      if (settings.length === 0) {
        await db.insert(systemSettings).values({
          operatingRateLowerLimit: input.lowerLimit,
          operatingRateUpperLimit: input.upperLimit,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      } else {
        await db.update(systemSettings)
          .set({
            operatingRateLowerLimit: input.lowerLimit,
            operatingRateUpperLimit: input.upperLimit,
            updatedAt: new Date(),
          })
          .where(eq(systemSettings.id, settings[0].id));
      }
      return { success: true };
    }),

  aggregate: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
        groupBy: z.enum(["daily", "weekly", "monthly"]).default("daily"),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }
      // ★ 修正: machineId をしっかり渡す
      const logs = await listPeriodLogs({ machineId: input.machineId, from: effectiveFrom, to: effectiveTo });

      const byPeriod = new Map<string, any>();
      for (const log of logs) {
        const date = new Date(log.periodStart);
        const key = getPeriodKey(date, input.groupBy);
        const existing = byPeriod.get(key);
        if (!existing) {
          byPeriod.set(key, {
            periodLabel: getPeriodLabel(date, input.groupBy),
            periodKey: key,
            totalRunningSeconds: log.runningSeconds ?? 0,
            totalStoppedSeconds: log.stoppedSeconds ?? 0,
            totalPlannedStopSeconds: log.plannedStopSeconds ?? 0,
            totalIdleSeconds: log.idleSeconds ?? 0,
            totalProductionCount: log.productionCount ?? 0,
            operatingRate: null,
          });
        } else {
          existing.totalRunningSeconds += log.runningSeconds ?? 0;
          existing.totalStoppedSeconds += log.stoppedSeconds ?? 0;
          existing.totalPlannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.totalIdleSeconds += log.idleSeconds ?? 0;
          existing.totalProductionCount += log.productionCount ?? 0;
        }
      }

      const result = Array.from(byPeriod.values()).sort((a, b) => a.periodKey.localeCompare(b.periodKey));
      for (const r of result) {
        const total = r.totalRunningSeconds + r.totalStoppedSeconds + r.totalPlannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.totalRunningSeconds / total) * 1000) / 10 : null;
      }
      return result;
    }),

  exportCsv: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }

      const logs = await listPeriodLogs({
        machineId: input.machineId,
        from: effectiveFrom,
        to: effectiveTo,
      });

      if (logs.length === 0) return [];

      const sumLog: any = { ...logs[logs.length - 1] };
      sumLog.runningSeconds = 0;
      sumLog.stoppedSeconds = 0;
      sumLog.idleSeconds = 0;
      sumLog.plannedStopSeconds = 0;
      sumLog.productionCount = 0;
      // ★修正: チョコ停・ドカ停の日次合計が集計されておらず、
      // 「最後の1件分（数十秒〜数分程度）」の値しか入っていなかったバグを修正。
      // これによりタイムラインの凡例（チョコ停/ドカ停の合計分数）が正しい値になる。
      sumLog.chocoSeconds = 0;
      sumLog.dokaSeconds = 0;

      for (const log of logs) {
        sumLog.runningSeconds += log.runningSeconds ?? 0;
        sumLog.stoppedSeconds += log.stoppedSeconds ?? 0;
        sumLog.idleSeconds += log.idleSeconds ?? 0;
        sumLog.plannedStopSeconds += log.plannedStopSeconds ?? 0;
        sumLog.productionCount += log.productionCount ?? 0;
        sumLog.chocoSeconds += (log as any).chocoSeconds ?? 0;
        sumLog.dokaSeconds += (log as any).dokaSeconds ?? 0;
      }

      if (sumLog.updatedAt) {
        sumLog.updatedAt = sumLog.updatedAt instanceof Date 
          ? sumLog.updatedAt.toISOString() 
          : new Date(sumLog.updatedAt).toISOString() as any;
      }

      return [sumLog];
    }),

  machineSummary: protectedProcedure
    .input(
      z.object({
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }

      const [logs, stopEvts, machines] = await Promise.all([
        listPeriodLogs({ from: effectiveFrom, to: effectiveTo }),
        listStopEvents({ from: effectiveFrom, to: effectiveTo }),
        listMachines(false),
      ]);

      const machineMap = new Map(machines.map(m => [m.machineId, m]));
      const byMachine = new Map<string, any>();

      for (const log of logs) {
        const machine = machineMap.get(log.machineId);
        const existing = byMachine.get(log.machineId);
        if (!existing) {
          byMachine.set(log.machineId, {
            machineId: log.machineId,
            machineName: machine?.displayName ?? log.machineId,
            runningSeconds: log.runningSeconds ?? 0,
            stoppedSeconds: log.stoppedSeconds ?? 0,
            plannedStopSeconds: log.plannedStopSeconds ?? 0,
            idleSeconds: log.idleSeconds ?? 0,
            productionCount: log.productionCount ?? 0,
            targetProductionCount: log.targetProductionCount ?? 0,
            chocoCount: 0,
            dokaCount: 0,
            chocoTotalSec: 0,
            dokaTotalSec: 0,
            operatingRate: null,
          });
        } else {
          existing.runningSeconds += log.runningSeconds ?? 0;
          existing.stoppedSeconds += log.stoppedSeconds ?? 0;
          existing.plannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.idleSeconds += log.idleSeconds ?? 0;
          existing.productionCount += log.productionCount ?? 0;
          existing.targetProductionCount += log.targetProductionCount ?? 0;
        }
      }

      for (const evt of stopEvts) {
        if (evt.lifecycleState !== "closed") continue;
        const entry = byMachine.get(evt.machineId);
        if (!entry) continue;
        const cls = evt.finalStopClass ?? evt.stopClass;
        const dur = evt.finalStopDurationSec ?? 0;
        if (cls === "choco") { entry.chocoCount++; entry.chocoTotalSec += dur; }
        else if (cls === "doka") { entry.dokaCount++; entry.dokaTotalSec += dur; }
      }

      const rows = Array.from(byMachine.values());
      for (const r of rows) {
        const total = r.runningSeconds + r.stoppedSeconds + r.plannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.totalRunningSeconds / total) * 1000) / 10 : null;
      }

      return rows;
    }),
});