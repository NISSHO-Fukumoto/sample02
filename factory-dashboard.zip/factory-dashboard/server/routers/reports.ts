import { z } from "zod";
import { listMachines, listPeriodLogs, listStopEvents } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

function startOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(0, 0, 0, 0);
  return r;
}
function endOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(23, 59, 59, 999);
  return r;
}

function getPeriodLabel(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" });
  } else if (groupBy === "weekly") {
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    return weekStart.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" }) + "週";
  } else {
    return date.toLocaleDateString("ja-JP", { year: "numeric", month: "2-digit" });
  }
}

function getPeriodKey(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toISOString().slice(0, 10);
  } else if (groupBy === "weekly") {
    const d = new Date(date);
    d.setDate(d.getDate() - d.getDay());
    return d.toISOString().slice(0, 10);
  } else {
    return date.toISOString().slice(0, 7);
  }
}

export const reportsRouter = router({
  aggregate: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
        groupBy: z.enum(["daily", "weekly", "monthly"]).default("daily"),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }
      const logs = await listPeriodLogs({ machineId: input.machineId, from: effectiveFrom, to: effectiveTo });

      const byPeriod = new Map<string, any>();
      for (const log of logs) {
        const date = new Date(log.periodStart);
        const key = getPeriodKey(date, input.groupBy);
        const existing = byPeriod.get(key);
        if (!existing) {
          byPeriod.set(key, {
            periodLabel: getPeriodLabel(date, input.groupBy),
            periodKey: key,
            totalRunningSeconds: log.runningSeconds ?? 0,
            totalStoppedSeconds: log.stoppedSeconds ?? 0,
            totalPlannedStopSeconds: log.plannedStopSeconds ?? 0,
            totalIdleSeconds: log.idleSeconds ?? 0,
            totalProductionCount: log.productionCount ?? 0,
            operatingRate: null,
          });
        } else {
          existing.totalRunningSeconds += log.runningSeconds ?? 0;
          existing.totalStoppedSeconds += log.stoppedSeconds ?? 0;
          existing.totalPlannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.totalIdleSeconds += log.idleSeconds ?? 0;
          existing.totalProductionCount += log.productionCount ?? 0;
        }
      }

      const result = Array.from(byPeriod.values()).sort((a, b) => a.periodKey.localeCompare(b.periodKey));
      for (const r of result) {
        const total = r.totalRunningSeconds + r.totalStoppedSeconds + r.totalPlannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.totalRunningSeconds / total) * 1000) / 10 : null;
      }
      return result;
    }),

  /** CSV エクスポート用データ（詳細画面のヘッダー表示用） */
  exportCsv: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }

      const logs = await listPeriodLogs({
        machineId: input.machineId,
        from: effectiveFrom,
        to: effectiveTo,
      });

      if (logs.length === 0) return [];

      // =====================================================================
      // 全データを1行の「メガ・ログ」に圧縮して返す
      // =====================================================================
      const sumLog = { ...logs[logs.length - 1] };
      sumLog.runningSeconds = 0;
      sumLog.stoppedSeconds = 0;
      sumLog.idleSeconds = 0;
      sumLog.plannedStopSeconds = 0;
      sumLog.productionCount = 0;

      for (const log of logs) {
        sumLog.runningSeconds += log.runningSeconds ?? 0;
        sumLog.stoppedSeconds += log.stoppedSeconds ?? 0;
        sumLog.idleSeconds += log.idleSeconds ?? 0;
        sumLog.plannedStopSeconds += log.plannedStopSeconds ?? 0;
        sumLog.productionCount += log.productionCount ?? 0;
      }

      // =====================================================================
      // ★ 時差問題の修正: updatedAt を ISO形式 (Z付き) に変換
      // これにより詳細画面の「更新：22:xx」が正しい時間に戻ります
      // =====================================================================
      if (sumLog.updatedAt) {
        sumLog.updatedAt = sumLog.updatedAt instanceof Date 
          ? sumLog.updatedAt.toISOString() 
          : new Date(sumLog.updatedAt).toISOString() as any;
      }

      return [sumLog];
    }),

  machineSummary: protectedProcedure
    .input(
      z.object({
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      let effectiveFrom = input.from;
      let effectiveTo = input.to;
      if (effectiveTo.getTime() - effectiveFrom.getTime() < 24 * 60 * 60 * 1000) {
        effectiveFrom = startOfDay(effectiveFrom);
        effectiveTo = endOfDay(effectiveTo);
      }

      const [logs, stopEvts, machines] = await Promise.all([
        listPeriodLogs({ from: effectiveFrom, to: effectiveTo }),
        listStopEvents({ from: effectiveFrom, to: effectiveTo }),
        listMachines(false),
      ]);

      const machineMap = new Map(machines.map(m => [m.machineId, m]));
      const byMachine = new Map<string, any>();

      for (const log of logs) {
        const machine = machineMap.get(log.machineId);
        const existing = byMachine.get(log.machineId);
        if (!existing) {
          byMachine.set(log.machineId, {
            machineId: log.machineId,
            machineName: machine?.displayName ?? log.machineId,
            runningSeconds: log.runningSeconds ?? 0,
            stoppedSeconds: log.stoppedSeconds ?? 0,
            plannedStopSeconds: log.plannedStopSeconds ?? 0,
            idleSeconds: log.idleSeconds ?? 0,
            productionCount: log.productionCount ?? 0,
            targetProductionCount: log.targetProductionCount ?? 0,
            chocoCount: 0,
            dokaCount: 0,
            chocoTotalSec: 0,
            dokaTotalSec: 0,
            operatingRate: null,
          });
        } else {
          existing.runningSeconds += log.runningSeconds ?? 0;
          existing.stoppedSeconds += log.stoppedSeconds ?? 0;
          existing.plannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.idleSeconds += log.idleSeconds ?? 0;
          existing.productionCount += log.productionCount ?? 0;
          existing.targetProductionCount += log.targetProductionCount ?? 0;
        }
      }

      for (const evt of stopEvts) {
        if (evt.lifecycleState !== "closed") continue;
        const entry = byMachine.get(evt.machineId);
        if (!entry) continue;
        const cls = evt.finalStopClass ?? evt.stopClass;
        const dur = evt.finalStopDurationSec ?? 0;
        if (cls === "choco") { entry.chocoCount++; entry.chocoTotalSec += dur; }
        else if (cls === "doka") { entry.dokaCount++; entry.dokaTotalSec += dur; }
      }

      const rows = Array.from(byMachine.values());
      for (const r of rows) {
        const total = r.runningSeconds + r.stoppedSeconds + r.plannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.totalRunningSeconds / total) * 1000) / 10 : null;
      }

      return rows;
    }),
});