/**
 * Node Terminal REST API
 * Authentication: Bearer API Key (Authorization: Bearer <api_key>)
 * These endpoints are NOT tRPC — they are plain Express routes.
 *
 * POST /api/node/current-status
 * POST /api/node/stop-event
 * POST /api/node/period-log
 */
import type { NextFunction, Request, Response, Router } from "express";
import { nanoid } from "nanoid";
import { z } from "zod";
import {
  createApiKey,
  getActiveApiKeyByMachineId,
  getApiKeyRecord,
  upsertCurrentStatus,
  upsertPeriodLog,
  upsertStopEvent,
  writeAuditLog,
} from "../db";

// ─────────────────────────────────────────────
// API Key authentication middleware
// ─────────────────────────────────────────────

async function nodeApiAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization ?? "";
  const apiKey = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : null;
  if (!apiKey) {
    res.status(401).json({ error: "Missing API key" });
    return;
  }
  const record = await getApiKeyRecord(apiKey);
  if (!record) {
    res.status(401).json({ error: "Invalid or inactive API key" });
    return;
  }
  (req as any).nodeApiKeyRecord = record;
  next();
}

// ─────────────────────────────────────────────
// Zod schemas (passthrough: unknown fields are preserved)
// ─────────────────────────────────────────────

const currentStatusSchema = z
  .object({
    machineId: z.string().min(1).max(128),
    currentState: z.string().min(1).max(64),
    // タイムスタンプ: eventTime または sampleTime のどちらかを受理
    eventTime: z.string().optional().nullable(),
    sampleTime: z.string().optional().nullable(),
    // optional fields
    stopClass: z.string().optional().nullable(),
    alarm: z.union([z.boolean(), z.string()]).optional().nullable(),
    timeZone: z.string().optional().nullable(),
    scheduleViolation: z.string().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
  })
  .passthrough(); // 未知フィールドを保持

const stopEventSchema = z
  .object({
    eventId: z.string().min(1).max(256),
    machineId: z.string().min(1).max(128),
    action: z.enum(["open", "update", "close"]).optional(),
    // 既存フィールド
    startTime: z.string().optional().nullable(),
    updateTime: z.string().optional().nullable(),
    endTime: z.string().optional().nullable(),
    stopClass: z.string().optional().nullable(),
    finalStopClass: z.string().optional().nullable(),
    elapsedSec: z.number().optional().nullable(),
    finalStopDurationSec: z.number().optional().nullable(),
    closeReason: z.string().optional().nullable(),
    reasonCode: z.string().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
    // ノード互換拡張フィールド
    segmentStart: z.string().optional().nullable(),
    dokaAt: z.string().optional().nullable(),
    segmentEnd: z.string().optional().nullable(),
    currentStopElapsedSec: z.number().optional().nullable(),
    thresholdSec: z.number().optional().nullable(),
    isClosed: z.boolean().optional().nullable(),
  })
  .passthrough();

const periodLogSchema = z
  .object({
    machineId: z.string().min(1).max(128),
    periodStart: z.string().min(1),
    periodEnd: z.string().min(1),
    // 既存フィールド
    runningSeconds: z.number().optional().nullable(),
    idleSeconds: z.number().optional().nullable(),
    stoppedSeconds: z.number().optional().nullable(),
    plannedStopSeconds: z.number().optional().nullable(),
    productionCount: z.number().optional().nullable(),
    targetProductionCount: z.number().optional().nullable(),
    schemaVersion: z.string().optional().nullable(),
    // ノード互換拡張フィールド
    stopSeconds: z.number().optional().nullable(),
    chocoSeconds: z.number().optional().nullable(),
    dokaSeconds: z.number().optional().nullable(),
  })
  .passthrough();

const tokenRequestSchema = z.object({
  machineId: z.string().min(1).max(128),
});

// ─────────────────────────────────────────────
// Helper: parse ISO8601 string to Date safely
// ─────────────────────────────────────────────

function parseDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  
  let dateStr = s.trim();

  // ★ 修正箇所: 文字列の末尾にタイムゾーン情報（Z, +09:00, -0500 など）が含まれていないかチェック
  if (!/(Z|[+-]\d{2}:?\d{2})$/.test(dateStr)) {
    // 含まれていない場合、半角スペースがあれば "T" に置換し、強制的に日本時間 "+09:00" を付与する
    // 例: "2026-04-14 17:55:00" -> "2026-04-14T17:55:00+09:00"
    dateStr = dateStr.replace(' ', 'T') + '+09:00';
  }

  const d = new Date(dateStr);
  return isNaN(d.getTime()) ? null : d;
}

function alarmToString(alarm: boolean | string | null | undefined): string | null {
  if (alarm === null || alarm === undefined) return null;
  return String(alarm);
}

// ─────────────────────────────────────────────
// Register routes on an Express Router
// ─────────────────────────────────────────────

export function registerNodeApiRoutes(router: Router) {
  // ─────────────────────────────────────────────
  // POST /api/node/token-request
  // ノード端末からの machine_id を元に、APIキーを検索・（なければ）自動発行して返す。
  // このエンドポイントはまだAPIキーを持たないノードが呼ぶため、
  // nodeApiAuth（Bearer認証）より前に登録し、認証対象から除外する。
  // ─────────────────────────────────────────────
  router.post("/api/node/token-request", async (req: Request, res: Response) => {
    const result = tokenRequestSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ error: "Validation failed", details: result.error.flatten() });
      return;
    }
    const { machineId } = result.data;

    try {
      // 1) machine_id が一致する有効なAPIキーを検索（配布）
      let record = await getActiveApiKeyByMachineId(machineId);

      // 2) 存在しない場合は新規発行（従来の管理画面発行と同一形式）
      let issued = false;
      if (!record) {
        const apiKey = `fk_${nanoid(40)}`;
        record = await createApiKey({
          name: `auto-issued (${machineId})`,
          machineId,
          apiKey,
          description: "ノード端末からのリクエストにより自動発行",
          isActive: true,
        });
        issued = true;
      }

      await writeAuditLog({
        action: issued ? "apiKey.autoIssue" : "apiKey.distribute",
        targetType: "node_api_key",
        targetId: String(record.id),
        detail: { machineId, issued },
        ipAddress: req.ip,
      });

      res.json({ apiKey: record.apiKey, machineId, issued });
    } catch (e) {
      console.error("[NodeAPI] token-request error:", e);
      res.status(500).json({ error: "Token request failed" });
    }
  });

  router.use("/api/node", nodeApiAuth);

  // POST /api/node/current-status
  router.post("/api/node/current-status", async (req: Request, res: Response) => {
    // raw payload を先に保存（バリデーション前）
    const rawPayload = req.body;

    const result = currentStatusSchema.safeParse(rawPayload);
    if (!result.success) {
      res.status(400).json({ error: "Validation failed", details: result.error.flatten() });
      return;
    }
    const data = result.data;

    // サーバー側正規化: event_time = eventTime ?? sampleTime ?? 受信時刻
    const eventTime =
      parseDate(data.eventTime) ?? parseDate(data.sampleTime) ?? new Date();

    try {
      await upsertCurrentStatus({
        machineId: data.machineId,
        eventTime,
        currentState: data.currentState,
        stopClass: data.stopClass ?? null,
        alarm: alarmToString(data.alarm),
        timeZone: data.timeZone ?? null,
        scheduleViolation: data.scheduleViolation ?? null,
        rawPayloadJson: rawPayload, // 正規化前の生データ
      });
      await writeAuditLog({
        action: "node.currentStatus",
        targetType: "current_status",
        targetId: data.machineId,
        detail: { machineId: data.machineId, currentState: data.currentState },
        ipAddress: req.ip,
      });
      res.json({ success: true });
    } catch (e) {
      console.error("[NodeAPI] current-status error:", e);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // POST /api/node/stop-event
  router.post("/api/node/stop-event", async (req: Request, res: Response) => {
    const rawPayload = req.body;

    const result = stopEventSchema.safeParse(rawPayload);
    if (!result.success) {
      res.status(400).json({ error: "Validation failed", details: result.error.flatten() });
      return;
    }
    const data = result.data;

    // action の正規化: isClosed=true かつ action 未指定 → 'close'
    let action = data.action ?? (data.isClosed ? "close" : "open");

    // start_time = startTime ?? segmentStart
    const startTime = parseDate(data.startTime) ?? parseDate(data.segmentStart);
    // end_time = endTime ?? segmentEnd
    const endTime = parseDate(data.endTime) ?? parseDate(data.segmentEnd);
    const dokaAt = parseDate(data.dokaAt);

    try {
      await upsertStopEvent(data.eventId, data.machineId, action, {
        startTime: startTime ?? undefined,
        endTime: endTime ?? undefined,
        dokaAt: dokaAt ?? undefined,
        stopClass: data.stopClass ?? undefined,
        finalStopClass: data.finalStopClass ?? undefined,
        elapsedSec: data.elapsedSec != null ? Math.round(data.elapsedSec) : undefined,
        finalStopDurationSec:
          data.finalStopDurationSec != null ? Math.round(data.finalStopDurationSec) : undefined,
        closeReason: data.closeReason ?? undefined,
        reasonCode: data.reasonCode ?? undefined,
        rawPayloadJson: rawPayload, // 正規化前の生データ
      });
      await writeAuditLog({
        action: `node.stopEvent.${action}`,
        targetType: "stop_event",
        targetId: data.eventId,
        detail: { machineId: data.machineId, action },
        ipAddress: req.ip,
      });
      res.json({ success: true });
    } catch (e) {
      console.error("[NodeAPI] stop-event error:", e);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // POST /api/node/period-log
  router.post("/api/node/period-log", async (req: Request, res: Response) => {
    const rawPayload = req.body;

    const result = periodLogSchema.safeParse(rawPayload);
    if (!result.success) {
      res.status(400).json({ error: "Validation failed", details: result.error.flatten() });
      return;
    }
    const data = result.data;

    const periodStart = parseDate(data.periodStart);
    const periodEnd = parseDate(data.periodEnd);
    if (!periodStart || !periodEnd) {
      res.status(400).json({ error: "Invalid periodStart or periodEnd" });
      return;
    }

    // stopped_seconds = stoppedSeconds ?? stopSeconds
    const stoppedSeconds = data.stoppedSeconds ?? data.stopSeconds ?? null;

    try {
      await upsertPeriodLog({
        machineId: data.machineId,
        periodStart,
        periodEnd,
        runningSeconds: data.runningSeconds ?? null,
        idleSeconds: data.idleSeconds ?? null,
        stoppedSeconds: stoppedSeconds != null ? Math.round(stoppedSeconds) : null,
        chocoSeconds: data.chocoSeconds != null ? Math.round(data.chocoSeconds) : null,
        dokaSeconds: data.dokaSeconds != null ? Math.round(data.dokaSeconds) : null,
        plannedStopSeconds: data.plannedStopSeconds ?? null,
        productionCount: data.productionCount ?? null,
        targetProductionCount: data.targetProductionCount ?? null,
        schemaVersion: data.schemaVersion ?? null,
        rawPayloadJson: rawPayload, // 正規化前の生データ（chocoSeconds/dokaSeconds 含む）
      });
      await writeAuditLog({
        action: "node.periodLog",
        targetType: "period_log",
        targetId: `${data.machineId}|${data.periodStart}|${data.periodEnd}`,
        detail: { machineId: data.machineId },
        ipAddress: req.ip,
      });
      res.json({ success: true });
    } catch (e) {
      console.error("[NodeAPI] period-log error:", e);
      res.status(500).json({ error: "Internal server error" });
    }
  });
}
