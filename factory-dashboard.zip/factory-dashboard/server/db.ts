/**
 * Database layer using PostgreSQL via drizzle-orm/node-postgres (pg).
 * Designed for local Linux server deployment.
 * DATABASE_URL format: postgresql://user:password@localhost:5432/factory_db
 */
import { and, eq, gt, lt, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import {
  type InsertSession,
  type InsertUser,
  auditLogs,
  currentStatuses,
  dashboardLayouts,
  machines,
  nodeApiKeys,
  periodLogs,
  sessions,
  stopEvents,
  stopReasonMaster,
  users,
} from "../drizzle/schema";

const { Pool } = pg;

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const pool = new Pool({ connectionString: process.env.DATABASE_URL });
      _db = drizzle(pool);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─────────────────────────────────────────────
// Users
// ─────────────────────────────────────────────

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(users.createdAt);
}

export async function createUser(data: InsertUser) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(users).values(data).returning();
  return result[0]!;
}

export async function updateUser(id: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, id)).returning();
  return result[0];
}

export async function countAdminUsers() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(users)
    .where(eq(users.role, "admin"));
  return Number(result[0]?.count ?? 0);
}

// ─────────────────────────────────────────────
// Sessions (Cookie セッション)
// ─────────────────────────────────────────────

export async function createSession(data: InsertSession) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(sessions).values(data);
}

export async function getSession(id: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return result[0];
}

export async function deleteSession(id: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(sessions).where(eq(sessions.id, id));
}

export async function deleteExpiredSessions() {
  const db = await getDb();
  if (!db) return;
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
}

// ─────────────────────────────────────────────
// Machines
// ─────────────────────────────────────────────

export async function listMachines(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) {
    return db.select().from(machines).where(eq(machines.isActive, true)).orderBy(machines.sortOrder, machines.id);
  }
  return db.select().from(machines).orderBy(machines.sortOrder, machines.id);
}

export async function getMachineByMachineId(machineId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(machines)
    .where(eq(machines.machineId, machineId))
    .limit(1);
  return result[0];
}

export async function getMachineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(machines).where(eq(machines.id, id)).limit(1);
  return result[0];
}

export async function createMachine(data: typeof machines.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(machines).values(data).returning();
  return result[0]!;
}

export async function updateMachine(id: number, data: Partial<typeof machines.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(machines).set({ ...data, updatedAt: new Date() }).where(eq(machines.id, id)).returning();
  return result[0];
}

export async function deleteMachine(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(machines).where(eq(machines.id, id));
}

// ─────────────────────────────────────────────
// Node API Keys
// ─────────────────────────────────────────────

export async function getApiKeyRecord(apiKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(nodeApiKeys)
    .where(and(eq(nodeApiKeys.apiKey, apiKey), eq(nodeApiKeys.isActive, true)))
    .limit(1);
  return result[0];
}

export async function listApiKeys() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(nodeApiKeys).orderBy(nodeApiKeys.createdAt);
}

export async function createApiKey(data: typeof nodeApiKeys.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(nodeApiKeys).values(data).returning();
  return result[0]!;
}

export async function revokeApiKey(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(nodeApiKeys).set({ isActive: false, updatedAt: new Date() }).where(eq(nodeApiKeys.id, id)).returning();
  return result[0];
}

// ─────────────────────────────────────────────
// Current Statuses
// ─────────────────────────────────────────────

export async function upsertCurrentStatus(data: typeof currentStatuses.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  // 既存レコードの event_time より古い場合は更新しない
  const existing = await db
    .select({ eventTime: currentStatuses.eventTime })
    .from(currentStatuses)
    .where(eq(currentStatuses.machineId, data.machineId!))
    .limit(1);

  /*
    if (existing[0]?.eventTime && data.eventTime) {
    if (new Date(data.eventTime) <= new Date(existing[0].eventTime)) {
      return; // 古いデータは無視
    }
  }
  */

  // PostgreSQL: ON CONFLICT DO UPDATE (upsert)
  await db
    .insert(currentStatuses)
    .values(data)
    .onConflictDoUpdate({
      target: currentStatuses.machineId,
      set: {
        eventTime: data.eventTime,
        currentState: data.currentState,
        stopClass: data.stopClass,
        alarm: data.alarm,
        timeZone: data.timeZone,
        scheduleViolation: data.scheduleViolation,
        rawPayloadJson: data.rawPayloadJson,
        lastReceivedAt: data.lastReceivedAt,
        updatedAt: new Date(),
      },
    });
}

export async function listCurrentStatuses() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(currentStatuses).orderBy(currentStatuses.machineId);
}

export async function getCurrentStatusByMachineId(machineId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(currentStatuses)
    .where(eq(currentStatuses.machineId, machineId))
    .limit(1);
  return result[0];
}

// ─────────────────────────────────────────────
// Stop Events
// ─────────────────────────────────────────────

export async function upsertStopEvent(
  eventId: string,
  machineId: string,
  action: "open" | "update" | "close",
  data: Partial<typeof stopEvents.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");

  const existing = await db
    .select()
    .from(stopEvents)
    .where(eq(stopEvents.eventId, eventId))
    .limit(1);

  const now = new Date();

  if (!existing[0]) {
    // 新規作成（open/update/close どれでも INSERT）
    const lifecycleState =
      action === "close" ? "closed" : action === "update" ? "updating" : "open";
    await db.insert(stopEvents).values({
      eventId,
      machineId,
      lifecycleState,
      lastUpdateTime: now,
      ...data,
      createdAt: now,
    });
    return;
  }

  // 既に closed なら更新しない（冪等性保証）
  if (existing[0].lifecycleState === "closed") {
    return;
  }

  const lifecycleState =
    action === "close" ? "closed" : action === "update" ? "updating" : existing[0].lifecycleState;

  await db
    .update(stopEvents)
    .set({
      lifecycleState,
      lastUpdateTime: now,
      updatedAt: now,
      // start_time は COALESCE: 最初の値を保護
      startTime: existing[0].startTime ?? data.startTime,
      endTime: data.endTime ?? existing[0].endTime,
      dokaAt: data.dokaAt ?? existing[0].dokaAt,
      stopClass: data.stopClass ?? existing[0].stopClass,
      finalStopClass: data.finalStopClass ?? existing[0].finalStopClass,
      elapsedSec: data.elapsedSec,
      finalStopDurationSec: data.finalStopDurationSec ?? existing[0].finalStopDurationSec,
      closeReason: data.closeReason ?? existing[0].closeReason,
      reasonCode: data.reasonCode ?? existing[0].reasonCode,
      rawPayloadJson: data.rawPayloadJson,
    })
    .where(eq(stopEvents.eventId, eventId));
}

export async function listStopEvents(filters?: {
  machineId?: string;
  lifecycleState?: "open" | "updating" | "closed";
  from?: Date;
  to?: Date;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(stopEvents).$dynamic();
  const conditions = [];
  if (filters?.machineId) conditions.push(eq(stopEvents.machineId, filters.machineId));
  if (filters?.lifecycleState)
    conditions.push(eq(stopEvents.lifecycleState, filters.lifecycleState));
  if (filters?.from) conditions.push(gt(stopEvents.createdAt, filters.from));
  if (filters?.to) conditions.push(lt(stopEvents.createdAt, filters.to));
  if (conditions.length > 0) query = query.where(and(...conditions));
  query = query.orderBy(stopEvents.createdAt);
  if (filters?.limit) query = query.limit(filters.limit);
  if (filters?.offset) query = query.offset(filters.offset);
  return query;
}

export async function getStopEventByEventId(eventId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(stopEvents)
    .where(eq(stopEvents.eventId, eventId))
    .limit(1);
  return result[0];
}

export async function updateStopEventMeta(
  id: number,
  data: { tags?: string | null; operatorNote?: string | null; reasonCode?: string | null }
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(stopEvents).set({ ...data, updatedAt: new Date() }).where(eq(stopEvents.id, id)).returning();
  return result[0];
}

// ─────────────────────────────────────────────
// Period Logs
// ─────────────────────────────────────────────

export async function upsertPeriodLog(data: typeof periodLogs.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .insert(periodLogs)
    .values(data)
    .onConflictDoUpdate({
      target: [periodLogs.machineId, periodLogs.periodStart, periodLogs.periodEnd],
      set: {
        runningSeconds: data.runningSeconds,
        idleSeconds: data.idleSeconds,
        stoppedSeconds: data.stoppedSeconds,
        chocoSeconds: data.chocoSeconds,
        dokaSeconds: data.dokaSeconds,
        plannedStopSeconds: data.plannedStopSeconds,
        productionCount: data.productionCount,
        targetProductionCount: data.targetProductionCount,
        schemaVersion: data.schemaVersion,
        rawPayloadJson: data.rawPayloadJson,
        updatedAt: new Date(),
      },
    });
}

export async function listPeriodLogs(filters?: {
  machineId?: string;
  from?: Date;
  to?: Date;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(periodLogs).$dynamic();
  const conditions = [];
  if (filters?.machineId) conditions.push(eq(periodLogs.machineId, filters.machineId));
  if (filters?.from) conditions.push(gt(periodLogs.periodStart, filters.from));
  if (filters?.to) conditions.push(lt(periodLogs.periodEnd, filters.to));
  if (conditions.length > 0) query = query.where(and(...conditions));
  query = query.orderBy(periodLogs.periodStart);
  if (filters?.limit) query = query.limit(filters.limit);
  return query;
}

// ─────────────────────────────────────────────
// Stop Reason Master
// ─────────────────────────────────────────────

export async function listStopReasons(activeOnly = true) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) {
    return db
      .select()
      .from(stopReasonMaster)
      .where(eq(stopReasonMaster.isActive, true))
      .orderBy(stopReasonMaster.sortOrder);
  }
  return db.select().from(stopReasonMaster).orderBy(stopReasonMaster.sortOrder);
}

export async function createStopReason(data: typeof stopReasonMaster.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(stopReasonMaster).values(data).returning();
  return result[0]!;
}

export async function updateStopReason(
  id: number,
  data: Partial<typeof stopReasonMaster.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(stopReasonMaster).set({ ...data, updatedAt: new Date() }).where(eq(stopReasonMaster.id, id)).returning();
  return result[0];
}

// ─────────────────────────────────────────────
// Dashboard Layouts
// ─────────────────────────────────────────────

export async function getDashboardLayout(userId: number, layoutName = "default") {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(dashboardLayouts)
    .where(
      and(eq(dashboardLayouts.userId, userId), eq(dashboardLayouts.layoutName, layoutName))
    )
    .limit(1);
  return result[0];
}

export async function saveDashboardLayout(
  userId: number,
  layoutJson: Array<{ machineId: string; position: number; visible: boolean }>,
  layoutName = "default"
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .insert(dashboardLayouts)
    .values({ userId, layoutName, layoutJson })
    .onConflictDoUpdate({
      target: [dashboardLayouts.userId, dashboardLayouts.layoutName],
      set: { layoutJson, updatedAt: new Date() },
    });
}

// ─────────────────────────────────────────────
// Audit Logs
// ─────────────────────────────────────────────

export async function writeAuditLog(data: typeof auditLogs.$inferInsert) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(auditLogs).values(data);
  } catch (e) {
    console.error("[AuditLog] Failed to write:", e);
  }
}

export async function listAuditLogs(filters?: { limit?: number; offset?: number }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(auditLogs).orderBy(auditLogs.createdAt).$dynamic();
  if (filters?.limit) query = query.limit(filters.limit);
  if (filters?.offset) query = query.offset(filters.offset);
  return query;
}

// ─────────────────────────────────────────────
// Legacy compatibility shim (used by sdk.ts / context.ts)
// ─────────────────────────────────────────────

/** @deprecated Use getUserById instead. Kept for sdk.ts compatibility. */
export async function getUserByOpenId(openId: string) {
  const id = parseInt(openId, 10);
  if (isNaN(id)) return undefined;
  return getUserById(id);
}

/** @deprecated Use createUser/updateUser instead. Kept for sdk.ts compatibility. */
export async function upsertUser(_user: {
  openId?: string;
  name?: string | null;
  email?: string | null;
  loginMethod?: string | null;
  lastSignedIn?: Date;
  role?: "admin" | "operator" | "viewer";
}): Promise<void> {
  // no-op for local auth
}
