import { and, eq, gt, lt, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import {
  auditLogs,
  currentStatuses,
  dashboardLayouts,
  machines,
  nodeApiKeys,
  periodLogs,
  sessions,
  stopEvents,
  stopReasonMaster,
  users,
} from "../drizzle/schema";

const { Pool } = pg;
let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const pool = new Pool({ connectionString: process.env.DATABASE_URL });
      _db = drizzle(pool);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─────────────────────────────────────────────
// Users & Sessions
// ─────────────────────────────────────────────

export async function getUserByUsername(username: string) {
  const db = await getDb();
  return db?.select().from(users).where(eq(users.username, username)).limit(1).then(r => r[0]);
}

export async function getUserById(id: number) {
  const db = await getDb();
  return db?.select().from(users).where(eq(users.id, id)).limit(1).then(r => r[0]);
}

export async function listUsers() {
  const db = await getDb();
  return db ? db.select().from(users).orderBy(users.createdAt) : [];
}

export async function createUser(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(users).values(data).returning();
  return result[0]!;
}

export async function updateUser(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, id)).returning();
  return result[0];
}

export async function deleteUser(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(users).where(eq(users.id, id));
}

export async function countAdminUsers() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "admin"));
  return Number(result[0]?.count ?? 0);
}

export async function createSession(data: any) {
  const db = await getDb();
  if (db) await db.insert(sessions).values(data);
}

export async function getSession(id: string) {
  const db = await getDb();
  return db?.select().from(sessions).where(and(eq(sessions.id, id), gt(sessions.expiresAt, new Date()))).limit(1).then(r => r[0]);
}

export async function deleteSession(id: string) {
  const db = await getDb();
  if (db) await db.delete(sessions).where(eq(sessions.id, id));
}

// ─────────────────────────────────────────────
// Machines
// ─────────────────────────────────────────────

export async function listMachines(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(machines).orderBy(machines.sortOrder, machines.id);
}

export async function getMachineById(id: number) {
  const db = await getDb();
  return db?.select().from(machines).where(eq(machines.id, id)).limit(1).then(r => r[0]);
}

export async function createMachine(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(machines).values(data).returning();
  return result[0]!;
}

export async function updateMachine(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.update(machines).set({ ...data, updatedAt: new Date() }).where(eq(machines.id, id)).returning();
  return result[0];
}

export async function deleteMachine(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(machines).where(eq(machines.id, id));
}

// ─────────────────────────────────────────────
// API Keys & Statuses
// ─────────────────────────────────────────────

export async function listApiKeys() {
  const db = await getDb();
  return db ? db.select().from(nodeApiKeys).orderBy(nodeApiKeys.createdAt) : [];
}

export async function createApiKey(data: any) {
  const db = await getDb();
  if (!db) throw new Error();
  const result = await db.insert(nodeApiKeys).values(data).returning();
  return result[0]!;
}

export async function revokeApiKey(id: number) {
  const db = await getDb();
  if (!db) throw new Error();
  return db.update(nodeApiKeys).set({ isActive: false, updatedAt: new Date() }).where(eq(nodeApiKeys.id, id)).returning().then(r => r[0]);
}

export async function getApiKeyRecord(apiKey: string) {
  const db = await getDb();
  return db?.select().from(nodeApiKeys).where(and(eq(nodeApiKeys.apiKey, apiKey), eq(nodeApiKeys.isActive, true))).limit(1).then(r => r[0]);
}

export async function listCurrentStatuses() {
  const db = await getDb();
  return db ? db.select().from(currentStatuses).orderBy(currentStatuses.machineId) : [];
}

export async function upsertCurrentStatus(data: any) {
  const db = await getDb();
  if (db) await db.insert(currentStatuses).values(data).onConflictDoUpdate({ target: currentStatuses.machineId, set: { ...data, updatedAt: new Date() } });
}

// ─────────────────────────────────────────────
// Events & Logs
// ─────────────────────────────────────────────

export async function listStopEvents(filters?: any) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(stopEvents).$dynamic();
  
  // ★ 修正: 条件を配列にまとめ、and() で結合する
  const conditions = [];
  if (filters?.from) conditions.push(gt(stopEvents.createdAt, filters.from));
  if (filters?.to) conditions.push(lt(stopEvents.createdAt, filters.to));
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }
  
  return query.orderBy(stopEvents.createdAt);
}

export async function getStopEventByEventId(eventId: string) {
  const db = await getDb();
  return db?.select().from(stopEvents).where(eq(stopEvents.eventId, eventId)).limit(1).then(r => r[0]);
}

export async function updateStopEventMeta(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error();
  return db.update(stopEvents).set({ ...data, updatedAt: new Date() }).where(eq(stopEvents.id, id)).returning();
}

export async function upsertStopEvent(eventId: string, machineId: string, action: string, data: any) {
  const db = await getDb();
  if (!db) return;
  await db.insert(stopEvents).values({ eventId, machineId, lifecycleState: action === "close" ? "closed" : "open", ...data, createdAt: new Date() })
    .onConflictDoUpdate({ target: stopEvents.eventId, set: { ...data, updatedAt: new Date() } });
}

export async function listPeriodLogs(filters?: any) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(periodLogs).$dynamic();
  
  // ★ 修正: 条件を配列にまとめ、and() で結合して一発で where() に渡す
  const conditions = [];
  if (filters?.machineId) conditions.push(eq(periodLogs.machineId, filters.machineId));
  if (filters?.from) conditions.push(gt(periodLogs.periodStart, filters.from));
  if (filters?.to) conditions.push(lt(periodLogs.periodEnd, filters.to));

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }
  
  return query.orderBy(periodLogs.periodStart);
}

export async function upsertPeriodLog(data: any) {
  const db = await getDb();
  if (db) await db.insert(periodLogs).values(data).onConflictDoUpdate({ target: [periodLogs.machineId, periodLogs.periodStart, periodLogs.periodEnd], set: { ...data, updatedAt: new Date() } });
}

// ─────────────────────────────────────────────
// Masters & Layouts
// ─────────────────────────────────────────────

export async function listStopReasons() {
  const db = await getDb();
  return db ? db.select().from(stopReasonMaster).orderBy(stopReasonMaster.sortOrder) : [];
}

export async function createStopReason(data: any) {
  const db = await getDb();
  if (!db) throw new Error();
  const result = await db.insert(stopReasonMaster).values(data).returning();
  return result[0]!;
}

export async function updateStopReason(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error();
  const result = await db.update(stopReasonMaster).set({ ...data, updatedAt: new Date() }).where(eq(stopReasonMaster.id, id)).returning();
  return result[0];
}

export async function getDashboardLayout(userId: number) {
  const db = await getDb();
  return db?.select().from(dashboardLayouts).where(eq(dashboardLayouts.userId, userId)).limit(1).then(r => r[0]);
}

export async function saveDashboardLayout(userId: number, layoutJson: any) {
  const db = await getDb();
  if (db) await db.insert(dashboardLayouts).values({ userId, layoutName: "default", layoutJson }).onConflictDoUpdate({ target: [dashboardLayouts.userId, dashboardLayouts.layoutName], set: { layoutJson, updatedAt: new Date() } });
}

export async function writeAuditLog(data: any) {
  const db = await getDb();
  if (db) try { await db.insert(auditLogs).values(data); } catch (e) { console.error(e); }
}

export async function listAuditLogs(f?: any) {
  const db = await getDb();
  return db ? db.select().from(auditLogs).orderBy(auditLogs.createdAt).limit(f?.limit || 100) : [];
}

export async function getUserByOpenId(openId: string) {
  const id = parseInt(openId, 10);
  return isNaN(id) ? undefined : getUserById(id);
}