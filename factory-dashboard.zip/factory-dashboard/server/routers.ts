import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { apiKeysRouter } from "./routers/apiKeys";
import { auditLogsRouter } from "./routers/auditLogs";
import { authRouter } from "./routers/auth";
import { dashboardRouter } from "./routers/dashboard";
import { machinesRouter } from "./routers/machines";
import { reportsRouter } from "./routers/reports";
import { stopEventsRouter } from "./routers/stopEvents";
import { stopReasonsRouter } from "./routers/stopReasons";
import { usersAdminRouter } from "./routers/usersAdmin";

export const appRouter = router({
  system: systemRouter,

  // ローカル認証（username/password + Cookie セッション）
  auth: authRouter,

  // 機械マスター管理
  machines: machinesRouter,

  // ダッシュボード（現在ステータス + レイアウト）
  dashboard: dashboardRouter,

  // 停止イベント（UI側: 一覧/詳細/タグ/ノート/理由コード）
  stopEvents: stopEventsRouter,

  // 停止理由マスター
  stopReasons: stopReasonsRouter,

  // 集計・レポート
  reports: reportsRouter,

  // APIキー管理（admin only）
  apiKeys: apiKeysRouter,

  // ユーザー管理（admin only）
  usersAdmin: usersAdminRouter,

  // 監査ログ（admin only）
  auditLogs: auditLogsRouter,
});

export type AppRouter = typeof appRouter;
