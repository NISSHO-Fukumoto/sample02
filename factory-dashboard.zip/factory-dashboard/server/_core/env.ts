/**
 * Server-side environment variables.
 * Populated by dotenv from .env file at project root.
 */
export const ENV = {
  /** Secret key for signing session cookies. Set JWT_SECRET in .env */
  cookieSecret: process.env.JWT_SECRET ?? "change-me-in-production-use-a-long-random-string",
  /** Database connection string. Set DATABASE_URL in .env */
  databaseUrl: process.env.DATABASE_URL ?? "",
  /** true in production build */
  isProduction: process.env.NODE_ENV === "production",
  // ── Manus platform APIs (not used in local deployment) ──────────────────
  /** Manus Forge API URL (Manus platform only, not used in local deployment) */
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  /** Manus Forge API Key (Manus platform only, not used in local deployment) */
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Manus OAuth server URL (Manus platform only, not used in local deployment) */
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  /** Manus App ID (Manus platform only, not used in local deployment) */
  appId: process.env.VITE_APP_ID ?? "",
};
