#!/bin/bash
# =============================================================================
# 工場機械稼働状況ダッシュボード - ローカルLinuxサーバー セットアップスクリプト
# =============================================================================
# 使用方法: bash setup-local.sh
# 対応OS: Ubuntu 20.04 / 22.04 / Debian 11 / 12
# =============================================================================

set -e

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${BOLD}${CYAN}"
echo "============================================================"
echo "  工場機械稼働状況ダッシュボード セットアップ"
echo "============================================================"
echo -e "${NC}"

# ── 1. 前提条件チェック ──────────────────────────────────────────────────────

echo -e "${BOLD}[1/5] 前提条件チェック${NC}"

# Node.js
if ! command -v node &> /dev/null; then
  echo -e "${RED}❌ Node.js が見つかりません${NC}"
  echo "   インストール方法: https://nodejs.org/"
  echo "   または: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs"
  exit 1
fi
NODE_VERSION=$(node --version | sed 's/v//')
NODE_MAJOR=$(echo $NODE_VERSION | cut -d. -f1)
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo -e "${RED}❌ Node.js 18以上が必要です（現在: v${NODE_VERSION}）${NC}"
  exit 1
fi
echo -e "  ${GREEN}✓ Node.js v${NODE_VERSION}${NC}"

# npm
if ! command -v npm &> /dev/null; then
  echo -e "${RED}❌ npm が見つかりません${NC}"
  exit 1
fi
echo -e "  ${GREEN}✓ npm $(npm --version)${NC}"

# PostgreSQL
if ! command -v psql &> /dev/null; then
  echo -e "${YELLOW}⚠ psql が見つかりません。PostgreSQL をインストールします...${NC}"
  sudo apt update -q
  sudo apt install -y postgresql postgresql-contrib
fi
echo -e "  ${GREEN}✓ PostgreSQL $(psql --version | awk '{print $3}')${NC}"

# ── 2. PostgreSQL セットアップ ────────────────────────────────────────────────

echo ""
echo -e "${BOLD}[2/5] PostgreSQL セットアップ${NC}"

# PostgreSQL サービス起動
if ! sudo systemctl is-active --quiet postgresql; then
  echo "  PostgreSQL サービスを起動中..."
  sudo systemctl start postgresql
  sudo systemctl enable postgresql
fi
echo -e "  ${GREEN}✓ PostgreSQL サービス起動済み${NC}"

# データベースとユーザーを作成（既に存在する場合はスキップ）
echo "  データベースとユーザーを作成中..."
sudo -u postgres psql -c "
  DO \$\$
  BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'factory_user') THEN
      CREATE USER factory_user WITH PASSWORD 'factory_pass';
    END IF;
  END
  \$\$;
" 2>/dev/null || true

sudo -u postgres psql -c "
  SELECT 'CREATE DATABASE factory_db OWNER factory_user'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'factory_db')
" -t 2>/dev/null | sudo -u postgres psql 2>/dev/null || true

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE factory_db TO factory_user;" 2>/dev/null || true

echo -e "  ${GREEN}✓ データベース factory_db 準備完了${NC}"

# ── 3. 環境変数ファイル作成 ───────────────────────────────────────────────────

echo ""
echo -e "${BOLD}[3/5] 環境変数設定${NC}"

if [ ! -f ".env" ]; then
  # ランダムなシークレットキーを生成
  SECRET_KEY=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  
  cat > .env << EOF
# PostgreSQL 接続文字列
DATABASE_URL=postgresql://factory_user:factory_pass@localhost:5432/factory_db

# Cookie セッション署名シークレット（本番環境では必ず変更）
JWT_SECRET=${SECRET_KEY}

# サーバーポート（デフォルト: 3000）
PORT=3000

# 環境
NODE_ENV=production
EOF
  echo -e "  ${GREEN}✓ .env ファイルを作成しました${NC}"
  echo -e "  ${YELLOW}⚠ JWT_SECRET は自動生成されました。本番環境ではバックアップしてください。${NC}"
else
  echo -e "  ${YELLOW}⚠ .env ファイルが既に存在します（スキップ）${NC}"
fi

# ── 4. 依存パッケージとデータベース初期化 ─────────────────────────────────────

echo ""
echo -e "${BOLD}[4/5] 依存パッケージのインストールとDB初期化${NC}"

# pnpm があれば使用、なければ npm
if command -v pnpm &> /dev/null; then
  PKG_MGR="pnpm"
else
  PKG_MGR="npm"
  echo "  pnpm が見つかりません。npm を使用します..."
fi

echo "  パッケージをインストール中... (数分かかる場合があります)"
if [ "$PKG_MGR" = "pnpm" ]; then
  pnpm install --prod 2>&1 | tail -3
else
  npm install --legacy-peer-deps --omit=dev 2>&1 | tail -3
fi
echo -e "  ${GREEN}✓ パッケージインストール完了${NC}"

# データベースのテーブルを作成
echo "  データベーステーブルを作成中..."
source .env 2>/dev/null || true
export DATABASE_URL
node scripts/setup-db.mjs
echo -e "  ${GREEN}✓ データベース初期化完了${NC}"

# ── 5. ビルド ────────────────────────────────────────────────────────────────

echo ""
echo -e "${BOLD}[5/5] アプリケーションのビルド${NC}"

if [ ! -f "dist/index.js" ]; then
  echo "  ビルド中... (数分かかる場合があります)"
  if [ "$PKG_MGR" = "pnpm" ]; then
    pnpm run build 2>&1 | tail -5
  else
    npm run build 2>&1 | tail -5
  fi
  echo -e "  ${GREEN}✓ ビルド完了${NC}"
else
  echo -e "  ${YELLOW}⚠ dist/index.js が既に存在します（スキップ）${NC}"
  echo "  再ビルドする場合: npm run build"
fi

# ── 完了メッセージ ────────────────────────────────────────────────────────────

echo ""
echo -e "${BOLD}${GREEN}"
echo "============================================================"
echo "  ✅ セットアップ完了！"
echo "============================================================"
echo -e "${NC}"
echo -e "${BOLD}サーバーを起動するには:${NC}"
echo "  npm start"
echo ""
echo -e "${BOLD}ブラウザでアクセス:${NC}"
echo "  http://localhost:3000"
echo ""
echo -e "${BOLD}初回セットアップ:${NC}"
echo "  http://localhost:3000/setup  ← 管理者アカウントを作成"
echo ""
echo -e "${BOLD}systemd サービスとして登録（オプション）:${NC}"
echo "  sudo bash scripts/install-service.sh"
echo ""
