# ローカルLinuxサーバー セットアップガイド

工場機械稼働状況ダッシュボードをローカルLinuxサーバーで運用するための手順書です。

---

## 必要環境

| ソフトウェア | バージョン | 備考 |
|------------|-----------|------|
| Linux | Ubuntu 20.04 / 22.04 / Debian 11 / 12 | その他のディストリビューションでも動作可能 |
| Node.js | 18以上 | `node --version` で確認 |
| npm または pnpm | 最新版 | npm は Node.js に同梱 |
| PostgreSQL | 14以上 | ローカルインストールまたはDockerで起動 |

---

## クイックスタート（推奨）

プロジェクトディレクトリで以下を実行するだけでセットアップが完了します。

```bash
# セットアップスクリプトを実行
bash setup-local.sh

# サーバーを起動
npm start
```

ブラウザで `http://localhost:3000/setup` にアクセスして管理者アカウントを作成します。

---

## 手動セットアップ手順

### 1. PostgreSQL のインストールと設定

```bash
# Ubuntu/Debian の場合
sudo apt update
sudo apt install -y postgresql postgresql-contrib

# PostgreSQL サービス起動
sudo systemctl start postgresql
sudo systemctl enable postgresql

# データベースとユーザーを作成
sudo -u postgres psql << 'EOF'
CREATE USER factory_user WITH PASSWORD 'factory_pass';
CREATE DATABASE factory_db OWNER factory_user;
GRANT ALL PRIVILEGES ON DATABASE factory_db TO factory_user;
EOF
```

> **セキュリティ:** 本番環境では `factory_pass` を強力なパスワードに変更し、`.env` ファイルの `DATABASE_URL` も合わせて更新してください。

---

### 2. 環境変数の設定

プロジェクトルートに `.env` ファイルを作成します。

```bash
# ランダムなシークレットキーを生成
SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")

cat > .env << EOF
# PostgreSQL 接続文字列
DATABASE_URL=postgresql://factory_user:factory_pass@localhost:5432/factory_db

# Cookie セッション署名シークレット（本番環境では必ず変更）
JWT_SECRET=${SECRET}

# サーバーポート（デフォルト: 3000）
PORT=3000

# 環境
NODE_ENV=production
EOF
```

> **重要:** `JWT_SECRET` は本番環境では必ずランダムな文字列を使用してください。このシークレットが漏洩するとセッションが偽造される可能性があります。

---

### 3. データベーステーブルの作成

```bash
# 依存パッケージのインストール
npm install --legacy-peer-deps

# データベーステーブルを作成
node scripts/setup-db.mjs
```

または、SQLファイルを直接実行する場合:

```bash
psql -U factory_user -d factory_db -h localhost \
  -f drizzle/migrations/0001_factory_init.sql
```

---

### 4. アプリケーションのビルド

```bash
npm run build
```

ビルドが完了すると `dist/index.js` と `dist/public/` が生成されます。

---

### 5. サーバーの起動

```bash
# 本番モードで起動
npm start

# または直接実行
NODE_ENV=production node dist/index.js
```

ブラウザで `http://localhost:3000` にアクセスします。

---

### 6. 初回セットアップ

1. `http://localhost:3000/setup` にアクセス
2. 管理者ユーザー名とパスワード（8文字以上）を入力して「管理者アカウントを作成」をクリック
3. 作成後、自動的にログインページにリダイレクトされます
4. 作成したユーザー名とパスワードでログイン

> **注意:** `/setup` ページは管理者アカウントが存在しない場合のみアクセス可能です。既にアカウントが存在する場合はログインページにリダイレクトされます。

---

## systemd サービスとして登録（推奨）

サーバー起動時に自動的にダッシュボードが起動するよう、systemd サービスとして登録します。

```bash
# サービス登録スクリプトを実行（sudo が必要）
sudo bash scripts/install-service.sh
```

### サービス管理コマンド

| 操作 | コマンド |
|------|---------|
| 状態確認 | `sudo systemctl status factory-dashboard` |
| 起動 | `sudo systemctl start factory-dashboard` |
| 停止 | `sudo systemctl stop factory-dashboard` |
| 再起動 | `sudo systemctl restart factory-dashboard` |
| ログ確認 | `sudo journalctl -u factory-dashboard -f` |
| 自動起動無効化 | `sudo systemctl disable factory-dashboard` |

---

## ノード端末からのAPI接続

### APIキーの発行

1. ダッシュボードにログイン
2. 左サイドバーの「APIキー管理」をクリック
3. 「新規APIキー作成」ボタンをクリック
4. キー名を入力して作成
5. 表示されたAPIキーをコピー（**一度しか表示されません**）

### ノード端末の設定

ノード端末（Raspberry Pi等）の設定ファイルに以下を設定します。

```
サーバーURL: http://<サーバーIPアドレス>:3000
APIキー: fk_xxxxxxxxxxxxxxxxxxxx（発行したキー）
```

### APIエンドポイント

| エンドポイント | メソッド | 説明 |
|-------------|---------|------|
| `/api/node/current-status` | POST | 機械の現在状態を送信 |
| `/api/node/stop-event` | POST | 停止イベントを送信 |
| `/api/node/period-log` | POST | 期間集計ログを送信 |

**認証ヘッダー:**
```
Authorization: Bearer <APIキー>
```

### current-status リクエスト例

```json
{
  "machineId": "MACHINE-001",
  "currentState": "running",
  "eventTime": "2026-03-20T10:00:00+09:00",
  "stopClass": null
}
```

**currentState の値:**

| 値 | 意味 | 表示色 |
|----|------|--------|
| `running` | 稼働中 | 緑 |
| `choco` | チョコ停（短時間停止） | 黄 |
| `doka` | ドカ停（長時間停止） | 赤 |
| `planned_stop` | 計画停止 | 青 |
| `off` | 電源オフ | グレー |

### stop-event リクエスト例

```json
{
  "machineId": "MACHINE-001",
  "eventId": "EVT-20260320-001",
  "action": "open",
  "startTime": "2026-03-20T10:05:00+09:00",
  "stopClass": "doka"
}
```

**action の値:**

| 値 | 意味 |
|----|------|
| `open` | 停止イベント開始 |
| `update` | 停止イベント更新 |
| `close` | 停止イベント終了 |

### period-log リクエスト例

```json
{
  "machineId": "MACHINE-001",
  "periodStart": "2026-03-20T09:00:00+09:00",
  "periodEnd": "2026-03-20T10:00:00+09:00",
  "runningSeconds": 3200,
  "stoppedSeconds": 400,
  "chocoSeconds": 250,
  "dokaSeconds": 150,
  "productionCount": 120,
  "targetProductionCount": 130
}
```

---

## ダッシュボード機能一覧

| 機能 | 説明 |
|------|------|
| リアルタイムダッシュボード | 全機械の稼働状況をカード表示。ドラッグ&ドロップで並び替え可能 |
| 停止イベント管理 | 停止イベントの一覧表示、タグ付け、メモ記入 |
| 集計レポート | 日次・週次・月次の稼働率・停止時間グラフ |
| 機械管理 | 機械の登録・編集・削除、停止判定閾値の設定 |
| APIキー管理 | ノード端末用APIキーの発行・無効化 |
| ユーザー管理 | ユーザーの追加・権限変更（管理者のみ） |
| 監査ログ | システム操作履歴の確認 |

---

## トラブルシューティング

### `DB not available` エラー

- `.env` ファイルの `DATABASE_URL` が正しく設定されているか確認
- PostgreSQL サービスが起動しているか確認:
  ```bash
  sudo systemctl status postgresql
  ```
- 接続テスト:
  ```bash
  psql "postgresql://factory_user:factory_pass@localhost:5432/factory_db" -c "SELECT 1;"
  ```

### ログイン後に画面が真っ白になる

- ブラウザのキャッシュをクリア（Ctrl+Shift+R）
- `npm run build` を再実行してビルドを更新

### ポート 3000 が使用中

- `.env` の `PORT` を別の番号（例: `8080`）に変更して再起動:
  ```bash
  # .env を編集
  PORT=8080
  # 再起動
  npm start
  ```

### ノード端末からAPIに接続できない

- サーバーのファイアウォールでポートが開放されているか確認:
  ```bash
  sudo ufw allow 3000/tcp
  sudo ufw status
  ```
- サーバーのIPアドレスを確認:
  ```bash
  ip addr show | grep "inet "
  ```

### 管理者パスワードを忘れた場合

PostgreSQL に直接接続してパスワードをリセットします。

```bash
# 新しいパスワードハッシュを生成
node -e "
const bcrypt = require('bcryptjs');
const hash = bcrypt.hashSync('新しいパスワード', 10);
console.log(hash);
"

# データベースを更新
psql "postgresql://factory_user:factory_pass@localhost:5432/factory_db" \
  -c "UPDATE users SET password_hash = '<上記のハッシュ>' WHERE username = 'admin';"
```

---

## バックアップ

### データベースのバックアップ

```bash
# バックアップ
pg_dump "postgresql://factory_user:factory_pass@localhost:5432/factory_db" \
  > backup_$(date +%Y%m%d).sql

# リストア
psql "postgresql://factory_user:factory_pass@localhost:5432/factory_db" \
  < backup_20260320.sql
```

### 定期バックアップ（cron）

```bash
# crontab を編集
crontab -e

# 毎日午前2時にバックアップ（以下を追加）
0 2 * * * pg_dump "postgresql://factory_user:factory_pass@localhost:5432/factory_db" > /backup/factory_$(date +\%Y\%m\%d).sql
```

---

## セキュリティ推奨事項

1. **パスワードを変更する:** `factory_pass` を強力なパスワードに変更する
2. **JWT_SECRET を変更する:** 十分にランダムな文字列を使用する
3. **ファイアウォールを設定する:** 工場内LANからのみアクセスを許可する
4. **HTTPS を設定する:** Nginx をリバースプロキシとして使用し、SSL証明書を設定する
5. **定期バックアップ:** データベースの定期バックアップを設定する

### Nginx リバースプロキシ設定例

```nginx
server {
    listen 80;
    server_name factory-dashboard.local;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```
