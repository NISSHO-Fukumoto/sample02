# 設計仕様書 — 製造現場 機械稼働状況ダッシュボード

> 実装開始前の最終確認用ドキュメント。確認後に変更がある場合は本ドキュメントを更新してから実装に着手する。

---

## 1. ER 図

```
┌─────────────────────────────────────────────────────────────────────────┐
│ users                                                                   │
│  id (PK, serial)                                                        │
│  username (varchar, unique)                                             │
│  password_hash (text)                                                   │
│  role (enum: 'admin'|'operator'|'viewer')  default 'operator'          │
│  is_active (boolean) default true                                       │
│  created_at / updated_at (timestamptz)                                  │
└──────────────┬──────────────────────────────────────────────────────────┘
               │ 1:N
               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ dashboard_layouts                                                       │
│  id (PK, serial)                                                        │
│  user_id (FK → users.id)                                               │
│  layout_name (varchar) default 'default'                               │
│  layout_json (jsonb)   ← [{machineId, position, visible}]              │
│  created_at / updated_at (timestamptz)                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ machines                                                                │
│  id (PK, serial)                                                        │
│  machine_id (varchar, unique)  ← ノード端末が送ってくる識別子          │
│  machine_name (varchar)                                                 │
│  machine_type (varchar)                                                 │
│  dur_choco_sec (integer)  ← チョコ停判定閾値(秒)                       │
│  dur_doka_sec  (integer)  ← ドカ停判定閾値(秒)                         │
│  time_start (time)        ← 稼働開始時刻                               │
│  time_end   (time)        ← 稼働終了時刻                               │
│  break_times (jsonb)      ← [{start, end}]                             │
│  is_active (boolean) default true                                       │
│  created_at / updated_at (timestamptz)                                  │
└──────────────┬──────────────────────────────────────────────────────────┘
               │ 1:1 (最新1件)
               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ current_statuses                                                        │
│  id (PK, serial)                                                        │
│  machine_id (varchar, unique)  ← machines.machine_id と対応            │
│  event_time (timestamptz)                                               │
│  current_state (varchar)  ← running/stop/planned_stop/off              │
│  stop_class (varchar nullable)  ← choco/doka/null                      │
│  alarm (varchar nullable)                                               │
│  time_zone (varchar nullable)                                           │
│  schedule_violation (boolean nullable)                                  │
│  raw_payload_json (jsonb)                                               │
│  updated_at (timestamptz)                                               │
└─────────────────────────────────────────────────────────────────────────┘

               │ 1:N
               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ stop_events                                                             │
│  id (PK, serial)                                                        │
│  event_id (varchar, unique)  ← ノードが発行する一意ID                  │
│  machine_id (varchar)        ← machines.machine_id と対応              │
│  lifecycle_state (enum: 'open'|'updating'|'closed')                    │
│  start_time (timestamptz nullable)                                      │
│  last_update_time (timestamptz nullable)                                │
│  end_time (timestamptz nullable)                                        │
│  stop_class (varchar nullable)                                          │
│  final_stop_class (varchar nullable)                                    │
│  final_stop_duration_sec (integer nullable)                             │
│  close_reason (varchar nullable)                                        │
│  reason_code (varchar nullable)  ← stop_reason_master.reason_code 参照 │
│  tag (varchar nullable)                                                 │
│  note (text nullable)                                                   │
│  raw_payload_json (jsonb)                                               │
│  created_at / updated_at (timestamptz)                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ period_logs                                                             │
│  id (PK, serial)                                                        │
│  machine_id (varchar)                                                   │
│  period_start (timestamptz)                                             │
│  period_end   (timestamptz)                                             │
│  running_seconds (integer nullable)                                     │
│  idle_seconds (integer nullable)                                        │
│  stopped_seconds (integer nullable)                                     │
│  planned_stop_seconds (integer nullable)                                │
│  production_count (integer nullable)                                    │
│  target_production_count (integer nullable)                             │
│  raw_payload_json (jsonb)                                               │
│  created_at / updated_at (timestamptz)                                  │
│  UNIQUE(machine_id, period_start, period_end)                           │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ node_api_keys                                                           │
│  id (PK, serial)                                                        │
│  machine_id (varchar)  ← machines.machine_id と対応（nullable可）      │
│  api_key (varchar, unique)  ← nanoid(32) で生成                        │
│  description (text nullable)                                            │
│  is_active (boolean) default true                                       │
│  created_at / updated_at (timestamptz)                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ stop_reason_master                                                      │
│  id (PK, serial)                                                        │
│  reason_code (varchar, unique)                                          │
│  display_name (varchar)                                                 │
│  sort_order (integer) default 0                                         │
│  is_active (boolean) default true                                       │
│  created_at / updated_at (timestamptz)                                  │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│ audit_logs                                                              │
│  id (PK, serial)                                                        │
│  user_id (integer nullable)  ← users.id（システム操作はnull）          │
│  action (varchar)  ← 'login'/'logout'/'create'/'update'/'delete' 等    │
│  target_type (varchar nullable)  ← 'machine'/'user'/'api_key' 等       │
│  target_id (varchar nullable)                                           │
│  detail (jsonb nullable)                                                │
│  ip_address (varchar nullable)                                          │
│  created_at (timestamptz)                                               │
└─────────────────────────────────────────────────────────────────────────┘

【将来拡張用・初期実装対象外】
┌─────────────────────────────────────────────────────────────────────────┐
│ daily_records（日次集計キャッシュ）                                     │
│  id / machine_id / date / running_seconds / stopped_seconds /          │
│  choco_seconds / doka_seconds / planned_stop_seconds /                  │
│  production_count / target_production_count /                           │
│  availability_rate / created_at / updated_at                            │
│  UNIQUE(machine_id, date)                                               │
│  ※ CRUDではなく集計バッチの成果物として扱う                            │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 2. API 契約一覧

### 2-1. ノード端末向け REST API（Bearer API Key 認証）

すべてのノードAPIは `Authorization: Bearer <api_key>` ヘッダーを必須とする。
認証失敗時は `401 Unauthorized` を返す。
**tRPC 化しない。** Express ルートとして直接実装する。

#### POST /api/node/current-status

| 項目 | 内容 |
|------|------|
| 認証 | Bearer API Key |
| 役割 | 機械の現在状態を受信し、machine_id 単位で最新1件を upsert |
| 成功レスポンス | `200 { success: true }` |

**Request Body（zod スキーマ）:**

```typescript
// 必須フィールド
machineId: string
currentState: string  // 'running' | 'stop' | 'planned_stop' | 'off'

// タイムスタンプ（eventTime または sampleTime のどちらかを受理、両方来た場合は eventTime 優先）
eventTime?: string | null   // ISO8601
sampleTime?: string | null  // ISO8601（ノード端末が sampleTime で送ってくる場合に対応）

// optional フィールド
stopClass?: string | null       // 'choco' | 'doka' | null
alarm?: boolean | string | null // boolean または string を両方受理
timeZone?: string | null
scheduleViolation?: string | null  // boolean ではなく string/null を受理
schemaVersion?: string | null
// その他未知フィールドは passthrough で受理し raw_payload_json に保存
```

**サーバー側正規化ルール:**
- `event_time` = `eventTime ?? sampleTime ?? 受信時刻（サーバー時刻）` の優先順で決定
- `alarm` は boolean/string どちらで来ても文字列として正規化して保存
- `scheduleViolation` は文字列のまま保存（`'true'`/`'false'`/`null` 等）
- `raw_payload_json` には **バリデーション前の `req.body` 生データ**をそのまま保存

**upsert 条件:** `machine_id` をキーに ON CONFLICT UPDATE。
ただし受信した `event_time`（正規化後）が既存レコードの `event_time` より **古い場合は更新しない**（古いデータによる上書き防止）。

---

#### POST /api/node/stop-event

| 項目 | 内容 |
|------|------|
| 認証 | Bearer API Key |
| 役割 | 停止イベントの open/update/close を受信し、eventId 単位で lifecycle 管理 |
| 成功レスポンス | `200 { success: true }` |

**Request Body（zod スキーマ）:**

```typescript
// 必須フィールド
eventId: string
machineId: string
action: 'open' | 'update' | 'close'

// optional フィールド（既存仕様）
startTime?: string | null
updateTime?: string | null
endTime?: string | null
stopClass?: string | null
finalStopClass?: string | null
elapsedSec?: number | null
finalStopDurationSec?: number | null
closeReason?: string | null
reasonCode?: string | null
schemaVersion?: string | null

// optional フィールド（ノード端末互換拡張）
segmentStart?: string | null     // ISO8601 — startTime の別名として受理
dokaAt?: string | null           // ISO8601 — ドカ停移行時刻
segmentEnd?: string | null       // ISO8601 — endTime の別名として受理
currentStopElapsedSec?: number | null  // 現在の停止経過秒数
thresholdSec?: number | null     // 停止判定閾値（秒）
isClosed?: boolean | null        // close 済みフラグ（action='close' と併用）
// その他未知フィールドは passthrough で受理し raw_payload_json に保存
```

**サーバー側正規化ルール:**
- `start_time` = `startTime ?? segmentStart` の優先順で決定
- `end_time` = `endTime ?? segmentEnd` の優先順で決定
- `isClosed = true` かつ `action` が未指定の場合は `action = 'close'` として扱う（将来の互換対応）
- `raw_payload_json` には **バリデーション前の `req.body` 生データ**をそのまま保存

**lifecycle 管理ルール（後述 §5 参照）**

---

#### POST /api/node/period-log

| 項目 | 内容 |
|------|------|
| 認証 | Bearer API Key |
| 役割 | 一定期間の集計値を受信し保存 |
| 成功レスポンス | `200 { success: true }` |

**Request Body（zod スキーマ）:**

```typescript
// 必須フィールド
machineId: string
periodStart: string (ISO8601)
periodEnd: string (ISO8601)

// optional フィールド（既存仕様）
runningSeconds?: number | null
idleSeconds?: number | null
stoppedSeconds?: number | null      // 停止秒数（正式名）
plannedStopSeconds?: number | null
productionCount?: number | null
targetProductionCount?: number | null
schemaVersion?: string | null

// optional フィールド（ノード端末互換拡張）
stopSeconds?: number | null         // stoppedSeconds の別名として受理
chocoSeconds?: number | null        // チョコ停秒数（raw_payload_json に保存、将来 daily_records に活用）
dokaSeconds?: number | null         // ドカ停秒数（raw_payload_json に保存、将来 daily_records に活用）
// その他未知フィールドは passthrough で受理し raw_payload_json に保存
```

**サーバー側正規化ルール:**
- `stopped_seconds` = `stoppedSeconds ?? stopSeconds` の優先順で決定
- `chocoSeconds` / `dokaSeconds` は現時点では専用カラムを持たず `raw_payload_json` に保存。将来 `daily_records` テーブル実装時に活用する
- `raw_payload_json` には **バリデーション前の `req.body` 生データ**をそのまま保存

**upsert 条件:** `(machine_id, period_start, period_end)` をキーに ON CONFLICT UPDATE。

---

### 2-2. 管理 UI 向け tRPC ルーター

| ルーター | プロシージャ | 認証 | 概要 |
|----------|-------------|------|------|
| `auth.login` | mutation | public | username/password → Cookie セッション発行 |
| `auth.logout` | mutation | public | Cookie セッション破棄 |
| `auth.me` | query | public | 現在のログインユーザー情報 |
| `machines.list` | query | protected | 機械一覧取得 |
| `machines.get` | query | protected | 機械詳細取得 |
| `machines.create` | mutation | admin | 機械登録 |
| `machines.update` | mutation | admin | 機械編集 |
| `machines.delete` | mutation | admin | 機械削除 |
| `currentStatuses.list` | query | protected | 全機械の最新状態一覧（通信状態判定付き） |
| `currentStatuses.get` | query | protected | 特定機械の最新状態 |
| `stopEvents.list` | query | protected | 停止イベント一覧（機械ID・期間フィルタ） |
| `stopEvents.get` | query | protected | 停止イベント詳細 |
| `stopEvents.updateTag` | mutation | protected | タグ付け更新 |
| `stopEvents.updateNote` | mutation | protected | 備考更新 |
| `stopEvents.updateReasonCode` | mutation | protected | 停止理由コード更新 |
| `periodLogs.list` | query | protected | 期間ログ一覧 |
| `dashboardLayouts.get` | query | protected | ユーザー別レイアウト取得 |
| `dashboardLayouts.save` | mutation | protected | ユーザー別レイアウト保存 |
| `apiKeys.list` | query | admin | APIキー一覧 |
| `apiKeys.create` | mutation | admin | APIキー発行 |
| `apiKeys.revoke` | mutation | admin | APIキー無効化 |
| `users.list` | query | admin | ユーザー一覧 |
| `users.create` | mutation | admin | ユーザー追加 |
| `users.update` | mutation | admin | パスワード再設定・権限変更・有効無効 |
| `stopReasons.list` | query | protected | 停止理由マスター一覧 |
| `stopReasons.create` | mutation | admin | 停止理由マスター追加 |
| `stopReasons.update` | mutation | admin | 停止理由マスター編集 |
| `reports.summary` | query | protected | 日次・週次・月次・期間指定集計 |
| `reports.exportCsv` | mutation | protected | CSV データ生成（文字列返却） |
| `auditLogs.list` | query | admin | 監査ログ一覧 |

---

## 3. ディレクトリ構成

```
factory-dashboard/
├── client/
│   └── src/
│       ├── _core/hooks/useAuth.ts        ← 既存（流用）
│       ├── components/
│       │   ├── DashboardLayout.tsx       ← 既存（カスタマイズ）
│       │   ├── MachineCard.tsx           ← 機械状態カード
│       │   ├── StatusBadge.tsx           ← 状態色分けバッジ
│       │   └── ui/                       ← shadcn/ui（既存）
│       ├── pages/
│       │   ├── Login.tsx                 ← ローカルログイン画面
│       │   ├── Dashboard.tsx             ← カンバンボード（D&D）
│       │   ├── MachineDetail.tsx         ← 機械詳細
│       │   ├── StopEvents.tsx            ← 停止イベント一覧・タグ付け
│       │   ├── Machines.tsx              ← 機械マスター管理
│       │   ├── Users.tsx                 ← ユーザー管理（Admin）
│       │   ├── ApiKeys.tsx               ← APIキー管理（Admin）
│       │   ├── Reports.tsx               ← 集計・レポート
│       │   └── AuditLogs.tsx             ← 監査ログ（Admin）
│       ├── lib/trpc.ts                   ← 既存（流用）
│       ├── const.ts                      ← 既存（ローカルログインURL追加）
│       └── App.tsx                       ← ルーティング更新
│
├── drizzle/
│   └── schema.ts                         ← 全テーブル定義（PostgreSQL）
│
├── server/
│   ├── _core/                            ← フレームワーク層（原則変更なし）
│   │   ├── index.ts                      ← ノードREST APIルート登録を追加
│   │   ├── context.ts                    ← ローカル認証対応に拡張
│   │   └── ...
│   ├── routes/
│   │   └── nodeApi.ts                    ← ノード端末向けREST API（Express）
│   ├── routers/
│   │   ├── index.ts                      ← appRouter（各ルーターを結合）
│   │   ├── auth.ts                       ← ローカル認証（login/logout/me）
│   │   ├── machines.ts                   ← 機械マスターCRUD
│   │   ├── currentStatuses.ts            ← 最新状態取得
│   │   ├── stopEvents.ts                 ← 停止イベント管理（UI側）
│   │   ├── periodLogs.ts                 ← 期間ログ取得
│   │   ├── dashboardLayouts.ts           ← レイアウト保存
│   │   ├── apiKeys.ts                    ← APIキー管理
│   │   ├── users.ts                      ← ユーザー管理
│   │   ├── stopReasons.ts                ← 停止理由マスター
│   │   ├── reports.ts                    ← 集計・CSV
│   │   └── auditLogs.ts                  ← 監査ログ
│   └── db.ts                             ← DB クエリヘルパー（PostgreSQL）
│
├── shared/
│   └── const.ts                          ← 既存（COOKIE_NAME 等）
│
├── drizzle.config.ts                     ← PostgreSQL 設定済み
├── todo.md
└── docs/
    └── design-spec.md                    ← 本ドキュメント
```

---

## 4. 認証フロー（Cookie セッション）

### 4-1. ローカル認証フロー

```
ブラウザ                          Express サーバー                    DB (PostgreSQL)
   │                                     │                                  │
   │  POST /api/trpc/auth.login           │                                  │
   │  { username, password }             │                                  │
   │ ─────────────────────────────────► │                                  │
   │                                     │  SELECT * FROM users             │
   │                                     │  WHERE username = ?              │
   │                                     │ ───────────────────────────────► │
   │                                     │ ◄─────────────────────────────── │
   │                                     │  bcrypt.compare(password, hash)  │
   │                                     │  ↓ 一致                          │
   │                                     │  signSession({ userId, role })   │
   │                                     │  → JWT ではなく                  │
   │                                     │    nanoid(32) のセッションID を  │
   │                                     │    sessions テーブルに保存       │
   │  Set-Cookie: app_session_id=<sid>   │                                  │
   │  HttpOnly; Secure; SameSite=None    │                                  │
   │ ◄─────────────────────────────────  │                                  │
   │                                     │                                  │
   │  以降のリクエスト（Cookie自動付与） │                                  │
   │ ─────────────────────────────────► │                                  │
   │                                     │  Cookie からセッションID取得     │
   │                                     │  sessions テーブルで検証         │
   │                                     │  → user 情報を ctx.user に注入   │
```

### 4-2. セッション保存方式

| 項目 | 内容 |
|------|------|
| セッションID | `nanoid(32)` で生成（推測不能なランダム文字列） |
| 保存先 | **DB の `sessions` テーブル**（または既存 SDK の JWT 方式を維持しつつ payload に userId を埋め込む） |
| Cookie 名 | `app_session_id`（既存 `COOKIE_NAME` 定数を流用） |
| Cookie 属性 | `HttpOnly: true`, `Secure: true`（HTTPS時）, `SameSite: None`, `Path: /` |
| 有効期限 | 24時間（設定ファイルで変更可能） |
| logout | Cookie を削除 + sessions テーブルのレコードを削除 |

> **実装方針の補足:** 既存の `sdk.ts` は Manus OAuth 用の JWT 署名/検証を行っている。
> ローカル認証では `sdk.signSession()` の仕組みを流用し、payload に `{ userId, role, loginMethod: 'local' }` を埋め込む形で実装する。
> これにより `context.ts` の `sdk.authenticateRequest()` を最小限の変更で拡張できる。

### 4-3. 初回起動時 Admin 自動作成

```
サーバー起動時（index.ts の startServer()）
  ↓
users テーブルに username='admin' が存在するか確認
  ↓ 存在しない場合のみ
bcrypt.hash('admin1234', 12) でハッシュ化
INSERT INTO users (username, password_hash, role) VALUES ('admin', <hash>, 'admin')
  ↓
起動ログに「Admin user created: admin / admin1234」を出力
```

---

## 5. stop-event の重複送信・順不同受信時の扱い

### 5-1. 基本原則

`stop_events` テーブルは `event_id` を一意キーとして管理する。
`action` フィールドによって以下のルールを適用する。

| action | 処理内容 |
|--------|---------|
| `open` | `event_id` が存在しない → INSERT（`lifecycle_state = 'open'`）。既に存在する場合は **無視**（重複送信対策） |
| `update` | `event_id` が存在する → UPDATE（`lifecycle_state = 'updating'`、各フィールドを上書き）。存在しない場合は **INSERT**（open を受け損なったケースへの対応） |
| `close` | `event_id` が存在する → UPDATE（`lifecycle_state = 'closed'`、`end_time` 等を確定）。存在しない場合は **INSERT**（同上） |

### 5-2. 順不同受信（out-of-order）の扱い

```
受信した action の優先度: close > update > open
```

- `lifecycle_state` が既に `'closed'` のレコードに対して `open` や `update` が届いた場合 → **無視する**（確定済みイベントは上書きしない）
- `lifecycle_state` が `'closed'` のレコードに `close` が再送された場合 → **無視する**（冪等性保証）
- `update` が `open` より先に届いた場合 → INSERT として処理し、`lifecycle_state = 'updating'` で作成する

### 5-3. 重複送信（duplicate）の扱い

- 同一 `event_id` + 同一 `action` の重複送信 → 最後に受信したデータで上書き（ただし `close` 済みは除く）
- `raw_payload_json` は常に最後に受信した payload で更新する

### 5-4. タイムスタンプ競合の扱い

- `last_update_time` は受信のたびに更新する
- `start_time` は最初の `open` 時のみ設定し、以降は上書きしない（`COALESCE` で保護）

---

## 6. ダッシュボード表示値の算出元定義

機械カードに表示する各値の算出元を明確に定義する。

| 表示項目 | 算出元テーブル | 算出方法 |
|---------|--------------|---------|
| **機械名** | `machines.machine_name` | そのまま表示 |
| **現在状態** | `current_statuses.current_state` + `current_statuses.stop_class` | `current_state` が `stop` かつ `stop_class = 'choco'` → **CHOCO STOP**（黄）、`stop_class = 'doka'` → **DOKA STOP**（赤）、`current_state = 'running'` → **RUNNING**（緑）、`current_state = 'planned_stop'` → **PLANNED STOP**（青）、`current_state = 'off'` または未受信 → **OFF**（灰） |
| **稼働率** | `period_logs`（直近の period_log レコード） | `running_seconds / (running_seconds + stopped_seconds + planned_stop_seconds) × 100`。period_log が存在しない場合は `--` 表示 |
| **RUNNING 時間** | `period_logs.running_seconds`（当日分） | 秒を `HH:MM:SS` に変換して表示 |
| **CHOCO STOP 時間** | `stop_events`（当日分、`stop_class = 'choco'`、`lifecycle_state = 'closed'`） | `SUM(final_stop_duration_sec)` を秒 → `HH:MM:SS` に変換 |
| **DOKA STOP 時間** | `stop_events`（当日分、`stop_class = 'doka'`、`lifecycle_state = 'closed'`） | `SUM(final_stop_duration_sec)` を秒 → `HH:MM:SS` に変換 |
| **PLANNED STOP 時間** | `period_logs.planned_stop_seconds`（当日分） | 秒 → `HH:MM:SS` に変換 |
| **生産数** | `period_logs.production_count`（当日分） | そのまま表示。未受信の場合は `--` |
| **最終更新時刻** | `current_statuses.updated_at` | ローカル時刻に変換して表示（例: `14:32:05`） |
| **通信状態** | `current_statuses.updated_at` との現在時刻差分 | 差分 < 5分 → **正常**（緑）、5〜15分 → **遅延**（黄）、15分以上または未受信 → **通信断**（赤） |

### 6-1. 「当日分」の定義

- `machines.time_start` が設定されている場合: 当日の `time_start` から現在時刻まで
- 設定されていない場合: 当日 00:00:00 JST から現在時刻まで

### 6-2. 稼働率の優先順位

1. `period_logs` に当日分のレコードが存在する → そのデータを使用
2. 存在しない場合 → `stop_events` と `current_statuses` から **サーバー側でオンデマンド計算**（将来実装）
3. 初期実装では `period_logs` のみを参照し、データなしの場合は `--` 表示とする

### 6-3. 状態色分け定義

| 状態 | 表示ラベル | カード背景色 | バッジ色 |
|------|----------|------------|---------|
| `running` | RUNNING | 緑（`#16a34a` 系） | green |
| `stop` + `stop_class=choco` | CHOCO STOP | 黄（`#ca8a04` 系） | yellow |
| `stop` + `stop_class=doka` | DOKA STOP | 赤（`#dc2626` 系） | red |
| `stop` + `stop_class=null/other` | STOP | オレンジ（`#ea580c` 系） | orange |
| `planned_stop` | PLANNED STOP | 青（`#2563eb` 系） | blue |
| `off` / 未受信 | OFF | 灰（`#6b7280` 系） | gray |

---

## 7. 補足事項

### 7-1. zod スキーマ設計方針

すべてのノード受信スキーマは以下の方針に従う。

```typescript
// passthrough() で未知フィールドを保持したまま受け取る
const schema = z.object({ ... }).passthrough();

// バリデーション前の生データを raw_payload_json に保存
const rawPayload = req.body; // zod 検証前
const parsed = schema.parse(req.body);
// → DB 保存時: raw_payload_json = JSON.stringify(rawPayload)
```

**ノード端末互換吸収の原則:**
- フィールド名の別名（`sampleTime`/`eventTime`、`stopSeconds`/`stoppedSeconds`、`segmentStart`/`startTime` 等）はサーバー側で正規化する
- 型の揺れ（`alarm` が boolean/string 両方）はサーバー側で吸収する
- 未知フィールドはエラーにせず `raw_payload_json` に保存する
- ノード端末側の大規模修正は不要とする

### 7-2. オフライン動作保証

- 外部 CDN・外部 API への依存なし
- フォント・アイコンはすべてバンドルに含める（Google Fonts CDN は使用しない）
- DB は PostgreSQL（ローカル）のみ

### 7-3. systemd 対応

`npm start`（`node dist/index.js`）で起動できる構成とし、systemd unit ファイルのサンプルを `docs/systemd.service` として提供する。
