import { z } from "zod";
import {
  getDashboardLayout,
  listCurrentStatuses,
  listMachines,
  saveDashboardLayout,
} from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const dashboardRouter = router({
  /** ダッシュボード表示用: 機械一覧 + 最新ステータスを結合して返す */
  overview: protectedProcedure.query(async () => {
    const [machines, statuses] = await Promise.all([
      listMachines(true),
      listCurrentStatuses(),
    ]);
    const statusMap = new Map(statuses.map(s => [s.machineId, s]));
    return machines.map(m => ({
      ...m,
      currentStatus: statusMap.get(m.machineId) ?? null,
    }));
  }),

  /** ユーザー別レイアウト取得 */
  getLayout: protectedProcedure
    .input(z.object({ layoutName: z.string().optional() }).optional())
    .query(async ({ ctx, input }) => {
      return getDashboardLayout(ctx.user.id, input?.layoutName ?? "default");
    }),

  /** ユーザー別レイアウト保存 */
  saveLayout: protectedProcedure
    .input(
      z.object({
        layoutName: z.string().optional(),
        layout: z.array(
          z.object({
            machineId: z.string(),
            position: z.number().int(),
            visible: z.boolean(),
          })
        ),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await saveDashboardLayout(ctx.user.id, input.layout, input.layoutName ?? "default");
      return { success: true };
    }),
});
