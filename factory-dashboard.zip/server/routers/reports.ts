import { z } from "zod";
import { listMachines, listPeriodLogs, listStopEvents } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

function startOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(0, 0, 0, 0);
  return r;
}
function endOfDay(d: Date) {
  const r = new Date(d);
  r.setHours(23, 59, 59, 999);
  return r;
}

function getPeriodLabel(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" });
  } else if (groupBy === "weekly") {
    const weekStart = new Date(date);
    weekStart.setDate(date.getDate() - date.getDay());
    return weekStart.toLocaleDateString("ja-JP", { month: "2-digit", day: "2-digit" }) + "週";
  } else {
    return date.toLocaleDateString("ja-JP", { year: "numeric", month: "2-digit" });
  }
}

function getPeriodKey(date: Date, groupBy: "daily" | "weekly" | "monthly"): string {
  if (groupBy === "daily") {
    return date.toISOString().slice(0, 10);
  } else if (groupBy === "weekly") {
    const d = new Date(date);
    d.setDate(d.getDate() - d.getDay());
    return d.toISOString().slice(0, 10);
  } else {
    return date.toISOString().slice(0, 7);
  }
}

export const reportsRouter = router({
  /** 期間集計: period_logs ベース、groupBy 対応 */
  aggregate: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
        groupBy: z.enum(["daily", "weekly", "monthly"]).default("daily"),
      })
    )
    .query(async ({ input }) => {
      const logs = await listPeriodLogs({
        machineId: input.machineId,
        from: input.from,
        to: input.to,
      });
      const stopEvts = await listStopEvents({
        machineId: input.machineId,
        from: input.from,
        to: input.to,
      });

      // group by period
      const byPeriod = new Map<
        string,
        {
          periodLabel: string;
          periodKey: string;
          totalRunningSeconds: number;
          totalStoppedSeconds: number;
          totalPlannedStopSeconds: number;
          totalIdleSeconds: number;
          totalProductionCount: number;
          operatingRate: number | null;
        }
      >();

      for (const log of logs) {
        const date = new Date(log.periodStart);
        const key = getPeriodKey(date, input.groupBy);
        const existing = byPeriod.get(key);
        if (!existing) {
          byPeriod.set(key, {
            periodLabel: getPeriodLabel(date, input.groupBy),
            periodKey: key,
            totalRunningSeconds: log.runningSeconds ?? 0,
            totalStoppedSeconds: log.stoppedSeconds ?? 0,
            totalPlannedStopSeconds: log.plannedStopSeconds ?? 0,
            totalIdleSeconds: log.idleSeconds ?? 0,
            totalProductionCount: log.productionCount ?? 0,
            operatingRate: null,
          });
        } else {
          existing.totalRunningSeconds += log.runningSeconds ?? 0;
          existing.totalStoppedSeconds += log.stoppedSeconds ?? 0;
          existing.totalPlannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.totalIdleSeconds += log.idleSeconds ?? 0;
          existing.totalProductionCount += log.productionCount ?? 0;
        }
      }

      // 稼働率計算
      const result = Array.from(byPeriod.values()).sort((a, b) =>
        a.periodKey.localeCompare(b.periodKey)
      );
      for (const r of result) {
        const total = r.totalRunningSeconds + r.totalStoppedSeconds + r.totalPlannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.totalRunningSeconds / total) * 1000) / 10 : null;
      }

      return result;
    }),

  /** CSV エクスポート用データ（period_logs の生データ） */
  exportCsv: protectedProcedure
    .input(
      z.object({
        machineId: z.string().optional(),
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      return listPeriodLogs({
        machineId: input.machineId,
        from: input.from,
        to: input.to,
      });
    }),

  /** 機械別サマリー（aggregate の機械別版） */
  machineSummary: protectedProcedure
    .input(
      z.object({
        from: z.date(),
        to: z.date(),
      })
    )
    .query(async ({ input }) => {
      const [logs, stopEvts, machines] = await Promise.all([
        listPeriodLogs({ from: input.from, to: input.to }),
        listStopEvents({ from: input.from, to: input.to }),
        listMachines(false),
      ]);

      const machineMap = new Map(machines.map(m => [m.machineId, m]));
      const byMachine = new Map<
        string,
        {
          machineId: string;
          machineName: string;
          runningSeconds: number;
          stoppedSeconds: number;
          plannedStopSeconds: number;
          idleSeconds: number;
          productionCount: number;
          targetProductionCount: number;
          chocoCount: number;
          dokaCount: number;
          chocoTotalSec: number;
          dokaTotalSec: number;
          operatingRate: number | null;
        }
      >();

      for (const log of logs) {
        const machine = machineMap.get(log.machineId);
        const existing = byMachine.get(log.machineId);
        if (!existing) {
          byMachine.set(log.machineId, {
            machineId: log.machineId,
            machineName: machine?.displayName ?? log.machineId,
            runningSeconds: log.runningSeconds ?? 0,
            stoppedSeconds: log.stoppedSeconds ?? 0,
            plannedStopSeconds: log.plannedStopSeconds ?? 0,
            idleSeconds: log.idleSeconds ?? 0,
            productionCount: log.productionCount ?? 0,
            targetProductionCount: log.targetProductionCount ?? 0,
            chocoCount: 0,
            dokaCount: 0,
            chocoTotalSec: 0,
            dokaTotalSec: 0,
            operatingRate: null,
          });
        } else {
          existing.runningSeconds += log.runningSeconds ?? 0;
          existing.stoppedSeconds += log.stoppedSeconds ?? 0;
          existing.plannedStopSeconds += log.plannedStopSeconds ?? 0;
          existing.idleSeconds += log.idleSeconds ?? 0;
          existing.productionCount += log.productionCount ?? 0;
          existing.targetProductionCount += log.targetProductionCount ?? 0;
        }
      }

      for (const evt of stopEvts) {
        if (evt.lifecycleState !== "closed") continue;
        const entry = byMachine.get(evt.machineId);
        if (!entry) continue;
        const cls = evt.finalStopClass ?? evt.stopClass;
        const dur = evt.finalStopDurationSec ?? 0;
        if (cls === "choco") { entry.chocoCount++; entry.chocoTotalSec += dur; }
        else if (cls === "doka") { entry.dokaCount++; entry.dokaTotalSec += dur; }
      }

      const rows = Array.from(byMachine.values());
      for (const r of rows) {
        const total = r.runningSeconds + r.stoppedSeconds + r.plannedStopSeconds;
        r.operatingRate = total > 0 ? Math.round((r.runningSeconds / total) * 1000) / 10 : null;
      }

      return rows;
    }),
});
