import { Badge } from "@/components/ui/badge";
import {
  calcOperatingRate,
  formatDuration,
  getCommStatus,
  getCommStatusColor,
  getCommStatusLabel,
  getStateLabel,
  getStateStyle,
} from "@/lib/machineState";
import { Activity, AlertTriangle, Clock, Package, Wifi, WifiOff } from "lucide-react";
import { useLocation } from "wouter";

interface CurrentStatus {
  machineId: string;
  currentState: string;
  stopClass?: string | null;
  eventTime?: Date | string | null;
  updatedAt: Date | string;
}

interface PeriodSummary {
  runningSeconds?: number | null;
  stoppedSeconds?: number | null;
  plannedStopSeconds?: number | null;
  productionCount?: number | null;
  targetProductionCount?: number | null;
}

interface MachineCardProps {
  machineId: string;
  displayName: string;
  location?: string | null;
  currentStatus?: CurrentStatus | null;
  todaySummary?: PeriodSummary | null;
  dragging?: boolean;
  onClick?: () => void;
}

export function MachineCard({
  machineId,
  displayName,
  location,
  currentStatus,
  todaySummary,
  dragging,
  onClick,
}: MachineCardProps) {
  const [, navigate] = useLocation();
  const state = currentStatus?.currentState ?? "off";
  const stopClass = currentStatus?.stopClass;
  const style = getStateStyle(state, stopClass);
  const commStatus = getCommStatus(currentStatus?.updatedAt ? new Date(currentStatus.updatedAt) : null);
  const operatingRate = calcOperatingRate(
    todaySummary?.runningSeconds,
    todaySummary?.stoppedSeconds,
    todaySummary?.plannedStopSeconds
  );

  const handleClick = () => {
    if (onClick) onClick();
    else navigate(`/machines/${machineId}`);
  };

  return (
    <div
      onClick={handleClick}
      className={`
        relative rounded-xl border p-4 cursor-pointer transition-all duration-200
        bg-card hover:bg-card/80
        ${style.borderClass}
        ${dragging ? "opacity-50 scale-95" : "hover:scale-[1.01] hover:shadow-lg"}
        ${style.glowClass}
      `}
    >
      {/* State indicator bar */}
      <div className={`absolute top-0 left-0 right-0 h-0.5 rounded-t-xl ${style.dotClass}`} />

      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold text-foreground text-sm truncate">{displayName}</h3>
          <p className="text-xs text-muted-foreground truncate">{machineId}</p>
          {location && (
            <p className="text-xs text-muted-foreground/70 truncate">{location}</p>
          )}
        </div>
        <div className="ml-2 flex flex-col items-end gap-1">
          {/* State badge */}
          <Badge
            variant="outline"
            className={`text-xs font-medium px-2 py-0.5 border ${style.badgeClass}`}
          >
            <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 ${style.dotClass}`} />
            {getStateLabel(state, stopClass)}
          </Badge>
          {/* Comm status */}
          <div className={`flex items-center gap-1 text-xs ${getCommStatusColor(commStatus)}`}>
            {commStatus === "ok" ? (
              <Wifi className="w-3 h-3" />
            ) : commStatus === "delayed" ? (
              <AlertTriangle className="w-3 h-3" />
            ) : (
              <WifiOff className="w-3 h-3" />
            )}
            <span>{getCommStatusLabel(commStatus)}</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 mt-3">
        {/* Operating rate */}
        <div className="bg-muted/40 rounded-lg p-2 text-center">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <Activity className="w-3 h-3 text-muted-foreground" />
          </div>
          <p className={`text-lg font-bold leading-none ${style.textClass}`}>
            {operatingRate != null ? `${operatingRate}%` : "--"}
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">稼働率</p>
        </div>

        {/* Running time */}
        <div className="bg-muted/40 rounded-lg p-2 text-center">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <Clock className="w-3 h-3 text-muted-foreground" />
          </div>
          <p className="text-xs font-mono font-semibold text-foreground leading-none">
            {formatDuration(todaySummary?.runningSeconds)}
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">稼働時間</p>
        </div>

        {/* Production count */}
        <div className="bg-muted/40 rounded-lg p-2 text-center">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <Package className="w-3 h-3 text-muted-foreground" />
          </div>
          <p className="text-xs font-semibold text-foreground leading-none">
            {todaySummary?.productionCount != null
              ? todaySummary.productionCount.toLocaleString()
              : "--"}
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">生産数</p>
        </div>
      </div>

      {/* Last update */}
      {currentStatus?.updatedAt && (
        <p className="text-[10px] text-muted-foreground/60 mt-2 text-right">
          更新: {new Date(currentStatus.updatedAt).toLocaleTimeString("ja-JP")}
        </p>
      )}
    </div>
  );
}
