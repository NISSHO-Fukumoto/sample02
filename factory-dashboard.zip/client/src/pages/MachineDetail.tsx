import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  calcOperatingRate,
  formatDuration,
  getCommStatus,
  getCommStatusColor,
  getCommStatusLabel,
  getStateLabel,
  getStateStyle,
} from "@/lib/machineState";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Clock,
  Package,
  Wifi,
  WifiOff,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation, useParams } from "wouter";

export default function MachineDetail() {
  const { machineId } = useParams<{ machineId: string }>();
  const [, navigate] = useLocation();
  const [todayDate] = useState(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const [todayEnd] = useState(() => {
    const d = new Date();
    d.setHours(23, 59, 59, 999);
    return d;
  });

  const { data: overview } = trpc.dashboard.overview.useQuery();
  const { data: stopEvents } = trpc.stopEvents.list.useQuery({
    machineId,
    from: todayDate,
    to: todayEnd,
    limit: 50,
  });
  const { data: periodLogs } = trpc.reports.exportCsv.useQuery({
    machineId,
    from: todayDate,
    to: todayEnd,
  });

  const machine = useMemo(
    () => overview?.find(m => m.machineId === machineId),
    [overview, machineId]
  );

  const todayLog = useMemo(() => {
    if (!periodLogs || periodLogs.length === 0) return null;
    // 最新のperiod logを使用
    return periodLogs[periodLogs.length - 1];
  }, [periodLogs]);

  if (!machine) {
    return (
      <div className="p-6">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-1" /> 戻る
        </Button>
        <p className="text-muted-foreground">機械が見つかりません: {machineId}</p>
      </div>
    );
  }

  const state = machine.currentStatus?.currentState ?? "off";
  const stopClass = machine.currentStatus?.stopClass;
  const style = getStateStyle(state, stopClass);
  const commStatus = getCommStatus(
    machine.currentStatus?.updatedAt ? new Date(machine.currentStatus.updatedAt) : null
  );
  const operatingRate = calcOperatingRate(
    todayLog?.runningSeconds,
    todayLog?.stoppedSeconds,
    todayLog?.plannedStopSeconds
  );

  const openEvents = stopEvents?.filter(e => e.lifecycleState !== "closed") ?? [];
  const closedEvents = stopEvents?.filter(e => e.lifecycleState === "closed") ?? [];

  return (
    <div className="p-6 space-y-6">
      {/* Back button */}
      <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="gap-1">
        <ArrowLeft className="w-4 h-4" /> ダッシュボードに戻る
      </Button>

      {/* Machine header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">{machine.displayName}</h1>
          <p className="text-sm text-muted-foreground">{machine.machineId}</p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <Badge
            variant="outline"
            className={`text-sm font-medium px-3 py-1 border ${style.badgeClass}`}
          >
            <span className={`inline-block w-2 h-2 rounded-full mr-2 ${style.dotClass}`} />
            {getStateLabel(state, stopClass)}
          </Badge>
          <div className={`flex items-center gap-1.5 text-sm ${getCommStatusColor(commStatus)}`}>
            {commStatus === "ok" ? (
              <Wifi className="w-4 h-4" />
            ) : commStatus === "delayed" ? (
              <AlertTriangle className="w-4 h-4" />
            ) : (
              <WifiOff className="w-4 h-4" />
            )}
            {getCommStatusLabel(commStatus)}
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">稼働率（本日）</span>
            </div>
            <p className={`text-3xl font-bold ${style.textClass}`}>
              {operatingRate != null ? `${operatingRate}%` : "--"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-[oklch(0.65_0.18_145)]" />
              <span className="text-xs text-muted-foreground">稼働時間</span>
            </div>
            <p className="text-2xl font-mono font-bold text-foreground">
              {formatDuration(todayLog?.runningSeconds)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-[oklch(0.55_0.22_25)]" />
              <span className="text-xs text-muted-foreground">停止時間</span>
            </div>
            <p className="text-2xl font-mono font-bold text-foreground">
              {formatDuration(todayLog?.stoppedSeconds)}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Package className="w-4 h-4 text-[oklch(0.75_0.18_85)]" />
              <span className="text-xs text-muted-foreground">生産数</span>
            </div>
            <p className="text-2xl font-bold text-foreground">
              {todayLog?.productionCount != null
                ? todayLog.productionCount.toLocaleString()
                : "--"}
              {todayLog?.targetProductionCount != null && (
                <span className="text-sm text-muted-foreground ml-1">
                  / {todayLog.targetProductionCount.toLocaleString()}
                </span>
              )}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* State time breakdown */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">本日の状態別時間</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              {
                label: "稼働",
                value: todayLog?.runningSeconds,
                color: "oklch(0.65 0.18 145)",
              },
              {
                label: "停止",
                value: todayLog?.stoppedSeconds,
                color: "oklch(0.55 0.22 25)",
              },
              {
                label: "計画停止",
                value: todayLog?.plannedStopSeconds,
                color: "oklch(0.60 0.15 255)",
              },
              {
                label: "アイドル",
                value: todayLog?.idleSeconds,
                color: "oklch(0.50 0.02 240)",
              },
            ].map(({ label, value, color }) => (
              <div
                key={label}
                className="bg-muted/30 rounded-lg p-3 border"
                style={{ borderColor: `${color}30` }}
              >
                <p className="text-xs text-muted-foreground mb-1">{label}</p>
                <p className="text-sm font-mono font-semibold" style={{ color }}>
                  {formatDuration(value)}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active stop events */}
      {openEvents.length > 0 && (
        <Card className="bg-card border-[oklch(0.55_0.22_25/0.3)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-[oklch(0.65_0.22_25)]" />
              進行中の停止イベント ({openEvents.length}件)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {openEvents.map(evt => (
              <div
                key={evt.id}
                className="flex items-center justify-between bg-muted/30 rounded-lg px-3 py-2 border border-[oklch(0.55_0.22_25/0.2)]"
              >
                <div>
                  <p className="text-xs font-mono text-muted-foreground">{evt.eventId}</p>
                  <p className="text-sm text-foreground">
                    {evt.stopClass ?? "不明"} —{" "}
                    {evt.startTime
                      ? new Date(evt.startTime).toLocaleTimeString("ja-JP")
                      : "時刻不明"}
                  </p>
                </div>
                <Badge variant="outline" className="text-xs border-[oklch(0.55_0.22_25/0.4)] text-[oklch(0.65_0.22_25)]">
                  {evt.lifecycleState}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Closed stop events today */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            本日の停止イベント（確定済み: {closedEvents.length}件）
          </CardTitle>
        </CardHeader>
        <CardContent>
          {closedEvents.length === 0 ? (
            <p className="text-sm text-muted-foreground">本日の停止イベントはありません</p>
          ) : (
            <div className="space-y-2">
              {closedEvents.map(evt => (
                <div
                  key={evt.id}
                  className="flex items-center justify-between bg-muted/20 rounded-lg px-3 py-2"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-mono text-muted-foreground truncate">{evt.eventId}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-sm text-foreground">
                        {evt.finalStopClass ?? evt.stopClass ?? "不明"}
                      </span>
                      {evt.finalStopDurationSec != null && (
                        <span className="text-xs text-muted-foreground">
                          {formatDuration(evt.finalStopDurationSec)}
                        </span>
                      )}
                      {evt.reasonCode && (
                        <Badge variant="secondary" className="text-xs">
                          {evt.reasonCode}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground text-right ml-2">
                    {evt.startTime && new Date(evt.startTime).toLocaleTimeString("ja-JP")}
                    {evt.endTime && ` ~ ${new Date(evt.endTime).toLocaleTimeString("ja-JP")}`}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Last update */}
      {machine.currentStatus?.updatedAt && (
        <p className="text-xs text-muted-foreground text-right">
          最終更新: {new Date(machine.currentStatus.updatedAt).toLocaleString("ja-JP")}
        </p>
      )}
    </div>
  );
}
