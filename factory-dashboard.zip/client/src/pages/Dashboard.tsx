import { MachineCard } from "@/components/MachineCard";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  rectSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, LayoutGrid, RefreshCw } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

interface LayoutItem {
  machineId: string;
  position: number;
  visible: boolean;
}

interface MachineWithStatus {
  id: number;
  machineId: string;
  displayName: string;
  location?: string | null;
  currentStatus?: {
    machineId: string;
    currentState: string;
    stopClass?: string | null;
    eventTime?: Date | string | null;
    updatedAt: Date | string;
  } | null;
}

function SortableMachineCard({
  machine,
  visible,
  onToggleVisible,
}: {
  machine: MachineWithStatus;
  visible: boolean;
  onToggleVisible: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: machine.machineId,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  if (!visible) return null;

  return (
    <div ref={setNodeRef} style={style} className="relative group">
      {/* Drag handle */}
      <div
        {...attributes}
        {...listeners}
        className="absolute top-2 left-2 z-10 opacity-0 group-hover:opacity-60 cursor-grab active:cursor-grabbing transition-opacity"
      >
        <GripVertical className="w-4 h-4 text-muted-foreground" />
      </div>
      <MachineCard
        machineId={machine.machineId}
        displayName={machine.displayName}
        location={machine.location}
        currentStatus={machine.currentStatus}
        dragging={isDragging}
      />
    </div>
  );
}

export default function Dashboard() {
  const utils = trpc.useUtils();
  const { data: machines, isLoading, refetch } = trpc.dashboard.overview.useQuery(undefined, {
    refetchInterval: 30_000, // 30秒ごとに自動更新
  });
  const { data: savedLayout } = trpc.dashboard.getLayout.useQuery();
  const saveLayoutMutation = trpc.dashboard.saveLayout.useMutation();

  const [orderedIds, setOrderedIds] = useState<string[]>([]);
  const [visibilityMap, setVisibilityMap] = useState<Map<string, boolean>>(new Map());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [layoutDirty, setLayoutDirty] = useState(false);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

  // レイアウト初期化
  useEffect(() => {
    if (!machines) return;
    const allIds = machines.map(m => m.machineId);
    if (savedLayout?.layoutJson) {
      const saved = savedLayout.layoutJson as LayoutItem[];
      const savedIds = saved
        .filter(l => allIds.includes(l.machineId))
        .sort((a, b) => a.position - b.position)
        .map(l => l.machineId);
      // 新しく追加された機械を末尾に追加
      const newIds = allIds.filter(id => !savedIds.includes(id));
      setOrderedIds([...savedIds, ...newIds]);
      const visMap = new Map<string, boolean>();
      for (const l of saved) visMap.set(l.machineId, l.visible);
      for (const id of newIds) visMap.set(id, true);
      setVisibilityMap(visMap);
    } else {
      setOrderedIds(allIds);
      const visMap = new Map<string, boolean>();
      for (const id of allIds) visMap.set(id, true);
      setVisibilityMap(visMap);
    }
  }, [machines, savedLayout]);

  const machineMap = useMemo(() => {
    if (!machines) return new Map<string, MachineWithStatus>();
    return new Map(machines.map(m => [m.machineId, m as MachineWithStatus]));
  }, [machines]);

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback(
    (event: DragEndEvent) => {
      setActiveId(null);
      const { active, over } = event;
      if (!over || active.id === over.id) return;
      setOrderedIds(prev => {
        const oldIndex = prev.indexOf(active.id as string);
        const newIndex = prev.indexOf(over.id as string);
        return arrayMove(prev, oldIndex, newIndex);
      });
      setLayoutDirty(true);
    },
    []
  );

  const handleSaveLayout = useCallback(async () => {
    const layout = orderedIds.map((id, idx) => ({
      machineId: id,
      position: idx,
      visible: visibilityMap.get(id) ?? true,
    }));
    await saveLayoutMutation.mutateAsync({ layout });
    setLayoutDirty(false);
    toast.success("レイアウトを保存しました");
  }, [orderedIds, visibilityMap, saveLayoutMutation]);

  const activeM = activeId ? machineMap.get(activeId) : null;

  // State summary counts
  const stateCounts = useMemo(() => {
    if (!machines) return { running: 0, choco: 0, doka: 0, planned_stop: 0, off: 0 };
    const counts = { running: 0, choco: 0, doka: 0, planned_stop: 0, off: 0 };
    for (const m of machines) {
      const s = m.currentStatus;
      if (!s) { counts.off++; continue; }
      const cls = s.stopClass;
      const state = s.currentState?.toLowerCase() ?? "off";
      if (cls === "choco") counts.choco++;
      else if (cls === "doka") counts.doka++;
      else if (state === "running") counts.running++;
      else if (state === "planned_stop") counts.planned_stop++;
      else counts.off++;
    }
    return counts;
  }, [machines]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground text-sm">読み込み中...</div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <LayoutGrid className="w-5 h-5 text-primary" />
            稼働状況ダッシュボード
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            全 {machines?.length ?? 0} 台 — 30秒ごとに自動更新
          </p>
        </div>
        <div className="flex items-center gap-2">
          {layoutDirty && (
            <Button size="sm" onClick={handleSaveLayout} disabled={saveLayoutMutation.isPending}>
              レイアウト保存
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={() => refetch()}
            className="gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            更新
          </Button>
        </div>
      </div>

      {/* State summary bar */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { key: "running", label: "稼働中", color: "oklch(0.65 0.18 145)" },
          { key: "choco", label: "チョコ停", color: "oklch(0.75 0.18 85)" },
          { key: "doka", label: "ドカ停", color: "oklch(0.55 0.22 25)" },
          { key: "planned_stop", label: "計画停止", color: "oklch(0.60 0.15 255)" },
          { key: "off", label: "停止", color: "oklch(0.50 0.02 240)" },
        ].map(({ key, label, color }) => (
          <div
            key={key}
            className="bg-card border border-border rounded-lg p-3 text-center"
            style={{ borderColor: `${color}40` }}
          >
            <p className="text-2xl font-bold" style={{ color }}>
              {stateCounts[key as keyof typeof stateCounts]}
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      {/* Kanban grid with DnD */}
      {machines && machines.length > 0 ? (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <SortableContext items={orderedIds} strategy={rectSortingStrategy}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {orderedIds.map(id => {
                const m = machineMap.get(id);
                if (!m) return null;
                return (
                  <SortableMachineCard
                    key={id}
                    machine={m}
                    visible={visibilityMap.get(id) ?? true}
                    onToggleVisible={() => {
                      setVisibilityMap(prev => {
                        const next = new Map(prev);
                        next.set(id, !prev.get(id));
                        return next;
                      });
                      setLayoutDirty(true);
                    }}
                  />
                );
              })}
            </div>
          </SortableContext>

          <DragOverlay>
            {activeM && (
              <MachineCard
                machineId={activeM.machineId}
                displayName={activeM.displayName}
                location={activeM.location}
                currentStatus={activeM.currentStatus}
                dragging
              />
            )}
          </DragOverlay>
        </DndContext>
      ) : (
        <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
          <p className="text-sm">機械が登録されていません</p>
          <p className="text-xs mt-1">「機械管理」から機械を追加してください</p>
        </div>
      )}
    </div>
  );
}
