import tkinter as tk
from tkinter import scrolledtext
import RPi.GPIO as GPIO
from datetime import datetime

# --- 設定 ---
# 監視対象のGPIOピン（BCM番号）
TARGET_PINS = [3, 4, 17, 27, 22, 5] 

class GPIOTester:
    def __init__(self, root):
        self.root = root
        self.root.title("GPIO Input Tester")
        self.root.geometry("500x400")

        # ログ保持用リスト
        self.log_data = []

        # UIの構築
        self.setup_ui()

        # GPIOの初期化
        self.setup_gpio()

    def setup_ui(self):
        # タイトルラベル
        lbl = tk.Label(self.root, text="GPIO 入力履歴 (最新10件)", font=("Arial", 14, "bold"))
        lbl.pack(pady=10)

        # ログ表示エリア
        self.log_display = scrolledtext.ScrolledText(self.root, width=50, height=15, font=("Consolas", 10))
        self.log_display.pack(padx=10, pady=10)

        # 状態表示用（現在の各ピンの値）
        self.status_frame = tk.Frame(self.root)
        self.status_frame.pack(pady=5)
        self.status_labels = {}
        
        for pin in TARGET_PINS:
            l = tk.Label(self.status_frame, text=f"GPIO {pin}: --", width=12, relief="sunken")
            l.pack(side=tk.LEFT, padx=2)
            self.status_labels[pin] = l

    def setup_gpio(self):
        GPIO.setmode(GPIO.BCM)
        for pin in TARGET_PINS:
            try:
                # 内部プルアップを有効化（スイッチを押すとLowになる設定）
                GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
                # 立ち下がり（押した瞬間）を検知
                GPIO.add_event_detect(pin, GPIO.FALLING, callback=self.gpio_callback, bouncetime=200)
                self.add_log(f"SYSTEM: GPIO {pin} initialized.")
            except Exception as e:
                self.add_log(f"ERROR: GPIO {pin} setup failed: {e}")

    def gpio_callback(self, pin):
        # 割り込みハンドラ内ではGUIを直接操作せず、afterメソッドなどを使うのが安全
        now = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        msg = f"[{now}] GPIO {pin} DETECTED (FALLING)"
        self.root.after(0, self.add_log, msg)

    def add_log(self, message):
        # 新しいログを先頭に追加
        self.log_data.insert(0, message)
        # 10件に制限
        self.log_data = self.log_data[:10]
        
        # 表示更新
        self.log_display.config(state=tk.NORMAL)
        self.log_display.delete(1.0, tk.END)
        self.log_display.insert(tk.END, "\n".join(self.log_data))
        self.log_display.config(state=tk.DISABLED)

    def update_status(self):
        # 現在のピンの生の状態を定期的に更新表示
        for pin in TARGET_PINS:
            try:
                val = GPIO.input(pin)
                state_str = "HIGH" if val else "LOW"
                color = "white" if val else "yellow"
                self.status_labels[pin].config(text=f"GPIO {pin}: {state_str}", bg=color)
            except:
                pass
        self.root.after(500, self.update_status)

def on_closing():
    GPIO.cleanup()
    root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = GPIOTester(root)
    app.update_status() # 状態監視スタート
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()