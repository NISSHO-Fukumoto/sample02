"""
app.py - Flight_Status_Board メインアプリケーション（v5.0）
Raspberry Pi 400 エントリーモデル ノード端末

起動:
  python3 app.py

アーキテクチャ:
  pasted_content.txt §14 に準拠したモジュール構成
"""
import sys
import os
import re
import csv
import io
import time
import threading
import logging
import socket
import subprocess  # システムコマンド（シャットダウン）を実行するため
import signal      # プログラム終了時の割り込みをキャッチするため追加
from collections import deque
from datetime import datetime, timedelta, timezone
from flask import Flask, render_template, jsonify, request, Response

# QRコード生成（未インストールでもQR以外の機能は動作する）
try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False
JST = timezone(timedelta(hours=9))

# 選択可能な組込みUIデザインの内部index（表示順は index.html 側 VALID_THEMES と一致）。
# 旧 DESIGN 3（HUD, index 2/5）は廃止済みのため含めない。
VALID_UI_THEMES = (0, 1, 3, 4, 6, 7)

# ── パス設定 ──────────────────────────────────────────────────────────
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, BASE_DIR)

# ── ログ設定 ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('Flight_Status_Board')
# Werkzeug のログを抑制
logging.getLogger('werkzeug').setLevel(logging.ERROR)

# ── コアモジュール ────────────────────────────────────────────────────
from core.config_loader    import ConfigLoader
from core.state_machine    import StateMachine
from core.counter_tracker  import CounterTracker
from core.input_reader     import InputReader
from core.break_scheduler  import BreakScheduler
try:
    from camera_config_ui import CameraConfigUI
    HAS_CAMERA_UI = True
except ImportError:
    HAS_CAMERA_UI = False
from core.stop_event_manager import StopEventManager
from core.period_aggregator  import PeriodAggregator
from core.api_client       import ApiClient
from core.spool_queue      import SpoolQueue
from core.sender           import Sender

# ── 設定読み込み ──────────────────────────────────────────────────────
config_file = os.path.join(BASE_DIR, 'conf.ini')
config = ConfigLoader(config_file)

# ── コアオブジェクト生成 ──────────────────────────────────────────────
state_machine    = StateMachine(config)
counter          = CounterTracker(config)
break_scheduler  = BreakScheduler(config)
stop_event_mgr   = StopEventManager(config.get('machine_id', 'DEFAULT_MACHINE'))
period_aggregator = PeriodAggregator(config, counter)
# input_reader は main() 内で生成される（カメラ/GPIO初期化を起動時まで
# 遅延させるため）。/api/data 等のルート関数から参照できるよう、
# ここでモジュールレベルの変数として先に宣言しておく（既定 None）。
input_reader = None
api_client       = ApiClient(config)
spool_queue      = SpoolQueue(os.path.join(BASE_DIR, 'spool.json'))
sender           = Sender(config, api_client, spool_queue,
                          state_machine, counter,
                          stop_event_mgr, period_aggregator)

# ── Flask アプリ ──────────────────────────────────────────────────────
TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR   = os.path.join(BASE_DIR, 'static')
app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

# ── ユーティリティ ────────────────────────────────────────────────────
def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def format_duration(seconds: float) -> str:
    # 負値（ドカ停昇格時の choco 補償など）は表示上 0 に丸める。
    # accumulated_*_sec 自体はサーバー相殺のため負値を保持するが、
    # 画面・CSV表示では 00:00:00 とする（桁溢れ・マイナス表示防止）。
    s = max(0, int(seconds))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h:02}:{m:02}:{sec:02}"

def get_status_key() -> str:
    """フロントエンド用のステータスキーを返す"""
    state = state_machine.current_state
    if state == "stop":
        return "stop_doka" if state_machine.stop_class == "doka" else "stop_choco"
    return state

# ── カウント発生コールバック ──────────────────────────────────────────
_input_lock = threading.Lock()

# タクト自動計測用: 直近カウントの発生時刻（テスト運転から推奨閾値を算出する）
_count_timestamps = deque(maxlen=30)

# CSVエクスポート用: 当日の停止イベント履歴（メモリ保持・最大300件）
_stop_log = []

def _record_stop_events(events):
    """stop_event_manager が生成したイベントをローカル履歴に記録する"""
    for ev in events:
        action = ev.get("action")
        if action == "open":
            _stop_log.append({
                "id":       ev.get("eventId"),
                "cls":      ev.get("stopClass"),
                "start":    ev.get("segmentStart"),
                "end":      None,
                "duration": None,
                "reason":   None,
            })
        elif action == "update":
            for entry in reversed(_stop_log):
                if entry["id"] == ev.get("eventId"):
                    entry["cls"] = ev.get("stopClass", entry["cls"])
                    break
        elif action == "close":
            for entry in reversed(_stop_log):
                if entry["id"] == ev.get("eventId"):
                    entry["cls"]      = ev.get("finalStopClass", entry["cls"])
                    entry["end"]      = ev.get("segmentEnd")
                    entry["duration"] = ev.get("finalStopDurationSec")
                    entry["reason"]   = ev.get("closeReason")
                    break
    del _stop_log[:-300]   # 古いものから捨てる（メモリ保護）

def on_count(increment=1):
    """入力モジュールからカウント発生時に呼ばれる"""
    with _input_lock:
        _count_timestamps.append(time.time())
        state_machine.on_count()

        # カウントアップのみ実行（時間の加算は background_loop が行う）
        counter.on_count(state_machine, increment=increment)
        logger.info(f"[COUNT] count={counter.count} (+{increment})")

        events = stop_event_mgr.process(state_machine)
        if events:
            _record_stop_events(events)
            sender.on_stop_events(events)

        if state_machine.has_changed():
            sender.on_state_changed()

def on_alarm(active: bool):
    state_machine.alarm = active
    logger.info(f"[ALARM] alarm={'ON' if active else 'OFF'}")
    sender.on_state_changed()

# ── バックグラウンド監視ループ ─────────────────────────────────────────
def background_loop():
    while True:
        try:
            # 1. 状態の決定
            state_machine.update()

            # 2. ★新規追加：リアルタイム排他集計の実行
            counter.update_time(state_machine)

            # 3. 各種モジュールの更新
            period_aggregator.update(state_machine)
            events = stop_event_mgr.process(state_machine)

            if events:
                _record_stop_events(events)
                sender.on_stop_events(events)

            if state_machine.has_changed():
                sender.on_state_changed()
                logger.info(
                    f"[STATE] {state_machine.current_state} / "
                    f"stop_class={state_machine.stop_class} / "
                    f"zone={state_machine.time_zone} / "
                    f"violation={state_machine.schedule_violation}"
                )
        except Exception as e:
            logger.error(f"[BG] Error: {e}")
        time.sleep(0.5)

# ── プログラム終了時の割り込み処理 ────────────────────────────────────
def handle_graceful_shutdown(signum, frame):
    """Ctrl+C や systemctl stop などの終了シグナルを受け取った時の処理"""
    logger.info(f"\n[Shutdown] Received signal {signum}. Shutting down gracefully...")
    try:
        # 終了直前にオフライン状態をサーバーへ送信
        sender.send_offline_status()
    except Exception as e:
        logger.error(f"Failed to send offline status: {e}")
    
    # プログラムを終了
    sys.exit(0)

# ── Flask ルート ──────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template(
        'index.html',
        product_name=config.get('product_name', 'Flight_Status_Board'),
        model_number='Entry Model',
        current_ip=get_local_ip(),
        enable_keyboard_reset=config.get('enable_keyboard_reset', True),
        reset_hold_time=config.get('reset_hold_time', 3.0),
        exit_hold_time=config.get('exit_hold_time', 2.0),
        default_theme=config.get('ui_theme', 0),
        external_design=config.get('external_design', ''),
        stream_port=config.get('stream_port', 5001),
        input_mode=config.get('input_mode', 'GPIO'),
    )

@app.route('/api/takt')
def api_takt():
    """
    タクト自動計測: 直近カウントの間隔から平均タクトを算出し、
    チョコ停閾値の推奨値（平均タクト×1.5）を返す。
    テスト運転（3サイクル以上）で自動的に値が埋まる。
    """
    ts = list(_count_timestamps)
    intervals = [t2 - t1 for t1, t2 in zip(ts, ts[1:])]

    valid = []
    if intervals:
        # 停止をまたいだ長い間隔を除外（中央値の5倍超は停止とみなす）
        s = sorted(intervals)
        median = s[len(s) // 2]
        valid = [v for v in intervals if v <= max(median * 5, 1.0)]

    if len(valid) >= 3:
        avg = sum(valid) / len(valid)
        recommended = max(5, int(round(avg * 1.5)))
        return jsonify({
            "samples":               len(valid),
            "avg_takt_sec":          round(avg, 1),
            "recommended_choco_sec": recommended,
        })
    return jsonify({
        "samples":               len(valid),
        "avg_takt_sec":          None,
        "recommended_choco_sec": None,
    })

@app.route('/api/qr_matrix')
def api_qr_matrix():
    """
    自局URL（http://<IP>:5000/）のQRコード行列を返す。
    フロント側でcanvas描画する（画像ライブラリ不要・全テーマ共通表示用）。
    """
    url = f"http://{get_local_ip()}:5000/"
    if not HAS_QRCODE:
        return jsonify({"status": "error", "url": url,
                        "message": "qrcode library not installed"}), 501
    qr = qrcode.QRCode(border=1, error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(url)
    qr.make(fit=True)
    matrix = qr.get_matrix()
    return jsonify({
        "status": "ok",
        "url":    url,
        "size":   len(matrix),
        "rows":   ["".join('1' if c else '0' for c in row) for row in matrix],
    })

@app.route('/api/export_csv')
def api_export_csv():
    """
    当日データのCSVエクスポート（サーバー未導入のノード単体運用向け）。
    スマホ・タブレット・事務所PCのブラウザからダウンロードし日次データを取得する。
    ファイル名: FSB_<MachineID>_<IPアドレス>_<日付>.csv
    """
    now_dt = datetime.now(JST)
    ip     = get_local_ip()
    mid    = str(config.get('machine_id', 'MACHINE'))
    today  = now_dt.strftime('%Y-%m-%d')

    def _iso_short(s):
        """ISO文字列 → 'YYYY-MM-DD HH:MM:SS'"""
        if not s:
            return ""
        return s.replace("T", " ")[:19]

    todays = [e for e in _stop_log if (e.get("start") or "").startswith(today)]
    choco_n = sum(1 for e in todays if e.get("cls") == "choco")
    doka_n  = sum(1 for e in todays if e.get("cls") == "doka")

    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Flight_Status_Board 日次レポート"])
    w.writerow(["日付",         today])
    w.writerow(["Machine ID",  mid])
    w.writerow(["IPアドレス",   ip])
    w.writerow(["出力時刻",     now_dt.strftime('%H:%M:%S')])
    w.writerow([])
    w.writerow(["生産サマリ"])
    w.writerow(["生産カウント",       counter.count])
    w.writerow(["目標",              config.get('target', 0)])
    w.writerow(["達成率(%)",         counter.get_percent()])
    w.writerow(["平均生産数(個/h)",   counter.get_avg_per_hour()])
    w.writerow(["稼働時間",          format_duration(counter.get_current_work_sec())])
    w.writerow(["チョコ停時間",       format_duration(counter.get_current_choco_sec())])
    w.writerow(["ドカ停時間",        format_duration(counter.get_current_doka_sec())])
    w.writerow(["計画停止時間",       format_duration(counter.get_current_planned_stop_sec())])
    w.writerow(["チョコ停回数",       choco_n])
    w.writerow(["ドカ停回数",        doka_n])
    w.writerow([])
    w.writerow(["停止イベント履歴（当日）"])
    w.writerow(["No", "種別", "開始時刻", "終了時刻", "継続時間(秒)", "終了理由"])
    for i, e in enumerate(todays, 1):
        w.writerow([
            i,
            e.get("cls") or "",
            _iso_short(e.get("start")),
            _iso_short(e.get("end")) if e.get("end") else "継続中",
            e.get("duration") if e.get("duration") is not None else "",
            e.get("reason") or "",
        ])
    if not todays:
        w.writerow(["-", "本日の停止イベントはありません", "", "", "", ""])

    # UTF-8 BOM付き（Excelで文字化けさせない）
    csv_text = "﻿" + buf.getvalue()
    fname = f"FSB_{mid}_{ip.replace('.', '-')}_{now_dt.strftime('%Y%m%d')}.csv"
    logger.info(f"[CSV] Exported: {fname}")
    return Response(
        csv_text,
        mimetype="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )

# ── ダウンロード型デザイン（外部デザインファイル） ─────────────────────
# designs/ フォルダに自己完結の .html デザインを置くと選択肢に追加される。
# 弊社 HP からダウンロードしたデザインを、ブラウザからアップロード（＝追加/上書き）できる。
DESIGNS_DIR = os.path.join(BASE_DIR, 'designs')

def _safe_design_name(name: str) -> str:
    """ディレクトリトラバーサル対策。ファイル名のみ・.html のみ許可。"""
    base = os.path.basename(str(name or '')).strip()
    return base if base.lower().endswith('.html') else ''

@app.route('/api/designs')
def api_designs():
    """designs/ 内の外部デザイン一覧を返す。'_' 始まりはテンプレート等として除外。"""
    items = []
    if os.path.isdir(DESIGNS_DIR):
        for fn in sorted(os.listdir(DESIGNS_DIR)):
            if not fn.lower().endswith('.html') or fn.startswith('_'):
                continue
            title = fn
            try:
                with open(os.path.join(DESIGNS_DIR, fn), encoding='utf-8') as f:
                    head = f.read(4000)
                m = re.search(r'<title>(.*?)</title>', head, re.I | re.S)
                if m:
                    title = m.group(1).strip()
            except Exception:
                pass
            items.append({"file": fn, "title": title})
    return jsonify({"designs": items, "current": config.get('external_design', '')})

@app.route('/design/<path:name>')
def serve_design(name):
    """外部デザインHTMLを配信する（iframe表示用）。"""
    safe = _safe_design_name(name)
    path = os.path.join(DESIGNS_DIR, safe)
    if not safe or not os.path.isfile(path):
        return "Design not found", 404
    with open(path, encoding='utf-8') as f:
        return Response(f.read(), mimetype='text/html; charset=utf-8')

@app.route('/api/upload_design', methods=['POST'])
def upload_design():
    """ブラウザから .html デザインをアップロード（同名なら上書き）。"""
    try:
        f = request.files.get('file')
        if not f:
            return jsonify({"status": "error", "message": "ファイルがありません"}), 400
        safe = _safe_design_name(f.filename)
        if not safe:
            return jsonify({"status": "error", "message": "HTMLファイル(.html)を選択してください"}), 400
        os.makedirs(DESIGNS_DIR, exist_ok=True)
        f.save(os.path.join(DESIGNS_DIR, safe))
        logger.info(f"[Design] Uploaded/overwritten: {safe}")
        return jsonify({"status": "ok", "file": safe})
    except Exception as e:
        logger.error(f"[Design] Upload error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/select_design', methods=['POST'])
def select_design():
    """起動時デザインを設定する。file='' で組込みデザインに戻す。"""
    try:
        data = request.get_json() or {}
        raw = str(data.get('file', ''))
        name = _safe_design_name(raw) if raw else ''
        if name and not os.path.isfile(os.path.join(DESIGNS_DIR, name)):
            return jsonify({"status": "error", "message": "not found"}), 404
        config.update_and_save('DISPLAY', 'external_design', name)
        config.load()
        logger.info(f"[Design] Boot design set to: {name or '(built-in)'}")
        return jsonify({"status": "ok", "file": name})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/delete_design', methods=['POST'])
def delete_design():
    """外部デザインファイルを削除する。"""
    try:
        data = request.get_json() or {}
        name = _safe_design_name(data.get('file', ''))
        if name:
            p = os.path.join(DESIGNS_DIR, name)
            if os.path.isfile(p):
                os.remove(p)
            if config.get('external_design', '') == name:
                config.update_and_save('DISPLAY', 'external_design', '')
            config.load()
            logger.info(f"[Design] Deleted: {name}")
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/theme', methods=['GET'])
def api_theme_get():
    return jsonify({"theme": config.get('ui_theme', 0)})

@app.route('/api/theme', methods=['POST'])
def api_theme_post():
    """UI デザイン（テーマ番号）を conf.ini に保存する。
    旧 DESIGN 3（HUD, index 2/5）は廃止済みのため許可しない。"""
    try:
        data = request.get_json() or {}
        theme = int(data.get('theme', 0))
        if theme not in VALID_UI_THEMES:
            theme = 0
        config.update_and_save('DISPLAY', 'ui_theme', str(theme))
        config.load()
        logger.info(f"[Theme] UI theme saved: {theme}")
        return jsonify({"status": "ok", "theme": theme})
    except Exception as e:
        logger.error(f"[Theme] Save error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/data')
def api_data():
    try:
        now = time.time()
        stop_elapsed = 0
        if state_machine.stop_start_at:
            stop_elapsed = int(now - state_machine.stop_start_at)

        last_count_str = "--"
        if state_machine.last_count_at:
            last_count_str = datetime.fromtimestamp(
                state_machine.last_count_at, JST).strftime('%H:%M:%S')

        # WebCamの接続状態（OK/NG の2値のみ。再接続中等の中間状態は出さない）。
        # CAMERA モード以外（GPIO等）では判定対象外のため常にOK扱いとする。
        webcam_ok = True
        if config.get('input_mode', '--') == 'CAMERA':
            grabber = getattr(input_reader, '_grabber', None)
            webcam_ok = bool(grabber is not None and grabber.is_opened())

        return jsonify({
            "count":              counter.count,
            "target":             config.get('target', 100),
            "percent":            counter.get_percent(),
            "avg_count":          counter.get_avg_per_hour(),
            "status":             get_status_key(),
            "stop_elapsed_sec":   stop_elapsed,
            "last_count_at":      last_count_str,
            "op_time":            format_duration(counter.get_current_work_sec()),
            "choco_time":         format_duration(counter.get_current_choco_sec()),
            "doka_time":          format_duration(counter.get_current_doka_sec()),
            "planned_time":       format_duration(counter.get_current_planned_stop_sec()), # ← カウンターから直接取得するように修正
            "alarm":              state_machine.alarm,
            "schedule_violation": state_machine.schedule_violation,
            "time_zone":          state_machine.time_zone,
            "machine_id":         config.get('machine_id', '--'),
            "input_mode":         config.get('input_mode', '--'),
            "webcam_ok":          webcam_ok,
            "stop_detect_sec":    config.get('dur_choco_sec', 180),
            "doka_threshold_sec": config.get('dur_doka_sec', 600),
            "spool_size":         spool_queue.size(),
            "timestamp":          datetime.now().strftime('%H:%M:%S'),
        })
    except Exception as e:
        logger.error(f"[API /data] {e}")
        return jsonify({"count": 0, "status": "off"})

@app.route('/api/settings/verify', methods=['POST'])
def api_settings_verify():
    """設定画面を開く前のパスワード照合"""
    stored = config.get('settings_password', '')
    if not stored:
        # パスワード未設定なら保護なし
        return jsonify({"status": "ok"})
    data = request.get_json(silent=True) or {}
    entered = str(data.get('password', ''))
    if entered == stored:
        return jsonify({"status": "ok"})
    logger.warning("[Settings] Password mismatch.")
    return jsonify({"status": "denied"}), 403

@app.route('/api/request_token', methods=['POST'])
def api_request_token():
    """サーバーへトークンをリクエストし、取得したAPIキーを conf.ini に保存・有効化する"""
    import requests as _rq
    base_url = config.get('api_url', '').rstrip('/')
    machine_id = config.get('machine_id', '')
    if not base_url or not machine_id:
        return jsonify({"status": "error", "message": "api_url または machine_id が未設定です"}), 400
    try:
        res = _rq.post(
            base_url + '/token-request',
            json={"machineId": machine_id},
            timeout=10,
        )
        if res.status_code != 200:
            return jsonify({"status": "error",
                            "message": f"サーバー応答 {res.status_code}: {res.text[:200]}"}), 502
        data = res.json()
        api_key = data.get('apiKey', '')
        if not api_key:
            return jsonify({"status": "error", "message": "サーバーからキーが返却されませんでした"}), 502

        # conf.ini に保存して即時有効化
        config.update_and_save('CLOUD', 'api_key', api_key)
        config.load()
        api_client.reload()
        logger.info(f"[Token] API key received and activated (issued={data.get('issued')}).")
        return jsonify({
            "status": "ok",
            "issued": bool(data.get('issued')),
            "api_key_masked": api_key[:6] + '...' + api_key[-4:],
        })
    except Exception as e:
        logger.error(f"[Token] Request failed: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/settings', methods=['GET'])
def api_settings_get():
    return jsonify({
        "machine_id":          config.get('machine_id'),
        "input_mode":          config.get('input_mode'),
        "target":              config.get('target'),
        "dur_choco_sec":       config.get('dur_choco_sec'),
        "dur_doka_sec":        config.get('dur_doka_sec'),
        "api_url":             config.get('api_url'),
        "sync_interval_sec":   config.get('sync_interval_sec'),
        "time_start":          config.get('time_start'),
        "time_end":            config.get('time_end'),
        "breaks":              config.get('breaks', []),
        "ignore_schedule":     config.get('ignore_schedule', False),
        "error_input_enabled": config.get('error_input_enabled', False),
        "error_input_pin":     config.get('error_input_pin', 27),
        "error_active_state":  config.get('error_active_state', 'HIGH'),
        "ui_theme":            config.get('ui_theme', 0),
    })

@app.route('/api/settings', methods=['POST'])
def api_settings_post():
    try:
        data = request.get_json()

        config.update_and_save('BASIC', 'machine_id', data.get('machine_id', config.get('machine_id')))
        config.update_and_save('BASIC', 'input_mode', data.get('input_mode', config.get('input_mode')))
        config.update_and_save('BASIC', 'target',     str(data.get('target', config.get('target'))))

        config.update_and_save('TIMEOUT', 'dur_choco_sec', str(data.get('dur_choco_sec', config.get('dur_choco_sec'))))
        config.update_and_save('TIMEOUT', 'dur_doka_sec',  str(data.get('dur_doka_sec',  config.get('dur_doka_sec'))))

        config.update_and_save('CLOUD', 'api_url', data.get('api_url', config.get('api_url')))
        if data.get('api_key'):
            config.update_and_save('CLOUD', 'api_key', data['api_key'])
        config.update_and_save('CLOUD', 'sync_interval_sec', str(data.get('sync_interval_sec', config.get('sync_interval_sec'))))

        config.update_and_save('SCHEDULE', 'time_start', data.get('time_start', config.get('time_start', '')))
        config.update_and_save('SCHEDULE', 'time_end',   data.get('time_end',   config.get('time_end', '')))
        breaks_val = data.get('breaks', '')
        if isinstance(breaks_val, list):
            breaks_val = ', '.join(breaks_val)
        config.update_and_save('SCHEDULE', 'breaks', breaks_val)

        if 'ignore_schedule' in data:
            config.update_and_save('SCHEDULE', 'ignore_schedule', str(bool(data['ignore_schedule'])).lower())

        if 'error_input_enabled' in data:
            config.update_and_save('INPUT', 'error_input_enabled', str(data['error_input_enabled']).lower())
        if 'error_input_pin' in data:
            config.update_and_save('INPUT', 'error_input_pin', str(data['error_input_pin']))
        if 'error_active_state' in data:
            config.update_and_save('INPUT', 'error_active_state', str(data['error_active_state']).upper())

        if 'ui_theme' in data:
            try:
                theme = int(data['ui_theme'])
            except (TypeError, ValueError):
                theme = 0
            if theme not in VALID_UI_THEMES:
                theme = 0
            config.update_and_save('DISPLAY', 'ui_theme', str(theme))

        config.load()
        break_scheduler.reload()
        api_client.reload()
        state_machine.reload_config()

        logger.info("[Settings] Saved and reloaded.")
        return jsonify({"status": "ok"})
    except Exception as e:
        logger.error(f"[Settings] Save error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/manual_reset', methods=['POST'])
def api_manual_reset():
    if not config.get('enable_keyboard_reset', True):
        return jsonify({"status": "disabled"}), 403

    counter.reset()
    # ★重要: counter.reset() で累計を0に戻しても、period_aggregator が保持する
    # 「前回送信済みの累計」(_sent_total_work_sec 等)は自動的には追従しない。
    # これを放置すると、次回の定期送信時に
    #   差分 = 現在の累計(リセット直後なのでほぼ0) − 前回送信済み累計(リセット前の大きな値)
    # という計算になり、巨大なマイナス値がサーバーへ送信されてしまう
    # （実際に発生した不具合: 翌日の作業開始時等に数万時間規模のマイナスが送信された）。
    # reset_period() を呼び、送信済み基準をリセット後の状態（0相当）に同期させる。
    period_aggregator.reset_period()
    state_machine.last_count_at = None
    state_machine.stop_start_at = None
    state_machine.current_state = "off"
    state_machine.stop_class    = None
    state_machine.alarm         = False
    logger.info("[Reset] Manual reset performed (period_aggregator baseline synced).")
    return jsonify({"status": "reset_completed"})

@app.route('/api/shutdown', methods=['POST'])
def api_shutdown():
    logger.info("[Shutdown] System shutdown requested.")
    
    def execute_shutdown():
        time.sleep(1)
        try:
            sender.send_offline_status()
            subprocess.run(['sudo', 'poweroff'], check=True)
        except Exception as e:
            logger.error(f"Failed to execute system shutdown: {e}")
            os._exit(0)

    threading.Thread(target=execute_shutdown, daemon=True).start()
    return jsonify({"status": "shutdown"})

# ── カメラストリーム ──────────────────────────────────────────────────
def generate_frame(reader):
    while True:
        jpeg = reader.get_frame_jpeg()
        if jpeg:
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + jpeg + b'\r\n')
        time.sleep(0.05)

# ── メイン ────────────────────────────────────────────────────────────
def main():
    global input_reader
    logger.info("=" * 55)
    logger.info(f"  Flight_Status_Board v5.0 Starting...")
    logger.info(f"  Machine ID : {config.get('machine_id')}")
    logger.info(f"  Input Mode : {config.get('input_mode')}")
    logger.info(f"  API URL    : {config.get('api_url')}")
    err_enabled = config.get('error_input_enabled', False)
    if err_enabled:
        logger.info(
            f"  Error Input: GPIO pin {config.get('error_input_pin')} "
            f"({config.get('error_active_state')} active)"
        )
    else:
        logger.info(f"  Error Input: disabled")
    logger.info("=" * 55)

    signal.signal(signal.SIGINT, handle_graceful_shutdown)
    signal.signal(signal.SIGTERM, handle_graceful_shutdown)

    input_reader = InputReader(config, on_count, on_alarm_callback=on_alarm)
    input_reader.start()

    if config.get('input_mode') == 'CAMERA':
        @app.route('/video_feed')
        def video_feed():
            return Response(generate_frame(input_reader),
                            mimetype='multipart/x-mixed-replace; boundary=frame')
        if HAS_CAMERA_UI:
            try:
                camera_ui = CameraConfigUI(
                    config=config,
                    config_file=os.path.join(BASE_DIR, 'conf.ini'),
                    lock=input_reader._frame_lock,
                    state_refs={
                        'rawFrame':     lambda: input_reader.raw_frame,
                        'outputFrame':  lambda: input_reader.output_frame,
                        'outputFrameId': lambda: input_reader.output_frame_id,
                        'cam_width':    config.get('cam_width',  640),
                        'cam_height':   config.get('cam_height', 480),
                        'stream_port':  config.get('stream_port', 5001),
                        'reopenCamera': input_reader.reopen_camera,
                    }
                )
                threading.Thread(target=camera_ui.run, daemon=True).start()
                logger.info(f"  Camera Config UI: http://{get_local_ip()}:{config.get('stream_port', 5001)}")
            except Exception as e:
                logger.warning(f"  Camera Config UI failed to start: {e}")

    threading.Thread(target=background_loop, daemon=True).start()
    sender.start()

    logger.info(f"  Web UI     : http://{get_local_ip()}:5000")
    logger.info("=" * 55)
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False, threaded=True)

if __name__ == '__main__':
    main()