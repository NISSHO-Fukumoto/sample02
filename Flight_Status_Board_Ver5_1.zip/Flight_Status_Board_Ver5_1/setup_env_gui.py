import os
import sys
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
import stat

class AppSetupGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("仮想環境 & 自動起動 セットアップツール")
        self.root.geometry("550x520")
        self.root.padding = 10

        self.target_dir = tk.StringVar()
        self.target_script = tk.StringVar()
        self.req_file = tk.StringVar() # requirements.txt用
        
        # ブラウザ起動用の変数
        self.use_browser = tk.BooleanVar(value=True)
        self.browser_url = tk.StringVar(value="http://localhost:5000")

        self.create_widgets()

    def create_widgets(self):
        # 1. ディレクトリ選択UI
        tk.Label(self.root, text="1. プロジェクトのディレクトリを選択してください:").pack(anchor=tk.W, pady=(10, 0), padx=10)
        frame_dir = tk.Frame(self.root)
        frame_dir.pack(fill=tk.X, padx=10, pady=5)
        tk.Entry(frame_dir, textvariable=self.target_dir, state='readonly', width=50).pack(side=tk.LEFT, padx=(0, 10))
        tk.Button(frame_dir, text="フォルダ参照", command=self.select_directory).pack(side=tk.LEFT)

        # 2. スクリプト選択UI
        tk.Label(self.root, text="2. 起動するPythonスクリプトを選択してください:").pack(anchor=tk.W, pady=(15, 0), padx=10)
        frame_script = tk.Frame(self.root)
        frame_script.pack(fill=tk.X, padx=10, pady=5)
        tk.Entry(frame_script, textvariable=self.target_script, state='readonly', width=50).pack(side=tk.LEFT, padx=(0, 10))
        tk.Button(frame_script, text="ファイル参照", command=self.select_script).pack(side=tk.LEFT)

        # 3. requirements.txt 選択UI (オプション)
        tk.Label(self.root, text="3. requirements.txt を選択してください (オプション):").pack(anchor=tk.W, pady=(15, 0), padx=10)
        frame_req = tk.Frame(self.root)
        frame_req.pack(fill=tk.X, padx=10, pady=5)
        tk.Entry(frame_req, textvariable=self.req_file, state='readonly', width=43).pack(side=tk.LEFT, padx=(0, 10))
        tk.Button(frame_req, text="ファイル参照", command=self.select_requirements).pack(side=tk.LEFT)
        tk.Button(frame_req, text="クリア", command=lambda: self.req_file.set("")).pack(side=tk.LEFT, padx=(5, 0))

        # 4. ブラウザ設定UI
        tk.Label(self.root, text="4. Web表示設定 (オプション):").pack(anchor=tk.W, pady=(15, 0), padx=10)
        frame_browser = tk.Frame(self.root)
        frame_browser.pack(fill=tk.X, padx=10, pady=5)
        tk.Checkbutton(frame_browser, text="起動後にChromium(全画面)で開く", variable=self.use_browser, command=self.toggle_browser_entry).pack(anchor=tk.W)
        
        self.entry_url = tk.Entry(frame_browser, textvariable=self.browser_url, width=40)
        self.entry_url.pack(anchor=tk.W, padx=(20, 0), pady=(5,0))

        # 実行ボタン
        tk.Button(self.root, text="環境構築＆自動起動セットアップを実行", 
                  command=self.execute_setup, bg="lightblue", font=("", 11, "bold")).pack(pady=25, ipadx=10, ipady=10)

    def select_directory(self):
        d = filedialog.askdirectory(initialdir=Path.home(), title="プロジェクトフォルダを選択")
        if d:
            self.target_dir.set(d)
            self.target_script.set("")
            # requirements.txt が同じフォルダにあれば自動でセットする
            default_req = Path(d) / "requirements.txt"
            if default_req.exists():
                self.req_file.set(str(default_req))
            else:
                self.req_file.set("")

    def select_script(self):
        init_dir = self.target_dir.get() if self.target_dir.get() else Path.home()
        f = filedialog.askopenfilename(initialdir=init_dir, title="Pythonスクリプトを選択", filetypes=[("Python files", "*.py")])
        if f:
            self.target_script.set(f)

    def select_requirements(self):
        init_dir = self.target_dir.get() if self.target_dir.get() else Path.home()
        f = filedialog.askopenfilename(initialdir=init_dir, title="requirements.txtを選択", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if f:
            self.req_file.set(f)

    def toggle_browser_entry(self):
        if self.use_browser.get():
            self.entry_url.config(state='normal')
        else:
            self.entry_url.config(state='disabled')

    def get_desktop_path(self):
        desktop_ja = Path.home() / "デスクトップ"
        desktop_en = Path.home() / "Desktop"
        return desktop_ja if desktop_ja.exists() else desktop_en

    def execute_setup(self):
        target_dir = self.target_dir.get()
        target_script = self.target_script.get()
        req_file_path = self.req_file.get()

        if not target_dir or not target_script:
            messagebox.showwarning("確認", "ディレクトリとスクリプトの両方を選択してください。")
            return

        try:
            os.chdir(target_dir)

            # 仮想環境のチェックと作成 (.env)
            env_path = Path(target_dir) / ".env"
            activate_path = env_path / "bin" / "activate"
            pip_executable = env_path / "bin" / "pip"

            if not activate_path.exists():
                messagebox.showinfo("進行状況", "仮想環境(.env)が見つかりません。\n新規作成を開始します...（数分かかる場合があります）")
                subprocess.run([sys.executable, "-m", "venv", ".env"], check=True)
            
            # requirements.txt が指定されている場合はインストールを実行
            if req_file_path and Path(req_file_path).exists():
                messagebox.showinfo("インストール開始", 
                                    f"requirements.txt からライブラリのインストールを開始します。\n\n"
                                    f"※インストールには数分かかる場合があります。\n"
                                    f"※処理中は画面が固まったように見えますが、そのままお待ちください。")
                # 仮想環境内の pip を直接指定してインストール
                subprocess.run([str(pip_executable), "install", "-r", req_file_path], check=True)
                messagebox.showinfo("インストール完了", "ライブラリのインストールが正常に完了しました！")

            # ランチャースクリプトの生成
            script_name = Path(target_script).name
            launcher_path = Path(target_dir) / "launcher.sh"
            
            with open(launcher_path, "w", encoding="utf-8") as f:
                f.write("#!/bin/bash\n")
                f.write(f"cd \"{target_dir}\"\n")
                f.write("source .env/bin/activate\n\n")
                
                if self.use_browser.get():
                    url = self.browser_url.get()
                    f.write("# Pythonサーバーをバックグラウンドで起動\n")
                    f.write(f"python \"{script_name}\" &\n")
                    f.write("SERVER_PID=$!\n\n")
                    
                    f.write("# サーバーの起動を待機 (curlでアクセス成功するまで1秒待機をループ)\n")
                    f.write("echo 'サーバーの起動を待機しています...'\n")
                    f.write(f"until curl -s {url} > /dev/null; do\n")
                    f.write("    sleep 1\n")
                    f.write("done\n")
                    f.write("echo 'サーバーの起動を確認しました。ブラウザを開きます。'\n\n")
                    
                    f.write("# Chromiumをキオスクモードで起動（エラーダイアログ等を無効化）\n")
                    f.write(f"chromium --kiosk --noerrdialogs --disable-infobars \"{url}\"\n\n")
                    
                    f.write("# ブラウザが閉じられたらPythonサーバーも終了する\n")
                    f.write("kill $SERVER_PID\n")
                else:
                    f.write(f"python \"{script_name}\"\n")
                    f.write("read -p 'Press Enter to close...' \n")

            # 権限付与
            launcher_path.chmod(launcher_path.stat().st_mode | stat.S_IEXEC)

            # .desktopファイルの生成
            desktop_entry_content = f"""[Desktop Entry]
Type=Application
Name={script_name.replace('.py', '')}_App
Comment=Auto generated launcher
Exec=lxterminal -e "{launcher_path}"
Terminal=false
Categories=Utility;
"""
            # デスクトップショートカット作成
            desktop_dir = self.get_desktop_path()
            desktop_shortcut = desktop_dir / f"{script_name.replace('.py', '')}.desktop"
            with open(desktop_shortcut, "w", encoding="utf-8") as f:
                f.write(desktop_entry_content)
            desktop_shortcut.chmod(desktop_shortcut.stat().st_mode | stat.S_IEXEC)

            # 自動起動（autostart）作成
            autostart_dir = Path.home() / ".config" / "autostart"
            autostart_dir.mkdir(parents=True, exist_ok=True)
            autostart_shortcut = autostart_dir / f"{script_name.replace('.py', '')}.desktop"
            with open(autostart_shortcut, "w", encoding="utf-8") as f:
                f.write(desktop_entry_content)
            autostart_shortcut.chmod(autostart_shortcut.stat().st_mode | stat.S_IEXEC)

            messagebox.showinfo("セットアップ完了", 
                                "すべてのセットアップが完了しました！\n"
                                "デスクトップのショートカットからテスト起動が可能です。")

        except subprocess.CalledProcessError as e:
            messagebox.showerror("インストールエラー", f"コマンドの実行中にエラーが発生しました。\n(requirements.txt の内容などに問題がある可能性があります)\n\n{e}")
        except Exception as e:
            messagebox.showerror("エラー", f"処理中に予期せぬエラーが発生しました:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AppSetupGUI(root)
    root.mainloop()