#!/bin/bash
# Flight Status Board startup script for Raspberry Pi 400
#
# 事前にこのディレクトリ内に .env (仮想環境) が作成されている必要があります。

# スクリプトの絶対パスを基準にディレクトリを移動
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 仮想環境（.env）の存在チェック
if [ ! -d ".env" ]; then
    echo "[エラー] 仮想環境 .env がありません。"
    echo "        パスを確認するか、python3 -m venv .env で作成してください。"
    exit 1
fi

# 仮想環境のアクティベート
# shellcheck disable=SC1091
source .env/bin/activate

# 依存ライブラリの簡易チェック（必要に応じて修正してください。例：flaskなど）
if ! python3 -c "import flask" 2>/dev/null; then
    echo "[警告] flask が import できません。pip install されているか確認してください。"
fi

echo "[start] Flight Status Board starting..."

# 優先度（nice値）を調整して app.py を実行
nice -n 10 python3 app.py
