"""
state_machine.py - 状態機械モジュール（v3 / 目覚まし機能付き）
pasted_content_2.txt §2〜§8 に準拠。

時間帯区分（4種のみ）:
  pre_shift  : 始業前
  work_time  : 稼働時間
  break_time : 休憩時間
  post_shift : 終業後

scheduleViolation（補助表現）:
  early_start     : 始業前に稼働
  break_overrun   : 休憩中に稼働継続
  after_hours_run : 終業後に稼働継続

overtime 概念は使用しない。
終業後に稼働している場合は currentState=running + scheduleViolation=after_hours_run で表現。

判定優先順位:
  1. 直近カウントあり → running（scheduleViolation を付与する場合あり）
  1.5 計画停止明けの目覚まし → stop (choco) としてタイマーリセット ★新規追加
  2. 停止確定済み（stop）→ スケジュール時間帯なら planned_stop/off に遷移
  3. 停止候補（未確定）→ 停止確定時刻がスケジュール外なら planned_stop/off に吸収
  4. スケジュール時間帯 → planned_stop / off
  5. 無信号              → off
"""
import time
import logging
from datetime import datetime, time as dtime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)
JST = timezone(timedelta(hours=+9), 'JST')


def _parse_time(s: str) -> Optional[dtime]:
    if not s:
        return None
    try:
        return datetime.strptime(s.strip(), "%H:%M").time()
    except Exception:
        return None


# 時間帯区分の定数
ZONE_PRE_SHIFT  = "pre_shift"
ZONE_WORK_TIME  = "work_time"
ZONE_BREAK_TIME = "break_time"
ZONE_POST_SHIFT = "post_shift"


class StateMachine:
    """
    最後のカウントからの経過時間と時刻スケジュールにより状態を推定する。
    """

    def __init__(self, config):
        self.config = config
        self._reload_config()

        # 主状態
        self.current_state: str = "off"
        self.stop_class: Optional[str] = None

        # 補助フラグ
        self.time_zone: str = ZONE_PRE_SHIFT   # 現在の時間帯区分
        self.schedule_violation: Optional[str] = None
        self.alarm: bool = False
        self.manual: bool = False
        self.offline: bool = False

        # タイムスタンプ
        self.last_count_at: Optional[float] = None
        self.stop_start_at: Optional[float] = None
        self.doka_at: Optional[float] = None
        self.segment_start: float = time.time()

        # 変化検知スナップショット
        self._prev_snapshot: dict = {}

        # 停止候補（未確定）
        self._stop_candidate_since: Optional[float] = None

    # ------------------------------------------------------------------
    #   設定リロード
    # ------------------------------------------------------------------
    def _reload_config(self):
        self.dur_choco_sec: int    = int(self.config.get('dur_choco_sec', 180))
        self.dur_doka_sec: int     = int(self.config.get('dur_doka_sec', 600))
        self.dur_poweroff_sec: int = int(self.config.get('dur_poweroff_sec', 3600))
        self.time_start: Optional[dtime] = _parse_time(self.config.get('time_start', '08:00'))
        self.time_end:   Optional[dtime] = _parse_time(self.config.get('time_end',   '17:00'))
        self._breaks: list = self._parse_breaks()
        # 稼働カレンダー無視（常時監視）モード。始業/休憩/終業に関係なく
        # チョコ停・ドカ停を検知する（24時間稼働・デモ・テスト向け）。
        self.ignore_schedule: bool = bool(self.config.get('ignore_schedule', False))

    def reload_config(self):
        self._reload_config()

    def _parse_breaks(self) -> list:
        breaks_raw = self.config.get('breaks', [])
        if isinstance(breaks_raw, str):
            breaks_raw = [b.strip() for b in breaks_raw.split(',') if b.strip()]
        result = []
        for b in breaks_raw:
            try:
                s, e = b.split('-')
                result.append((_parse_time(s), _parse_time(e)))
            except Exception:
                pass
        return [(s, e) for s, e in result if s and e]

    # ------------------------------------------------------------------
    #   カウント発生
    # ------------------------------------------------------------------
    def on_count(self, now: Optional[float] = None):
        if now is None:
            now = time.time()
        self.last_count_at = now
        self._stop_candidate_since = None

    # ------------------------------------------------------------------
    #   時間帯区分の判定（4種）
    # ------------------------------------------------------------------
    def _get_time_zone(self, t: dtime) -> str:
        """現在時刻の時間帯区分を返す（4種のみ）"""
        if self._is_in_break(t):
            return ZONE_BREAK_TIME
        if self.time_start and t < self.time_start:
            return ZONE_PRE_SHIFT
        if self.time_end and t > self.time_end:
            return ZONE_POST_SHIFT
        return ZONE_WORK_TIME

    def _is_in_break(self, t: dtime) -> bool:
        for start, end in self._breaks:
            if start <= end:
                if start <= t <= end:
                    return True
            else:
                if t >= start or t <= end:
                    return True
        return False

    def _is_scheduled_stop_zone(self, zone: str) -> bool:
        """計画停止・off になるべき時間帯かどうか"""
        # 常時監視モードでは時間帯による吸収を行わない（常に稼働扱い）
        if self.ignore_schedule:
            return False
        return zone in (ZONE_PRE_SHIFT, ZONE_BREAK_TIME, ZONE_POST_SHIFT)

    # ------------------------------------------------------------------
    #   メイン更新
    # ------------------------------------------------------------------
    def update(self, now: Optional[float] = None,
               is_break_time: bool = False) -> str:
        if now is None:
            now = time.time()

        dt_now   = datetime.fromtimestamp(now, JST)
        zone_now = self._get_time_zone(dt_now.time())
        self.time_zone = zone_now

        elapsed = (now - self.last_count_at) if self.last_count_at else None

        # ── 優先順位1: 直近カウントあり → running ──────────────────────
        if elapsed is not None and elapsed < self.dur_choco_sec:
            self._enter_running(now, zone_now)
            return self.current_state

        # ── 優先順位1.5: 計画停止・offからの目覚まし ───────────────────
        # ★ 新規追加: スケジュールが稼働時間に入ったが、まだカウントが来ていない場合
        if self.current_state in ("planned_stop", "off") and not self._is_scheduled_stop_zone(zone_now):
            if elapsed is not None and elapsed >= self.dur_choco_sec:
                self.current_state = "stop"
                self.stop_class = "choco"
                self.stop_start_at = now  # 休憩終了の「今この瞬間」を停止の起点としてタイマーリセット
                self.segment_start = now
                self.doka_at = None
                self._stop_candidate_since = None
                self.schedule_violation = None
                logger.info(f"[SM] Wake up from {self.current_state}. Start choco stop at {now}")
                return self.current_state

        # ── 優先順位2: 停止確定済み（stop）→ スケジュール遷移チェック ──
        if self.current_state == "stop":
            if self._is_scheduled_stop_zone(zone_now):
                self._enter_planned_or_off(now, zone_now)
                return self.current_state
            
            # 停止継続（ドカ停昇格チェック）
            # ★ 修正: elapsed ではなく、stop_start_at(停止開始時刻)からの経過時間で判定する
            stop_duration = (now - self.stop_start_at) if self.stop_start_at else 0
            if stop_duration >= self.dur_doka_sec:
                self._enter_stop(now, "doka")
            else:
                self._enter_stop(now, "choco")
            return self.current_state

        # ── 優先順位3: 停止候補（未確定）────────────────────────────────
        if elapsed is not None and elapsed >= self.dur_choco_sec:
            if self._stop_candidate_since is None:
                self._stop_candidate_since = self.last_count_at + self.dur_choco_sec

            stop_confirmed_at = self._stop_candidate_since
            stop_dt   = datetime.fromtimestamp(stop_confirmed_at, JST)
            zone_stop = self._get_time_zone(stop_dt.time())

            # 停止確定時刻 または「現在時刻」がスケジュール外なら吸収する
            if self._is_scheduled_stop_zone(zone_stop) or self._is_scheduled_stop_zone(zone_now):
                self._enter_planned_or_off(now, zone_now)
                return self.current_state

            # 通常停止確定
            if elapsed >= self.dur_doka_sec:
                self._enter_stop(now, "doka")
            else:
                self._enter_stop(now, "choco")
            return self.current_state

        # ── 優先順位4: スケジュール時間帯 ────────────────────────────────
        if self._is_scheduled_stop_zone(zone_now):
            self._enter_planned_or_off(now, zone_now)
            return self.current_state

        # ── 優先順位5: off ────────────────────────────────────────────
        if elapsed is None:
            self._enter_off(now)
        else:
            self._enter_running(now, zone_now)

        return self.current_state

    # ------------------------------------------------------------------
    #   状態遷移ヘルパー
    # ------------------------------------------------------------------
    def _enter_running(self, now: float, zone: str):
        prev = self.current_state
        self.current_state = "running"
        self.stop_class    = None
        self.stop_start_at = None
        self.doka_at       = None
        self._stop_candidate_since = None

        # scheduleViolation の設定（3種のみ）
        if zone == ZONE_BREAK_TIME:
            self.schedule_violation = "break_overrun"
        elif zone == ZONE_PRE_SHIFT:
            self.schedule_violation = "early_start"
        elif zone == ZONE_POST_SHIFT:
            self.schedule_violation = "after_hours_run"
        else:
            self.schedule_violation = None

        if prev != "running":
            self.segment_start = now

    def _enter_stop(self, now: float, new_class: str):
        prev_state = self.current_state
        prev_class = self.stop_class

        if prev_state != "stop":
            # 新規停止確定
            self.current_state = "stop"
            self.stop_class    = new_class
            self.stop_start_at = self._stop_candidate_since or now
            self.segment_start = self.stop_start_at
            self.schedule_violation = None
            logger.info(f"[SM] Stop confirmed: {new_class} at {self.stop_start_at}")
        elif prev_class == "choco" and new_class == "doka":
            # ドカ停昇格
            self.stop_class = "doka"
            self.doka_at    = now
            logger.info(f"[SM] Stop escalated to doka at {now}")

    def _enter_planned_or_off(self, now: float, zone: str):
        prev = self.current_state
        # post_shift は off、pre_shift / break_time は planned_stop
        new_state = "off" if zone == ZONE_POST_SHIFT else "planned_stop"

        if prev != new_state:
            self.current_state = new_state
            self.stop_class    = None
            self.stop_start_at = None
            self.doka_at       = None
            self.segment_start = now
            self.schedule_violation = None
        else:
            self.current_state = new_state

    def _enter_off(self, now: float):
        if self.current_state != "off":
            self.current_state = "off"
            self.stop_class    = None
            self.stop_start_at = None
            self.doka_at       = None
            self.segment_start = now
            self.schedule_violation = None

    # ------------------------------------------------------------------
    #   変化検知（主状態・補助フラグ含む）
    # ------------------------------------------------------------------
    def _snapshot(self) -> dict:
        return {
            "current_state":      self.current_state,
            "stop_class":         self.stop_class,
            "schedule_violation": self.schedule_violation,
            "alarm":              self.alarm,
            "manual":             self.manual,
            "offline":            self.offline,
            "time_zone":          self.time_zone,
        }

    def has_changed(self) -> bool:
        """主状態・補助フラグ含めた変化を検知"""
        snap = self._snapshot()
        changed = snap != self._prev_snapshot
        if changed:
            self._prev_snapshot = snap.copy()
        return changed

    # ------------------------------------------------------------------
    #   current_status ペイロード
    # ------------------------------------------------------------------
    def to_dict(self, machine_id: str, heartbeat_type: str = "periodic") -> dict:
        now = time.time()
        elapsed = int(now - self.last_count_at) if self.last_count_at else None
        last_count_str = None
        if self.last_count_at:
            last_count_str = datetime.fromtimestamp(self.last_count_at, JST).isoformat()
        seg_start_str = datetime.fromtimestamp(self.segment_start, JST).isoformat()

        return {
            "machineId":           machine_id,
            "sampleTime":          datetime.fromtimestamp(now, JST).isoformat(),
            "heartbeatType":       heartbeat_type,
            "currentState":        self.current_state,
            "stopClass":           self.stop_class,
            "reasonCode":          self._reason_code(),
            "alarm":               self.alarm,
            "manual":              self.manual,
            "offline":             self.offline,
            "scheduleViolation":   self.schedule_violation,
            "timeZone":            self.time_zone,
            "currentSegmentStart": seg_start_str,
            "elapsedSec":          elapsed,
            "lastCountAt":         last_count_str,
        }

    def _reason_code(self) -> Optional[str]:
        # alarm が立っている場合は alarm を優先（将来拡張の器）
        if self.alarm and self.current_state == "stop":
            return "alarm"
        if self.current_state == "planned_stop":
            if self.time_zone == ZONE_BREAK_TIME:
                return "break"
            if self.time_zone == ZONE_PRE_SHIFT:
                return "pre_shift"
            return "scheduled"
        if self.current_state == "off":
            return "no_signal"
        if self.schedule_violation:
            return self.schedule_violation
        return None

    # ------------------------------------------------------------------
    #   後方互換プロパティ
    # ------------------------------------------------------------------
    @property
    def stop_detect_sec(self) -> int:
        return self.dur_choco_sec

    @property
    def doka_threshold_sec(self) -> int:
        return self.dur_doka_sec

    @property
    def stop_candidate_since(self) -> Optional[float]:
        return self._stop_candidate_since

    # 旧フラグ互換（テスト・app.py 参照用）
    @property
    def in_break_window(self) -> bool:
        return self.time_zone == ZONE_BREAK_TIME

    @property
    def in_pre_shift_window(self) -> bool:
        return self.time_zone == ZONE_PRE_SHIFT

    @property
    def in_overtime_window(self) -> bool:
        """後方互換: post_shift を overtime として扱う（削除予定）"""
        return self.time_zone == ZONE_POST_SHIFT