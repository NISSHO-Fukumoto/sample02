"""
input_reader.py - 入力監視モジュール（本命版・表示強化・カウント非同期化）
GPIO / カメラ の入力を監視し、カウント発生コールバックを呼び出す。

改良点:
- CAMERA モード時に roi_contours を優先して監視対象に使用
- 複数 contour をすべて監視対象に使用
- roi_contours が無い場合は roi_rect の矩形ROIを使用
- detect_color が設定されている場合、HSV色マスクで対象輪郭を抽出して安定化
- 輪郭履歴を持ち、安定輪郭を一定期間保持
- motion_area の絶対値だけでなく motion_ratio（監視対象面積に対する比率）でも判定
- 一定時間継続で LOCKED（1カウント）
- プレビュー上で 非検知時:シアン枠 / 検知時:赤枠＋画面外周フラッシュ
- 状態チップ（SCANNING/VERIFYING/LOCKED/DETECT）と計測値ストリップを半透明下地で表示
- FPS 表示
- 検知後の on_count_callback は別スレッドで実行（プレビュー停止対策）
- 大量入力時の遅延を防ぐバッチ処理（キュー一括吸い上げ）を追加

将来拡張: GPIO エラー入力（error_input_enabled = true の場合のみ有効）
"""
import threading
import time
import logging
import json
import queue
import subprocess
import os
from collections import deque

logger = logging.getLogger(__name__)

# ── GPIO ──────────────────────────────────────────────────────────────
try:
    from gpiozero import Button, InputDevice
    HAS_GPIO = True
except (ImportError, RuntimeError):
    Button = None
    InputDevice = None
    HAS_GPIO = False
    logger.warning("gpiozero not found. GPIO input disabled.")

# ── OpenCV ────────────────────────────────────────────────────────────
try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    cv2 = None
    np = None
    HAS_OPENCV = False
    logger.warning("opencv-python not installed. Camera input disabled.")


def _list_stable_camera_paths():
    """
    /dev/v4l/by-id/ から、USB再列挙・USBリセット後も番号が変わらない
    安定パスを、決まった順序（ファイル名の昇順）で列挙する。

    camera_device_index に指定する数値（0, 1, 2...）は、OSが割り振る
    生の /dev/videoN 番号（再列挙のたびに変わりうる）ではなく、この
    「安定パスをソートしたリストの何番目か」を指す。1台構成の環境では
    通常つねに 0 が同じ物理カメラに解決される。

    by-id が使えない環境では、/sys/class/video4linux/ で「今も実在する
    デバイスだけ」に絞り込んだ /dev/videoN をフォールバックとして返す
    （camera_config_ui.py の _list_camera_devices() と同じロジック。
    ここが揃っていないと、UIで選んだ番号とinput_readerが実際に開く
    デバイスがズレてしまう）。単純に /dev/video* を列挙すると、過去の
    USB再接続のたびに残った「もう存在しない古いデバイスファイル」まで
    拾ってしまうため、/sys 側の実在確認を必ず行う。
    """
    devices = []
    by_id_dir = "/dev/v4l/by-id"
    if os.path.isdir(by_id_dir):
        entries = sorted(os.listdir(by_id_dir))
        preferred = [e for e in entries if e.endswith("-video-index0")]
        chosen = preferred if preferred else entries
        seen_real = set()
        for name in chosen:
            link_path = os.path.join(by_id_dir, name)
            try:
                real_path = os.path.realpath(link_path)
            except Exception:
                continue
            if real_path in seen_real:
                continue
            seen_real.add(real_path)
            devices.append(link_path)
        if devices:
            return devices

    # ── フォールバック: /sys/class/video4linux で実在確認した /dev/video* ──
    import glob as _glob
    sysfs_dir = "/sys/class/video4linux"
    seen_device_real = set()
    for dev in sorted(_glob.glob("/dev/video*")):
        name = os.path.basename(dev)
        sysfs_node = os.path.join(sysfs_dir, name)
        if not os.path.isdir(sysfs_node):
            continue  # /sys側に実体が無い＝切断済みの古いデバイスファイル
        device_link = os.path.join(sysfs_node, "device")
        try:
            device_real = os.path.realpath(device_link)
        except Exception:
            device_real = sysfs_node
        if device_real in seen_device_real:
            continue
        seen_device_real.add(device_real)
        devices.append(dev)
    return devices


def resolve_camera_device(index_or_path):
    """
    camera_device_index の設定値を、実際に cv2.VideoCapture() へ渡す
    デバイス指定に解決する。

    - 数値（0, 1, 2...）: _list_stable_camera_paths() の並び順で該当する
      デバイスに解決する（by-id が使えない環境でも、sysfsで実在確認した
      安定な順序を使うため、単純なOS生インデックスよりは安定する）。
      一覧が空、または範囲外の場合のみ、最後の手段として数値をそのまま
      OSの生インデックスとして使う。
    - 文字列パス（過去バージョンで /dev/v4l/by-id/... を直接保存した場合等）:
      そのまま使う。
    """
    if not isinstance(index_or_path, int):
        return index_or_path
    stable_paths = _list_stable_camera_paths()
    if 0 <= index_or_path < len(stable_paths):
        return stable_paths[index_or_path]
    return index_or_path


class _FrameGrabber:
    """
    cv2.VideoCapture からのフレーム取得だけを専任で行うスレッド。

    背景: cap.read() と重い画像処理（色検出・背景差分・OSD描画）を
    同じループで直列に行うと、処理側が一瞬でも遅延した場合に
    カメラドライバ内部のバッファへフレームが溜まり続け、
    「今の映像」と「表示されている内容」との間に遅延が蓄積していく
    （一度発生すると自然には解消しない）。

    対策として、cap.read() はこのスレッドで独立してひたすら回し続け、
    常に「最新の1枚」だけを保持する。処理側はこの最新フレームだけを
    参照するため、古いフレームは自動的に読み捨てられ、処理の遅延が
    映像の遅延として蓄積することがなくなる。

    ── 自動復旧（USB切断対策） ──────────────────────────────
    USBの電源不足・ケーブル不良等により、カメラがOSから完全に
    見えなくなる（lsusbから消える）事象が実機で確認されている。
    dmesg解析の結果、error -71（プロトコルエラー）を伴い、
    カーネル自身のポート単位の電源再投入でも復旧しないが、
    親ハブ（実機検証: ポートパス "1-1"）の unbind/bind による
    ソフトリセットでは確実に復旧することを実機で確認済み。

    このクラスでは読み取り失敗が続いた場合、以下の2段階で自動復旧を試みる。
      段階1（軽量・sudo不要）: cv2.VideoCapture の再オープンのみ試行
                                （何らかの理由で既に再列挙済みの場合に有効）
      段階2（重量・sudo必要）: USBハブポートの unbind/bind でソフトリセットし、
                                再列挙を待ってから再オープン
    """

    _RECONNECT_AFTER_SEC = 5.0          # この時間読み取り失敗が続いたら段階1を試みる
    _RECONNECT_RETRY_INTERVAL_SEC = 5.0  # 段階1の再試行間隔
    _USB_RESET_AFTER_SEC = 5.0           # この時間失敗が続いたら段階2（USBリセット）へ進む
    _USB_RESET_MIN_INTERVAL_SEC = 30.0   # 段階2の連続実行を防ぐ最小間隔
    _USB_RESET_PORT = "1-1"              # 実機検証済みのハブポートパス。環境が異なる場合は要調整

    def __init__(self, cam_index, cam_width, cam_height):
        self._cam_index = self._normalize_device(cam_index)
        self._cam_width = cam_width
        self._cam_height = cam_height
        self._lock = threading.Lock()          # フレームバッファ（_frame等）の保護用
        self._cap_lock = threading.RLock()      # self._cap 自体の入れ替え保護用
        self._frame = None
        self._ret = False
        self._frame_id = 0
        self._running = True
        self._cap = self._open_capture()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    @staticmethod
    def _normalize_device(value):
        """
        camera_device_index は数値（従来互換）と、/dev/v4l/by-id/... の
        ような安定パス文字列の両方を受け付ける。数値文字列なら int に
        変換し（cv2.VideoCaptureの整数インデックス指定）、それ以外は
        そのままパス文字列として扱う。
        """
        if isinstance(value, int):
            return value
        s = str(value).strip()
        if s.lstrip("-").isdigit():
            return int(s)
        return s

    def _open_capture(self):
        """cv2.VideoCapture を（再）オープンする。失敗しても例外は投げない。"""
        try:
            resolved = resolve_camera_device(self._cam_index)
            if resolved != self._cam_index:
                logger.info(
                    f"[CameraGrabber] camera_device_index={self._cam_index} を "
                    f"安定パス {resolved} に解決してオープンします。"
                )
            cap = cv2.VideoCapture(resolved)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._cam_width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._cam_height)
            return cap
        except Exception as e:
            logger.error(f"[CameraGrabber] VideoCaptureのオープン中にエラー: {e}")
            return cv2.VideoCapture()  # isOpened()がFalseになるダミー

    def is_opened(self):
        with self._cap_lock:
            return self._cap is not None and self._cap.isOpened()

    def force_reopen(self, new_device=None):
        """
        設定画面（ポート5001）からの明示操作で、待たずに即座に
        カメラを再オープンする。USB切断時の自動復旧（段階1/2）とは
        別の、ユーザー起点のエントリポイント。

        Args:
            new_device: 新しいデバイス指定（数値インデックス文字列、
                        または /dev/v4l/by-id/... 等のパス）。
                        None の場合は現在のデバイスのまま再オープンのみ行う。
        Returns:
            bool: オープンに成功したかどうか
        """
        with self._cap_lock:
            if new_device is not None:
                self._cam_index = self._normalize_device(new_device)
            try:
                if self._cap is not None:
                    self._cap.release()
            except Exception:
                pass
            self._cap = self._open_capture()
            opened = self._cap.isOpened()
        if opened:
            logger.info(f"[CameraGrabber] 手動再オープンに成功しました（device={self._cam_index}）。")
        else:
            logger.warning(f"[CameraGrabber] 手動再オープンに失敗しました（device={self._cam_index}）。")
        return opened

    def _reset_usb_port(self):
        """
        実機検証済み: ハブポート（既定 "1-1"）を unbind → bind することで、
        error -71 等でOSから見えなくなったUSBカメラを再列挙させる。

        注意: /sys 以下への書き込みには root 権限が必要。本プロセスを
        rootで動かすのではなく、sudoers に本コマンドのみ NOPASSWD で
        許可することを推奨（運用ドキュメント参照）。許可されていない
        場合はここで失敗し、ログに記録されるだけでアプリは継続動作する。
        """
        try:
            logger.warning(
                f"[CameraGrabber] 読み取り失敗が長時間継続。"
                f"USBポート({self._USB_RESET_PORT})のリセットを試みます。"
            )
            subprocess.run(
                ["sudo", "-n", "sh", "-c",
                 f"echo '{self._USB_RESET_PORT}' > /sys/bus/usb/drivers/usb/unbind"],
                timeout=5, check=True, capture_output=True,
            )
            time.sleep(3)
            subprocess.run(
                ["sudo", "-n", "sh", "-c",
                 f"echo '{self._USB_RESET_PORT}' > /sys/bus/usb/drivers/usb/bind"],
                timeout=5, check=True, capture_output=True,
            )
            time.sleep(5)  # USB再列挙・ドライバ初期化待ち
            logger.info("[CameraGrabber] USBポートのリセット処理が完了しました。")
            return True
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode(errors="ignore") if e.stderr else ""
            logger.error(
                f"[CameraGrabber] USBポートのリセットに失敗しました（sudoers未設定の可能性）: {stderr}"
            )
            return False
        except Exception as e:
            logger.error(f"[CameraGrabber] USBポートのリセット中に予期しないエラー: {e}")
            return False

    def _reopen(self):
        with self._cap_lock:
            try:
                if self._cap is not None:
                    self._cap.release()
            except Exception:
                pass
            self._cap = self._open_capture()
            return self._cap.isOpened()

    def _loop(self):
        last_ok_time = time.time()
        last_reopen_attempt = 0.0
        last_usb_reset_attempt = 0.0

        while self._running:
            with self._cap_lock:
                if self._cap is not None and self._cap.isOpened():
                    ret, frame = self._cap.read()
                else:
                    ret, frame = False, None
            if ret:
                last_ok_time = time.time()
                with self._lock:
                    self._frame = frame
                    self._ret = True
                    self._frame_id += 1
                continue

            now = time.time()
            fail_duration = now - last_ok_time

            # ── 段階1: 単純な再オープン（軽量） ─────────────────
            if fail_duration >= self._RECONNECT_AFTER_SEC and \
                    (now - last_reopen_attempt) >= self._RECONNECT_RETRY_INTERVAL_SEC:
                last_reopen_attempt = now
                logger.warning(
                    f"[CameraGrabber] {fail_duration:.0f}秒間フレーム取得に失敗。"
                    f"VideoCaptureの再オープンを試みます。"
                )
                if self._reopen():
                    logger.info("[CameraGrabber] 再オープンに成功しました。")
                    last_ok_time = time.time()
                    continue

            # ── 段階2: USBポートのリセット（重量・sudo必要） ─────
            if fail_duration >= self._USB_RESET_AFTER_SEC and \
                    (now - last_usb_reset_attempt) >= self._USB_RESET_MIN_INTERVAL_SEC:
                last_usb_reset_attempt = now
                if self._reset_usb_port() and self._reopen():
                    logger.info("[CameraGrabber] USBリセット後の再オープンに成功しました。")
                    last_ok_time = time.time()
                    continue

            time.sleep(0.2)

    def read(self, last_frame_id: int = -1):
        """
        最新フレームを返す（コピーを返すため呼び出し側で自由に書き換え可）。
        last_frame_id を渡すと、前回処理したフレームと同じ場合は
        (False, None, last_frame_id) を返す（同一フレームの二重処理・
        CPU浪費を避けるため）。
        """
        with self._lock:
            if not self._ret or self._frame is None:
                return False, None, last_frame_id
            if self._frame_id == last_frame_id:
                return False, None, last_frame_id
            return True, self._frame.copy(), self._frame_id

    def stop(self):
        self._running = False
        self._thread.join(timeout=1.0)
        try:
            if self._cap is not None:
                self._cap.release()
        except Exception:
            pass


class InputReader:
    """
    GPIO または カメラ からの入力を監視し、
    カウント発生時に on_count_callback を呼び出す。
    """

    def __init__(self, config, on_count_callback, on_alarm_callback=None):
        self.config = config
        self.on_count_callback = on_count_callback
        self.on_alarm_callback = on_alarm_callback
        self.input_mode = self._cfg(['input_mode'], 'CAMERA')

        self._gpio_buttons = []
        self._error_device = None
        self._camera_thread = None
        self._error_thread = None
        self._running = False
        self._input_lock = threading.Lock()

        # カメラ映像共有（ストリーミング用）
        self.output_frame = None
        self.output_frame_id = 0  # output_frame を更新するたびに増分。配信側の停滞検知用
        self.raw_frame = None
        self._frame_lock = threading.Lock()
        self._grabber = None  # _FrameGrabber インスタンス（カメラ起動後に設定される）

        # カウント処理の非同期実行
        self._count_queue = queue.Queue()
        self._count_worker_thread = None
        
        # GPIO用の連続カウント防止タイマー（ピンごとに管理する辞書）
        self._last_gpio_count_times = {}

    # ------------------------------------------------------------------
    #   共通設定取得
    # ------------------------------------------------------------------
    def _cfg(self, keys, default=None):
        for key in keys:
            try:
                value = self.config.get(key, None)
                if value is not None:
                    return value
            except Exception:
                pass
        return default

    def _parse_list(self, key, type_func):
        """設定ファイルからのリスト読み込みを確実に処理する"""
        val = self._cfg([key], [])
        if isinstance(val, str):
            return [type_func(x.strip()) for x in val.split(',') if x.strip()]
        if isinstance(val, list):
            return [type_func(x) for x in val]
        return []

    # ------------------------------------------------------------------
    #   起動 / 停止
    # ------------------------------------------------------------------
    def start(self):
        self._running = True

        self._count_worker_thread = threading.Thread(
            target=self._count_worker_loop,
            daemon=True
        )
        self._count_worker_thread.start()

        if str(self.input_mode).upper() == 'GPIO':
            self._setup_gpio()
        elif str(self.input_mode).upper() == 'CAMERA':
            self._start_camera()
        else:
            logger.warning(f"Unknown input_mode: {self.input_mode}")

        if self._cfg(['error_input_enabled'], False):
            self._setup_error_input()

    def stop(self):
        self._running = False

    def reopen_camera(self, new_device=None):
        """
        カメラ設定画面（ポート5001）等、外部から明示的にカメラの
        再オープンを要求するためのエントリポイント。

        Args:
            new_device: 新しいデバイス指定（数値インデックス文字列、
                        または /dev/v4l/by-id/... 等の安定パス）。
                        None なら現在のデバイスのまま再オープンのみ行う。
        Returns:
            bool: オープンに成功したかどうか。グラバー未起動時は False。
        """
        if self._grabber is None:
            logger.warning("[InputReader] reopen_camera: カメラがまだ初期化されていません。")
            return False
        return self._grabber.force_reopen(new_device)

    # ------------------------------------------------------------------
    #   非同期カウント処理 (バッチ処理対応)
    # ------------------------------------------------------------------
    def _count_worker_loop(self):
        while self._running:
            try:
                item = self._count_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            except Exception:
                continue

            if item == "COUNT":
                increment = 1
                # キューに溜まっている「待ち」のカウントをすべて一瞬で吸い上げる
                while not self._count_queue.empty():
                    try:
                        next_item = self._count_queue.get_nowait()
                        if next_item == "COUNT":
                            increment += 1
                    except queue.Empty:
                        break

                try:
                    with self._input_lock:
                        try:
                            # まとめて加算する数字（increment）を渡す
                            self.on_count_callback(increment)
                        except TypeError:
                            # 安全策: 古い仕様のコールバックの場合はループで回す
                            for _ in range(increment):
                                self.on_count_callback()
                except Exception as e:
                    logger.error(f"Count worker error: {e}")

    # ------------------------------------------------------------------
    #   GPIO カウント入力
    # ------------------------------------------------------------------
    def _setup_gpio(self):
        if not HAS_GPIO:
            logger.error("GPIO requested but gpiozero is not available.")
            return

        pins = self._parse_list('gpio_pins', int)
        hold_times = self._parse_list('gpio_hold_times', float)
        bounce_times = self._parse_list('gpio_bounce_times', float)

        def make_callback(pin_num):
            return lambda: self._on_gpio_input(pin_num)

        for i, pin in enumerate(pins):
            try:
                hold_t = hold_times[i] if i < len(hold_times) else 0.0
                bounce_t = bounce_times[i] if i < len(bounce_times) else 0.0
                btn = Button(
                    pin,
                    pull_up=True,
                    hold_time=hold_t,
                    bounce_time=bounce_t if bounce_t > 0 else None
                )
                btn.when_pressed = make_callback(pin)
                self._gpio_buttons.append(btn)
                logger.info(f"GPIO count pin {pin} configured.")
            except Exception as e:
                logger.error(f"GPIO pin {pin} setup error: {e}")

        if self._cfg(['enable_gpio_reset'], True):
            reset_pin = self._cfg(['gpio_reset_pin'], 5)
            try:
                r_btn = Button(
                    reset_pin,
                    pull_up=True,
                    hold_time=self._cfg(['reset_hold_time'], 3.0)
                )
                r_btn.when_held = self._on_gpio_reset
                self._gpio_buttons.append(r_btn)
                logger.info(f"GPIO reset pin {reset_pin} configured.")
            except Exception as e:
                logger.error(f"GPIO reset pin setup error: {e}")

    def _on_gpio_input(self, pin):
        now = time.time()
        cooldown_sec = float(self._cfg(['gpio_cooldown_sec'], 0.05))
        last_time = self._last_gpio_count_times.get(pin, 0.0)
        
        if now - last_time >= cooldown_sec:
            self._count_queue.put("COUNT")
            self._last_gpio_count_times[pin] = now
            logger.info(f"GPIO Count input accepted from pin {pin}.")
        else:
            logger.debug(f"GPIO input from pin {pin} ignored (cooldown).")

    def _on_gpio_reset(self):
        logger.info("GPIO reset triggered.")

    # ------------------------------------------------------------------
    #   GPIO エラー入力（将来拡張）
    # ------------------------------------------------------------------
    def _setup_error_input(self):
        if not HAS_GPIO:
            logger.warning("GPIO error input requested but gpiozero is not available.")
            return
        if self.on_alarm_callback is None:
            logger.warning("error_input_enabled=true but no on_alarm_callback provided.")
            return

        pin = self._cfg(['error_input_pin'], 27)
        active_state = str(self._cfg(['error_active_state'], 'HIGH')).upper()
        pull_up = (active_state == 'LOW')

        try:
            self._error_device = InputDevice(pin, pull_up=pull_up)
            logger.info(
                f"GPIO error input pin {pin} configured "
                f"(active_state={active_state}, pull_up={pull_up})."
            )
            self._error_thread = threading.Thread(
                target=self._error_monitor_loop,
                daemon=True
            )
            self._error_thread.start()
        except Exception as e:
            logger.error(f"GPIO error input pin {pin} setup error: {e}")

    def _error_monitor_loop(self):
        prev_state = None
        while self._running:
            try:
                if self._error_device is None:
                    break
                current = self._error_device.is_active
                if current != prev_state:
                    prev_state = current
                    logger.info(f"[ErrorInput] alarm={'ON' if current else 'OFF'}")
                    if self.on_alarm_callback:
                        self.on_alarm_callback(current)
            except Exception as e:
                logger.error(f"[ErrorInput] monitor error: {e}")
            time.sleep(0.1)

    # ------------------------------------------------------------------
    #   カメラ入力
    # ------------------------------------------------------------------
    def _start_camera(self):
        if not HAS_OPENCV:
            logger.error("Camera requested but opencv is not available.")
            return
        self._camera_thread = threading.Thread(
            target=self._camera_monitor_loop,
            daemon=True
        )
        self._camera_thread.start()

    def _safe_parse_contours(self, raw_value):
        if raw_value is None:
            return []
        if isinstance(raw_value, list):
            return raw_value
        if isinstance(raw_value, str):
            raw_value = raw_value.strip()
            if raw_value == "":
                return []
            try:
                parsed = json.loads(raw_value)
                if isinstance(parsed, list):
                    return parsed
            except Exception:
                return []
        return []

    def _build_monitor_contours(self, frame_w, frame_h):
        contours_out = []
        raw_contours = self._cfg(['roi_contours'], [])
        contour_groups = self._safe_parse_contours(raw_contours)

        if contour_groups:
            for group in contour_groups:
                pts = []
                try:
                    for p in group:
                        x = int(float(p[0]) * frame_w)
                        y = int(float(p[1]) * frame_h)
                        pts.append([[x, y]])
                    if pts:
                        cnt = np.array(pts, dtype=np.int32)
                        contours_out.append(cnt)
                except Exception:
                    continue
            if contours_out:
                return contours_out

        roi_str = self._cfg(['roi_rect', 'cam_roi'], '0.0, 0.0, 1.0, 1.0')
        try:
            rx, ry, rw, rh = [float(x.strip()) for x in roi_str.split(',')]
        except Exception:
            rx, ry, rw, rh = 0.0, 0.0, 1.0, 1.0

        roi_x = max(0, int(frame_w * rx))
        roi_y = max(0, int(frame_h * ry))
        roi_w = min(frame_w - roi_x, int(frame_w * rw))
        roi_h = min(frame_h - roi_y, int(frame_h * rh))

        if roi_w > 0 and roi_h > 0:
            rect_cnt = np.array(
                [
                    [[roi_x, roi_y]],
                    [[roi_x + roi_w, roi_y]],
                    [[roi_x + roi_w, roi_y + roi_h]],
                    [[roi_x, roi_y + roi_h]],
                ],
                dtype=np.int32
            )
            contours_out.append(rect_cnt)
        return contours_out

    def _build_mask_from_contours(self, frame_w, frame_h, contours):
        mask = np.zeros((frame_h, frame_w), dtype=np.uint8)
        if contours:
            cv2.fillPoly(mask, contours, 255)
        else:
            mask[:, :] = 255
        return mask

    def _get_detect_color(self):
        color = self._cfg(['detect_color'], None)
        if not color:
            return None
        color = str(color).strip().lower()
        if color in ('red', 'green', 'blue'):
            return color
        return None

    def _get_hsv_range(self, color_name):
        try:
            l_raw = self._cfg([f'{color_name}_l_hsv'], '[0,64,64]')
            h_raw = self._cfg([f'{color_name}_h_hsv'], '[10,255,255]')
            l_hsv = np.array(json.loads(l_raw), dtype=np.uint8)
            h_hsv = np.array(json.loads(h_raw), dtype=np.uint8)
            return l_hsv, h_hsv
        except Exception:
            return None, None

    def _find_color_contours(self, frame, base_mask, color_name, area_limit_min):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        l_hsv, h_hsv = self._get_hsv_range(color_name)
        if l_hsv is None or h_hsv is None:
            return []

        if color_name == 'red':
            mask1 = cv2.inRange(hsv, l_hsv, h_hsv)
            low2 = np.array([170, 64, 64], dtype=np.uint8)
            high2 = np.array([179, 255, 255], dtype=np.uint8)
            mask2 = cv2.inRange(hsv, low2, high2)
            color_mask = cv2.bitwise_or(mask1, mask2)
        else:
            color_mask = cv2.inRange(hsv, l_hsv, h_hsv)

        color_mask = cv2.bitwise_and(color_mask, color_mask, mask=base_mask)
        kernel = np.ones((5, 5), np.uint8)
        color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_OPEN, kernel)
        color_mask = cv2.morphologyEx(color_mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        valid = [cnt for cnt in contours if cv2.contourArea(cnt) >= area_limit_min]
        return valid

    def _evaluate_motion_blobs(self, fgmask, area_th):
        """動体マスクをブロブ（個別の連結領域）単位で評価する。

        【目的】小さい動体の集合体による誤検知の低減。
        従来は cv2.countNonZero(fgmask) で「マスク全体の動きピクセル数の
        合計」を見ていたため、コンベアの継ぎ目のように複数の小さい動きが
        同時に発生すると、個々は閾値未満でも合計では閾値を超えてしまい
        誤検知していた。本メソッドでは連結領域ごとに面積を判定し、
        「合計」ではなく「単体で閾値を超えるブロブがあるか」で判定する。

        【ブロブ分離の方式】
        単純な MORPH_OPEN（収縮→膨張）を全体にかけると、近接する複数の
        小さいブロブが膨張ステップで再び結合してしまう副作用がある
        （収縮で分離できても、直後の膨張で外側に広がり、近ければ再び
        くっつく）。これを避けるため、まず収縮のみでブロブを分離し、
        connectedComponents で個々のブロブに分割したうえで、各ブロブを
        「他のブロブとは独立して」個別に膨張して元のサイズへ復元する。

        【パフォーマンス最適化】
        各ブロブの膨張・面積カウントを「フレーム全体サイズ」の配列に対して
        行うと、ブロブ1個あたりのコストが画像全体の解像度に比例してしまい、
        動体検知中にブロブ数が増える（実物体の動き＋背景差分特有の細かい
        ノイズで分裂）とFPSが顕著に低下する原因になっていた。
        connectedComponentsWithStats で各ブロブの外接矩形を取得し、
        膨張処理をその矩形（＋カーネル半径分の余白）だけに限定することで、
        ブロブが小さいほど高速に、かつブロブ数が増えても影響を受けにくくなる。

        Returns:
            valid_count: 単体で area_th 以上と判定されたブロブの個数
            valid_area:  有効ブロブ（閾値以上）の面積合計（OSD "DETECTED" 表示用）
            max_blob_area: 閾値に関わらない、その時点で最大のブロブの面積
                            （複数ブロブがあっても最大の1個のみ。ブロブが
                            無ければ0。閾値調整の目安として、動きはあるが
                            未検知の対象物の実際のサイズを把握するために
                            OSD "MOTION" として常時表示する）
        """
        kernel = np.ones((5, 5), np.uint8)
        pad = 2  # カーネル半径。個別膨張時に境界を正しく復元するための余白
        eroded = cv2.erode(fgmask, kernel, iterations=1)
        n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(eroded, connectivity=8)

        frame_h, frame_w = fgmask.shape[:2]
        valid_count = 0
        valid_area = 0
        max_blob_area = 0
        for label_id in range(1, n_labels):  # 0 は背景
            x, y, bw, bh, _area_px = stats[label_id]
            # 外接矩形をカーネル半径分だけ広げてクロップ（画像端はクランプ）
            x0 = max(0, x - pad)
            y0 = max(0, y - pad)
            x1 = min(frame_w, x + bw + pad)
            y1 = min(frame_h, y + bh + pad)
            labels_crop = labels[y0:y1, x0:x1]
            # 他ブロブとは独立して個別に膨張復元（近接ブロブの誤結合を防ぐ）
            # ※ crop範囲内には他ラベルの画素も含まれ得るが、label_idとの
            #   一致判定で除外されるため、他ブロブへ影響することはない。
            blob_mask = np.where(labels_crop == label_id, 255, 0).astype(np.uint8)
            blob_mask = cv2.dilate(blob_mask, kernel, iterations=1)
            area = cv2.countNonZero(blob_mask)
            if area > max_blob_area:
                max_blob_area = area
            if area < area_th:
                continue  # 単体で閾値未満 → ノイズ（継ぎ目等）として除外
            valid_count += 1
            valid_area += area
        return valid_count, valid_area, max_blob_area

    def _camera_monitor_loop(self):
        cam_index = self._cfg(['camera_device_index', 'cam_index'], 0)
        cam_width = self._cfg(['camera_width', 'cam_width'], 640)
        cam_height = self._cfg(['camera_height', 'cam_height'], 480)

        area_th = self._cfg(['motion_area_threshold', 'cam_area_th'], 300)
        hold_frames = self._cfg(['camera_hold_frames', 'cam_hold_frames'], 5)
        cooldown = self._cfg(['camera_cooldown_sec', 'cam_cooldown'], 0.5)

        area_limit_min = self._cfg(['area_limit_min'], 500)
        motion_ratio_threshold = self._cfg(['motion_ratio_threshold'], 0.03)
        motion_duration_threshold_sec = self._cfg(['motion_duration_threshold_sec'], 0.15)
        contour_history_size = self._cfg(['contour_history_size'], 20)
        exit_frames_threshold = self._cfg(['exit_frames_threshold'], 10)

        # ── 背景差分の学習率 ────────────────────────────────
        # 既定では明示指定せず、OpenCVが history から自動計算する値に
        # 任せていたが、対象物と背景のコントラストが低い現場では、
        # 対象物がわずかに滞留しただけで背景モデルに学習されてしまい、
        # 直後に続けて別の対象物が来た際の検知感度が落ちる事象が確認された。
        # 明示的に低い値へ固定し、対象物が背景として学習されにくくする。
        background_learning_rate = self._cfg(['background_learning_rate'], 0.001)
        # 対象物が「存在中」と判定され続ける異常事態（背景モデルの学習停止と
        # 実際の背景の変化が乖離し、動き検知が自己強化的に続いてしまう場合等）
        # を強制的に断ち切るための上限時間。通常の対象物通過時間より十分長い値。
        max_presence_duration_sec = self._cfg(['max_presence_duration_sec'], 8.0)

        # ── フレーム取得を専用スレッドに分離（遅延蓄積対策・自動復旧対応） ──
        # 初回オープンに失敗しても、ここで即座に諦めず _FrameGrabber 内の
        # 自動復旧ループ（再オープン→USBリセット→再オープン）に任せる。
        grabber = _FrameGrabber(cam_index, cam_width, cam_height)
        self._grabber = grabber  # 外部（camera_config_ui等）から再オープンを要求できるよう公開
        if not grabber.is_opened():
            logger.warning(
                f"Cannot open camera index {cam_index} at startup. "
                f"バックグラウンドで自動復旧を試みます。"
            )
        else:
            logger.info(
                f"[CameraGrabber] カメラ index={cam_index} を正常にオープンしました "
                f"（{cam_width}x{cam_height}）。"
            )
        last_frame_id = -1

        fgbg = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=25, detectShadows=True)

        frames_with_motion = 0
        frames_without_motion = 0
        is_object_present = False
        last_count_time = 0.0
        motion_start_time = None
        object_present_since = None  # 異常長時間検知の安全装置用

        contour_history = deque(maxlen=contour_history_size)
        stable_contours = []
        detect_hold_until = 0.0

        fps_display = 0.0
        fps_frame_count = 0
        fps_start_time = time.time()

        # ── 検知パラメータのライブ再読込 ──────────────────────────
        # カメラ設定画面（ポート5001）から保存された値を、アプリ再起動なしで
        # 反映させるため、一定間隔でconf.iniから再読込する。
        # camera_device_index / camera_width / camera_height はカメラの
        # 再オープンが必要になるため対象外。contour_history_size は
        # deque の maxlen が固定のため対象外。
        CFG_RELOAD_INTERVAL_SEC = 1.0
        last_cfg_reload_time = time.time()

        # ── 処理ループの遅延診断 ──────────────────────────
        # 1フレームの処理（取得〜output_frame更新）に想定以上の時間が
        # かかった場合、どの段階が重いかの内訳をログへ出す。
        # 「映像が固まる」現象が配信側ではなくこちら（検知処理側）に
        # 原因がある場合の切り分け用。
        SLOW_LOOP_THRESHOLD_SEC = 0.15
        SLOW_LOOP_LOG_MIN_INTERVAL_SEC = 5.0
        last_slow_loop_log_time = 0.0

        while self._running:
            _t_loop_start = time.time()
            ret, frame, last_frame_id = grabber.read(last_frame_id)
            if not ret:
                time.sleep(0.005)
                continue

            # ── 検知パラメータのライブ再読込 ──────────────────
            _reload_now = time.time()
            if _reload_now - last_cfg_reload_time >= CFG_RELOAD_INTERVAL_SEC:
                area_th = self._cfg(['motion_area_threshold', 'cam_area_th'], area_th)
                hold_frames = self._cfg(['camera_hold_frames', 'cam_hold_frames'], hold_frames)
                cooldown = self._cfg(['camera_cooldown_sec', 'cam_cooldown'], cooldown)
                area_limit_min = self._cfg(['area_limit_min'], area_limit_min)
                motion_ratio_threshold = self._cfg(['motion_ratio_threshold'], motion_ratio_threshold)
                motion_duration_threshold_sec = self._cfg(
                    ['motion_duration_threshold_sec'], motion_duration_threshold_sec)
                exit_frames_threshold = self._cfg(['exit_frames_threshold'], exit_frames_threshold)
                background_learning_rate = self._cfg(
                    ['background_learning_rate'], background_learning_rate)
                max_presence_duration_sec = self._cfg(
                    ['max_presence_duration_sec'], max_presence_duration_sec)
                last_cfg_reload_time = _reload_now

            fps_frame_count += 1
            elapsed_fps = time.time() - fps_start_time
            if elapsed_fps >= 1.0:
                fps_display = fps_frame_count / elapsed_fps
                fps_frame_count = 0
                fps_start_time = time.time()

            with self._frame_lock:
                self.raw_frame = frame.copy()

            h, w = frame.shape[:2]
            base_contours = self._build_monitor_contours(w, h)
            base_mask = self._build_mask_from_contours(w, h, base_contours)
            _t_setup = time.time()

            detect_color = self._get_detect_color()
            if detect_color:
                current_target_contours = self._find_color_contours(frame, base_mask, detect_color, area_limit_min)
                if current_target_contours:
                    contour_history.append(current_target_contours)
            _t_color = time.time()

            if contour_history:
                stable_contours = contour_history[-1]

            active_contours = stable_contours if stable_contours else base_contours
            active_mask = self._build_mask_from_contours(w, h, active_contours)

            masked_frame = cv2.bitwise_and(frame, frame, mask=active_mask)
            # 対象物が検知確定・滞留している間（is_object_present）は、
            # 学習率を通常の5%程度まで大きく下げることで、対象物が背景として
            # 学習され、直後に続く別の対象物の検知感度が落ちる「学習データの
            # 汚染」を抑える。
            #
            # ★注意: 完全に0（学習停止）にはしない。0にすると、対象物が
            # 存在し続ける間ずっと背景モデルが更新されなくなり、実際の背景
            # （照明のわずかな変化・振動等）が少しずつ本物のモデルからずれて
            # いく。ずれが大きくなるほど「背景との差」が動きとして検知され
            # やすくなり、その結果 is_object_present が解除されず、さらに
            # 学習が止まったままになる……という自己強化ループ（検知状態から
            # 二度と戻らなくなる不具合）を引き起こしたことがあるため、
            # 必ず非ゼロの低い値を使う。
            # is_object_present は前フレーム終了時点の状態（この時点では
            # まだ今フレームの判定前）を参照する。
            effective_learning_rate = (
                background_learning_rate * 0.05 if is_object_present else background_learning_rate
            )
            fgmask = fgbg.apply(masked_frame, learningRate=effective_learning_rate)
            _, fgmask = cv2.threshold(fgmask, 200, 255, cv2.THRESH_BINARY)
            # ノイズ除去・ブロブ分離は _evaluate_motion_blobs 内で
            # 「収縮→ブロブごとに個別復元」方式で行うため、ここでは
            # グローバルな MORPH_OPEN は行わない（近接ブロブの誤結合を防ぐため）。
            fgmask = cv2.bitwise_and(fgmask, fgmask, mask=active_mask)

            valid_blob_count, motion_area, max_blob_area = self._evaluate_motion_blobs(fgmask, area_th)
            _t_blob = time.time()
            monitored_area = max(1, cv2.countNonZero(active_mask))
            motion_ratio = motion_area / monitored_area

            motion_detected = (valid_blob_count > 0) or (motion_ratio >= motion_ratio_threshold)

            if motion_detected:
                frames_with_motion += 1
                frames_without_motion = 0
                if motion_start_time is None:
                    motion_start_time = time.time()
            else:
                frames_with_motion = 0
                frames_without_motion += 1
                motion_start_time = None

            now = time.time()
            state_label = "SCANNING"
            detected_display = False

            if motion_detected and motion_start_time is not None:
                elapsed_motion = now - motion_start_time
                if elapsed_motion >= motion_duration_threshold_sec and frames_with_motion >= hold_frames:
                    state_label = "LOCKED"
                    detected_display = True
                else:
                    state_label = "VERIFYING"

            if not is_object_present:
                if detected_display:
                    if now - last_count_time >= cooldown:
                        self._count_queue.put("COUNT")
                        last_count_time = now
                        detect_hold_until = now + 0.5
                    is_object_present = True
                    object_present_since = now
            else:
                detected_display = True
                state_label = "LOCKED"
                if frames_without_motion >= exit_frames_threshold:
                    is_object_present = False
                    motion_start_time = None
                    object_present_since = None
                elif object_present_since is not None and \
                        (now - object_present_since) >= max_presence_duration_sec:
                    # 安全装置: 通常あり得ない長さ検知が続いている場合、
                    # 背景モデルの汚染・自己強化ループを断ち切るため強制解除する。
                    logger.warning(
                        f"[InputReader] 検知状態が{max_presence_duration_sec:.0f}秒以上継続したため、"
                        f"安全装置により強制的に解除しました（背景モデル汚染の可能性）。"
                    )
                    is_object_present = False
                    motion_start_time = None
                    object_present_since = None
                    frames_with_motion = 0
                    frames_without_motion = 0

            display = frame.copy()
            display_detect = detected_display or (now < detect_hold_until)
            draw_color = (82, 82, 255) if display_detect else (218, 198, 38)

            if active_contours:
                cv2.drawContours(display, active_contours, -1, draw_color, 2, cv2.LINE_AA)

            osd_label = "DETECT" if display_detect else state_label
            self._draw_osd(display, osd_label, display_detect,
                           motion_area, max_blob_area, motion_ratio, fps_display)

            with self._frame_lock:
                self.output_frame = display
                self.output_frame_id += 1

            _t_loop_end = time.time()
            _loop_total = _t_loop_end - _t_loop_start
            if _loop_total >= SLOW_LOOP_THRESHOLD_SEC and \
                    (_t_loop_start - last_slow_loop_log_time) >= SLOW_LOOP_LOG_MIN_INTERVAL_SEC:
                logger.warning(
                    f"[InputReader] 検知処理が遅延: 合計{_loop_total*1000:.0f}ms "
                    f"(監視エリア構築={(_t_setup - _t_loop_start)*1000:.0f}ms, "
                    f"色検出={(_t_color - _t_setup)*1000:.0f}ms, "
                    f"背景差分+ブロブ評価={(_t_blob - _t_color)*1000:.0f}ms, "
                    f"描画等={(_t_loop_end - _t_blob)*1000:.0f}ms)"
                )
                last_slow_loop_log_time = _t_loop_start

            time.sleep(0.005)

        grabber.stop()

    # ── 映像オーバーレイ（OSD）描画 ──────────────────────────────
    # ダッシュボードUIと同系色の落ち着いたデザイン。
    #   ・左上: 状態チップ（色ドット＋ラベル、半透明ダーク下地）
    #   ・左下: 計測値ストリップ（AREA / RATIO / FPS）
    #   ・検知時: 画面枠を赤くフラッシュ（旧: 巨大DETECT文字）
    _OSD_COLORS = {
        "SCANNING":  (218, 198, 38),   # シアン (BGR)
        "VERIFYING": (0, 176, 255),    # ゴールド
        "LOCKED":    (82, 82, 255),    # レッド
        "DETECT":    (82, 82, 255),
    }

    def _blend_rect(self, img, x1, y1, x2, y2, color=(20, 12, 6), alpha=0.6):
        """指定矩形領域のみ半透明の下地を合成する（全面合成より軽量・RPi向け）"""
        h, w = img.shape[:2]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)
        if x2 <= x1 or y2 <= y1:
            return
        roi = img[y1:y2, x1:x2]
        bg = np.full_like(roi, color)
        cv2.addWeighted(bg, alpha, roi, 1 - alpha, 0, dst=roi)

    def _draw_osd(self, display, label, detect, motion_area, max_blob_area, motion_ratio, fps):
        h, w = display.shape[:2]
        color = self._OSD_COLORS.get(label, (218, 198, 38))
        font = cv2.FONT_HERSHEY_DUPLEX

        # 検知フラッシュ: 画面外周を赤枠でハイライト
        if detect:
            cv2.rectangle(display, (2, 2), (w - 3, h - 3), color, 4, cv2.LINE_AA)

        # 状態チップ（左上）
        (tw, _), _ = cv2.getTextSize(label, font, 0.55, 1)
        self._blend_rect(display, 10, 10, 10 + tw + 36, 40)
        cv2.circle(display, (25, 25), 5, color, -1, cv2.LINE_AA)
        cv2.putText(display, label, (37, 32), font, 0.55, (235, 235, 235), 1, cv2.LINE_AA)

        # 計測値ストリップ（左下）
        # DETECTED: 閾値以上で検知に寄与した面積合計（従来のAREAと同じ計算）
        # MOTION:   閾値に関わらない、その時点で最大のブロブ面積
        #           （複数あっても最大の1個のみ）。動きはあるが未検知の
        #           対象物の実際のサイズを把握し、閾値調整の目安にするための表示。
        info = f"DETECTED {motion_area}   MOTION {max_blob_area}   RATIO {motion_ratio:.3f}   FPS {fps:.1f}"
        (iw, _), _ = cv2.getTextSize(info, font, 0.45, 1)
        self._blend_rect(display, 10, h - 38, 10 + iw + 20, h - 10)
        cv2.putText(display, info, (20, h - 19), font, 0.45, (205, 210, 215), 1, cv2.LINE_AA)

    def get_frame_jpeg(self):
        if not HAS_OPENCV:
            return None
        with self._frame_lock:
            frame = self.output_frame
        if frame is None:
            return None
        try:
            _, jpeg = cv2.imencode('.jpg', frame)
            return jpeg.tobytes()
        except Exception:
            return None