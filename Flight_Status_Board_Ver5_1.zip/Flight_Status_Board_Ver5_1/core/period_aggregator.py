"""
period_aggregator.py - 実績集計モジュール（マイナスレコード・差分自己修復対応版）

集計責務の整理:
  - planned_stop の累計は本モジュールが自己集計する。
  - period_log 送信失敗時は基準値を更新せず、次回送信時に差分として補正（マイナス値含む）する。
"""
import time
from datetime import datetime, timezone, timedelta
from typing import Optional

JST = timezone(timedelta(hours=+9), 'JST')

# planned_stop とみなす time_zone
PLANNED_STOP_ZONES = {"break_time", "pre_shift"}


class PeriodAggregator:
    """
    一定期間ごとの生産実績を集計し、API 送信用ペイロードを生成する。
    「前回送信成功時の累計」と「現在の累計」の差分をとることで、
    マイナスレコードによる二重計上の自動補正を実現する。
    """

    def __init__(self, config, counter_tracker):
        self.config  = config
        self.counter = counter_tracker
        self.machine_id = config.get('machine_id', 'DEFAULT_MACHINE')
        self.target     = config.get('target', 100)

        # ------------------------------------------------------------------
        # 「前回の送信成功時」の累計値を保持する（差分計算用）
        # ------------------------------------------------------------------
        self._period_start_ts:        float = time.time()
        self._sent_total_count:       int   = 0
        self._sent_total_work_sec:    float = 0.0
        self._sent_total_choco_sec:   float = 0.0
        self._sent_total_doka_sec:    float = 0.0
        self._sent_total_planned_sec: float = 0.0

        # 計画停止の「本日累計」を保持する変数
        self._planned_total_sec:      float = 0.0
        self._planned_stop_start:     Optional[float] = None

    # ------------------------------------------------------------------
    #   定期更新（background_loop から毎秒呼び出す）
    # ------------------------------------------------------------------
    def update(self, state_machine):
        """
        state_machine.time_zone を見て計画停止時間を自己集計する。
        """
        now = time.time()
        in_planned = state_machine.time_zone in PLANNED_STOP_ZONES

        if in_planned:
            if self._planned_stop_start is None:
                self._planned_stop_start = now
        else:
            if self._planned_stop_start is not None:
                self._planned_total_sec += now - self._planned_stop_start
                self._planned_stop_start = None

    # ------------------------------------------------------------------
    #   集計ペイロード生成
    # ------------------------------------------------------------------
    def generate_payload(self, state_machine) -> dict:
        """
        前回送信時からの差分（マイナス補正含む）ペイロードを生成する。
        """
        now = time.time()
        period_start = datetime.fromtimestamp(self._period_start_ts, JST)
        period_end   = datetime.fromtimestamp(now, JST)

        # 1. 現在の「本日累計」を取得
        current_work  = self.counter.get_current_work_sec()
        current_choco = self.counter.get_current_choco_sec()
        current_doka  = self.counter.get_current_doka_sec()
        current_count = self.counter.count
        
        # 計画停止の「本日累計」を計算（進行中の分も加算）
        current_planned = self._planned_total_sec
        if self._planned_stop_start is not None:
            current_planned += now - self._planned_stop_start

        # ------------------------------------------------------------------
        # 2. マイナス補正ロジック: (今の累計) - (前回送信済みの累計)
        # ------------------------------------------------------------------
        # max(0, ...) を使わないため、過去の判定が覆った場合（稼働→停止など）は
        # ここで自動的にマイナス値が算出され、DBの二重計上を相殺します。
        run_sec    = current_work    - self._sent_total_work_sec
        choco_sec  = current_choco   - self._sent_total_choco_sec
        doka_sec   = current_doka    - self._sent_total_doka_sec
        prod_count = current_count   - self._sent_total_count
        plan_sec   = current_planned - self._sent_total_planned_sec

        # 停止時間 = チョコ停増減 + ドカ停増減
        stop_sec = choco_sec + doka_sec

        return {
            "machineId":             self.machine_id,
            "periodStart":           period_start.isoformat(),
            "periodEnd":             period_end.isoformat(),
            "runningSeconds":        int(run_sec),
            "stopSeconds":           int(stop_sec),
            "plannedStopSeconds":    int(plan_sec),
            "chocoSeconds":          int(choco_sec),
            "dokaSeconds":           int(doka_sec),
            "productionCount":       int(prod_count),
            "targetProductionCount": self.target,
        }

    # ------------------------------------------------------------------
    #   集計リセット（送信後に呼び出す）
    # ------------------------------------------------------------------
    def reset_period(self):
        """
        送信成功時に sender.py からのみ呼び出される。
        「送信済み累計」を現在の値で更新する。
        """
        now = time.time()
        self._period_start_ts = now
        
        # 本日の累計値を「送信済み基準」として記録
        self._sent_total_count     = self.counter.count
        self._sent_total_work_sec  = self.counter.get_current_work_sec()
        self._sent_total_choco_sec = self.counter.get_current_choco_sec()
        self._sent_total_doka_sec  = self.counter.get_current_doka_sec()
        
        # 計画停止の累計も送信済みとして記録
        current_planned = self._planned_total_sec
        if self._planned_stop_start is not None:
            current_planned += now - self._planned_stop_start
        self._sent_total_planned_sec = current_planned

    @staticmethod
    def time() -> float:
        return time.time()