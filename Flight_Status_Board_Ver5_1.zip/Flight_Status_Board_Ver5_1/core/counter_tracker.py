"""
counter_tracker.py - カウント追跡モジュール（リアルタイム排他集計版）

仕様:
- 生産カウントの累計を管理する。
- 停止時間や稼働時間は、StateMachine が決定した「唯一の状態」を
  リアルタイムに確認し、正確に振り分けて加算する（重複計測の排除）。
- ドカ停昇格時は、過去の送信分を相殺するためマイナスレコードを許容して時間を移し替える。
"""
import time

class CounterTracker:
    def __init__(self, config):
        self.config = config
        self.count: int = 0
        self.target: int = config.get('target', 100)

        # 最終確定済み累計（秒）
        self.accumulated_work_sec: float = 0.0
        self.accumulated_choco_sec: float = 0.0
        self.accumulated_doka_sec: float = 0.0
        self.accumulated_planned_stop_sec: float = 0.0 # 計画停止も記録

        # 時間計算用のタイムスタンプと直前の状態
        self._last_update_ts: float = time.time()
        self._last_state: str = "off"
        self._last_stop_class = None

    # ------------------------------------------------------------------
    #   毎秒の計測アップデート（排他制御の心臓部）
    # ------------------------------------------------------------------
    def update_time(self, state_machine):
        """
        メインループで毎秒（または定期的に）呼び出され、
        state_machine が決定した「たった1つの状態」の時間を加算する。
        """
        now = time.time()
        delta = now - self._last_update_ts
        self._last_update_ts = now

        # プログラム停止などで異常な時間ジャンプをした場合は安全策をとる
        if delta > 5.0 or delta < 0:
            delta = 1.0

        # ★ ドカ停への昇格（プロモーション）を検知して時間を移し替える
        if self._last_state == "stop" and state_machine.current_state == "stop":
            if self._last_stop_class == "choco" and state_machine.stop_class == "doka":
                # チョコ停からドカ停に切り替わった瞬間！
                # 最初から今まで止まっていた全時間を計算
                transfer_sec = now - state_machine.stop_start_at if state_machine.stop_start_at else 0
                
                # 過去に送信済みの時間がある場合、ここでマイナス値（補償レコード）が発生する。
                # これにより、ダッシュボードでの合計値の辻褄が完璧に合う。
                self.accumulated_choco_sec -= transfer_sec
                self.accumulated_doka_sec += transfer_sec

        # 直前の状態に対して時間を加算する（絶対にどれか1つしか加算されない）
        if self._last_state == "running":
            self.accumulated_work_sec += delta
        elif self._last_state == "planned_stop":
            self.accumulated_planned_stop_sec += delta
        elif self._last_state == "stop":
            if self._last_stop_class == "doka":
                self.accumulated_doka_sec += delta
            else:
                self.accumulated_choco_sec += delta

        # 次回の計算のために現在の状態を記憶
        self._last_state = state_machine.current_state
        self._last_stop_class = state_machine.stop_class

    # ------------------------------------------------------------------
    #   カウント発生
    # ------------------------------------------------------------------
    def on_count(self, state_machine=None, increment=1):
        """カウントアップのみを行う。時間の加算は update_time が担当する。"""
        self.count += increment

    # ------------------------------------------------------------------
    #   stop_event_manager 連携用（後方互換）
    # ------------------------------------------------------------------
    def finalize_closed_stop(self, final_stop_class: str, final_stop_duration_sec: float):
        """
        リアルタイムで秒数を計算する方式に変更したため、ここでの一括加算は不要。
        （呼び出し元の stop_event_manager がエラーにならないようメソッドだけ残す）
        """
        pass

    # ------------------------------------------------------------------
    #   現在の稼働時間（リアルタイム表示用）
    # ------------------------------------------------------------------
    def get_current_work_sec(self) -> float:
        return self.accumulated_work_sec

    def get_current_choco_sec(self) -> float:
        return self.accumulated_choco_sec

    def get_current_doka_sec(self) -> float:
        return self.accumulated_doka_sec

    def get_current_planned_stop_sec(self) -> float:
        return self.accumulated_planned_stop_sec

    # ------------------------------------------------------------------
    #   リセット・計算系
    # ------------------------------------------------------------------
    def reset(self):
        self.count = 0
        self._last_update_ts = time.time()
        self.accumulated_work_sec = 0.0
        self.accumulated_choco_sec = 0.0
        self.accumulated_doka_sec = 0.0
        self.accumulated_planned_stop_sec = 0.0

    def get_percent(self) -> int:
        current_target = int(self.config.get('target', 100))
        if current_target <= 0:
            return 0
        return int(self.count / current_target * 100)

    def get_avg_per_hour(self) -> int:
        total_sec = (
            self.accumulated_work_sec +
            self.accumulated_choco_sec +
            self.accumulated_doka_sec
        )
        if self.count < 2 or total_sec <= 0:
            return 0
        return int(self.count * 3600 / total_sec)