"""
sender.py - 送信管理モジュール（マイナスレコード・差分自己修復対応版）
"""
import threading
import time
import logging

logger = logging.getLogger(__name__)


class Sender:
    """
    API クライアントと再送キューを使って、
    ハートビート・停止イベント・実績ログを送信する。
    """

    def __init__(self, config, api_client, spool_queue,
                 state_machine, counter_tracker,
                 stop_event_manager, period_aggregator):
        self.config      = config
        self.api         = api_client
        self.spool       = spool_queue
        self.sm          = state_machine
        self.counter     = counter_tracker
        self.stop_mgr    = stop_event_manager
        self.aggregator  = period_aggregator

        self._running    = False
        self._thread     = None

        self._last_heartbeat  = 0.0
        self._last_period_log = 0.0
        self._last_retry      = 0.0
        self._retry_interval  = 30.0

    # ------------------------------------------------------------------
    #   起動 / 停止
    # ------------------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("[Sender] Started.")

    def stop(self):
        self._running = False

    # ------------------------------------------------------------------
    #   メインループ
    # ------------------------------------------------------------------
    def _loop(self):
        while self._running:
            try:
                self._tick()
            except Exception as e:
                logger.error(f"[Sender] Loop error: {e}")
            time.sleep(1.0)

    def _tick(self):
        now = time.time()
        sync_interval   = int(self.config.get('sync_interval_sec', 60))
        period_interval = max(sync_interval, 300)

        if now - self._last_heartbeat >= sync_interval:
            self._send_current_status("periodic")
            self._last_heartbeat = now

        if now - self._last_period_log >= period_interval:
            self._send_period_log()
            self._last_period_log = now

        if not self.spool.is_empty() and now - self._last_retry >= self._retry_interval:
            self._retry_spool()
            self._last_retry = now

    # ------------------------------------------------------------------
    #   状態変化時の即時送信
    # ------------------------------------------------------------------
    def on_state_changed(self):
        self._send_current_status("event")

    def on_stop_events(self, events: list):
        for event in events:
            ok = self.api.send_stop_event(event)
            if not ok:
                self.spool.enqueue("stop_event", event)
                logger.warning(f"[Sender] stop_event queued: {event.get('eventId')}")

    # ------------------------------------------------------------------
    #   送信実装
    # ------------------------------------------------------------------
    def _send_current_status(self, heartbeat_type: str = "periodic"):
        machine_id = self.config.get('machine_id', 'DEFAULT_MACHINE')
        payload = self.sm.to_dict(machine_id, heartbeat_type)
        payload["productionCount"]       = self.counter.count
        payload["targetProductionCount"] = self.config.get('target', 100)

        ok = self.api.send_current_status(payload)
        if not ok:
            self.spool.enqueue("current_status", payload)
            logger.debug("[Sender] current_status queued to spool.")

    def _send_period_log(self):
        payload = self.aggregator.generate_payload(self.sm)
        ok = self.api.send_period_log(payload)
        
        if ok:
            # ★ 送信成功時のみ、アグリゲーターの「送信済み基準値」を更新する
            self.aggregator.reset_period()
            logger.info(f"[Sender] period_log sent: count={payload.get('productionCount')}, run={payload.get('runningSeconds')}, stop={payload.get('stopSeconds')}")
        else:
            # ★ 変更点: スプールには入れない
            # 基準値が更新されないため、次回の generate_payload 時には
            # 今回送れなかった分も含めた「正しい差分」が自動的に再計算されます。
            logger.warning("[Sender] period_log failed to send. Accumulating difference for next cycle.")

    # ------------------------------------------------------------------
    #   再送（クラッシュ安全）
    # ------------------------------------------------------------------
    def _retry_spool(self):
        items = self.spool.dequeue_all()
        if not items:
            return

        logger.info(f"[Sender] Retrying {len(items)} spooled items...")
        sent_ids = []

        for item in items:
            item_type = item.get("type")
            payload   = item.get("payload", {})
            item_id   = item.get("id")
            ok = False

            if item_type == "current_status":
                ok = self.api.send_current_status(payload)
            elif item_type == "stop_event":
                ok = self.api.send_stop_event(payload)
            elif item_type == "period_log":
                # 過去にスプールされた古いログが残っていた場合のための処理
                ok = self.api.send_period_log(payload)

            if ok and item_id:
                sent_ids.append(item_id)

        if sent_ids:
            self.spool.mark_sent(sent_ids)
            logger.info(f"[Sender] {len(sent_ids)} items marked as sent.")

        failed = len(items) - len(sent_ids)
        if failed > 0:
            logger.warning(f"[Sender] {failed} items still failed after retry.")

    # ------------------------------------------------------------------
    #   終了時の強制オフライン送信
    # ------------------------------------------------------------------
    def send_offline_status(self):
        """
        プログラム終了時（Ctrl+Cやシャットダウン）に確実に「停止(off)」状態を送信する
        """
        machine_id = self.config.get('machine_id', 'DEFAULT_MACHINE')
        payload = self.sm.to_dict(machine_id, "shutdown")
        
        # 強制的に状態を「off」に書き換える
        payload["currentState"] = "off"
        payload["stopClass"] = None
        payload["productionCount"] = self.counter.count
        payload["targetProductionCount"] = self.config.get('target', 100)

        logger.info("[Sender] Sending final offline status to server...")
        # スプール（再送キュー）には入れず、ダイレクトに1回だけ送信を試みる
        self.api.send_current_status(payload)