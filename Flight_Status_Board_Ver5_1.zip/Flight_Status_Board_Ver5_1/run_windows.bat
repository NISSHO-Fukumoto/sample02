@echo off
setlocal

cd /d "%~dp0"

echo ============================================
echo  Flight_Status_Board (Ver 5.0)
echo  Windows Test Launcher
echo ============================================
echo.

where python >nul 2>nul
if not errorlevel 1 (
    set "PYCMD=python"
    goto :python_ready
)

where py >nul 2>nul
if not errorlevel 1 (
    set "PYCMD=py"
    goto :python_ready
)

echo [ERROR] Python was not found on PATH.
echo Please install Python 3.10 or later from python.org and try again.
pause
exit /b 1

:python_ready
echo Using Python command: %PYCMD%
echo.

%PYCMD% -c "import flask, cv2, numpy" >nul 2>nul
if not errorlevel 1 goto :launch

echo [INFO] Some required packages are missing.
echo        Installing Windows-compatible dependencies from requirements-windows.txt ...
echo        (Raspberry Pi-only GPIO packages are skipped; versions are unpinned so they
echo         match whatever Python is already installed on this machine.)
echo.
%PYCMD% -m pip install -r requirements-windows.txt
if errorlevel 1 (
    echo.
    echo [ERROR] pip install failed. Please check your Python/pip setup.
    pause
    exit /b 1
)

:launch
echo.
echo Starting server on http://localhost:5000
echo The browser will open automatically in a few seconds.
echo Press Ctrl+C in this window to stop the server.
echo.

start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"

%PYCMD% app.py

echo.
echo Server stopped.
pause
