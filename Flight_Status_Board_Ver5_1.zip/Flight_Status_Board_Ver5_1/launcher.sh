#!/bin/bash
cd "/home/raspberrypi-s14/ドキュメント/Flight_Status_Board_Ver5_0"
source .env/bin/activate

# Pythonサーバーをバックグラウンドで起動
python "app.py" &
SERVER_PID=$!

# サーバーの起動を待機 (curlでアクセス成功するまで1秒待機をループ)
echo 'サーバーの起動を待機しています...'
until curl -s http://localhost:5000 > /dev/null; do
    sleep 1
done
echo 'サーバーの起動を確認しました。ブラウザを開きます。'

# Chromiumをキオスクモードで起動（エラーダイアログ等を無効化）
chromium --kiosk --noerrdialogs --disable-infobars "http://localhost:5000"

# ブラウザが閉じられたらPythonサーバーも終了する
kill $SERVER_PID
