"""
camera_config_ui.py - カメラROI設定UI（Flight_Status_Board v5.0）

ポート 5001 で起動する独立した Flask アプリ。
input_mode = CAMERA の場合のみ app.py から起動される。

機能:
  - ライブMJPEGストリーム表示（ROIオーバーレイ付き）
  - 手動ROI: ブラウザ上でドラッグ矩形指定 → roi_rect に保存
  - 自動ROI: R/G/B ごとのHSV設定でカラー領域を自動検出 → roi_contours に保存
    - 小さすぎる領域（area_limit_min 未満）は除外
    - 複数候補は全て採用
  - ROIクリア: roi_rect を全画面に、roi_contours を空にリセット

エンドポイント:
  GET  /            : 設定UI HTML
  GET  /video_feed  : MJPEGストリーム（ROIオーバーレイ付き）
  GET  /api/roi_info        : 現在のROI設定状態（領域数・面積閾値など）
  GET  /api/regions         : 教示済み領域の一覧（正規化ポリゴン＋外接矩形）
  POST /api/set_roi         : 手動ROI保存 { roi: [x, y, w, h] (normalized) }
  POST /api/auto_detect/<color> : 自動ROI検出 (color: red/green/blue)
  POST /api/delete_region   : 教示領域を1つ削除 { index: int }（不要候補のタッチ削除用）
  POST /api/clear_roi       : ROIクリア
  POST /api/set_motion_settings : 最小検知面積・動体検知の閾値・最低継続フレーム数・検知終了フレーム数の保存
                                   { area_limit_min, area_threshold, hold_frames, exit_frames }
  GET  /api/list_camera_devices : 現在接続中のカメラデバイス一覧（valueは0〜100の順序インデックス）
  POST /api/set_camera_device   : カメラデバイスをconf.iniへ保存し、即座に再オープンを試みる
                                   { device: str（0〜100の数字） }

conf.ini [CAMERA] セクションに以下を読み書きする:
  roi_rect        = 0.0, 0.0, 1.0, 1.0   (正規化 x,y,w,h)
  roi_contours    = []                    (正規化ポリゴンリスト JSON)
  red_l_hsv       = [0,64,64]
  red_h_hsv       = [10,255,255]
  green_l_hsv     = [50,64,64]
  green_h_hsv     = [90,255,255]
  blue_l_hsv      = [100,64,64]
  blue_h_hsv      = [140,255,255]
  area_limit_min  = 500
  stream_port     = 5001
"""

import threading
import time
import json
import logging
import os
import glob
import re

from flask import Flask, Response, jsonify, request

try:
    import cv2
    import numpy as np
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

logger = logging.getLogger('Flight_Status_Board.camera_config_ui')


class CameraConfigUI:
    """
    カメラROI設定UIサーバー。

    Parameters
    ----------
    config : ConfigLoader
        Flight_Status_Board の ConfigLoader インスタンス。
        conf.ini の [CAMERA] セクションを読み書きする。
    config_file : str
        conf.ini の絶対パス。
    lock : threading.Lock
        rawFrame へのアクセスを保護する既存ロック。
    state_refs : dict
        {
            "rawFrame": callable -> 最新フレーム (np.ndarray) または None,
            "cam_width": int,
            "cam_height": int,
            "stream_port": int,
        }
    """

    def __init__(self, config, config_file: str, lock: threading.Lock, state_refs: dict):
        self.config      = config
        self.config_file = config_file
        self.lock        = lock
        self.state_refs  = state_refs

        self.app = Flask("camera_config_ui")
        self.latest_overlay_contours = []   # 最後に検出したコンター（表示用）
        self._register_routes()

    # ----------------------------------------------------------------
    # conf.ini ヘルパー
    # ----------------------------------------------------------------
    def _ensure_camera_section(self):
        """[CAMERA] セクションが存在しない場合は追加する"""
        if not self.config._parser.has_section("CAMERA"):
            self.config._parser.add_section("CAMERA")

    def _save_config(self):
        """conf.ini に書き戻す"""
        with open(self.config_file, "w", encoding="utf-8") as f:
            self.config._parser.write(f)

        # ★追加: ファイル書き込み後、システム全体の設定キャッシュを更新し
        # input_reader.py などの別モジュールに即座に変更を反映させる
        if hasattr(self.config, 'load'):
            self.config.load()

    def _get_camera_value(self, key: str, fallback: str = "") -> str:
        self._ensure_camera_section()
        return self.config._parser.get("CAMERA", key, fallback=fallback)

    def _set_camera_value(self, key: str, value: str):
        self._ensure_camera_section()
        self.config._parser.set("CAMERA", key, value)

    def _parse_hsv(self, color_name: str):
        """
        conf.ini の {color}_l_hsv / {color}_h_hsv を読み込んで
        numpy 配列として返す。
        """
        l_key = f"{color_name}_l_hsv"
        h_key = f"{color_name}_h_hsv"

        # デフォルト値（色ごとに適切な初期値）
        defaults = {
            "red":   ("[0,64,64]",   "[10,255,255]"),
            "green": ("[50,64,64]",  "[90,255,255]"),
            "blue":  ("[100,64,64]", "[140,255,255]"),
        }
        dl, dh = defaults.get(color_name, ("[0,0,0]", "[180,255,255]"))

        l_raw = self._get_camera_value(l_key, dl)
        h_raw = self._get_camera_value(h_key, dh)

        l_hsv = np.array(json.loads(l_raw), dtype=np.uint8)
        h_hsv = np.array(json.loads(h_raw), dtype=np.uint8)
        return l_hsv, h_hsv

    def _get_area_limit_min(self) -> int:
        try:
            return self.config._parser.getint("CAMERA", "area_limit_min", fallback=500)
        except Exception:
            return 500

    def _get_motion_area_threshold(self) -> int:
        try:
            return self.config._parser.getint("CAMERA", "motion_area_threshold", fallback=300)
        except Exception:
            return 300

    def _get_camera_hold_frames(self) -> int:
        try:
            return self.config._parser.getint("CAMERA", "camera_hold_frames", fallback=5)
        except Exception:
            return 5

    def _get_exit_frames_threshold(self) -> int:
        try:
            return self.config._parser.getint("CAMERA", "exit_frames_threshold", fallback=10)
        except Exception:
            return 10

    def _get_camera_device_index(self) -> str:
        try:
            return self.config._parser.get("CAMERA", "camera_device_index", fallback="0")
        except Exception:
            return "0"

    # ----------------------------------------------------------------
    # カメラデバイス列挙
    # ----------------------------------------------------------------
    def _list_camera_devices(self):
        """
        接続中のカメラデバイス候補を列挙する。

        /dev/v4l/by-id/ の安定パス（USB再列挙・USBリセット後も番号が
        変わらない）を優先して使用する。udev の慣例で、実際の映像
        キャプチャ用ノードは "-video-index0" で終わることが多いため、
        まずそのパターンに絞り込み、該当が無ければ by-id 配下すべてを
        候補とする（メタデータ専用ノードが混ざる可能性はあるが、
        後述の通り実際に開いて確認するため実害はない）。

        conf.ini の camera_device_index には、この一覧の「並び順の
        インデックス（0, 1, 2...）」を保存する。個体名（長いパス文字列）
        ではなく単純な数値にすることで、複数の設置端末間で設定を
        統一・記録しやすくする（core/input_reader.py 側で、この数値を
        毎回このリストの並び順から実際の安定パスへ解決してからオープン
        するため、番号自体は数値のままでも従来のOS生インデックスのような
        不安定さは生じない）。

        注意: 稼働中の input_reader がカメラを排他オープンしている場合、
        ここでの試験オープンは失敗する。そのため「オープンできるか」の
        判定は行わず、パスの一覧のみを返す（実際に使えるかどうかは
        選択・保存後の再オープン結果で分かる）。
        """
        devices = []
        by_id_dir = "/dev/v4l/by-id"
        entries = []
        if os.path.isdir(by_id_dir):
            entries = sorted(os.listdir(by_id_dir))

        preferred = [e for e in entries if e.endswith("-video-index0")]
        chosen_entries = preferred if preferred else entries

        seen_real = set()
        index = 0
        for name in chosen_entries:
            link_path = os.path.join(by_id_dir, name)
            try:
                real_path = os.path.realpath(link_path)
            except Exception:
                continue
            if real_path in seen_real:
                continue
            seen_real.add(real_path)
            # 表示名: "usb-icSpring_WebCamera_20240603181141-video-index0"
            #        -> "icSpring WebCamera"（末尾のシリアル番号は表示上省く）
            label = name
            if label.startswith("usb-"):
                label = label[len("usb-"):]
            if label.endswith("-video-index0"):
                label = label[:-len("-video-index0")]
            label = label.replace("_", " ").strip()
            # 末尾トークンが「英数字のみ・6文字以上」ならシリアル番号/型番と
            # みなし、人間が読む名称からは省く（実際の識別には link_path を
            # 使うため、除外しても機能上の影響は無い）。
            tokens = label.split(" ")
            if tokens and re.fullmatch(r"[A-Za-z0-9]{6,}", tokens[-1]):
                tokens = tokens[:-1]
            label = " ".join(tokens).strip() or label
            devices.append({
                "value": str(index),  # ★ 個体名パスではなく順序インデックス
                "label": f"{index}: {label}  ({real_path})",
                "path": link_path,    # 参考表示用（保存には使わない）
            })
            index += 1

        # by-id が使えない環境向けフォールバック: /dev/video* を数値indexとして列挙
        # ※この場合の数値は実際のOS番号そのもの（従来通り不安定）。
        #   by-id が使える環境では上のブロックの「並び順インデックス」が
        #   優先されるため、このフォールバックに入るのは非常時のみ。
        #
        # ★重要: 単純に /dev/video* を列挙すると、過去のUSB再接続・
        # USBリセットのたびに作られた「もう存在しない古いデバイスファイル」
        # が /dev 上に残ったままになり、実際には1台しか繋がっていないのに
        # 大量の候補が出てしまうことがある（実機で確認済みの不具合）。
        # /sys/class/video4linux/videoN は、デバイスが物理的に切断されると
        # カーネルによって確実に削除されるため、ここに存在するものだけを
        # 「今も本当に有効なデバイス」として扱う。
        # さらに、1台のカメラが複数ノード（映像用+メタデータ用等）を
        # 持つことがあるため、実体（/sys/.../device のリンク先）が
        # 同じものは1つにまとめる。
        if not devices:
            sysfs_dir = "/sys/class/video4linux"
            seen_device_real = set()
            fallback_index = 0
            for dev in sorted(glob.glob("/dev/video*")):
                name = os.path.basename(dev)  # 例: "video10"
                sysfs_node = os.path.join(sysfs_dir, name)
                if not os.path.isdir(sysfs_node):
                    # /sys 側に実体が無い = 切断済みの古いデバイスファイル。除外する。
                    continue
                # 物理デバイス単位の重複排除（同じカメラの別ノードをまとめる）
                device_link = os.path.join(sysfs_node, "device")
                try:
                    device_real = os.path.realpath(device_link)
                except Exception:
                    device_real = sysfs_node
                if device_real in seen_device_real:
                    continue
                seen_device_real.add(device_real)

                # 可能であればデバイス名（例: "icSpring WebCamera"）を取得する
                friendly = None
                try:
                    with open(os.path.join(sysfs_node, "name"), "r", encoding="utf-8", errors="ignore") as f:
                        friendly = f.read().strip()
                except Exception:
                    pass
                label_name = friendly if friendly else dev

                devices.append({
                    "value": str(fallback_index),
                    "label": f"{fallback_index}: {label_name} ({dev})",
                    "path": dev,
                })
                fallback_index += 1

        return devices

    # ----------------------------------------------------------------
    # フレーム取得
    # ----------------------------------------------------------------
    def _get_frame(self):
        """最新フレームのコピーを返す。取得できない場合は None。

        ロックは参照の取得だけに使い、コピー自体はロックの外で行う。
        input_reader 側は毎フレーム新しい配列を作って output_frame に
        代入する実装（既存の配列をその場で書き換えることはない）ため、
        参照を受け取った後にロック外でコピーしても安全であり、
        ロック保持時間（＝input_reader 側の待ち時間）を最小化できる。
        """
        getter = self.state_refs.get("outputFrame") or self.state_refs.get("rawFrame")
        with self.lock:
            frame = getter()
        if frame is None:
            return None
        return frame.copy()

    # ----------------------------------------------------------------
    # ROI 正規化・保存
    # ----------------------------------------------------------------
    def _normalize_rect(self, x1, y1, x2, y2, w, h):
        """
        ピクセル座標の矩形を正規化 [left, top, width, height] に変換する。
        無効な矩形の場合は None を返す。
        """
        left   = max(0, min(x1, x2))
        top    = max(0, min(y1, y2))
        right  = min(w, max(x1, x2))
        bottom = min(h, max(y1, y2))

        rw = max(0, right  - left)
        rh = max(0, bottom - top)

        if rw <= 0 or rh <= 0:
            return None

        return [
            round(left / w, 4),
            round(top  / h, 4),
            round(rw   / w, 4),
            round(rh   / h, 4),
        ]

    def _save_manual_roi(self, roi_rect: list):
        """
        手動ROIを conf.ini に保存する。
        roi_rect = [x, y, w, h] (正規化済み)
        """
        self._set_camera_value(
            "roi_rect",
            f"{roi_rect[0]:.4f}, {roi_rect[1]:.4f}, {roi_rect[2]:.4f}, {roi_rect[3]:.4f}"
        )
        self._set_camera_value("roi_contours", "[]")
        self._save_config()

    def _save_auto_contours(self, contours: list, frame_w: int, frame_h: int):
        """
        自動検出したコンターを正規化して conf.ini に保存する。
        代表矩形（全コンターを包む外接矩形）も roi_rect に保存する。
        """
        normalized_all = []
        all_points     = []

        for cnt in contours:
            pts = cnt.reshape(-1, 2).tolist()
            norm_pts = []
            for x, y in pts:
                nx = round(float(x) / frame_w, 4)
                ny = round(float(y) / frame_h, 4)
                norm_pts.append([nx, ny])
                all_points.append((x, y))
            normalized_all.append(norm_pts)

        if not all_points:
            raise ValueError("No contour points")

        xs = [p[0] for p in all_points]
        ys = [p[1] for p in all_points]
        roi_rect = self._normalize_rect(min(xs), min(ys), max(xs), max(ys), frame_w, frame_h)
        if roi_rect is None:
            raise ValueError("Invalid roi rect from contours")

        self._set_camera_value(
            "roi_rect",
            f"{roi_rect[0]:.4f}, {roi_rect[1]:.4f}, {roi_rect[2]:.4f}, {roi_rect[3]:.4f}"
        )
        self._set_camera_value(
            "roi_contours",
            json.dumps(normalized_all, ensure_ascii=False)
        )
        self._save_config()

    # ----------------------------------------------------------------
    # オーバーレイ読み込み（ストリーム表示用）
    # ----------------------------------------------------------------
    def _load_saved_overlays(self, frame_w: int, frame_h: int) -> list:
        """
        保存済みの roi_contours / roi_rect をピクセル座標のコンター配列として返す。
        roi_contours が存在する場合はそちらを優先する。
        """
        raw = self._get_camera_value("roi_contours", "[]")
        try:
            contour_groups = json.loads(raw)
        except Exception:
            contour_groups = []

        if contour_groups:
            overlays = []
            for group in contour_groups:
                pts = [
                    [[int(float(p[0]) * frame_w), int(float(p[1]) * frame_h)]]
                    for p in group
                ]
                if pts:
                    overlays.append(np.array(pts, dtype=np.int32))
            return overlays

        # roi_contours が空の場合は roi_rect を矩形コンターに変換
        roi_rect_raw = self._get_camera_value("roi_rect", "0.0, 0.0, 1.0, 1.0")
        try:
            rx, ry, rw, rh = [float(v.strip()) for v in roi_rect_raw.split(",")]
            x1 = int(rx * frame_w)
            y1 = int(ry * frame_h)
            x2 = int((rx + rw) * frame_w)
            y2 = int((ry + rh) * frame_h)
            rect_cnt = np.array(
                [[[x1, y1]], [[x2, y1]], [[x2, y2]], [[x1, y2]]],
                dtype=np.int32
            )
            return [rect_cnt]
        except Exception:
            return []

    # ----------------------------------------------------------------
    # 自動カラー検出
    # ----------------------------------------------------------------
    def _auto_detect_color(self, color_name: str):
        """
        HSV 色空間でカラー領域を検出し、有効なコンターを roi_contours に保存する。

        Returns
        -------
        (dict, int) : (レスポンス辞書, HTTPステータスコード)
        """
        frame = self._get_frame()
        if frame is None:
            return {"status": "error", "message": "No camera frame available"}, 400

        h, w = frame.shape[:2]
        l_hsv, h_hsv = self._parse_hsv(color_name)
        area_limit_min = self._get_area_limit_min()

        # HSV 変換 → マスク生成
        hsv  = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, l_hsv, h_hsv)

        # ノイズ除去（オープニング → クロージング）
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 面積フィルタ（小さすぎる領域を除外）、複数候補は全て採用
        valid_contours = [cnt for cnt in contours if cv2.contourArea(cnt) >= area_limit_min]

        if not valid_contours:
            return {
                "status":  "error",
                "message": f"No valid {color_name} region found (area_limit_min={area_limit_min})"
            }, 404

        self.latest_overlay_contours = valid_contours
        self._save_auto_contours(valid_contours, w, h)

        logger.info(f"[CameraConfigUI] Auto detect {color_name}: {len(valid_contours)} region(s)")
        return {
            "status":  "success",
            "message": f"{color_name.capitalize()} regions detected",
            "count":   len(valid_contours),
        }, 200

    # ----------------------------------------------------------------
    # MJPEGストリーム生成
    # ----------------------------------------------------------------
    def _generate_frames(self):
        """
        ROI オーバーレイを描画した MJPEG フレームを yield する。
        """
        last_none_log_time = 0.0
        last_encode_fail_log_time = 0.0
        last_slow_log_time = 0.0
        # このステップの処理（取得〜yield）に想定以上の時間がかかった場合、
        # 「映像が固まる」現象の原因切り分け用に内訳をログへ出す。
        # 5秒に1回だけ出す間引きは、他の警告ログと同様。
        SLOW_FRAME_THRESHOLD_SEC = 0.3
        SLOW_LOG_MIN_INTERVAL_SEC = 5.0

        # ── input_reader 側の停滞検知 ──────────────────────
        # 配信ループ自体は速く回っていても、input_reader が新しい
        # フレームを作れていなければ（＝output_frame_id が増えていなければ）
        # 同じ古い映像を配信し続けることになり、見た目上「固まる」。
        # 配信パイプライン側の遅延（上のSLOW_FRAME）とは別の原因のため、
        # 区別してログに出す。
        id_getter = self.state_refs.get("outputFrameId")
        last_seen_frame_id = None
        last_frame_id_change_time = time.time()
        last_stale_log_time = 0.0
        STALE_THRESHOLD_SEC = 2.0
        STALE_LOG_MIN_INTERVAL_SEC = 5.0

        while True:
            t0 = time.time()
            frame = self._get_frame()
            t_get = time.time()

            if id_getter is not None:
                try:
                    current_frame_id = id_getter()
                except Exception:
                    current_frame_id = None
                if current_frame_id is not None:
                    if current_frame_id != last_seen_frame_id:
                        last_seen_frame_id = current_frame_id
                        last_frame_id_change_time = t0
                    else:
                        stale_duration = t0 - last_frame_id_change_time
                        if stale_duration >= STALE_THRESHOLD_SEC and \
                                (t0 - last_stale_log_time) >= STALE_LOG_MIN_INTERVAL_SEC:
                            logger.warning(
                                f"[CameraConfigUI] input_reader側が{stale_duration:.1f}秒間"
                                f"新しいフレームを生成していません（output_frame_id={current_frame_id}"
                                f"のまま停滞）。配信側ではなく検知処理側の遅延の可能性があります。"
                            )
                            last_stale_log_time = t0

            if frame is None:
                now = time.time()
                if now - last_none_log_time >= 5.0:
                    logger.warning(
                        "[CameraConfigUI] output_frame が取得できません"
                        "（カメラ未オープン、または input_reader 側の停止の可能性）。"
                    )
                    last_none_log_time = now
                time.sleep(0.05)
                continue

            h, w = frame.shape[:2]

            # 最新の検出結果があればそれを使用、なければ保存済みを使用
            if self.latest_overlay_contours:
                contours = self.latest_overlay_contours
            else:
                contours = self._load_saved_overlays(w, h)
            t_overlay = time.time()

            for cnt in contours:
                cv2.drawContours(frame, [cnt], -1, (0, 255, 255), 2)
            t_draw = time.time()

            ok, encoded = cv2.imencode(".jpg", frame)
            t_encode = time.time()
            if not ok:
                now = time.time()
                if now - last_encode_fail_log_time >= 5.0:
                    logger.warning("[CameraConfigUI] JPEGエンコードに失敗しました。")
                    last_encode_fail_log_time = now
                time.sleep(0.05)
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n" +
                bytearray(encoded) +
                b"\r\n"
            )
            t_yield = time.time()

            # ── 遅延診断: このフレームの処理に想定以上の時間がかかったら内訳を記録 ──
            total = t_yield - t0
            if total >= SLOW_FRAME_THRESHOLD_SEC and (t0 - last_slow_log_time) >= SLOW_LOG_MIN_INTERVAL_SEC:
                logger.warning(
                    f"[CameraConfigUI] 配信フレーム処理が遅延: 合計{total*1000:.0f}ms "
                    f"(取得={  (t_get-t0)*1000:.0f}ms, "
                    f"オーバーレイ取得={(t_overlay-t_get)*1000:.0f}ms, "
                    f"描画={(t_draw-t_overlay)*1000:.0f}ms, "
                    f"JPEGエンコード={(t_encode-t_draw)*1000:.0f}ms, "
                    f"クライアント送信(yield)={(t_yield-t_encode)*1000:.0f}ms)"
                )
                last_slow_log_time = t0
            time.sleep(0.05)

    # ----------------------------------------------------------------
    # Flask ルート登録
    # ----------------------------------------------------------------
    def _register_routes(self):

        @self.app.route("/")
        def index():
            return _CAMERA_CONFIG_HTML

        @self.app.route("/video_feed")
        def video_feed():
            return Response(
                self._generate_frames(),
                mimetype="multipart/x-mixed-replace; boundary=frame"
            )

        @self.app.route("/api/set_roi", methods=["POST"])
        def set_roi():
            data = request.get_json(force=True)
            roi  = data.get("roi")
            if not roi or len(roi) != 4:
                return jsonify({"status": "error", "message": "Invalid ROI: must be [x, y, w, h]"}), 400
            try:
                rx, ry, rw, rh = [float(v) for v in roi]
                self._save_manual_roi([rx, ry, rw, rh])
                self.latest_overlay_contours = []
                logger.info(f"[CameraConfigUI] Manual ROI saved: {rx:.4f},{ry:.4f},{rw:.4f},{rh:.4f}")
                return jsonify({"status": "success", "message": "ROI saved"})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/clear_roi", methods=["POST"])
        def clear_roi():
            try:
                self._set_camera_value("roi_rect",     "0.0000, 0.0000, 1.0000, 1.0000")
                self._set_camera_value("roi_contours", "[]")
                self._save_config()
                self.latest_overlay_contours = []
                logger.info("[CameraConfigUI] ROI cleared")
                return jsonify({"status": "success", "message": "ROI cleared"})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/auto_detect/<color_name>", methods=["POST"])
        def auto_detect(color_name):
            color_name = color_name.lower()
            if color_name not in ("red", "green", "blue"):
                return jsonify({"status": "error", "message": "Unsupported color (use red/green/blue)"}), 400
            data, code = self._auto_detect_color(color_name)
            return jsonify(data), code

        @self.app.route("/api/roi_info")
        def roi_info():
            """UI表示用: 現在保存されているROIの状態を返す"""
            try:
                raw = self._get_camera_value("roi_contours", "[]")
                try:
                    groups = json.loads(raw)
                except Exception:
                    groups = []
                roi_rect_raw = self._get_camera_value("roi_rect", "0.0, 0.0, 1.0, 1.0")
                is_fullscreen = False
                try:
                    rx, ry, rw, rh = [float(v.strip()) for v in roi_rect_raw.split(",")]
                    is_fullscreen = (rx <= 0.0001 and ry <= 0.0001 and rw >= 0.9999 and rh >= 0.9999)
                except Exception:
                    pass
                return jsonify({
                    "status":         "success",
                    "contour_count":  len(groups),
                    "roi_rect":       roi_rect_raw,
                    "is_fullscreen":  is_fullscreen and not groups,
                    "area_limit_min": self._get_area_limit_min(),
                    "motion_area_threshold": self._get_motion_area_threshold(),
                    "camera_hold_frames":    self._get_camera_hold_frames(),
                    "exit_frames_threshold": self._get_exit_frames_threshold(),
                })
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/set_motion_settings", methods=["POST"])
        def set_motion_settings():
            """最小検知面積・動体検知の閾値・最低継続フレーム数・検知終了フレーム数をまとめて保存する"""
            try:
                data = request.get_json(force=True)
                area_limit_min = max(0, int(data.get("area_limit_min", 500)))
                area_threshold = max(0, int(data.get("area_threshold", 300)))
                hold_frames    = max(1, int(data.get("hold_frames", 5)))
                exit_frames    = max(1, int(data.get("exit_frames", 10)))
                self._set_camera_value("area_limit_min", str(area_limit_min))
                self._set_camera_value("motion_area_threshold", str(area_threshold))
                self._set_camera_value("camera_hold_frames", str(hold_frames))
                self._set_camera_value("exit_frames_threshold", str(exit_frames))
                self._save_config()
                logger.info(
                    f"[CameraConfigUI] area_limit_min={area_limit_min}, "
                    f"motion_area_threshold={area_threshold}, "
                    f"camera_hold_frames={hold_frames}, "
                    f"exit_frames_threshold={exit_frames} saved"
                )
                return jsonify({
                    "status": "success",
                    "message": "detection settings saved",
                    "area_limit_min": area_limit_min,
                    "area_threshold": area_threshold,
                    "hold_frames": hold_frames,
                    "exit_frames": exit_frames,
                })
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/list_camera_devices")
        def list_camera_devices():
            """現在接続中のカメラデバイス候補を返す"""
            try:
                devices = self._list_camera_devices()
                return jsonify({
                    "status": "success",
                    "devices": devices,
                    "current": self._get_camera_device_index(),
                })
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/set_camera_device", methods=["POST"])
        def set_camera_device():
            """
            カメラデバイスをconf.iniへ保存し、即座に再オープンを試みる。

            保存する値は「安定パス一覧の並び順インデックス」を表す
            0〜100の単純な数字に限定する（個体名の長いパス文字列は
            保存しない）。複数の設置端末間で設定を統一・記録しやすくする
            ための方針。実際のデバイスへの解決（USB再列挙後も追従する
            安定パスへの変換）は core/input_reader.py 側で毎回行う。
            """
            try:
                data = request.get_json(force=True)
                device_raw = str(data.get("device", "")).strip()
                if not device_raw:
                    return jsonify({"status": "error", "message": "device is required"}), 400
                if not re.fullmatch(r"\d+", device_raw):
                    return jsonify({
                        "status": "error",
                        "message": "device は0〜100の数字で指定してください",
                    }), 400
                device_num = int(device_raw)
                if not (0 <= device_num <= 100):
                    return jsonify({
                        "status": "error",
                        "message": "device は0〜100の範囲で指定してください",
                    }), 400
                device = str(device_num)

                self._set_camera_value("camera_device_index", device)
                self._save_config()
                logger.info(f"[CameraConfigUI] camera_device_index を保存しました: {device}")

                reopen_fn = self.state_refs.get("reopenCamera")
                opened = None
                if reopen_fn is not None:
                    try:
                        opened = bool(reopen_fn(device_num))
                    except Exception as e:
                        logger.error(f"[CameraConfigUI] カメラ再オープン呼び出しでエラー: {e}")
                        opened = False
                else:
                    logger.warning(
                        "[CameraConfigUI] reopenCamera が state_refs に無いため、"
                        "保存のみ行いました（再起動が必要な場合があります）。"
                    )

                return jsonify({
                    "status": "success",
                    "device": device,
                    "opened": opened,  # None = 再オープン機能が未接続（要app.py側の対応）
                })
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/regions")
        def get_regions():
            """教示済み領域（正規化ポリゴン）の一覧を返す"""
            try:
                raw = self._get_camera_value("roi_contours", "[]")
                try:
                    groups = json.loads(raw)
                except Exception:
                    groups = []
                regions = []
                for i, g in enumerate(groups):
                    xs = [float(p[0]) for p in g]
                    ys = [float(p[1]) for p in g]
                    if not xs:
                        continue
                    regions.append({
                        "index":  i,
                        "points": g,
                        "bbox":   [min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)],
                    })
                return jsonify({"status": "success", "regions": regions})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

        @self.app.route("/api/delete_region", methods=["POST"])
        def delete_region():
            """教示領域を1つ削除する（不要な候補領域のタッチ削除用）"""
            try:
                data = request.get_json(force=True)
                idx = int(data.get("index", -1))
                raw = self._get_camera_value("roi_contours", "[]")
                try:
                    groups = json.loads(raw)
                except Exception:
                    groups = []
                if idx < 0 or idx >= len(groups):
                    return jsonify({"status": "error", "message": f"Invalid region index: {idx}"}), 400
                groups.pop(idx)
                if groups:
                    # 残り領域の外接矩形で roi_rect を再計算
                    xs = [float(p[0]) for g in groups for p in g]
                    ys = [float(p[1]) for g in groups for p in g]
                    self._set_camera_value(
                        "roi_rect",
                        f"{min(xs):.4f}, {min(ys):.4f}, {max(xs) - min(xs):.4f}, {max(ys) - min(ys):.4f}"
                    )
                    self._set_camera_value("roi_contours", json.dumps(groups, ensure_ascii=False))
                else:
                    # 全て削除されたら全画面に戻す
                    self._set_camera_value("roi_rect",     "0.0000, 0.0000, 1.0000, 1.0000")
                    self._set_camera_value("roi_contours", "[]")
                self._save_config()
                self.latest_overlay_contours = []
                logger.info(f"[CameraConfigUI] Region {idx} deleted ({len(groups)} remaining)")
                return jsonify({"status": "success", "remaining": len(groups)})
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 500

    # ----------------------------------------------------------------
    # サーバー起動
    # ----------------------------------------------------------------
    def run(self):
        """別スレッドから呼び出す。ポートは state_refs["stream_port"] を使用。"""
        port = int(self.state_refs.get("stream_port", 5001))
        logger.info(f"[CameraConfigUI] Starting on port {port}")
        self.app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False, threaded=True)


# ----------------------------------------------------------------
# カメラ設定UI HTML（インライン）
# ----------------------------------------------------------------
_CAMERA_CONFIG_HTML = """<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Chromateach Camera Setup - Flight Status Board</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%F0%9F%93%B7%3C/text%3E%3C/svg%3E">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg: #070b14;
  --panel: #0d1524;
  --panel2: #101b30;
  --border: #1c2942;
  --border-hi: #2a3d63;
  --text: #d5e2f5;
  --dim: #5d7396;
  --gold: #ffb000;
  --cyan: #26c6da;
  --green: #46d95f;
  --red: #ff5252;
  --blue: #448aff;
}
html, body { height: 100%; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: "Segoe UI", "Hiragino Sans", "Yu Gothic UI", Meiryo, sans-serif;
  display: flex; flex-direction: column;
  min-height: 100vh;
}

/* ── ヘッダー ─────────────────────────── */
header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 22px;
  background: linear-gradient(180deg, #0d1524, #0a1120);
  border-bottom: 1px solid var(--border);
  flex-wrap: wrap; gap: 10px;
}
.brand { display: flex; align-items: center; gap: 14px; }
.brand-icon {
  width: 44px; height: 44px; border-radius: 10px;
  background: linear-gradient(135deg, #14233f, #0d1524);
  border: 1px solid var(--border-hi);
  display: flex; align-items: center; justify-content: center;
  font-size: 22px;
}
.brand-title {
  font-size: 16px; font-weight: 700; letter-spacing: 2px; color: var(--gold);
  font-family: Consolas, Monaco, monospace;
}
.brand-sub { font-size: 11px; color: var(--dim); letter-spacing: 1px; margin-top: 2px; }
.dash-link {
  color: var(--cyan); text-decoration: none; font-size: 13px;
  border: 1px solid rgba(38,198,218,0.35); border-radius: 6px;
  padding: 8px 14px; transition: background 0.15s;
  background: rgba(38,198,218,0.06);
}
.dash-link:hover { background: rgba(38,198,218,0.16); }

/* ── メイン2カラム ─────────────────────── */
main {
  flex: 1;
  display: grid; grid-template-columns: minmax(400px, 1fr) 1fr;
  gap: 16px; padding: 16px 22px;
  align-items: start;
}
@media (max-width: 980px) {
  main { grid-template-columns: 1fr; }
}

/* ── 映像パネル ─────────────────────── */
.video-panel {
  background: var(--panel);
  border: 1px solid var(--border); border-radius: 10px;
  padding: 14px 16px 12px;
  display: flex; flex-direction: column; gap: 10px;
}
.panel-head {
  display: flex; align-items: center; gap: 10px;
  font-size: 12px; letter-spacing: 3px; color: var(--dim);
  font-family: Consolas, Monaco, monospace;
}
.live-dot {
  width: 9px; height: 9px; border-radius: 50%;
  background: var(--red); box-shadow: 0 0 8px var(--red);
  animation: live-blink 1.6s ease-in-out infinite;
}
@keyframes live-blink { 50% { opacity: 0.35; } }
.video-meta { margin-left: auto; font-size: 12px; letter-spacing: 1px; }
.video-meta.ok   { color: var(--green); }
.video-meta.warn { color: var(--gold); }

.video-wrap {
  position: relative; align-self: flex-start;
  border: 2px solid var(--border-hi); border-radius: 6px;
  overflow: hidden; max-width: 100%; width: 100%;
  min-height: 220px;
  background: #000;
  transition: border-color 0.2s, box-shadow 0.2s;
}
/* カメラ映像が届くまでの待機表示（映像が来ると上に被さって隠れる） */
.video-wrap::before {
  content: "\\1F4F7  カメラ映像を待機しています...";
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  color: var(--dim); font-size: 14px; letter-spacing: 2px;
}
.video-wrap.editing {
  border-color: var(--gold);
  box-shadow: 0 0 18px rgba(255,176,0,0.35);
}
#video { display: block; width: 100%; height: auto; position: relative; }
#overlay {
  position: absolute; left: 0; top: 0; width: 100%; height: 100%;
}
.video-wrap.editing #overlay { cursor: crosshair; }
.mode-banner {
  position: absolute; top: 10px; left: 50%; transform: translateX(-50%);
  background: rgba(255,176,0,0.92); color: #1a1200;
  font-size: 12px; font-weight: 700; letter-spacing: 1px;
  padding: 6px 16px; border-radius: 20px;
  display: none; white-space: nowrap; pointer-events: none;
  box-shadow: 0 2px 10px rgba(0,0,0,0.5);
}
.video-wrap.editing .mode-banner { display: block; }

.status-bar {
  display: flex; align-items: center; gap: 10px;
  background: var(--panel2);
  border: 1px solid var(--border); border-radius: 6px;
  padding: 10px 14px; font-size: 13.5px; min-height: 42px;
}
#statusIcon { font-size: 12px; }
.st-ok   { color: var(--green); }
.st-err  { color: var(--red); }
.st-busy { color: var(--gold); }
.st-info { color: var(--cyan); }

/* ── 右カラム: 操作パネル ─────────────── */
.control-panel {
  display: grid; grid-template-columns: 1fr 1fr; gap: 14px;
  align-content: start;
}
@media (max-width: 1400px) {
  .control-panel { grid-template-columns: 1fr; }
}
/* 詳細設定カード（項目数が多い）は2カラムをまたいで横幅いっぱいに表示 */
.control-panel .card:nth-child(5) { grid-column: 1 / -1; }
/* 詳細設定カード内部も、広くなった横幅を活かして設定行を2カラムに */
.control-panel .card:nth-child(5) {
  display: grid; grid-template-columns: 1fr 1fr; gap: 4px 20px; align-content: start;
}
.control-panel .card:nth-child(5) .card-title,
.control-panel .card:nth-child(5) .btn-wide,
.control-panel .card:nth-child(5) .setting-row:last-of-type {
  grid-column: 1 / -1;
}
@media (max-width: 700px) {
  .control-panel .card:nth-child(5) { grid-template-columns: 1fr; }
}
.card {
  background: var(--panel);
  border: 1px solid var(--border); border-radius: 10px;
  padding: 14px 16px;
}
.card-title {
  display: flex; align-items: center; gap: 10px;
  font-size: 14px; font-weight: 700; letter-spacing: 1px;
  color: var(--text); margin-bottom: 8px;
}
.step {
  width: 22px; height: 22px; border-radius: 50%; flex-shrink: 0;
  background: var(--gold); color: #1a1200;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 700;
}
.card-desc {
  font-size: 12px; color: var(--dim); line-height: 1.7; margin-bottom: 12px;
}
.card-desc strong { color: #9fb4d4; font-weight: 600; }

/* 教示ボタン */
.teach-btns { display: flex; flex-direction: column; gap: 8px; }
.teach {
  display: flex; align-items: center; gap: 12px;
  width: 100%; padding: 12px 14px;
  background: var(--panel2); color: var(--text);
  border: 1px solid var(--border-hi); border-left-width: 5px;
  border-radius: 8px; cursor: pointer;
  font-size: 14px; font-weight: 600; font-family: inherit;
  transition: background 0.15s, transform 0.1s;
  text-align: left;
}
.teach:hover { background: #16233c; }
.teach:active { transform: scale(0.98); }
.teach:disabled { opacity: 0.45; cursor: wait; }
.teach .sw { width: 18px; height: 18px; border-radius: 4px; flex-shrink: 0; }
.teach .en { margin-left: auto; font-size: 10.5px; color: var(--dim); letter-spacing: 1px; font-family: Consolas, monospace; }
.teach.red   { border-left-color: var(--red); }
.teach.red   .sw { background: var(--red);   box-shadow: 0 0 8px rgba(255,82,82,0.6); }
.teach.green { border-left-color: var(--green); }
.teach.green .sw { background: var(--green); box-shadow: 0 0 8px rgba(70,217,95,0.6); }
.teach.blue  { border-left-color: var(--blue); }
.teach.blue  .sw { background: var(--blue);  box-shadow: 0 0 8px rgba(68,138,255,0.6); }

/* 汎用ボタン */
.btn-wide {
  display: block; width: 100%; padding: 12px 14px;
  background: var(--panel2); color: var(--text);
  border: 1px solid var(--border-hi); border-radius: 8px;
  cursor: pointer; font-size: 13.5px; font-weight: 600; font-family: inherit;
  transition: background 0.15s, border-color 0.15s;
}
.btn-wide:hover { background: #16233c; }
.btn-wide.active {
  background: rgba(255,176,0,0.12);
  border-color: var(--gold); color: var(--gold);
}
.btn-wide.danger { border-color: rgba(255,82,82,0.4); color: #ff8a8a; }
.btn-wide.danger:hover { background: rgba(255,82,82,0.1); }

/* 詳細設定 行 */
.setting-row {
  display: flex; align-items: center; gap: 8px; margin-bottom: 12px;
}
.setting-row label { font-size: 12.5px; color: var(--dim); flex: 1; line-height: 1.5; }
.setting-row input {
  width: 84px; padding: 8px 10px;
  background: #0a1120; color: var(--text);
  border: 1px solid var(--border-hi); border-radius: 6px;
  font-size: 14px; text-align: right; font-family: Consolas, monospace;
}
.setting-row input:focus { outline: none; border-color: var(--cyan); }
/* label幅の広い項目（select等）は横並びにせず縦に積む */
.setting-row-stacked {
  display: flex; flex-direction: column; gap: 6px; margin-bottom: 12px;
}
.setting-row-stacked label { font-size: 12.5px; color: var(--dim); line-height: 1.5; }
.setting-row-stacked select {
  width: 100%; padding: 8px 10px; box-sizing: border-box;
  background: #0a1120; color: var(--text);
  border: 1px solid var(--border-hi); border-radius: 6px;
  font-size: 13px; font-family: Consolas, monospace;
}
.setting-row-stacked select:focus { outline: none; border-color: var(--cyan); }
.btn-mini {
  padding: 8px 14px;
  background: rgba(38,198,218,0.08); color: var(--cyan);
  border: 1px solid rgba(38,198,218,0.35); border-radius: 6px;
  cursor: pointer; font-size: 12.5px; font-weight: 600; font-family: inherit;
}
.btn-mini:hover { background: rgba(38,198,218,0.18); }

/* 教示領域リスト */
.region-list { display: flex; flex-direction: column; gap: 6px; }
.region-empty { font-size: 12px; color: var(--dim); padding: 4px 2px; line-height: 1.6; }
.region-row {
  display: flex; align-items: center; gap: 10px;
  background: var(--panel2); border: 1px solid var(--border-hi);
  border-radius: 8px; padding: 8px 12px; font-size: 13px;
  transition: border-color 0.15s, background 0.15s;
}
.region-row.hover { border-color: var(--red); background: rgba(255,82,82,0.08); }
.region-num {
  width: 24px; height: 24px; border-radius: 50%; flex-shrink: 0;
  background: rgba(38,198,218,0.15); border: 1px solid var(--cyan); color: var(--cyan);
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 700;
}
.region-meta { flex: 1; color: var(--dim); font-size: 12px; }
.btn-del {
  padding: 6px 14px;
  background: rgba(255,82,82,0.08); color: #ff8a8a;
  border: 1px solid rgba(255,82,82,0.4); border-radius: 6px;
  cursor: pointer; font-size: 12px; font-weight: 600; font-family: inherit;
}
.btn-del:hover { background: rgba(255,82,82,0.2); }

/* ── フッター ─────────────────────── */
footer {
  padding: 10px 22px;
  border-top: 1px solid var(--border);
  font-size: 11.5px; color: var(--dim); letter-spacing: 1px;
  display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px;
}
kbd {
  background: var(--panel2); border: 1px solid var(--border-hi);
  border-radius: 4px; padding: 1px 6px; font-size: 10.5px;
  font-family: Consolas, monospace; color: #9fb4d4;
}
</style>
</head>
<body>

<header>
  <div class="brand">
    <div class="brand-icon">&#x1F4F7;</div>
    <div>
      <div class="brand-title">CHROMATEACH&reg; CAMERA SETUP</div>
      <div class="brand-sub">Flight_Status_Board Ver 5.0 &mdash; 検知エリア教示ツール (Port 5001)</div>
    </div>
  </div>
  <a class="dash-link" id="dashLink" href="#">&#x1F4CA; ダッシュボードへ &rarr;</a>
</header>

<main>
  <!-- 左: ライブ映像 -->
  <section class="video-panel">
    <div class="panel-head">
      <span class="live-dot"></span> LIVE VIEW
      <span class="video-meta" id="roiSummary">--</span>
    </div>
    <div class="video-wrap" id="wrap">
      <img id="video" src="/video_feed" alt="Camera stream" />
      <canvas id="overlay"></canvas>
      <div class="mode-banner">&#x270F; ドラッグで検知範囲を指定 &nbsp;(Esc で解除)</div>
    </div>
    <div class="status-bar">
      <span id="statusIcon" class="st-ok">&#x25CF;</span>
      <span id="statusText">準備完了 &mdash; 黄色い枠が現在の検知エリアです</span>
    </div>
  </section>

  <!-- 右: 操作パネル -->
  <aside class="control-panel">

    <section class="card">
      <div class="card-title"><span class="step">1</span>色シートで教示する</div>
      <p class="card-desc">
        検知したい場所（排出口・可動部など）に<strong>専用色シート</strong>を貼り、
        シートと同じ色のボタンを押すと検知エリアが自動設定されます。
      </p>
      <div class="teach-btns">
        <button class="teach red"   onclick="autoDetect('red')"><span class="sw"></span>赤シートで教示<span class="en">RED [R]</span></button>
        <button class="teach green" onclick="autoDetect('green')"><span class="sw"></span>緑シートで教示<span class="en">GREEN [G]</span></button>
        <button class="teach blue"  onclick="autoDetect('blue')"><span class="sw"></span>青シートで教示<span class="en">BLUE [B]</span></button>
      </div>
    </section>

    <section class="card">
      <div class="card-title"><span class="step">2</span>不要な領域を削除する</div>
      <p class="card-desc">
        反射や別の色物まで検出された場合は、<strong>映像上の番号バッジをタップ</strong>するか、
        下のリストの「削除」で不要な領域を取り除けます。<br>
        確認できたら<strong>色シートを撤去</strong>してください（検知エリアは保持されます）。
      </p>
      <div class="region-list" id="regionList"></div>
    </section>

    <section class="card">
      <div class="card-title">&#x270F; 手動で範囲を指定（オプション）</div>
      <p class="card-desc">色シートを使わずに、映像の上をドラッグして検知範囲の四角形を直接指定することもできます。</p>
      <button id="btnManual" class="btn-wide" onclick="toggleEdit()">&#x270F; 手動指定モード [M]</button>
    </section>

    <section class="card">
      <div class="card-title">&#x1F4F7; カメラデバイス</div>
      <div class="setting-row-stacked">
        <label>使用するカメラ（USB切断・再認識等でカメラが開けなくなった場合、ここで選び直せます）</label>
        <select id="cameraDeviceSelect"></select>
      </div>
      <div class="setting-row">
        <label></label>
        <button class="btn-mini" onclick="refreshCameraDevices()">一覧を更新</button>
        <button class="btn-mini" onclick="saveCameraDevice()">この端末を保存して再オープン</button>
      </div>
      <div style="font-size:12px;color:#777;margin-top:-4px;" id="camera-device-result"></div>
    </section>

    <section class="card">
      <div class="card-title">&#x2699; 詳細設定</div>
      <div class="setting-row">
        <label>最小検知面積 (px&sup2;)<br>これより小さい色領域はノイズとして無視します</label>
        <input type="number" id="areaInput" min="0" step="100" value="500">
      </div>
      <div class="setting-row">
        <label>動体検知の閾値 (px&sup2;)<br>フレーム間の変化量がこれ以上で「動きあり」と判定します</label>
        <input type="number" id="motionAreaInput" min="0" step="100" value="300">
      </div>
      <div class="setting-row">
        <label>最低継続フレーム数<br>この回数だけ連続で動きが続いたら検知確定します</label>
        <input type="number" id="holdFramesInput" min="1" step="1" value="5">
      </div>
      <div class="setting-row">
        <label>検知終了までの猶予フレーム数<br>この回数だけ連続で動きがなくなったら検知を解除します</label>
        <input type="number" id="exitFramesInput" min="1" step="1" value="10">
      </div>
      <div class="setting-row">
        <label></label>
        <button class="btn-mini" onclick="saveMotionSettings()">保存</button>
      </div>
      <button class="btn-wide danger" onclick="clearROI()">&#x1F5D1; 検知エリアをクリア（全画面に戻す）</button>
    </section>

  </aside>
</main>

<footer>
  <span>ショートカット: <kbd>R</kbd> 赤教示 &nbsp;<kbd>G</kbd> 緑教示 &nbsp;<kbd>B</kbd> 青教示 &nbsp;<kbd>M</kbd> 手動指定 &nbsp;<kbd>Esc</kbd> 解除</span>
  <span>Chromateach&reg; by Nissho Elektron</span>
</footer>

<script>
const video     = document.getElementById("video");
const wrap      = document.getElementById("wrap");
const canvas    = document.getElementById("overlay");
const ctx       = canvas.getContext("2d");
const statusIcon = document.getElementById("statusIcon");
const statusText = document.getElementById("statusText");
const btnManual  = document.getElementById("btnManual");
const roiSummary = document.getElementById("roiSummary");
const areaInput  = document.getElementById("areaInput");
const motionAreaInput = document.getElementById("motionAreaInput");
const holdFramesInput = document.getElementById("holdFramesInput");
const exitFramesInput = document.getElementById("exitFramesInput");
const cameraDeviceSelect = document.getElementById("cameraDeviceSelect");
const cameraDeviceResult = document.getElementById("camera-device-result");

let editMode   = false;
let dragging   = false;
let startX = 0, startY = 0;
let currentRect = null;
let regions     = [];   /* 教示済み領域 {index, points, bbox} */
let hoverRegion = -1;

/* ダッシュボードへのリンク（同一ホストのポート5000） */
document.getElementById("dashLink").href =
  location.protocol + "//" + location.hostname + ":5000/";

/* キャンバスをビデオサイズに合わせる */
function resizeCanvas() {
  canvas.width  = video.clientWidth;
  canvas.height = video.clientHeight;
  draw();
}
video.addEventListener("load", resizeCanvas);
window.addEventListener("resize", resizeCanvas);
setTimeout(resizeCanvas, 800);

/* ステータス表示 */
function setStatus(msg, kind) {
  kind = kind || "info";
  const map = { ok: "st-ok", err: "st-err", busy: "st-busy", info: "st-info" };
  statusIcon.className = map[kind] || "st-info";
  statusText.textContent = msg;
}

/* 現在のROI設定状態を取得して表示 */
async function loadInfo(updateArea) {
  try {
    const res = await fetch("/api/roi_info");
    const d = await res.json();
    if (d.status !== "success") return;
    if (updateArea) areaInput.value = d.area_limit_min;
    if (updateArea && d.motion_area_threshold !== undefined) motionAreaInput.value = d.motion_area_threshold;
    if (updateArea && d.camera_hold_frames !== undefined)    holdFramesInput.value = d.camera_hold_frames;
    if (updateArea && d.exit_frames_threshold !== undefined) exitFramesInput.value = d.exit_frames_threshold;
    if (d.contour_count > 0) {
      roiSummary.textContent = "検知エリア: " + d.contour_count + " 領域（教示済み）";
      roiSummary.className = "video-meta ok";
    } else if (d.is_fullscreen) {
      roiSummary.textContent = "検知エリア: 全画面（未設定）";
      roiSummary.className = "video-meta warn";
    } else {
      roiSummary.textContent = "検知エリア: 手動指定の矩形";
      roiSummary.className = "video-meta ok";
    }
  } catch (e) { /* ignore */ }
}
loadInfo(true);
refreshCameraDevices();

/* ── カメラデバイス選択 ───────────────── */
async function refreshCameraDevices() {
  try {
    const res = await fetch("/api/list_camera_devices");
    const data = await res.json();
    if (!res.ok || data.status !== "success") {
      cameraDeviceResult.style.color = "#ff5252";
      cameraDeviceResult.textContent = "一覧の取得に失敗しました";
      return;
    }
    cameraDeviceSelect.innerHTML = "";
    const current = String(data.current ?? "");
    let matched = false;
    (data.devices || []).forEach((d) => {
      const opt = document.createElement("option");
      opt.value = d.value;
      opt.textContent = d.label;
      if (d.value === current) { opt.selected = true; matched = true; }
      cameraDeviceSelect.appendChild(opt);
    });
    let note = "";
    if (!matched && current !== "") {
      // 現在の設定値（過去バージョンの長いパス指定等）が今回の一覧に
      // 見当たらない場合は、候補の先頭（通常は唯一のカメラ）を初期選択し、
      // 単純な番号指定への切り替えを促す。
      const opt = document.createElement("option");
      opt.value = current;
      opt.textContent = `${current}（現在の設定・一覧外の形式）`;
      cameraDeviceSelect.appendChild(opt);

      if ((data.devices || []).length > 0) {
        cameraDeviceSelect.value = data.devices[0].value;
        note = `現在の設定（${current}）は今回の番号方式と一致しません。`
             + `候補を選択済みにしています。問題なければ「保存して再オープン」を押してください。`;
      } else {
        opt.selected = true;
        note = "現在の設定が候補一覧に見つかりません。カメラの接続状態を確認するか、候補から選び直してください。";
      }
    }
    if ((data.devices || []).length === 0) {
      cameraDeviceResult.style.color = "#ff5252";
      cameraDeviceResult.textContent = "カメラデバイスが見つかりません";
    } else if (note) {
      cameraDeviceResult.style.color = "#e0a030";
      cameraDeviceResult.textContent = `${data.devices.length}台検出　${note}`;
    } else {
      cameraDeviceResult.style.color = "#777";
      cameraDeviceResult.textContent = `${data.devices.length}台検出`;
    }
  } catch (e) {
    cameraDeviceResult.style.color = "#ff5252";
    cameraDeviceResult.textContent = "一覧の取得に失敗しました（通信エラー）";
  }
}

async function saveCameraDevice() {
  const device = cameraDeviceSelect.value;
  if (!device) {
    cameraDeviceResult.style.color = "#ff5252";
    cameraDeviceResult.textContent = "デバイスを選択してください";
    return;
  }
  cameraDeviceResult.style.color = "#777";
  cameraDeviceResult.textContent = "保存・再オープン中...";
  try {
    const res = await fetch("/api/set_camera_device", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ device }),
    });
    const data = await res.json();
    if (!res.ok || data.status !== "success") {
      cameraDeviceResult.style.color = "#ff5252";
      cameraDeviceResult.textContent = data.message || "保存に失敗しました";
      return;
    }
    if (data.opened === true) {
      cameraDeviceResult.style.color = "var(--led-green)";
      cameraDeviceResult.textContent = "保存しました。カメラのオープンに成功しました。";
    } else if (data.opened === false) {
      cameraDeviceResult.style.color = "#ff5252";
      cameraDeviceResult.textContent = "保存しましたが、カメラのオープンに失敗しました。";
    } else {
      cameraDeviceResult.style.color = "#e0a030";
      cameraDeviceResult.textContent = "保存しました（再オープン機能未接続のためアプリ再起動が必要な場合があります）。";
    }
  } catch (e) {
    cameraDeviceResult.style.color = "#ff5252";
    cameraDeviceResult.textContent = "保存に失敗しました（通信エラー）";
  }
}

/* ── 教示領域の一覧・削除 ───────────────── */
async function loadRegions() {
  try {
    const res = await fetch("/api/regions");
    const d = await res.json();
    regions = (d.status === "success") ? d.regions : [];
  } catch (e) { regions = []; }
  hoverRegion = -1;
  renderRegionList();
  draw();
}

function renderRegionList() {
  const list = document.getElementById("regionList");
  if (!regions.length) {
    list.innerHTML = '<div class="region-empty">教示済みの領域はありません。教示を行うと候補がここに表示され、不要なものを削除できます。</div>';
    return;
  }
  list.innerHTML = "";
  regions.forEach((rg, i) => {
    const bw = rg.bbox[2], bh = rg.bbox[3];
    const pct = bw * bh * 100;
    const row = document.createElement("div");
    row.className = "region-row";
    row.innerHTML = '<span class="region-num">' + (i + 1) + '</span>' +
      '<span class="region-meta">画面の約 ' + (pct < 0.1 ? "0.1未満" : pct.toFixed(1)) + '%</span>';
    const btn = document.createElement("button");
    btn.className = "btn-del";
    btn.textContent = "削除";
    btn.onclick = () => deleteRegion(rg.index);
    row.appendChild(btn);
    row.addEventListener("mouseenter", () => { hoverRegion = i; row.classList.add("hover"); draw(); });
    row.addEventListener("mouseleave", () => { hoverRegion = -1; row.classList.remove("hover"); draw(); });
    list.appendChild(row);
  });
}

async function deleteRegion(i) {
  if (!confirm("領域 " + (i + 1) + " を削除しますか？")) return;
  try {
    const res = await fetch("/api/delete_region", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ index: i }),
    });
    const data = await res.json();
    if (res.ok) {
      setStatus("領域 " + (i + 1) + " を削除しました（残り " + data.remaining + " 領域）", "ok");
      loadRegions();
      loadInfo();
    } else {
      setStatus(data.message || "削除に失敗しました", "err");
    }
  } catch (e) {
    setStatus("削除に失敗しました（通信エラー）", "err");
  }
}

/* ポリゴン内判定（レイキャスティング法） */
function pointInPoly(nx, ny, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i][0], yi = pts[i][1];
    const xj = pts[j][0], yj = pts[j][1];
    if (((yi > ny) !== (yj > ny)) &&
        (nx < (xj - xi) * (ny - yi) / (yj - yi) + xi)) inside = !inside;
  }
  return inside;
}

/* キャンバス座標から領域番号を返す（バッジ円もヒット対象） */
function regionAt(x, y) {
  for (let i = 0; i < regions.length; i++) {
    const b = regions[i].bbox;
    const cx = (b[0] + b[2] / 2) * canvas.width;
    const cy = (b[1] + b[3] / 2) * canvas.height;
    if (Math.hypot(x - cx, y - cy) <= 18) return regions[i].index;
    if (pointInPoly(x / canvas.width, y / canvas.height, regions[i].points)) return regions[i].index;
  }
  return -1;
}
loadRegions();

/* ── 手動ROIモード ───────────────────── */
function toggleEdit(force) {
  editMode = (force !== undefined) ? force : !editMode;
  dragging = false;
  currentRect = null;
  draw();
  btnManual.classList.toggle("active", editMode);
  wrap.classList.toggle("editing", editMode);
  if (editMode) {
    setStatus("手動指定モード: 映像の上をドラッグして検知範囲を指定してください", "busy");
  } else {
    setStatus("手動指定モードを終了しました", "info");
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  /* 教示領域: 半透明ハイライト＋番号バッジ（タップで削除） */
  if (!editMode) {
    regions.forEach((rg, i) => {
      const pts = rg.points.map(p => [p[0] * canvas.width, p[1] * canvas.height]);
      if (!pts.length) return;
      const hovered = (i === hoverRegion);
      ctx.beginPath();
      ctx.moveTo(pts[0][0], pts[0][1]);
      for (let j = 1; j < pts.length; j++) ctx.lineTo(pts[j][0], pts[j][1]);
      ctx.closePath();
      ctx.fillStyle = hovered ? "rgba(255,82,82,0.35)" : "rgba(38,198,218,0.12)";
      ctx.fill();
      /* 番号バッジ（領域中心） */
      const b = rg.bbox;
      const cx = (b[0] + b[2] / 2) * canvas.width;
      const cy = (b[1] + b[3] / 2) * canvas.height;
      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.fillStyle = hovered ? "rgba(255,82,82,0.95)" : "rgba(7,20,40,0.85)";
      ctx.fill();
      ctx.strokeStyle = hovered ? "#ff5252" : "#26c6da";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = hovered ? "#fff" : "#26c6da";
      ctx.font = "bold 14px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(i + 1), cx, cy);
    });
  }

  /* 手動指定のドラッグ矩形 */
  if (currentRect) {
    ctx.fillStyle = "rgba(255,176,0,0.15)";
    ctx.fillRect(currentRect.x, currentRect.y, currentRect.w, currentRect.h);
    ctx.strokeStyle = "#ffb000";
    ctx.lineWidth   = 2;
    ctx.strokeRect(currentRect.x, currentRect.y, currentRect.w, currentRect.h);
  }
}

function pointerPos(e) {
  const r = canvas.getBoundingClientRect();
  const src = e.touches ? e.touches[0] : e;
  return { x: src.clientX - r.left, y: src.clientY - r.top };
}

function dragStart(e) {
  if (!editMode) return;
  if (e.touches) e.preventDefault();
  const p = pointerPos(e);
  startX = p.x; startY = p.y;
  dragging = true;
  currentRect = { x: startX, y: startY, w: 0, h: 0 };
  draw();
}

function dragMove(e) {
  if (!editMode || !dragging) return;
  if (e.touches) e.preventDefault();
  const p = pointerPos(e);
  currentRect = {
    x: Math.min(startX, p.x),
    y: Math.min(startY, p.y),
    w: Math.abs(p.x - startX),
    h: Math.abs(p.y - startY),
  };
  draw();
}

async function dragEnd() {
  if (!editMode || !dragging || !currentRect) return;
  dragging = false;
  if (currentRect.w < 5 || currentRect.h < 5) {
    setStatus("範囲が小さすぎます。もう少し大きくドラッグしてください", "err");
    return;
  }
  const rx = currentRect.x / canvas.width;
  const ry = currentRect.y / canvas.height;
  const rw = currentRect.w / canvas.width;
  const rh = currentRect.h / canvas.height;
  try {
    const res  = await fetch("/api/set_roi", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roi: [rx, ry, rw, rh] }),
    });
    const data = await res.json();
    if (res.ok) {
      toggleEdit(false);
      setStatus("検知範囲を保存しました", "ok");
      loadInfo();
      loadRegions();
    } else {
      setStatus(data.message || "保存に失敗しました", "err");
    }
  } catch (e) {
    setStatus("保存に失敗しました（通信エラー）", "err");
  }
}

canvas.addEventListener("mousedown",  dragStart);
canvas.addEventListener("mousemove",  dragMove);
canvas.addEventListener("mouseup",    dragEnd);
canvas.addEventListener("touchstart", dragStart, { passive: false });
canvas.addEventListener("touchmove",  dragMove,  { passive: false });
canvas.addEventListener("touchend",   dragEnd);

/* 領域タップで削除（手動指定モード中は無効） */
canvas.addEventListener("click", (e) => {
  if (editMode) return;
  const p = pointerPos(e);
  const i = regionAt(p.x, p.y);
  if (i >= 0) deleteRegion(i);
});
/* ホバーで対象領域をハイライト（マウス操作時） */
canvas.addEventListener("mousemove", (e) => {
  if (editMode) return;
  const p = pointerPos(e);
  const i = regionAt(p.x, p.y);
  if (i !== hoverRegion) {
    hoverRegion = i;
    canvas.style.cursor = (i >= 0) ? "pointer" : "default";
    document.querySelectorAll(".region-row").forEach((r, j) => r.classList.toggle("hover", j === i));
    draw();
  }
});

/* ── 教示（自動カラー検出） ───────────── */
const COLOR_JP = { red: "赤", green: "緑", blue: "青" };

let detecting = false;

async function autoDetect(color) {
  if (detecting) return;   /* 多重タップ防止 */
  detecting = true;
  const btns = document.querySelectorAll(".teach");
  btns.forEach(b => b.disabled = true);
  setStatus(COLOR_JP[color] + "シートを検出しています...", "busy");
  try {
    const res  = await fetch("/api/auto_detect/" + color, { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      setStatus(COLOR_JP[color] + "シートを検出しました（" + data.count +
                " 領域）。不要な領域は番号をタップして削除し、シートを撤去してください", "ok");
      loadInfo();
      loadRegions();
    } else {
      setStatus(COLOR_JP[color] + "色の領域が見つかりません。シートの位置・照明を確認するか、最小検知面積を下げてください", "err");
    }
  } catch (e) {
    setStatus("検出に失敗しました（通信エラー）", "err");
  } finally {
    detecting = false;
    btns.forEach(b => b.disabled = false);
  }
}

/* ── クリア ─────────────────────────── */
async function clearROI() {
  if (!confirm("検知エリアをクリアして全画面に戻しますか？")) return;
  try {
    const res  = await fetch("/api/clear_roi", { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      currentRect = null;
      setStatus("検知エリアをクリアしました（全画面）", "ok");
      loadInfo();
      loadRegions();
    } else {
      setStatus(data.message || "クリアに失敗しました", "err");
    }
  } catch (e) {
    setStatus("クリアに失敗しました（通信エラー）", "err");
  }
}

/* ── 最小検知面積 ───────────────────── */
/* ── 検知設定の一括保存（最小検知面積・動体検知閾値・最低継続フレーム数） ── */
async function saveMotionSettings() {
  const al = parseInt(areaInput.value);
  const at = parseInt(motionAreaInput.value);
  const hf = parseInt(holdFramesInput.value);
  const ef = parseInt(exitFramesInput.value);
  if (isNaN(al) || al < 0) {
    setStatus("最小検知面積には0以上の数値を入力してください", "err");
    return;
  }
  if (isNaN(at) || at < 0) {
    setStatus("動体検知の閾値には0以上の数値を入力してください", "err");
    return;
  }
  if (isNaN(hf) || hf < 1) {
    setStatus("最低継続フレーム数には1以上の数値を入力してください", "err");
    return;
  }
  if (isNaN(ef) || ef < 1) {
    setStatus("検知終了までの猶予フレーム数には1以上の数値を入力してください", "err");
    return;
  }
  try {
    const res  = await fetch("/api/set_motion_settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ area_limit_min: al, area_threshold: at, hold_frames: hf, exit_frames: ef }),
    });
    const data = await res.json();
    if (res.ok) {
      setStatus("検知設定を保存しました", "ok");
    } else {
      setStatus(data.message || "保存に失敗しました", "err");
    }
  } catch (e) {
    setStatus("保存に失敗しました（通信エラー）", "err");
  }
}

/* ── キーボードショートカット ───────────── */
document.addEventListener("keydown", (e) => {
  if (e.target.tagName === "INPUT") return;
  const k = e.key.toLowerCase();
  if (k === "r") autoDetect("red");
  if (k === "g") autoDetect("green");
  if (k === "b") autoDetect("blue");
  if (k === "m") toggleEdit();
  if (k === "escape" && editMode) toggleEdit(false);
});
</script>
</body>
</html>
"""
